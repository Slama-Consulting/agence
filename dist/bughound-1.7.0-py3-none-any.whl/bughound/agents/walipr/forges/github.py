"""Client GitHub REST pour WaliPR (P7.5).

Endpoints utilisés :

- ``GET /repos/{owner}/{repo}/pulls/{number}`` (Accept: JSON) →
  metadata (title, body, head/base ref, head sha, html_url).
- ``GET /repos/{owner}/{repo}/pulls/{number}`` (Accept:
  ``application/vnd.github.diff``) → diff unifié complet en une
  seule requête (déjà avec headers ``diff --git``).
- ``POST /repos/{owner}/{repo}/issues/{number}/comments`` →
  commentaire général sur la PR (côté API, une PR est une issue).

Auth : header ``Authorization: token <PAT>`` (compatible avec les
fine-grained tokens via ``Authorization: Bearer ...``, on garde
``token`` pour rester compat avec les classic PAT).
"""

from __future__ import annotations

from typing import Any, Optional

import httpx

from .base import ForgeClient, MergeRequestData, PostCommentResult
from .errors import ForgeAPIError, ForgeAuthError, ForgeNotFoundError
from .url import ForgeRef


_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


class GitHubForgeClient(ForgeClient):
    """Client REST GitHub utilisé par WaliPR P7.

    Args:
        token: Personal Access Token (scope ``repo`` minimum pour les
            repos privés ; ``public_repo`` suffit pour les publics).
        transport: Transport ``httpx`` optionnel (tests).
        timeout: Timeout HTTP. Default 30 s.
    """

    def __init__(
        self,
        token: str,
        *,
        transport: Optional[httpx.BaseTransport] = None,
        timeout: httpx.Timeout = _DEFAULT_TIMEOUT,
    ) -> None:
        self._token = token
        self._transport = transport
        self._timeout = timeout

    # ------------------------------------------------------------------
    # ForgeClient interface
    # ------------------------------------------------------------------

    def fetch_mr(self, ref: ForgeRef) -> MergeRequestData:
        with self._make_client(ref.api_base) as http:
            metadata = self._get_pr_json(http, ref)
            diff_text = self._get_pr_diff(http, ref)

        head = metadata.get("head") or {}
        base = metadata.get("base") or {}
        return MergeRequestData(
            ref=ref,
            title=str(metadata.get("title") or ""),
            description=str(metadata.get("body") or ""),
            source_branch=str(head.get("ref") or ""),
            target_branch=str(base.get("ref") or ""),
            source_sha=str(head.get("sha") or ""),
            web_url=str(metadata.get("html_url") or ""),
            diff_unified=diff_text,
        )

    def post_comment(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/repos/{ref.project}/issues/{ref.iid}/comments",
                json={"body": body},
            )
        _raise_for_status(response)
        payload = response.json()
        return PostCommentResult(
            id=str(payload.get("id", "")),
            url=str(payload.get("html_url") or ""),
        )

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _make_client(self, base_url: str) -> httpx.Client:
        return httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"token {self._token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "WaliPR/1.7",
            },
            timeout=self._timeout,
            transport=self._transport,
        )

    def _get_pr_json(
        self, http: httpx.Client, ref: ForgeRef,
    ) -> dict[str, Any]:
        response = http.get(
            f"/repos/{ref.project}/pulls/{ref.iid}",
        )
        _raise_for_status(response)
        data = response.json()
        if not isinstance(data, dict):
            raise ForgeAPIError(
                "Unexpected GitHub PR payload (not a dict)"
            )
        return data

    def _get_pr_diff(
        self, http: httpx.Client, ref: ForgeRef,
    ) -> str:
        response = http.get(
            f"/repos/{ref.project}/pulls/{ref.iid}",
            headers={"Accept": "application/vnd.github.diff"},
        )
        _raise_for_status(response)
        return response.text


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _raise_for_status(response: httpx.Response) -> None:
    code = response.status_code
    if 200 <= code < 300:
        return
    text = response.text[:200] if response.text else ""
    if code in (401, 403):
        raise ForgeAuthError(f"GitHub auth failed ({code}): {text}")
    if code == 404:
        raise ForgeNotFoundError(f"GitHub resource not found: {text}")
    raise ForgeAPIError(f"GitHub API error ({code}): {text}")


__all__ = ["GitHubForgeClient"]
