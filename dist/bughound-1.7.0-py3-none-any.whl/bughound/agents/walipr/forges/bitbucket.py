"""Client Bitbucket Cloud + Server pour WaliPR (P7.6).

Une seule classe :class:`BitbucketForgeClient` qui dispatch sur la
variante (Cloud / Server) en fonction du :class:`ForgeKind` du
:class:`ForgeRef` reçu — les paths et payloads sont totalement
différents entre les deux, mais le contrat ``ForgeClient`` reste
homogène vu de l'extérieur.

**Cloud** (api.bitbucket.org/2.0) :

- ``GET /repositories/{ws}/{repo}/pullrequests/{id}`` — metadata.
- ``GET /repositories/{ws}/{repo}/pullrequests/{id}/diff`` —
  diff unifié brut (text/plain).
- ``POST /repositories/{ws}/{repo}/pullrequests/{id}/comments`` —
  payload ``{"content": {"raw": "..."}}``.

**Server** (rest/api/1.0) :

- ``GET /projects/{KEY}/repos/{slug}/pull-requests/{id}`` — metadata.
- ``GET /projects/{KEY}/repos/{slug}/pull-requests/{id}.diff`` —
  diff unifié brut.
- ``POST /projects/{KEY}/repos/{slug}/pull-requests/{id}/comments`` —
  payload ``{"text": "..."}``.

Auth dans les deux cas : header ``Authorization: Bearer <token>``.
Pour Cloud, l'utilisateur peut soit utiliser un Workspace token, soit
un App Password — les deux fonctionnent en Bearer.
"""

from __future__ import annotations

from typing import Any, Optional

import httpx

from .base import ForgeClient, MergeRequestData, PostCommentResult
from .errors import ForgeAPIError, ForgeAuthError, ForgeNotFoundError
from .url import ForgeKind, ForgeRef


_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


class BitbucketForgeClient(ForgeClient):
    """Client REST Bitbucket Cloud + Server."""

    def __init__(
        self,
        token: str,
        *,
        transport: Optional[httpx.BaseTransport] = None,
        timeout: httpx.Timeout = _DEFAULT_TIMEOUT,
    ) -> None:
        self._token = token
        self._transport = transport
        self._timeout = timeout

    # ------------------------------------------------------------------
    # ForgeClient interface
    # ------------------------------------------------------------------

    def fetch_mr(self, ref: ForgeRef) -> MergeRequestData:
        if ref.kind is ForgeKind.BITBUCKET_CLOUD:
            return self._fetch_cloud(ref)
        if ref.kind is ForgeKind.BITBUCKET_SERVER:
            return self._fetch_server(ref)
        raise ValueError(
            f"BitbucketForgeClient does not support kind {ref.kind!r}"
        )

    def post_comment(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        if ref.kind is ForgeKind.BITBUCKET_CLOUD:
            return self._post_cloud(ref, body)
        if ref.kind is ForgeKind.BITBUCKET_SERVER:
            return self._post_server(ref, body)
        raise ValueError(
            f"BitbucketForgeClient does not support kind {ref.kind!r}"
        )

    # ------------------------------------------------------------------
    # Cloud
    # ------------------------------------------------------------------

    def _fetch_cloud(self, ref: ForgeRef) -> MergeRequestData:
        ws, _, repo = ref.project.partition("/")
        with self._make_client(ref.api_base) as http:
            metadata = self._get_json(
                http,
                f"/repositories/{ws}/{repo}/pullrequests/{ref.iid}",
            )
            diff_text = self._get_text(
                http,
                f"/repositories/{ws}/{repo}/pullrequests/{ref.iid}/diff",
            )

        source = metadata.get("source") or {}
        destination = metadata.get("destination") or {}
        src_branch = (source.get("branch") or {}).get("name") or ""
        src_sha = (source.get("commit") or {}).get("hash") or ""
        tgt_branch = (destination.get("branch") or {}).get("name") or ""
        web_url = (
            ((metadata.get("links") or {}).get("html") or {}).get("href")
            or ""
        )
        return MergeRequestData(
            ref=ref,
            title=str(metadata.get("title") or ""),
            description=str(metadata.get("description") or ""),
            source_branch=str(src_branch),
            target_branch=str(tgt_branch),
            source_sha=str(src_sha),
            web_url=str(web_url),
            diff_unified=diff_text,
        )

    def _post_cloud(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        ws, _, repo = ref.project.partition("/")
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/repositories/{ws}/{repo}/pullrequests/{ref.iid}/comments",
                json={"content": {"raw": body}},
            )
        _raise_for_status(response)
        payload = response.json()
        url = ""
        try:
            url = (
                ((payload.get("links") or {}).get("html") or {}).get("href")
                or ""
            )
        except AttributeError:
            url = ""
        return PostCommentResult(
            id=str(payload.get("id", "")), url=str(url),
        )

    # ------------------------------------------------------------------
    # Server
    # ------------------------------------------------------------------

    def _fetch_server(self, ref: ForgeRef) -> MergeRequestData:
        key, _, slug = ref.project.partition("/")
        path = (
            f"/projects/{key}/repos/{slug}/pull-requests/{ref.iid}"
        )
        with self._make_client(ref.api_base) as http:
            metadata = self._get_json(http, path)
            diff_text = self._get_text(http, path + ".diff")

        from_ref = metadata.get("fromRef") or {}
        to_ref = metadata.get("toRef") or {}
        web_url = ""
        links = metadata.get("links") or {}
        self_links = links.get("self") or []
        if isinstance(self_links, list) and self_links:
            first = self_links[0]
            if isinstance(first, dict):
                web_url = str(first.get("href") or "")
        return MergeRequestData(
            ref=ref,
            title=str(metadata.get("title") or ""),
            description=str(metadata.get("description") or ""),
            source_branch=str(from_ref.get("displayId") or ""),
            target_branch=str(to_ref.get("displayId") or ""),
            source_sha=str(from_ref.get("latestCommit") or ""),
            web_url=web_url,
            diff_unified=diff_text,
        )

    def _post_server(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        key, _, slug = ref.project.partition("/")
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/projects/{key}/repos/{slug}"
                f"/pull-requests/{ref.iid}/comments",
                json={"text": body},
            )
        _raise_for_status(response)
        payload = response.json()
        return PostCommentResult(
            id=str(payload.get("id", "")), url="",
        )

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _make_client(self, base_url: str) -> httpx.Client:
        return httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Accept": "application/json",
                "User-Agent": "WaliPR/1.7",
            },
            timeout=self._timeout,
            transport=self._transport,
        )

    def _get_json(
        self, http: httpx.Client, path: str,
    ) -> dict[str, Any]:
        response = http.get(path)
        _raise_for_status(response)
        data = response.json()
        if not isinstance(data, dict):
            raise ForgeAPIError(
                f"Unexpected Bitbucket payload for {path}: "
                f"{type(data)!r}"
            )
        return data

    def _get_text(self, http: httpx.Client, path: str) -> str:
        response = http.get(
            path,
            headers={"Accept": "text/plain"},
        )
        _raise_for_status(response)
        return response.text


def _raise_for_status(response: httpx.Response) -> None:
    code = response.status_code
    if 200 <= code < 300:
        return
    text = response.text[:200] if response.text else ""
    if code in (401, 403):
        raise ForgeAuthError(f"Bitbucket auth failed ({code}): {text}")
    if code == 404:
        raise ForgeNotFoundError(f"Bitbucket resource not found: {text}")
    raise ForgeAPIError(f"Bitbucket API error ({code}): {text}")


__all__ = ["BitbucketForgeClient"]
