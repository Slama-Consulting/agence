"""Orchestrateur ``review_merge_request`` (P7.7).

Pipeline complet pour reviewer une MR/PR distante :

1. ``parse_mr_url(url)`` → :class:`ForgeRef` canonique.
2. :func:`resolve_token` → token (env var → alias → erreur explicite).
3. ``_build_forge_client(ref, token)`` → client REST (GitLab/GitHub/
   Bitbucket).
4. ``client.fetch_mr(ref)`` → :class:`MergeRequestData` (metadata +
   diff unifié).
5. Soft-fail :class:`DiffTooLargeError` si
   ``mr_data.diff_size_lines > max_diff_lines``.
6. ``parse_unified_diff`` → liste de :class:`FileDiff`.
7. ``review_diff(...)`` (réutilisation 1:1 de la chaîne P3-P6, cache
   inclus). La clé de cache englobe ``source_sha`` + ``canonical_url``
   pour invalidation automatique sur push.
8. Si ``post_comment=True`` → ``client.post_comment(rendered_summary)``
   (opt-in strict).

Le résultat (:class:`ReviewMergeRequestResult`) est sérialisable en
dict via :func:`result_to_dict` pour la sortie MCP.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Optional

from ...config import BugHoundConfig, load_config
from ...llm import LLMClient, build_llm_client
from .diff import parse_unified_diff
from .forges.auth import resolve_token
from .forges.base import ForgeClient, MergeRequestData
from .forges.bitbucket import BitbucketForgeClient
from .forges.errors import DiffTooLargeError
from .forges.github import GitHubForgeClient
from .forges.gitlab import GitLabForgeClient
from .forges.url import ForgeKind, ForgeRef, parse_mr_url
from .review import ReviewResult, review_diff


# Default partagé avec ``walipr/mcp_server.py``. Passer ``config``
# directement à :func:`review_merge_request` est préféré côté CLI :
# le chemin réel a déjà été résolu via ``_resolve_mcp_config_path``.
_DEFAULT_CONFIG_PATH = Path("config/config.yaml")


# Default seuil de protection contre les MR géantes (P7 cadrage).
DEFAULT_MAX_DIFF_LINES = 5000


@dataclass(frozen=True)
class ReviewMergeRequestResult:
    """Résultat de :func:`review_merge_request`.

    Attributes:
        review: Résultat brut de :func:`review_diff` (summary, score,
            findings, languages, cache_status).
        mr_data: Métadonnées + diff de la MR/PR (source_sha,
            target_branch, web_url…).
        comment_posted: ``True`` si un commentaire a été effectivement
            posté sur la forge (post_comment=True + succès API).
        comment_url: URL du commentaire posté (vide sinon).
    """

    review: ReviewResult
    mr_data: MergeRequestData
    comment_posted: bool = False
    comment_url: str = ""


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def review_merge_request(
    url: str,
    *,
    explicit_token: Optional[str] = None,
    model_name: Optional[str] = None,
    languages: Optional[Iterable[str]] = None,
    standards: Optional[str] = None,
    use_cache: bool = False,
    cache_root: Optional[Any] = None,
    post_comment: bool = False,
    max_diff_lines: int = DEFAULT_MAX_DIFF_LINES,
    forge_client: Optional[ForgeClient] = None,
    llm: Optional[LLMClient] = None,
    config: Optional[BugHoundConfig] = None,
) -> ReviewMergeRequestResult:
    """Review une MR/PR distante de bout en bout.

    Args:
        url: URL web de la MR/PR.
        explicit_token: Token forge explicite (court-circuite l'env).
        model_name: Nom du modèle LLM (utilisé pour la clé de cache et
            pour ``build_llm_client``). Si ``None``, on lit la config.
        languages: Override de langages (sinon auto-détection).
        standards: Texte de standards explicite (rétro-compat).
        use_cache: Active le cache LLM-skip P6 (clé inclut
            ``source_sha`` + ``canonical_url``).
        cache_root: Racine où stocker ``.walipr-cache/``. Défaut :
            ``Path.cwd()`` (cohérent avec le mode local).
        post_comment: Si ``True``, poste le résumé en commentaire sur
            la MR/PR après la revue.
        max_diff_lines: Limite douce sur la taille du diff. Si dépassé,
            lève :class:`DiffTooLargeError` avant l'appel LLM.
        forge_client: Override pour les tests (sinon construit via
            :func:`_build_forge_client`).
        llm: Override pour les tests (sinon construit via
            :func:`_build_llm`).

    Raises:
        UnsupportedForgeError: URL non supportée.
        MissingForgeTokenError: aucun token disponible.
        DiffTooLargeError: diff dépasse ``max_diff_lines``.
        ForgeAPIError: erreur réseau/HTTP côté forge.
    """
    ref = parse_mr_url(url)

    if forge_client is None:
        token = resolve_token(ref.kind, explicit_token=explicit_token)
        forge_client = _build_forge_client(ref, token)

    mr_data = forge_client.fetch_mr(ref)

    if mr_data.diff_size_lines > max_diff_lines:
        raise DiffTooLargeError(
            lines=mr_data.diff_size_lines, limit=max_diff_lines,
        )

    file_diffs = parse_unified_diff(mr_data.diff_unified)

    if llm is None:
        llm = _build_llm(model_name, config=config)

    review = review_diff(
        file_diffs,
        llm,
        standards=standards,
        languages=languages,
        cache_enabled=use_cache,
        repo_root=cache_root if use_cache else None,
        model_name=model_name if use_cache else None,
        diff_text=(
            _build_cache_diff_text(mr_data) if use_cache else None
        ),
    )

    comment_posted = False
    comment_url = ""
    if post_comment:
        body = _render_comment_body(review, mr_data)
        try:
            outcome = forge_client.post_comment(ref, body)
            comment_posted = True
            comment_url = outcome.url
        except Exception:
            # Le post est optionnel — on n'invalide pas la review si
            # l'API forge refuse (ex. token sans scope).
            comment_posted = False
            comment_url = ""

    return ReviewMergeRequestResult(
        review=review,
        mr_data=mr_data,
        comment_posted=comment_posted,
        comment_url=comment_url,
    )


# ---------------------------------------------------------------------------
# Helpers (testables et mockables)
# ---------------------------------------------------------------------------


def _build_forge_client(ref: ForgeRef, token: str) -> ForgeClient:
    """Construit le client REST adapté à la forge cible."""
    if ref.kind is ForgeKind.GITLAB:
        return GitLabForgeClient(token=token)
    if ref.kind is ForgeKind.GITHUB:
        return GitHubForgeClient(token=token)
    if ref.kind in (ForgeKind.BITBUCKET_CLOUD, ForgeKind.BITBUCKET_SERVER):
        return BitbucketForgeClient(token=token)
    raise ValueError(f"No forge client for kind {ref.kind!r}")


def _build_llm(
    model_name: Optional[str],
    *,
    config: Optional[BugHoundConfig] = None,
) -> LLMClient:
    """Construit un LLMClient via la config BugHound.

    Si ``config`` est fourni (cas standard depuis la CLI/MCP), on
    l'utilise directement. Sinon on charge le default — utile uniquement
    pour les tests qui passent un ``llm=...`` mocké et n'atteignent
    jamais cette branche.
    """
    cfg = config if config is not None else load_config(_DEFAULT_CONFIG_PATH)
    llm_cfg = cfg.llm
    return build_llm_client(
        mode=llm_cfg.mode,
        provider=llm_cfg.provider,
        model=model_name or llm_cfg.model,
        api_key=llm_cfg.api_key,
    )


def _build_cache_diff_text(mr_data: MergeRequestData) -> str:
    """Texte qui entre dans la clé de cache (P7.7).

    On préfixe le diff avec l'URL canonique + le SHA pour qu'un push
    sur la branche source invalide automatiquement le cache, même si
    le contenu du diff resterait coïncidemment identique.
    """
    return (
        f"# walipr-mr-cache-v1\n"
        f"# url={mr_data.ref.canonical_url}\n"
        f"# source_sha={mr_data.source_sha}\n"
        f"{mr_data.diff_unified}"
    )


def _render_comment_body(
    review: ReviewResult, mr_data: MergeRequestData,
) -> str:
    """Rend le résumé de revue en markdown pour la forge."""
    lines: list[str] = [
        "🐺 **WaliPR review** (by Slama Consulting)",
        "",
        review.summary or "(no summary)",
    ]
    if review.score is not None:
        lines.append("")
        lines.append(f"**Score** : {review.score:.2f} / 1.00")
    if review.findings:
        lines.append("")
        lines.append(f"**Findings** : {len(review.findings)}")
        for finding in review.findings[:10]:
            lines.append(
                f"- `{finding.file}:{finding.line}` "
                f"[{finding.severity}/{finding.category}] "
                f"{finding.message}"
            )
        if len(review.findings) > 10:
            lines.append(
                f"- … {len(review.findings) - 10} more (see full report)"
            )
    return "\n".join(lines)


def result_to_dict(
    result: ReviewMergeRequestResult,
) -> dict[str, Any]:
    """Sérialise un :class:`ReviewMergeRequestResult` pour la sortie MCP."""
    from dataclasses import asdict
    review = result.review
    out: dict[str, Any] = {
        "summary": review.summary,
        "score": review.score,
        "findings": [asdict(f) for f in review.findings],
        "languages_detected": list(review.languages),
        "mr": {
            "url": result.mr_data.ref.canonical_url,
            "title": result.mr_data.title,
            "source_branch": result.mr_data.source_branch,
            "target_branch": result.mr_data.target_branch,
            "source_sha": result.mr_data.source_sha,
            "diff_size_lines": result.mr_data.diff_size_lines,
        },
        "comment_posted": result.comment_posted,
        "comment_url": result.comment_url,
    }
    if review.cache_status is not None:
        out["cache_status"] = review.cache_status
    return out


__all__ = [
    "DEFAULT_MAX_DIFF_LINES",
    "ReviewMergeRequestResult",
    "result_to_dict",
    "review_merge_request",
]
