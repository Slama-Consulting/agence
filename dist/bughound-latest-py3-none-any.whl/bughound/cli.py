"""Command-line entry point: ``python -m bughound analyze PROJ-42``."""

from __future__ import annotations

import json
import logging
import os
import shutil
from pathlib import Path
from typing import Optional

import typer
from dotenv import load_dotenv
from rich.console import Console
from rich.logging import RichHandler

from . import __version__
from .analyzers import (
    AutoClarificationHandler,
    BestHandoffPayload,
    InteractiveClarificationHandler,
    MonolithicAnalyzer,
)
from .attachments import (
    AttachmentManager,
    CachingPasswordProvider,
    TerminalPasswordProvider,
)
from .attachments.handlers import ConfiguredHostEntry, build_default_registry
from .config import BugHoundConfig, load_config
from .jira_client import (
    JiraClient,
    WriteRefusedError,
    WriteResult,
    build_jira_client,
)
from .core.models import ResolvedProject as ResolvedProjectModel
from .llm import build_llm_client
from .logs import LogCorrelator, LogcatParser
from .pipeline import BugHoundPipeline
from .projects import CodebaseInspector, ProjectResolver
from .projects.resolver import ResolvedProject
from .reporter import write_report
from .video import OcrDetector, SceneChangeDetector, TesseractOcrEngine, VideoAnalyzer


def _to_model_resolved(r: ResolvedProject) -> ResolvedProjectModel:
    return ResolvedProjectModel(
        ticket_key=r.ticket_key,
        root=r.root,
        name=r.name,
        matched_on=r.matched_on,
        score=r.score,
    )


app = typer.Typer(
    help="BugHound — trace bugs from Jira tickets to logs and videos.",
    add_completion=False,
)
console = Console()


def _configure_logging(verbose: bool) -> None:
    # force=True so a second CLI invocation within the same process replaces
    # any handler inherited from a previous basicConfig call.
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(
            console=console,
            rich_tracebacks=True,
            show_path=False,
            markup=True,
        )],
        force=True,
    )
    # The CLI logs through the root logger indirectly (via modules); make sure
    # our own modules' loggers are at the requested level.
    logging.getLogger("bughound").setLevel(
        logging.DEBUG if verbose else logging.INFO
    )


def _build_video_analyzer(cfg: BugHoundConfig) -> Optional[VideoAnalyzer]:
    """Try to build a video analyzer. Fall back to ``None`` on missing deps."""
    scene = SceneChangeDetector(change_threshold=cfg.video.scene_change_threshold)

    engine = None
    try:
        engine = TesseractOcrEngine(
            tesseract_cmd=Path(cfg.video.tesseract_cmd) if cfg.video.tesseract_cmd else None,
        )
    except RuntimeError as exc:
        console.print(f"[yellow]OCR disabled: {exc}[/yellow]")

    ocr_detector = OcrDetector(engine) if engine is not None else None

    # Use with_defaults so the new DisplayTimeDetector is wired in too.
    return VideoAnalyzer.with_defaults(
        ocr_engine=engine,
        scene_detector=scene,
    ) if engine is not None else VideoAnalyzer(
        ocr_detector=ocr_detector, scene_detector=scene,
    )


def _load(
    config_path: Path,
    env_file: Optional[Path],
) -> BugHoundConfig:
    if env_file and env_file.exists():
        load_dotenv(env_file, override=False)
    return load_config(config_path)


def _build_jira(cfg: BugHoundConfig) -> JiraClient:
    return build_jira_client(
        mode=cfg.jira.mode,
        base_url=cfg.jira.base_url,
        email=cfg.jira.email,
        api_token=cfg.jira.api_token,
        browser_profile_dir=cfg.jira.browser_profile_dir,
        browser_headless_after_login=cfg.jira.browser_headless_after_login,
        write_allowed_projects=cfg.jira.write_allowed_projects,
    )


def _build_project_resolver(cfg: BugHoundConfig) -> ProjectResolver:
    return ProjectResolver(
        search_roots=cfg.projects.search_roots,
        fuzzy_threshold=cfg.projects.fuzzy_threshold,
    )


def _build_monolithic_analyzer(llm) -> MonolithicAnalyzer:  # type: ignore[no-untyped-def]
    """Wire a :class:`MonolithicAnalyzer` for terminal use.

    The handler picks itself based on stdin: a TTY gets an
    :class:`InteractiveClarificationHandler` that prompts via ``typer``;
    a piped/CI run falls back to the deterministic
    :class:`AutoClarificationHandler` so the pipeline never blocks.
    """
    import sys

    if sys.stdin.isatty():
        def _prompt(question: str, options: list[str]) -> str:
            console.print(
                f"[cyan]Question de l'analyseur :[/cyan] {question}"
            )
            if options:
                console.print(
                    "[dim]Options proposées :[/dim] "
                    + " | ".join(options)
                )
            try:
                return typer.prompt("Réponse", default="").strip()
            except typer.Abort:
                return ""

        handler = InteractiveClarificationHandler(prompt_fn=_prompt)
    else:
        handler = AutoClarificationHandler()
    return MonolithicAnalyzer(llm, clarification_handler=handler)


def _interactive_project_pick(cfg: BugHoundConfig) -> Optional[Path]:
    """List candidate project directories and let the user pick one.

    Returns the selected path, or ``None`` if the user bailed out or if no
    candidates were found. Only called when automatic resolution failed
    *and* ``projects.interactive_fallback`` is true *and* stdin is a TTY.
    """
    import sys
    candidates: list[Path] = []
    for root in cfg.projects.search_roots:
        root = Path(root).expanduser()
        if not root.exists():
            continue
        for child in sorted(root.iterdir()):
            if child.is_dir() and not child.name.startswith("."):
                candidates.append(child)

    if not candidates:
        console.print("[yellow]No project candidates found under search_roots.[/yellow]")
        return None
    if not sys.stdin.isatty():
        return None

    console.print("[cyan]Pick the project this ticket belongs to:[/cyan]")
    for i, p in enumerate(candidates, start=1):
        console.print(f"  [bold]{i}[/bold]. {p.name}  [dim]{p}[/dim]")
    console.print("  [bold]0[/bold]. skip (no code cross-reference)")

    while True:
        raw = typer.prompt("Choice", default="0")
        try:
            choice = int(raw)
        except ValueError:
            console.print("[red]Please enter a number.[/red]")
            continue
        if choice == 0:
            return None
        if 1 <= choice <= len(candidates):
            return candidates[choice - 1]
        console.print(f"[red]Out of range (0-{len(candidates)}).[/red]")


def _print_dry_run(result: WriteResult) -> None:
    console.print(
        f"[yellow]DRY-RUN[/yellow] {result.action} on "
        f"[bold]{result.target}[/bold] — re-run with [bold]--yes[/bold] to apply."
    )
    console.print("Payload:")
    console.print_json(data=result.payload)


# ---------------------------------------------------------------------------
# analyze
# ---------------------------------------------------------------------------


@app.command()
def analyze(
    ticket_key: str = typer.Argument(..., help="Jira ticket key, e.g. PROJ-42"),
    config: Path = typer.Option(
        Path("config/config.yaml"),
        "--config", "-c",
        help="Path to the BugHound YAML config file.",
    ),
    env_file: Optional[Path] = typer.Option(
        Path(".env"),
        "--env-file",
        help="Path to a .env file with secrets (JIRA_API_TOKEN, LLM_API_KEY).",
    ),
    workdir: Optional[Path] = typer.Option(
        None,
        "--workdir", "-w",
        help="Override the output directory from config.",
    ),
    project_path: Optional[Path] = typer.Option(
        None,
        "--project-path", "-p",
        help="Force the local project directory (bypasses auto-resolution).",
    ),
    monolithic: bool = typer.Option(
        False,
        "--monolithic/--no-monolithic",
        help=(
            "Use the single-conversation analyser instead of the legacy "
            "chain of stateless LLM calls. Faster on native multi-turn "
            "backends, with optional clarification rounds. "
            "(Deprecated alias for ``--mode monolithic``.)"
        ),
    ),
    mode: str = typer.Option(
        "legacy",
        "--mode",
        help=(
            "Analysis mode: 'legacy' (default), 'monolithic' or 'best'. "
            "Use 'best' to skip BugHound's own LLM and produce a "
            "ready-to-execute prompt for an external chat LLM (Copilot)."
        ),
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Run the full BugHound pipeline on a Jira ticket."""
    _configure_logging(verbose)
    cfg = _load(config, env_file)
    out_dir = workdir or cfg.output.workdir
    out_dir = Path(out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    jira = _build_jira(cfg)
    llm = build_llm_client(
        mode=cfg.llm.mode,
        provider=cfg.llm.provider,
        model=cfg.llm.model,
        api_key=cfg.llm.api_key,
    )
    video_analyzer = _build_video_analyzer(cfg)
    resolver = _build_project_resolver(cfg)

    # Pre-resolve so that the CLI can handle the interactive fallback
    # *before* we start the (much slower) Jira + LLM work.
    project_override: Optional[ResolvedProject] = None
    if project_path is not None:
        root = Path(project_path).expanduser().resolve()
        project_override = ResolvedProject(
            ticket_key=ticket_key,
            root=root,
            name=root.name,
            matched_on="manual",
            score=1.0,
        )
        console.print(
            f"[cyan]Project[/cyan] forced to [bold]{project_override.root}[/bold]"
        )
    elif cfg.projects.interactive_fallback:
        # Peek at the cache; the pipeline will try a full resolve against
        # the ticket's components/labels once it has the ticket in hand.
        # If neither works, we'll fall back to an interactive pick *after*
        # the initial run sees an empty resolution.
        cached = resolver._lookup_cache(ticket_key)  # noqa: SLF001
        if cached is not None:
            console.print(f"[dim]Cached project:[/dim] {cached.root}")

    # Wrap the terminal prompt in a cache so the user only has to type the
    # password once per archive, even when the same archive is re-asked by
    # retry paths inside the extractor.
    password_provider = CachingPasswordProvider(TerminalPasswordProvider())
    artifactory_entries = [
        ConfiguredHostEntry(host=h.host, user=h.user, token=h.token)
        for h in cfg.artifactory.hosts
    ]
    attachment_manager = AttachmentManager(
        jira,
        password_provider=password_provider,
        url_handlers=build_default_registry(artifactory_entries=artifactory_entries),
    )

    # Reconcile the deprecated ``--monolithic`` flag with the new
    # ``--mode`` option. Setting both to incompatible values is an
    # error; otherwise ``--monolithic`` is honoured as a shortcut for
    # ``--mode monolithic``.
    if mode not in {"legacy", "monolithic", "best"}:
        raise typer.BadParameter(
            f"--mode must be 'legacy', 'monolithic' or 'best' (got {mode!r})"
        )
    if monolithic and mode == "legacy":
        effective_mode = "monolithic"
    elif monolithic and mode != "monolithic":
        raise typer.BadParameter(
            "--monolithic is incompatible with --mode " + repr(mode)
        )
    else:
        effective_mode = mode

    # ``best`` mode never invokes BugHound's own LLM. Skip building the
    # monolithic analyser entirely so we don't waste any resources.
    monolithic_analyzer = (
        _build_monolithic_analyzer(llm)
        if effective_mode == "monolithic"
        else None
    )
    pipeline = BugHoundPipeline(
        jira=jira,
        llm=llm,
        workdir=out_dir,
        attachment_manager=attachment_manager,
        video_analyzer=video_analyzer,
        correlator=LogCorrelator(
            parser=LogcatParser(),
            window_before_s=cfg.logs.window_before_s,
            window_after_s=cfg.logs.window_after_s,
        ),
        project_resolver=resolver,
        project_override=project_override,
        monolithic_analyzer=monolithic_analyzer,
        mode=effective_mode,
    )

    mode_label = {
        "legacy": "chaîne legacy",
        "monolithic": "monolithique",
        "best": "best (handoff Copilot)",
    }[effective_mode]
    console.print(
        "[bold yellow]🕵️ SherleKhomes[/bold yellow] — "
        "agent de l'agence [bold]Slama Consulting[/bold]"
    )
    console.print(
        f"[bold cyan]BugHound[/bold cyan] v{__version__} — analyzing "
        f"[bold]{ticket_key}[/bold] (mode jira=[yellow]{cfg.jira.mode}[/yellow]"
        f", analyseur=[yellow]{mode_label}[/yellow])"
    )
    console.print(f"[dim]Output directory:[/dim] {out_dir}")

    # Live step-by-step progress in the terminal. Keeping the format
    # identical to what the MCP server emits so the CLI experience and
    # the Copilot-Chat experience stay in lock-step.
    def _cli_progress(step: int, total: int, message: str) -> None:
        console.print(f"[bold cyan]\\[{step}/{total}][/bold cyan] {message}")

    result = pipeline.run(ticket_key, progress=_cli_progress)

    # ``best`` mode: BugHound stopped after deterministic ingestion.
    # Persist the prompt for later retrieval and surface it (and the
    # logs.txt path / missing pieces) to the user. No report writing.
    if isinstance(result, BestHandoffPayload):
        payload = result
        prompt_path = payload.analysis_dir / "handoff_prompt.md"
        try:
            prompt_path.write_text(payload.prompt, encoding="utf-8")
        except OSError as exc:
            console.print(
                f"[red]Could not persist handoff prompt:[/red] {exc}"
            )
        console.print(
            f"\n[green]✓ Mode best — artefacts prêts.[/green]"
        )
        console.print(f"  Workspace : [cyan]{payload.analysis_dir}[/cyan]")
        if payload.logs_txt_path is not None:
            console.print(
                f"  logs.txt  : [cyan]{payload.logs_txt_path}[/cyan]"
            )
        else:
            console.print("  logs.txt  : [yellow]absent[/yellow]")
        if payload.video_anchor:
            console.print(f"  Vidéo     : {payload.video_anchor}")
        if payload.missing:
            console.print(
                "  [yellow]Manquant :[/yellow] " + ", ".join(payload.missing)
            )
        console.print(
            f"  Prompt    : [cyan]{prompt_path}[/cyan]\n"
        )
        console.rule("[bold]Prompt Copilot[/bold]")
        console.print(payload.prompt)
        console.rule()
        return

    report = result

    # Interactive fallback: the pipeline couldn't resolve a project and
    # the user is on a TTY → let them pick one, then re-run just the
    # code cross-reference step (no need to re-fetch Jira / re-analyze).
    if (
        report.project is None
        and project_override is None
        and cfg.projects.interactive_fallback
    ):
        picked = _interactive_project_pick(cfg)
        if picked is not None:
            override = resolver.record_manual(report.ticket, picked)
            report.project = _to_model_resolved(override)
            insp = CodebaseInspector(override.root)
            haystack = "\n".join(
                line for ex in report.log_excerpts for line in ex.lines
            )
            if haystack:
                report.code_references = insp.cross_reference_logs(haystack)
            console.print(
                f"[green]✓ Cross-referenced[/green] against {override.root} "
                f"→ {len(report.code_references)} code ref(s)."
            )

    console.print("[cyan]Writing report…[/cyan]")
    workspace = pipeline.last_workspace
    md_path = write_report(
        report,
        out_dir,
        emit_json=cfg.output.emit_json,
        workspace=workspace,
    )
    console.print(f"[green]✓ Report written to[/green] {md_path}")
    if report.notes:
        console.print("[yellow]Notes:[/yellow]")
        for note in report.notes:
            console.print(f"  - {note}")

    # End-of-run confirmation: ask whether to discard the transient
    # artefacts (downloads, extracted, video frames) once the user has
    # had a chance to validate the report. Only when stdin is a TTY.
    if workspace is not None:
        import sys
        if sys.stdin.isatty():
            console.print(
                f"\n[bold]Artefacts temporaires[/bold] sous "
                f"[cyan]{workspace.root}[/cyan]"
            )
            if typer.confirm(
                "Supprimer les téléchargements / archives / frames vidéo "
                "(le rapport est conservé) ?",
                default=False,
            ):
                removed = workspace.cleanup_transients()
                console.print(
                    f"[green]✓ {len(removed)} dossier(s) transitoire(s) "
                    f"supprimé(s).[/green]"
                )
            else:
                console.print("[dim]Artefacts conservés en place.[/dim]")


# ---------------------------------------------------------------------------
# comment
# ---------------------------------------------------------------------------


@app.command()
def comment(
    ticket_key: str = typer.Argument(..., help="Ticket to comment on, e.g. CCSEXT-123"),
    body: str = typer.Option(..., "--body", "-b", help="Comment body (wiki markup)."),
    yes: bool = typer.Option(
        False, "--yes",
        help="Actually post the comment. Without this flag, runs in dry-run.",
    ),
    config: Path = typer.Option(Path("config/config.yaml"), "--config", "-c"),
    env_file: Optional[Path] = typer.Option(Path(".env"), "--env-file"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Add a comment to an existing Jira ticket (dry-run by default)."""
    _configure_logging(verbose)
    cfg = _load(config, env_file)
    jira = _build_jira(cfg)

    try:
        result = jira.add_comment(ticket_key, body, dry_run=not yes)
    except WriteRefusedError as exc:
        console.print(f"[red]Refused:[/red] {exc}")
        raise typer.Exit(code=2)

    if result.dry_run:
        _print_dry_run(result)
    else:
        console.print(
            f"[green]Comment posted[/green] on {result.target} "
            f"(id={result.key}) — {result.url}"
        )


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


@app.command()
def create(
    project: str = typer.Option(..., "--project", "-p", help="Project key, e.g. CCSEXT"),
    title: str = typer.Option(..., "--title", "-t", help="Issue summary."),
    body: str = typer.Option(..., "--body", "-b", help="Issue description (wiki markup)."),
    issue_type: str = typer.Option("Bug", "--type", help="Issue type."),
    yes: bool = typer.Option(
        False, "--yes",
        help="Actually create the issue. Without this flag, runs in dry-run.",
    ),
    config: Path = typer.Option(Path("config/config.yaml"), "--config", "-c"),
    env_file: Optional[Path] = typer.Option(Path(".env"), "--env-file"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Create a new Jira issue (dry-run by default)."""
    _configure_logging(verbose)
    cfg = _load(config, env_file)
    jira = _build_jira(cfg)

    try:
        result = jira.create_issue(
            project=project, title=title, body=body,
            issue_type=issue_type, dry_run=not yes,
        )
    except WriteRefusedError as exc:
        console.print(f"[red]Refused:[/red] {exc}")
        raise typer.Exit(code=2)

    if result.dry_run:
        _print_dry_run(result)
    else:
        console.print(
            f"[green]Issue created:[/green] {result.key} — {result.url}"
        )


# ---------------------------------------------------------------------------
# mcp-serve
# ---------------------------------------------------------------------------


def _resolve_mcp_config_path(explicit: Optional[Path]) -> Path:
    """Pick a config path that works regardless of the IDE's CWD.

    The MCP server is launched by the user's editor (VS Code, Claude
    Desktop, Cursor) with the workspace as CWD — typically NOT the
    BugHound checkout. A relative default like ``config/config.yaml``
    resolves against that workspace and breaks. We therefore:

    1. Honor an explicit ``--config`` path verbatim if provided.
    2. Otherwise fall back to ``~/.bughound/config.yaml`` (the
       canonical user-global location written by ``bughound setup``).
    3. As last resort, try ``./config/config.yaml`` for users who
       launch the server from the BugHound source tree directly.
    """
    if explicit is not None:
        return explicit
    user_global = Path("~/.bughound/config.yaml").expanduser()
    if user_global.exists():
        return user_global
    return Path("config/config.yaml")


@app.command(name="mcp-serve")
def mcp_serve(
    config: Optional[Path] = typer.Option(
        None,
        "--config", "-c",
        help=(
            "Path to the BugHound YAML config file. "
            "Defaults to ~/.bughound/config.yaml when present, "
            "else ./config/config.yaml."
        ),
    ),
    env_file: Optional[Path] = typer.Option(
        None,
        "--env-file",
        help=(
            "Path to a .env file with secrets (JIRA_API_TOKEN, "
            "LLM_API_KEY). Defaults to ~/.bughound/.env when present, "
            "else ./.env."
        ),
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Run BugHound as an MCP server over stdio.

    Lets editors like VS Code (Copilot Chat) or Claude Desktop drive
    BugHound directly — the user just asks "analyse CCSEXT-42" in the
    chat and the rendered report comes back inline.
    """
    # MCP stdio uses stdout for JSON-RPC. ANY non-JSON byte on stdout
    # corrupts the channel and the host (VS Code, Claude Desktop) emits
    # `Failed to parse message: …` warnings, which in turn make agents
    # hallucinate (e.g. fabricating local config.yaml files). All logs
    # MUST go to stderr. We bypass _configure_logging() — which targets
    # the default Console (stdout) — and force stderr instead.
    err_console = Console(stderr=True)
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.WARNING,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(
            console=err_console,
            rich_tracebacks=True,
            show_path=False,
            markup=True,
        )],
        force=True,
    )
    logging.getLogger("bughound").setLevel(
        logging.DEBUG if verbose else logging.INFO
    )

    config = _resolve_mcp_config_path(config)

    # Load .env so Jira/LLM secrets are available to the pipeline. The
    # MCP server itself reloads the YAML config on every tool call, so
    # edits to config.yaml take effect without restarting the server.
    if env_file is None:
        user_env = Path("~/.bughound/.env").expanduser()
        env_file = user_env if user_env.exists() else Path(".env")
    if env_file and env_file.exists():
        load_dotenv(env_file, override=False)

    from .mcp_server import run_stdio
    run_stdio(config)


# ---------------------------------------------------------------------------
# discard
# ---------------------------------------------------------------------------


@app.command()
def discard(
    ticket_key: str = typer.Argument(..., help="Ticket whose transient artefacts to delete."),
    config: Path = typer.Option(Path("config/config.yaml"), "--config", "-c"),
    env_file: Optional[Path] = typer.Option(Path(".env"), "--env-file"),
    yes: bool = typer.Option(
        False, "--yes",
        help="Skip the confirmation prompt.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Delete a ticket's downloads / extracted / video frames (keeps the report)."""
    from .workspace import TicketWorkspace

    _configure_logging(verbose)
    cfg = _load(config, env_file)
    out_dir = Path(cfg.output.workdir).expanduser()
    workspace = TicketWorkspace.for_ticket(out_dir, ticket_key)

    if not workspace.root.exists():
        console.print(
            f"[yellow]Aucun dossier d'analyse trouvé pour {ticket_key} "
            f"(attendu : {workspace.root}).[/yellow]"
        )
        raise typer.Exit(code=1)

    console.print(
        f"[bold]Workspace :[/bold] [cyan]{workspace.root}[/cyan]"
    )
    if not yes and not typer.confirm(
        "Supprimer downloads / extracted / video_analysis (rapport conservé) ?",
        default=False,
    ):
        console.print("[dim]Annulé.[/dim]")
        return

    removed = workspace.cleanup_transients()
    console.print(
        f"[green]✓ {len(removed)} dossier(s) supprimé(s).[/green] "
        f"Rapport conservé : {workspace.report_md}"
    )


# ---------------------------------------------------------------------------
# setup
# ---------------------------------------------------------------------------


_SETUP_HOME = Path("~/.bughound").expanduser()


def _render_user_config_yaml(
    *,
    mode: str,
    base_url: str,
    email: Optional[str],
) -> str:
    """Build the YAML body written into ``~/.bughound/config.yaml``."""
    header = (
        "# Configuration BugHound — générée par `bughound setup`\n"
        "# Les secrets (token, mot de passe) restent dans ~/.bughound/.env\n"
        "\n"
    )
    if mode == "browser":
        jira = (
            "jira:\n"
            "  mode: browser\n"
            f"  base_url: {base_url}\n"
            "  browser_profile_dir: ~/.bughound/chrome-profile\n"
            "  browser_headless_after_login: false\n"
            "  write_allowed_projects: []\n"
        )
    else:
        email_value = email or "<votre-email>"
        jira = (
            "jira:\n"
            "  mode: api\n"
            f"  base_url: {base_url}\n"
            f"  email: {email_value}\n"
            "  api_token: null  # défini via JIRA_API_TOKEN dans ~/.bughound/.env\n"
            "  write_allowed_projects: []\n"
        )
    rest = (
        "\n"
        "llm:\n"
        "  # Le LLM est routé via votre client MCP (Claude Code, Copilot, Cursor).\n"
        "  # Les paramètres ci-dessous ne sont utilisés qu'en mode CLI direct.\n"
        "  mode: copilot\n"
        "  provider: null\n"
        "  model: null\n"
        "  api_key: null\n"
        "\n"
        "video:\n"
        "  tesseract_cmd: null\n"
        "  ocr_sample_interval_s: 1.0\n"
        "  scene_change_threshold: 0.35\n"
        "\n"
        "logs:\n"
        "  window_before_s: 10\n"
        "  window_after_s: 5\n"
        "  timestamp_formats:\n"
        "    - \"%m-%d %H:%M:%S.%f\"\n"
        "    - \"%Y-%m-%d %H:%M:%S.%f\"\n"
        "\n"
        "projects:\n"
        "  search_roots:\n"
        "    - ~/AndroidStudioProjects\n"
        "  match_strategy: components-then-labels\n"
        "  fuzzy_threshold: 0.72\n"
        "  interactive_fallback: true\n"
        "\n"
        "artifactory:\n"
        "  # Optionnel : si vos pièces jointes Jira sont sur un Artifactory privé,\n"
        "  # ajoutez ici une entrée par hôte. Les credentials vont dans .env.\n"
        "  hosts: []\n"
        "\n"
        "output:\n"
        "  workdir: ~/.bughound/reports\n"
        "  emit_json: true\n"
    )
    return header + jira + rest


def _render_user_env_template(*, mode: str) -> str:
    """Build a commented ``.env`` template the user fills in locally."""
    common = (
        "# BugHound — secrets locaux (ne JAMAIS committer)\n"
        "# Décommentez et renseignez les variables dont vous avez besoin.\n"
        "\n"
    )
    jira_block = (
        "# --- Jira -----------------------------------------------------------\n"
    )
    if mode == "api":
        jira_block += (
            "# Token API Atlassian Cloud (id.atlassian.com → Manage account →\n"
            "# Security → Create and manage API tokens).\n"
            "# JIRA_API_TOKEN=\n"
        )
    else:
        jira_block += (
            "# Mode browser : pas de token. Le premier lancement ouvre\n"
            "# Chromium pour le SSO ; la session est ensuite réutilisée.\n"
        )
    artifactory_block = (
        "\n"
        "# --- Artifactory (optionnel) ---------------------------------------\n"
        "# Si vos pièces jointes Jira pointent sur un Artifactory privé :\n"
        "# ARTIFACTORY_USER=\n"
        "# ARTIFACTORY_TOKEN=\n"
    )
    llm_block = (
        "\n"
        "# --- LLM (optionnel, mode CLI direct uniquement) -------------------\n"
        "# Inutile si vous utilisez BugHound via Claude Code / Copilot / Cursor.\n"
        "# LLM_API_KEY=\n"
    )
    return common + jira_block + artifactory_block + llm_block


def _print_setup_summary(
    *,
    config_path: Path,
    env_path: Path,
    mode: str,
    base_url: str,
    is_new_env: bool,
) -> None:
    """Friendly recap so the user knows exactly what was written."""
    console.print()
    console.print("[green]✓ Configuration enregistrée.[/green]")
    console.print(f"  config : [cyan]{config_path}[/cyan]")
    console.print(
        f"  env    : [cyan]{env_path}[/cyan] "
        f"({'créé' if is_new_env else 'préservé'})"
    )
    console.print(f"  mode   : [yellow]{mode}[/yellow]")
    console.print(f"  jira   : [yellow]{base_url}[/yellow]")
    console.print()
    console.print("[bold]Étapes suivantes[/bold]")
    if mode == "api":
        console.print(
            f"  1. Ouvrez [cyan]{env_path}[/cyan] et renseignez "
            "[bold]JIRA_API_TOKEN[/bold]."
        )
    else:
        console.print(
            "  1. Premier lancement : Chromium s'ouvre pour le SSO, "
            "la session est ensuite réutilisée."
        )
    console.print(
        "  2. Lancez votre première enquête : "
        "[bold]bughound analyze MON-TICKET-42[/bold]"
    )


@app.command()
def setup(
    jira_url: Optional[str] = typer.Option(
        None,
        "--jira-url",
        envvar="JIRA_URL",
        help="URL de base de votre Jira (https://jira.maboite.com).",
    ),
    jira_mode: Optional[str] = typer.Option(
        None,
        "--jira-mode",
        envvar="JIRA_MODE",
        help="Mode Jira : 'browser' (Server/DC + SSO) ou 'api' (Cloud).",
    ),
    jira_email: Optional[str] = typer.Option(
        None,
        "--jira-email",
        envvar="JIRA_EMAIL",
        help="Email Atlassian (uniquement pour le mode api).",
    ),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help=(
            "N'invite jamais l'utilisateur. Utilisé par install.sh quand "
            "JIRA_URL / JIRA_MODE sont déjà fournis via env."
        ),
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Écrase ~/.bughound/config.yaml sans demander confirmation.",
    ),
) -> None:
    """Crée ``~/.bughound/config.yaml`` et ``~/.bughound/.env`` interactivement.

    Pour automatiser (install.sh, CI), passez ``--non-interactive`` avec
    ``JIRA_URL`` et ``JIRA_MODE`` (et ``JIRA_EMAIL`` si mode=api) en env.
    """
    home = _SETUP_HOME
    home.mkdir(parents=True, exist_ok=True)
    config_path = home / "config.yaml"
    env_path = home / ".env"

    # Mode ----------------------------------------------------------------
    if jira_mode is None:
        if non_interactive:
            jira_mode = "browser"
        else:
            jira_mode = typer.prompt(
                "Type de Jira [browser=Server/DC SSO, api=Cloud]",
                default="browser",
            ).strip().lower()
    jira_mode = jira_mode.strip().lower()
    if jira_mode not in {"browser", "api"}:
        raise typer.BadParameter(
            f"--jira-mode doit valoir 'browser' ou 'api' (reçu : {jira_mode!r})."
        )

    # URL -----------------------------------------------------------------
    if jira_url is None or not jira_url.strip():
        if non_interactive:
            raise typer.BadParameter(
                "--jira-url (ou env JIRA_URL) est requis en --non-interactive."
            )
        jira_url = typer.prompt("URL de base Jira (https://...)").strip()
    jira_url = jira_url.strip().rstrip("/")
    if not (jira_url.startswith("http://") or jira_url.startswith("https://")):
        raise typer.BadParameter(
            f"jira_url doit commencer par http(s):// (reçu : {jira_url!r})."
        )

    # Email (api uniquement) ----------------------------------------------
    if jira_mode == "api":
        if not jira_email or not jira_email.strip():
            if non_interactive:
                console.print(
                    "[yellow]Mode api sans email : laissez "
                    "<votre-email> dans le YAML, à compléter à la main.[/yellow]"
                )
                jira_email = None
            else:
                jira_email = typer.prompt(
                    "Email Atlassian", default=""
                ).strip() or None
        else:
            jira_email = jira_email.strip()
    else:
        jira_email = None

    # config.yaml ---------------------------------------------------------
    yaml_body = _render_user_config_yaml(
        mode=jira_mode, base_url=jira_url, email=jira_email,
    )
    if config_path.exists() and not force:
        if non_interactive:
            console.print(
                f"[yellow]{config_path} existe déjà — non écrasé "
                "(--force pour forcer).[/yellow]"
            )
        else:
            if not typer.confirm(
                f"{config_path} existe déjà. L'écraser ?",
                default=False,
            ):
                console.print("[dim]Configuration conservée en l'état.[/dim]")
                raise typer.Exit(code=0)
            config_path.write_text(yaml_body, encoding="utf-8")
    else:
        config_path.write_text(yaml_body, encoding="utf-8")

    # .env (jamais écrasé : il peut contenir des secrets) -----------------
    is_new_env = not env_path.exists()
    if is_new_env:
        env_path.write_text(
            _render_user_env_template(mode=jira_mode), encoding="utf-8"
        )
        try:
            env_path.chmod(0o600)
        except OSError:
            # Best-effort: Windows / restricted filesystems silently skip.
            pass

    _print_setup_summary(
        config_path=config_path,
        env_path=env_path,
        mode=jira_mode,
        base_url=jira_url,
        is_new_env=is_new_env,
    )


# ---------------------------------------------------------------------------
# mcp-install
# ---------------------------------------------------------------------------

# Catalogue des clients MCP supportés. Pour chaque client :
#   - path     : fichier de config JSON dans le HOME utilisateur
#   - container: chemin (clé(s) JSON imbriquées) où sont stockés les serveurs
#                (ex. ["mcpServers"] ou ["servers"])
#   - extra    : champs additionnels à ajouter à l'entrée serveur (ex. "type":
#                "stdio" pour VS Code/Copilot)
_MCP_CLIENTS: dict[str, dict] = {
    "claude": {
        "label": "Claude Code",
        "path": Path.home() / ".claude.json",
        "container": ["mcpServers"],
        "extra": {},
    },
    "vscode-copilot": {
        "label": "VS Code / Copilot Chat",
        "path": Path.home() / ".config" / "Code" / "User" / "mcp.json",
        "container": ["servers"],
        "extra": {"type": "stdio"},
    },
    "cursor": {
        "label": "Cursor",
        "path": Path.home() / ".cursor" / "mcp.json",
        "container": ["mcpServers"],
        "extra": {},
    },
}


def _resolve_bughound_command() -> str:
    """Return the absolute path to the running bughound binary.

    MCP clients launch servers with a minimal PATH; using a relative
    command name like "bughound" frequently fails. We resolve it once
    here so the written config always works.
    """
    abs_path = shutil.which("bughound")
    if abs_path:
        return abs_path
    # Fallback: inside a pipx venv the entry point lives next to the
    # current Python interpreter.
    cand = Path(os.sys.executable).parent / "bughound"
    if cand.exists():
        return str(cand)
    return "bughound"


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    raw = path.read_text(encoding="utf-8")
    if not raw.strip():
        return {}
    try:
        # VS Code's mcp.json may contain // comments — JSON5 isn't worth
        # a dependency, but a naive strip works for our own writes.
        # We only need to parse files we wrote ourselves; if the user
        # has comments we keep them by erroring out and asking.
        return json.loads(raw)
    except json.JSONDecodeError:
        # The file is JSONC (with comments). Try to strip common
        # comment styles before giving up.
        cleaned_lines = []
        for line in raw.splitlines():
            stripped = line.lstrip()
            if stripped.startswith("//"):
                continue
            cleaned_lines.append(line)
        cleaned = "\n".join(cleaned_lines)
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            raise typer.BadParameter(
                f"{path} contient du JSON invalide ou trop complexe à "
                f"parser ({e}). Éditez-le à la main, ou supprimez-le."
            ) from e


def _set_nested(obj: dict, keys: list[str], value: dict) -> None:
    cur = obj
    for k in keys[:-1]:
        nxt = cur.get(k)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[k] = nxt
        cur = nxt
    cur[keys[-1]] = value


def _get_nested(obj: dict, keys: list[str]) -> Optional[dict]:
    cur = obj
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur if isinstance(cur, dict) else None


def _build_server_entry(command: str, extra: dict) -> dict:
    entry = {"command": command, "args": ["mcp-serve"]}
    entry.update(extra)
    return entry


# Anciens noms de la clé MCP que l'on souhaite migrer automatiquement
# vers ``server_name`` au prochain ``mcp-install`` (évite les doublons
# "bughound" + "sherlekhomes" côté client).
_LEGACY_SERVER_NAMES = ("bughound",)


def _install_one_client(
    client_key: str,
    *,
    command: str,
    server_name: str,
    overwrite: Optional[bool],
    print_only: bool,
) -> str:
    """Install MCP for a single client. Returns a status string."""
    spec = _MCP_CLIENTS[client_key]
    path: Path = spec["path"]
    container: list[str] = list(spec["container"])
    extra: dict = spec["extra"]

    new_entry = _build_server_entry(command, extra)

    if print_only:
        snippet = {container[0]: {server_name: new_entry}}
        console.print(f"\n[bold]{spec['label']}[/bold] → [cyan]{path}[/cyan]")
        console.print(json.dumps(snippet, indent=2))
        return "printed"

    data = _load_json(path)
    existing_servers = _get_nested(data, container) or {}
    if server_name in existing_servers and existing_servers[server_name] != new_entry:
        if overwrite is None:
            if not typer.confirm(
                f"Le serveur '{server_name}' existe déjà dans {path}. "
                "Le remplacer ?",
                default=False,
            ):
                return f"skipped ({path})"
        elif not overwrite:
            return f"skipped ({path})"

    # Migration : on retire les anciens noms ("bughound", …) si l'on est
    # en train d'écrire un nouveau nom. Évite que l'utilisateur se
    # retrouve avec deux entrées équivalentes côté client MCP.
    merged = dict(existing_servers)
    for legacy in _LEGACY_SERVER_NAMES:
        if legacy != server_name and legacy in merged:
            merged.pop(legacy, None)
    merged[server_name] = new_entry

    # Build a fresh container if needed (preserves siblings).
    _set_nested(data, container, merged)

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return f"written ({path})"


@app.command("mcp-install")
def mcp_install(
    client: str = typer.Option(
        "all",
        "--client",
        "-c",
        help=(
            "Client MCP cible : 'claude', 'vscode-copilot', 'cursor', ou "
            "'all' (défaut : tous les clients détectés)."
        ),
    ),
    server_name: str = typer.Option(
        "sherlekhomes",
        "--name",
        help="Nom à donner au serveur MCP (défaut : 'sherlekhomes').",
    ),
    print_only: bool = typer.Option(
        False,
        "--print-only",
        help="Affiche la config qui serait écrite, sans toucher aux fichiers.",
    ),
    overwrite: bool = typer.Option(
        False,
        "--overwrite",
        help=(
            "Écrase une entrée du même nom existante sans demander. "
            "Utile pour les ré-installations idempotentes."
        ),
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Mode non-interactif : ne demande aucune confirmation.",
    ),
) -> None:
    """Enregistre BugHound comme serveur MCP dans Claude Code / VS Code / Cursor.

    Merge prudent : préserve toutes les autres entrées MCP de l'utilisateur,
    et demande confirmation avant d'écraser une entrée du même nom
    (sauf avec ``--overwrite`` ou ``--yes``). Migre automatiquement
    l'ancienne clé ``bughound`` vers ``sherlekhomes`` pour éviter les
    doublons côté client MCP.
    """
    if client == "all":
        targets = list(_MCP_CLIENTS.keys())
    elif client in _MCP_CLIENTS:
        targets = [client]
    else:
        raise typer.BadParameter(
            f"Client inconnu : {client!r}. "
            f"Valeurs valides : {', '.join(_MCP_CLIENTS)}, all."
        )

    command = _resolve_bughound_command()
    console.print(f"[*] Commande MCP : [cyan]{command} mcp-serve[/cyan]")

    overwrite_flag: Optional[bool] = True if overwrite else (False if yes else None)

    for key in targets:
        try:
            status = _install_one_client(
                key,
                command=command,
                server_name=server_name,
                overwrite=overwrite_flag,
                print_only=print_only,
            )
        except typer.BadParameter as exc:
            console.print(f"[red]✗ {_MCP_CLIENTS[key]['label']} : {exc}[/red]")
            continue
        console.print(
            f"[green]✓[/green] {_MCP_CLIENTS[key]['label']} : {status}"
        )

    if not print_only:
        console.print()
        console.print(
            "[dim]Rechargez votre client (Reload Window dans VS Code, "
            "ou redémarrage de Claude Code) pour prendre en compte la "
            "nouvelle config.[/dim]"
        )


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------


@app.command()
def version() -> None:
    """Print the BugHound version."""
    console.print(f"BugHound v{__version__}")


def main() -> None:
    app()


if __name__ == "__main__":  # pragma: no cover
    main()
