"""BugHound - trace bugs from Jira tickets to logs and videos."""

__version__ = "1.0.2"
