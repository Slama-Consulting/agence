"""Agent SherleKhomes — analyse de tickets Jira.

Ce sous-package enregistre l'agent ``sherlekhomes`` dans le registry
global :mod:`bughound.agents`. Le code historique de l'agent vit dans
:mod:`bughound.agents.sherlekhomes.mcp_server` (déplacé depuis
``bughound/mcp_server.py`` au Palier 1).
"""

from __future__ import annotations

from pathlib import Path

from .. import register


def _factory():  # type: ignore[no-untyped-def]
    """Construit le serveur FastMCP de SherleKhomes avec la config par défaut.

    Cette factory est utilisée quand ``mcp-serve --agent sherlekhomes``
    est appelé sans ``--config`` explicite. Elle reproduit la logique
    historique : ``~/.bughound/config.yaml`` si présent, sinon
    ``./config/config.yaml`` (résolu paresseusement par le serveur).
    """
    from .mcp_server import build_server, DEFAULT_CONFIG_PATH

    user_global = Path("~/.bughound/config.yaml").expanduser()
    config_path = user_global if user_global.exists() else DEFAULT_CONFIG_PATH
    return build_server(config_path)


register("sherlekhomes", _factory)
