"""Helpers pour les correctifs proposés par WaliPR (Palier 5).

Ce module est volontairement isolé du LLM : il ne fait que manipuler
des :class:`SuggestedPatch` côté code Python pur (parsing, conversion,
application). Les appels LLM restent dans :mod:`.review`.

Pipeline d'auto-apply (cf. :func:`bughound.cli.review_diff_cmd
--apply-trivial`) :

1. Pour chaque finding ``info`` ou ``minor`` ayant un
   ``suggested_patch`` applicable, on appelle :func:`apply_to_workdir`.
2. :func:`apply_to_workdir` privilégie ``unified_diff`` (plus précis) ;
   à défaut, applique le ``block_replacement``.
3. Renvoie un :class:`ApplyOutcome` par finding pour qu'un récap
   CLI/MCP puisse être produit.

Aucune écriture en dehors du working-tree du repo cible (jamais de
``git add``, jamais de ``git commit`` — l'utilisateur valide via
``git diff`` après coup).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .review import SuggestedPatch


__all__ = [
    "ApplyOutcome",
    "apply_to_workdir",
    "coerce_suggested_patch",
    "is_severity_auto_appliable",
    "to_unified_diff",
]


# ---------------------------------------------------------------------------
# Coercion (LLM JSON → SuggestedPatch)
# ---------------------------------------------------------------------------


def coerce_suggested_patch(value: Any) -> Optional[SuggestedPatch]:
    """Convertit un objet JSON tolérant en :class:`SuggestedPatch`.

    Formats acceptés :

    - ``str`` → traité comme un ``unified_diff``.
    - ``dict`` avec clé ``unified_diff`` (str non vide) → utilise tel
      quel ; les clés ``file``/``line_start``/``line_end``/
      ``replacement`` peuvent coexister à titre d'info mais l'unified
      diff prime côté apply.
    - ``dict`` avec ``file`` (str) + ``line_start``/``line_end`` (int)
      + ``replacement`` (str) → block_replacement.

    Renvoie ``None`` si rien d'exploitable n'est récupérable (le finding
    est alors traité comme « sans patch applicable »).
    """
    if value is None:
        return None

    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        return SuggestedPatch(unified_diff=text)

    if not isinstance(value, dict):
        return None

    unified = value.get("unified_diff")
    if isinstance(unified, str) and unified.strip():
        # On capture aussi les autres clés à titre informatif si elles
        # sont là (utile pour les rendus / le debug).
        return SuggestedPatch(
            unified_diff=unified.strip(),
            file=_coerce_str(value.get("file")),
            line_start=_coerce_pos_int(value.get("line_start")),
            line_end=_coerce_pos_int(value.get("line_end")),
            replacement=_coerce_replacement(value.get("replacement")),
        )

    file = _coerce_str(value.get("file"))
    line_start = _coerce_pos_int(value.get("line_start"))
    line_end = _coerce_pos_int(value.get("line_end"))
    replacement = _coerce_replacement(value.get("replacement"))
    if file and line_start and line_end and line_end >= line_start and replacement is not None:
        return SuggestedPatch(
            file=file,
            line_start=line_start,
            line_end=line_end,
            replacement=replacement,
        )
    return None


def _coerce_str(value: Any) -> Optional[str]:
    if isinstance(value, str) and value.strip():
        return value.strip()
    return None


def _coerce_pos_int(value: Any) -> Optional[int]:
    if isinstance(value, bool):
        return None  # True/False ne sont pas des numéros de ligne
    if isinstance(value, int) and value >= 1:
        return value
    if isinstance(value, str):
        try:
            n = int(value.strip())
        except ValueError:
            return None
        return n if n >= 1 else None
    return None


def _coerce_replacement(value: Any) -> Optional[str]:
    # Le replacement peut légitimement être une chaîne vide (suppression
    # d'un bloc de lignes), donc on accepte tout str sans strip.
    return value if isinstance(value, str) else None


# ---------------------------------------------------------------------------
# Conversion bloc → unified diff
# ---------------------------------------------------------------------------


def to_unified_diff(patch: SuggestedPatch, *, original_text: str) -> Optional[str]:
    """Convertit un block_replacement en mini-unified-diff git.

    ``original_text`` doit être le contenu courant du fichier visé
    (lecture working-tree). Renvoie ``None`` si :

    - ``patch.unified_diff`` est déjà fourni (rien à convertir),
    - le bloc ``[line_start, line_end]`` sort des bornes du fichier,
    - ``patch`` n'est pas un block_replacement valide.

    Format émis (relatif au repo, sans header global) :

    .. code-block:: diff

        --- a/<file>
        +++ b/<file>
        @@ -<start>,<count_old> +<start>,<count_new> @@
        -<old line 1>
        ...
        +<new line 1>
        ...
    """
    if patch.unified_diff:
        return None
    if not patch.is_applicable():
        return None
    file = patch.file
    assert file is not None  # garanti par is_applicable() ci-dessus

    # On split sans drop pour préserver la dernière ligne sans \n final.
    lines = original_text.splitlines(keepends=False)
    start = patch.line_start  # 1-based inclusif
    end = patch.line_end  # 1-based inclusif
    assert start is not None and end is not None
    if start > len(lines) + 1 or end > len(lines):
        # On accepte start == len+1 pour permettre l'append en fin de fichier
        # uniquement si end == start - 1 (cas dégénéré ; on refuse pour
        # rester simple).
        return None
    old_lines = lines[start - 1:end]
    new_block = patch.replacement or ""
    new_lines = new_block.splitlines() if new_block else []
    # Si replacement se termine par \n explicitement, splitlines() perd
    # l'info — on ne la traite pas spécialement, l'apply réinjecte un \n
    # uniforme côté écriture.

    body: list[str] = []
    for line in old_lines:
        body.append(f"-{line}")
    for line in new_lines:
        body.append(f"+{line}")

    count_old = len(old_lines)
    count_new = len(new_lines)
    header = f"@@ -{start},{count_old} +{start},{count_new} @@"
    return "\n".join([
        f"--- a/{file}",
        f"+++ b/{file}",
        header,
        *body,
    ]) + "\n"


# ---------------------------------------------------------------------------
# Apply
# ---------------------------------------------------------------------------


_HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


@dataclass(frozen=True)
class ApplyOutcome:
    """Résultat de l'application d'un patch dans le working-tree."""

    file: Optional[str]
    applied: bool
    reason: str  # ex. "applied", "no patch", "below severity", "hunk mismatch"


def is_severity_auto_appliable(severity: str) -> bool:
    """Filtre par sévérité — fixe à ``info`` / ``minor`` (P5)."""
    return severity in ("info", "minor")


def apply_to_workdir(
    patch: SuggestedPatch, *, repo_root: Path
) -> ApplyOutcome:
    """Applique un :class:`SuggestedPatch` dans le working-tree.

    Stratégie :

    1. Si ``unified_diff`` est présent : parse le mini-diff et applique
       hunk par hunk (un seul fichier — on ne supporte pas les patches
       multi-fichiers ici).
    2. Sinon (block_replacement) : remplace ``[line_start, line_end]``
       par ``replacement`` dans le fichier cible.

    Aucune commande externe (``git apply``, ``patch``) — implémentation
    100 % Python pour rester portable et testable offline.
    """
    if patch.unified_diff and patch.unified_diff.strip():
        return _apply_unified_diff(patch.unified_diff, repo_root=repo_root)
    if patch.is_applicable():
        return _apply_block_replacement(patch, repo_root=repo_root)
    return ApplyOutcome(file=None, applied=False, reason="no applicable patch")


def _apply_unified_diff(diff_text: str, *, repo_root: Path) -> ApplyOutcome:
    lines = diff_text.splitlines()
    file = _extract_target_file(lines)
    if file is None:
        return ApplyOutcome(file=None, applied=False, reason="missing file header")

    target = (repo_root / file).resolve()
    repo_root_resolved = repo_root.resolve()
    if repo_root_resolved not in target.parents and target != repo_root_resolved:
        return ApplyOutcome(
            file=file, applied=False, reason="path escapes repo root"
        )
    if not target.exists():
        return ApplyOutcome(file=file, applied=False, reason="target file missing")

    try:
        original_lines = target.read_text(encoding="utf-8").splitlines(keepends=False)
    except UnicodeDecodeError:
        return ApplyOutcome(file=file, applied=False, reason="binary or non-utf8 file")

    new_lines, ok, reason = _apply_hunks(lines, original_lines)
    if not ok:
        return ApplyOutcome(file=file, applied=False, reason=reason)

    target.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    return ApplyOutcome(file=file, applied=True, reason="applied")


def _extract_target_file(lines: list[str]) -> Optional[str]:
    """Extrait le chemin cible depuis l'en-tête ``+++ b/<path>``.

    Tolérant : accepte ``+++ b/foo.py`` ou ``+++ foo.py`` (sans
    préfixe ``b/``). Renvoie ``None`` si introuvable.
    """
    for line in lines:
        if line.startswith("+++ "):
            target = line[4:].strip()
            if target.startswith("b/"):
                target = target[2:]
            return target or None
    return None


def _apply_hunks(
    diff_lines: list[str], original: list[str]
) -> tuple[list[str], bool, str]:
    """Applique tous les hunks du diff à ``original``.

    Approche : on reconstruit le fichier de gauche à droite en suivant
    les hunks dans l'ordre. Chaque hunk doit s'aligner exactement avec
    le contenu courant (pas de fuzz, pas de retry).
    """
    out: list[str] = []
    cursor = 0  # index 0-based dans original
    i = 0
    n = len(diff_lines)

    while i < n:
        line = diff_lines[i]
        if not line.startswith("@@"):
            i += 1
            continue
        m = _HUNK_RE.match(line)
        if not m:
            return [], False, "malformed hunk header"
        old_start = int(m.group(1))  # 1-based, sauf cas count=0 → 0
        old_count = int(m.group(2)) if m.group(2) is not None else 1
        # `+start`/`+count` non utilisés directement (on reconstruit).

        # On copie le contenu intermédiaire entre cursor et old_start-1.
        old_index = max(old_start - 1, 0) if old_count > 0 else old_start
        if old_index < cursor:
            return [], False, "overlapping hunks"
        if old_index > len(original):
            return [], False, "hunk start beyond eof"
        out.extend(original[cursor:old_index])
        cursor = old_index

        # On consomme le corps du hunk.
        i += 1
        consumed = 0
        while i < n and not diff_lines[i].startswith("@@"):
            body = diff_lines[i]
            if body.startswith("---") or body.startswith("+++"):
                # Ne devrait pas apparaître au milieu d'un hunk, mais
                # on tolère et on saute.
                i += 1
                continue
            if not body:
                # Ligne contexte vide.
                if cursor >= len(original) or original[cursor] != "":
                    return [], False, "context mismatch (empty line)"
                out.append("")
                cursor += 1
                consumed += 1
            elif body[0] == " ":
                expected = body[1:]
                if cursor >= len(original) or original[cursor] != expected:
                    return [], False, "context mismatch"
                out.append(expected)
                cursor += 1
                consumed += 1
            elif body[0] == "-":
                expected = body[1:]
                if cursor >= len(original) or original[cursor] != expected:
                    return [], False, "deletion mismatch"
                cursor += 1
                consumed += 1
            elif body[0] == "+":
                out.append(body[1:])
            elif body.startswith("\\ No newline"):
                pass  # info-only line
            else:
                # Toute autre ligne au sein d'un hunk → mal formé.
                return [], False, "unexpected hunk line"
            i += 1

        if consumed != old_count:
            return [], False, f"hunk consumed {consumed} old lines, expected {old_count}"

    # Suffix après le dernier hunk.
    out.extend(original[cursor:])
    return out, True, "applied"


def _apply_block_replacement(
    patch: SuggestedPatch, *, repo_root: Path
) -> ApplyOutcome:
    file = patch.file
    assert file is not None
    target = (repo_root / file).resolve()
    repo_root_resolved = repo_root.resolve()
    if repo_root_resolved not in target.parents and target != repo_root_resolved:
        return ApplyOutcome(
            file=file, applied=False, reason="path escapes repo root"
        )
    if not target.exists():
        return ApplyOutcome(file=file, applied=False, reason="target file missing")

    try:
        text = target.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return ApplyOutcome(file=file, applied=False, reason="binary or non-utf8 file")

    lines = text.splitlines(keepends=False)
    start = patch.line_start
    end = patch.line_end
    assert start is not None and end is not None
    if start > len(lines) or end > len(lines):
        return ApplyOutcome(file=file, applied=False, reason="block out of range")

    replacement = patch.replacement or ""
    new_lines_chunk = replacement.splitlines() if replacement else []

    new = lines[: start - 1] + new_lines_chunk + lines[end:]
    # Préserve la présence/absence du trailing newline.
    trailing_nl = text.endswith("\n")
    new_text = "\n".join(new) + ("\n" if trailing_nl else "")
    target.write_text(new_text, encoding="utf-8")
    return ApplyOutcome(file=file, applied=True, reason="applied")
