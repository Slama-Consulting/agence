"""Serveur MCP de l'agent WaliPR.

Expose deux tools :

- ``review_local_diff(repo, range=None)`` — revue ``git diff [range]``.
- ``review_staged(repo)`` — revue ``git diff --cached`` (pre-commit).

Chaîne (identique pour les deux tools) :

1. :mod:`.diff` capture le diff brut + parse en :class:`FileDiff`.
2. :mod:`.review` sérialise les hunks et appelle le LLM.
3. Le résultat (:class:`ReviewResult`) est sérialisé en dict
   JSON-friendly puis renvoyé tel quel par FastMCP.

Le LLM est construit à partir de ``BugHoundConfig.llm`` (réutilisation
1:1 du factory :func:`bughound.llm.build_llm_client`).
"""

from __future__ import annotations

import logging
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING, Any, Iterable, Optional

from ...config import BugHoundConfig, load_config
from ...llm import LLMClient, build_llm_client
from .diff import (
    FileDiff,
    WaliPRDiffError,
    parse_unified_diff,
    run_local_diff,
    run_staged_diff,
)
from .review import ReviewResult, review_diff


# ``Context`` est importé sous ``TYPE_CHECKING`` pour les annotations,
# et au top-level du module via un import paresseux à l'intérieur de
# :func:`build_server` (où le SDK MCP est garanti disponible). Cet
# import top-level n'a lieu qu'au premier appel à ``build_server`` ;
# les tests qui importent uniquement ``_run_review_local`` ou
# ``_run_review_staged`` n'ont pas besoin du SDK MCP.
if TYPE_CHECKING:  # pragma: no cover
    from mcp.server.fastmcp import Context


log = logging.getLogger(__name__)

DEFAULT_CONFIG_PATH = Path("config/config.yaml")


# ---------------------------------------------------------------------------
# Helpers (testables hors MCP)
# ---------------------------------------------------------------------------


def _load_walipr_config(config_path: Path) -> BugHoundConfig:
    """Charge la config BugHound (section ``llm.*`` utilisée par WaliPR)."""
    return load_config(config_path)


def _resolve_repo(repo: Optional[str]) -> Path:
    """Résout le chemin du repo à analyser (cwd par défaut)."""
    return Path(repo).expanduser().resolve() if repo else Path.cwd()


def _build_llm_for_walipr(cfg: BugHoundConfig) -> LLMClient:
    """Construit le LLM via le factory partagé (mêmes mode/provider/key)."""
    llm_cfg = cfg.llm
    return build_llm_client(
        mode=llm_cfg.mode,
        provider=llm_cfg.provider,
        model=llm_cfg.model,
        api_key=llm_cfg.api_key,
    )


class _SamplingUnsupportedError(RuntimeError):
    """Levée quand le client MCP courant n'expose pas la capability
    ``sampling`` (donc impossible de demander une complétion au LLM
    hôte). Capturée par chaque tool pour rendre une réponse JSON
    actionnable à l'utilisateur (cf. message dans
    :func:`_build_copilot_override`).
    """


def _unwrap_elicit(answer: Any) -> Optional[str]:
    """Normalise les différentes formes d'une réponse MCP elicit.

    Les versions différentes du SDK MCP retournent soit une chaîne
    brute soit un petit objet avec un attribut ``.value`` /
    ``.content`` / ``.text``. Une réponse vide est traitée comme
    ``None`` (annulation). Dupliqué depuis SherleKhomes (15 lignes,
    duplication assumée — cf. plan).
    """
    if answer is None:
        return None
    for attr in ("value", "content", "text"):
        val = getattr(answer, attr, None)
        if isinstance(val, str):
            return val or None
    if isinstance(answer, str):
        return answer or None
    return None


def _result_to_dict(result: ReviewResult) -> dict[str, Any]:
    """Sérialise un :class:`ReviewResult` en structure JSON-friendly.

    Le champ ``languages_detected`` (P4.6) liste les langages
    effectivement appliqués pour la revue (auto-détection ou override).
    """
    out: dict[str, Any] = {
        "summary": result.summary,
        "score": result.score,
        "findings": [asdict(f) for f in result.findings],
        "languages_detected": list(result.languages),
    }
    if result.cache_status is not None:
        out["cache_status"] = result.cache_status
    return out


def _run_review_local(
    repo: Path,
    diff_range: Optional[str],
    cfg: BugHoundConfig,
    *,
    standards: Optional[str] = None,
    languages: Optional[Iterable[str]] = None,
    cache_enabled: bool = False,
    llm: Optional[LLMClient] = None,
    language: Optional[str] = None,
) -> dict[str, Any]:
    """Pipeline complet (synchrone) pour un diff local + range optionnel.

    ``llm`` permet d'injecter un client déjà construit (typiquement
    :class:`MCPCopilotClient` câblé sur ``ctx.info`` / ``ctx.elicit``
    par le tool MCP). Quand ``None`` on retombe sur le factory.

    ``language`` (``"fr"`` ou ``"en"``) est propagé tel quel à
    :func:`review_diff` (défaut ``"fr"`` côté review.py).
    """
    raw = run_local_diff(repo, diff_range)
    files = parse_unified_diff(raw)
    if llm is None:
        llm = _build_llm_for_walipr(cfg)
    result = review_diff(
        files,
        llm,
        standards=standards,
        languages=languages,
        cache_enabled=cache_enabled,
        repo_root=repo if cache_enabled else None,
        model_name=cfg.llm.model if cache_enabled else None,
        diff_text=raw if cache_enabled else None,
        language=language,
    )
    return {
        "repo": str(repo),
        "range": diff_range,
        "files_reviewed": len([f for f in files if not f.is_binary and f.hunks]),
        "files_total": len(files),
        **_result_to_dict(result),
    }


def _run_review_staged(
    repo: Path,
    cfg: BugHoundConfig,
    *,
    standards: Optional[str] = None,
    languages: Optional[Iterable[str]] = None,
    cache_enabled: bool = False,
    llm: Optional[LLMClient] = None,
    language: Optional[str] = None,
) -> dict[str, Any]:
    """Pipeline complet (synchrone) pour ``git diff --cached``.

    ``llm`` : cf. :func:`_run_review_local`.
    ``language`` : cf. :func:`_run_review_local`.
    """
    raw = run_staged_diff(repo)
    files = parse_unified_diff(raw)
    if llm is None:
        llm = _build_llm_for_walipr(cfg)
    result = review_diff(
        files,
        llm,
        standards=standards,
        languages=languages,
        cache_enabled=cache_enabled,
        repo_root=repo if cache_enabled else None,
        model_name=cfg.llm.model if cache_enabled else None,
        diff_text=raw if cache_enabled else None,
        language=language,
    )
    return {
        "repo": str(repo),
        "range": "--cached",
        "files_reviewed": len([f for f in files if not f.is_binary and f.hunks]),
        "files_total": len(files),
        **_result_to_dict(result),
    }


# ---------------------------------------------------------------------------
# FastMCP server
# ---------------------------------------------------------------------------


def build_server(config_path: Path = DEFAULT_CONFIG_PATH):  # type: ignore[no-untyped-def]
    """Construit et renvoie le :class:`FastMCP` de WaliPR.

    Import paresseux du SDK MCP pour rester aligné avec SherleKhomes
    (les tests unitaires n'ont pas besoin du SDK pour valider les
    helpers ``_run_review_local`` / ``_run_review_staged``).
    """
    from mcp.server.fastmcp import Context, FastMCP

    # FastMCP introspecte les annotations stringifiées des tools via
    # ``eval_str=True``. Pour que ``ctx: Context`` soit résolvable, il
    # faut que ``Context`` soit présent dans le globals du module au
    # moment du décorateur — on l'injecte ici, après l'import paresseux.
    globals()["Context"] = Context

    server = FastMCP(
        name="walipr",
        instructions=(
            "WaliPR — by Slama Consulting. Multi-language code "
            "reviewer (Kotlin, Python, TypeScript/JavaScript, "
            "Java). WaliPR NEVER modifies the target repo — it "
            "reads diffs/files and produces actionable reports.\n"
            "\n"
            "═══════════════════════════════════════════════════════\n"
            "MANDATORY WORKFLOW FOR REMOTE MR/PR REVIEWS\n"
            "═══════════════════════════════════════════════════════\n"
            "\n"
            "When the user asks ANYTHING that involves reviewing a "
            "remote merge/pull request URL (GitLab / GitHub / "
            "Bitbucket), even with a short phrasing like:\n"
            "  - 'review <url>'\n"
            "  - 'reviewe cette MR <url>'\n"
            "  - 'check this PR <url>'\n"
            "  - 'analyse ce MR <url>'\n"
            "  - 'donne-moi ton avis sur <url>'\n"
            "  - 'fait une code review de <url>'\n"
            "you MUST start by calling "
            "`walipr_review_mr_orchestrate(url)`. Period. This is "
            "the ONLY correct entry point — never skip this step, "
            "never call `review_merge_request` directly unless the "
            "user EXPLICITLY asks for the legacy/quick/shallow mode "
            "or for a one-shot review.\n"
            "\n"
            "After `walipr_review_mr_orchestrate(url)` returns the "
            "plan, you MUST follow ALL its steps in order:\n"
            "  1. `walipr_get_mr_metadata(url)` — title, description, "
            "branches, source SHA.\n"
            "  2. `walipr_get_mr_diff(url)` — unified diff + per-file "
            "summary.\n"
            "  3. For each non-trivial file: `walipr_get_mr_file(url, "
            "path, ref=\"head\")` to load the full file (or use your "
            "native `Read`/`Grep` if the repo is cloned locally).\n"
            "  4. Analyse with a Principal Software Engineer mindset "
            "(bugs, security, perf, architecture, readability). Tag "
            "findings as CRITICAL/HIGH/MEDIUM/LOW. Comment ONLY on "
            "added (`+`) lines.\n"
            "  5. `walipr_submit_mr_review(url, summary, comments)` — "
            "drafts mode by default (NOT publicly visible yet).\n"
            "  6. `walipr_publish_mr_review(url)` — publish all "
            "drafts as ONE grouped review (1 single notification "
            "instead of N).\n"
            "\n"
            "IMPORTANT: `review_merge_request` is the LEGACY one-shot "
            "tool. It is shallow (sees only the diff hors-contexte, "
            "often misses real bugs) and should NOT be your default "
            "choice. Only use it if the user explicitly says 'quick' "
            "/ 'shallow' / 'one-shot' / 'rapide' / 'legacy mode'.\n"
            "\n"
            "═══════════════════════════════════════════════════════\n"
            "REVIEW SCOPE — CHANGES ONLY (NOT THE FULL FILE)\n"
            "═══════════════════════════════════════════════════════\n"
            "\n"
            "When reviewing an MR/PR, you ONLY review the CHANGES "
            "introduced by that MR/PR — never the pre-existing "
            "code:\n"
            "  - ✅ Inline comments must point to lines `+` (added) "
            "or immediately next to `-` (removed) in the diff.\n"
            "  - ❌ NEVER post inline comments on context lines "
            "(starting with ` ` in the diff) nor on parts of the "
            "file untouched by the MR.\n"
            "  - ❌ NEVER post inline comments on files not present "
            "in `walipr_get_mr_diff(url).files`.\n"
            "  - 🎯 The full file content (loaded via "
            "`walipr_get_mr_file` or your native `Read`) is for "
            "CONTEXT ONLY — to judge the impact of the diff, not "
            "to be reviewed line-by-line.\n"
            "  - If you spot an issue in pre-existing untouched "
            "code, mention it ONLY in the global `summary`, never "
            "as an inline comment.\n"
            "\n"
            "═══════════════════════════════════════════════════════\n"
            "LOCAL DIFFS (no MR/PR yet):\n"
            "═══════════════════════════════════════════════════════\n"
            "  - `review_local_diff(repo, range=None)` for working "
            "tree changes.\n"
            "  - `review_staged(repo)` for `git diff --cached` "
            "(pre-commit hook style).\n"
            "\n"
            "Auto-detected language by file extension; override via "
            "`languages=[\"kotlin\", \"python\", ...]`. Cache "
            "(`use_cache=true`) skips redundant LLM calls if the "
            "same diff was reviewed < 7 days ago. Tokens loaded "
            "from `WALIPR_<FORGE>_TOKEN` (or `<FORGE>_TOKEN` alias); "
            "errors return typed `{error: \"<prefix>: <msg>\"}` "
            "payloads instead of raising."
        ),
    )

    def _cfg() -> BugHoundConfig:
        return load_config(config_path)

    # Les tools tournent en ``async def`` pour pouvoir construire un
    # :class:`MCPCopilotClient` dès que ``cfg.llm.mode == "copilot"``.
    # Imprimer le prompt sur ``sys.stdout`` corromprait le framing
    # JSON-RPC du transport stdio (cf. fix équivalent dans SherleKhomes,
    # commit ``e0f11d6``). Le travail synchrone (git diff + LLM call +
    # cache) est délégué à un worker thread via
    # :func:`anyio.to_thread.run_sync`, et le worker remonte les
    # callbacks ``ctx.info`` / ``ctx.elicit`` via
    # :func:`anyio.from_thread.run`.
    import anyio
    import anyio.from_thread as _from_thread

    def _build_copilot_override(ctx: "Context") -> Optional[LLMClient]:
        """Construit un :class:`MCPSamplingClient` ssi mode == copilot.

        Quand ``llm.mode != "copilot"`` (par ex. ``api`` avec une
        clé Anthropic), on rend ``None`` : le pipeline retombe sur
        le factory standard et tape directement le LLM.

        En mode copilot, on délègue la complétion au LLM hôte (Cursor,
        Claude Desktop, ...) via la primitive MCP standard
        ``sampling/createMessage`` (``ctx.session.create_message``).
        C'est l'API standard pour "demander au LLM du client de
        compléter ce prompt".

        IMPORTANT : tous les clients MCP n'implémentent pas la
        capability ``sampling`` (Claude Code CLI ne l'expose pas
        encore, Cursor et Claude Desktop oui). Si la capability
        manque, on retourne ``None`` et le tool remonte une
        ``WaliPRSamplingUnsupportedError`` claire à l'utilisateur
        avant tout appel LLM, plutôt que de bloquer silencieusement.
        """
        cfg_snapshot = _cfg()
        if cfg_snapshot.llm.mode.lower().strip() != "copilot":
            return None
        from mcp.types import ClientCapabilities, SamplingCapability, SamplingMessage, TextContent

        from ...llm import MCPSamplingClient

        # Pre-check : le client a-t-il déclaré la capability sampling ?
        # Si non, on lève très tôt pour éviter des appels qui
        # rendraient un ``McpError: Method not found`` au milieu d'une
        # review déjà entamée.
        supports_sampling = ctx.session.check_client_capability(
            ClientCapabilities(sampling=SamplingCapability()),
        )
        if not supports_sampling:
            raise _SamplingUnsupportedError(
                "Le client MCP courant n'a pas annoncé la capability "
                "``sampling`` : impossible de demander une complétion "
                "au LLM hôte. Solutions : (1) basculer en ``llm.mode: "
                "api`` dans ~/.bughound/config.yaml avec une clé "
                "Anthropic / OpenAI ; (2) utiliser un client MCP qui "
                "supporte sampling (Cursor, Claude Desktop). "
                "Claude Code CLI n'expose pas encore cette capability."
            )

        def _sample(system: str, user: str) -> str:
            messages = [
                SamplingMessage(
                    role="user",
                    content=TextContent(type="text", text=user),
                ),
            ]
            try:
                result = _from_thread.run(
                    lambda: ctx.session.create_message(
                        messages=messages,
                        max_tokens=8000,
                        system_prompt=system,
                    ),
                )
            except Exception:  # pragma: no cover - host glitches
                log.debug(
                    "walipr sampling/create_message failed",
                    exc_info=True,
                )
                return ""

            content = getattr(result, "content", None)
            if content is None:
                return ""
            text = getattr(content, "text", None)
            return text or ""

        return MCPSamplingClient(sample=_sample)

    @server.tool(
        description=(
            "Review the current local `git diff [range]` of a repo against "
            "language-specific code standards (Kotlin, Python, TypeScript/"
            "JavaScript, Java). Auto-detects the language from file "
            "extensions; pass `languages` (list of language keys) to "
            "force a specific set. Use this when the user asks for a "
            "code review of their working changes, or before opening a "
            "PR. `repo` defaults to the current working directory; "
            "`range` is forwarded to git (e.g. 'main..HEAD', 'HEAD~3'). "
            "Returns {summary, score in [0,1], findings: [{file, line, "
            "severity, category, message, suggestion, suggested_patch}], "
            "languages_detected: [...], cache_status?: 'hit'|'miss'}. "
            "`suggested_patch` may be null or {unified_diff: str} or "
            "{file, line_start, line_end, replacement} — the agent can "
            "apply it via the WaliPR CLI (`--apply-trivial`) for info/"
            "minor severities. Set `use_cache=true` (P6) to skip the "
            "LLM call when an identical diff was reviewed < 7 days ago "
            "with the same standards/languages/model "
            "(stored under `<repo>/.walipr-cache/`)."
        ),
    )
    async def review_local_diff(
        ctx: Context,
        repo: Optional[str] = None,
        range: Optional[str] = None,  # noqa: A002 (intentional MCP arg name)
        languages: Optional[list[str]] = None,
        use_cache: bool = False,
        language: str = "fr",
    ) -> dict[str, Any]:
        try:
            llm_override = _build_copilot_override(ctx)
        except _SamplingUnsupportedError as exc:
            return {
                "error": f"sampling_unsupported: {exc}",
                "repo": str(_resolve_repo(repo)),
                "range": range,
                "findings": [],
                "languages_detected": list(languages or ()),
            }
        cfg_snapshot = _cfg()
        resolved_repo = _resolve_repo(repo)

        def _run() -> dict[str, Any]:
            try:
                return _run_review_local(
                    resolved_repo,
                    range,
                    cfg_snapshot,
                    languages=languages,
                    cache_enabled=use_cache,
                    llm=llm_override,
                    language=language,
                )
            except WaliPRDiffError as exc:
                return {
                    "error": str(exc),
                    "repo": str(resolved_repo),
                    "range": range,
                    "findings": [],
                    "languages_detected": list(languages or ()),
                }

        return await anyio.to_thread.run_sync(_run)

    @server.tool(
        description=(
            "Review the staged changes (`git diff --cached`) of a repo "
            "against language-specific code standards. Ideal as a pre-"
            "commit check — flags issues before the commit happens. "
            "Auto-detects languages from extensions; pass `languages` "
            "to force a specific set. `repo` defaults to the current "
            "working directory. Same return shape as `review_local_diff` "
            "(including optional `cache_status` when `use_cache=true`)."
        ),
    )
    async def review_staged(
        ctx: Context,
        repo: Optional[str] = None,
        languages: Optional[list[str]] = None,
        use_cache: bool = False,
        language: str = "fr",
    ) -> dict[str, Any]:
        try:
            llm_override = _build_copilot_override(ctx)
        except _SamplingUnsupportedError as exc:
            return {
                "error": f"sampling_unsupported: {exc}",
                "repo": str(_resolve_repo(repo)),
                "range": "--cached",
                "findings": [],
                "languages_detected": list(languages or ()),
            }
        cfg_snapshot = _cfg()
        resolved_repo = _resolve_repo(repo)

        def _run() -> dict[str, Any]:
            try:
                return _run_review_staged(
                    resolved_repo,
                    cfg_snapshot,
                    languages=languages,
                    cache_enabled=use_cache,
                    llm=llm_override,
                    language=language,
                )
            except WaliPRDiffError as exc:
                return {
                    "error": str(exc),
                    "repo": str(resolved_repo),
                    "range": "--cached",
                    "findings": [],
                    "languages_detected": list(languages or ()),
                }

        return await anyio.to_thread.run_sync(_run)

    @server.tool(
        description=(
            "**[LEGACY ONE-SHOT — DO NOT USE BY DEFAULT]** Quick "
            "shallow review of a remote MR/PR via a SINGLE LLM call "
            "on the diff alone (no cross-file context). DEPRECATED "
            "for substantive code reviews because it routinely "
            "misses real bugs that require cross-file understanding "
            "(observed empirically on production MRs).\n"
            "\n"
            "USE `walipr_review_mr_orchestrate(url)` INSTEAD when "
            "the user asks for a code review. Only use THIS tool "
            "when the user explicitly asks for a 'quick', 'shallow', "
            "'one-shot', 'rapide' or 'legacy' review.\n"
            "\n"
            "Supports GitLab (cloud + self-hosted), GitHub (cloud + "
            "Enterprise Server) and Bitbucket (Cloud + Server). The "
            "tool fetches the MR metadata + unified diff via the "
            "forge REST API, then runs the multi-language review "
            "chain on the diff (Kotlin, Python, TypeScript/"
            "JavaScript, Java; auto-detected, override via "
            "`languages`).\n"
            "\n"
            "WHERE THE TOKEN IS LOADED FROM (priority order, first "
            "match wins):\n"
            "  1. The `token` parameter passed explicitly to this "
            "tool call (avoid in shared chats — leaks in logs).\n"
            "  2. Process environment variable `WALIPR_<FORGE>_TOKEN` "
            "— preferred for WaliPR-specific credentials. Concrete "
            "names: `WALIPR_GITLAB_TOKEN`, `WALIPR_GITHUB_TOKEN`, "
            "`WALIPR_BITBUCKET_TOKEN`.\n"
            "  3. Universal alias `<FORGE>_TOKEN` — fallback that "
            "reuses tokens already exported by other tools "
            "(`GITLAB_TOKEN`, `GITHUB_TOKEN`, `BITBUCKET_TOKEN`).\n"
            "\n"
            "USER SETUP (where to put the token so the agent finds "
            "it without `token=` argument): add a non-commented line "
            "to `~/.bughound/.env` (loaded automatically at boot, "
            "fallback `./.env`). Exact format — no leading `#`, no "
            "quotes, no spaces around `=`:\n"
            "    WALIPR_GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx\n"
            "Where to obtain the PAT: GitLab → User Settings → "
            "Access Tokens (scope `read_repository` for review, "
            "`api` if `post_comment=true`). GitHub → Settings → "
            "Developer settings → Personal access tokens (scope "
            "`repo` for private repos / `public_repo`; `repo` "
            "needed for `post_comment`). Bitbucket → Personal "
            "settings → App passwords or HTTP access tokens (scope "
            "`pullrequest:read`, `pullrequest:write` for posting).\n"
            "\n"
            "If no token is available, this tool returns "
            "`{\"error\": \"missing_token: ...\"}` naming exactly "
            "the variable to export — no exception is raised.\n"
            "\n"
            "The review is purely read-only by default. Two opt-in "
            "posting modes (mutually exclusive — pass at most ONE of "
            "them per call):\n"
            "  - `post_comment=true` (P7): publishes ONE global "
            "comment containing the summary + score + truncated "
            "findings list at the bottom of the MR/PR.\n"
            "  - `post_inline=true` (P8): publishes ONE comment per "
            "finding directly next to the relevant line of the diff "
            "(only findings with a non-null `line` are posted; non-"
            "localised findings are silently skipped). Recommended "
            "for actual code review.\n"
            "Both require write scope on the token. A failure on a "
            "single inline post never invalidates the local review "
            "or stops the loop. Passing both `post_comment=true` and "
            "`post_inline=true` returns "
            "`{\"error\": \"mutually_exclusive: ...\"}`.\n"
            "\n"
            "Diffs larger than `max_diff_lines` (default 5000) are "
            "rejected before the LLM call (no token consumed). With "
            "`use_cache=true` (P6), the cache key embeds the MR "
            "canonical URL + `source_sha` so a force-push correctly "
            "invalidates the cache. Returns {summary, score, "
            "findings: [...], languages_detected: [...], mr: {url, "
            "title, source_branch, target_branch, source_sha, "
            "diff_size_lines}, comment_posted, comment_url, "
            "inline_comments_posted, inline_comments_attempted, "
            "cache_status?}. On error returns a dict with typed "
            "`error` prefix (`unsupported_forge:`, `missing_token:`, "
            "`diff_too_large:`, `forge_api_error:`, "
            "`mutually_exclusive:`) + minimal context (no exception "
            "leak)."
        ),
    )
    async def review_merge_request(
        ctx: Context,
        url: str,
        languages: Optional[list[str]] = None,
        use_cache: bool = False,
        post_comment: bool = False,
        post_inline: bool = False,
        max_diff_lines: int = 5000,
        token: Optional[str] = None,
        language: str = "fr",
    ) -> dict[str, Any]:
        # Imports paresseux (P7) pour ne pas casser le serveur MCP si
        # `httpx` ou un module forge a un souci au boot.
        from .forges.auth import MissingForgeTokenError
        from .forges.errors import (
            DiffTooLargeError,
            ForgeAPIError,
        )
        from .forges.url import UnsupportedForgeError
        from .mr_review import (
            result_to_dict as _mr_result_to_dict,
            review_merge_request as _review_mr,
        )

        if post_comment and post_inline:
            return {
                "error": (
                    "mutually_exclusive: post_comment and post_inline "
                    "cannot both be true; pick one."
                ),
                "url": url,
                "findings": [],
                "languages_detected": list(languages or ()),
            }

        try:
            llm_override = _build_copilot_override(ctx)
        except _SamplingUnsupportedError as exc:
            return {
                "error": f"sampling_unsupported: {exc}",
                "url": url,
                "findings": [],
                "languages_detected": list(languages or ()),
            }
        cfg = _cfg()

        def _run() -> dict[str, Any]:
            try:
                result = _review_mr(
                    url=url,
                    explicit_token=token,
                    model_name=cfg.llm.model,
                    languages=languages,
                    use_cache=use_cache,
                    post_comment=post_comment,
                    post_inline=post_inline,
                    max_diff_lines=max_diff_lines,
                    config=cfg,
                    llm=llm_override,
                    language=language,
                )
                return _mr_result_to_dict(result)
            except UnsupportedForgeError as exc:
                return {
                    "error": f"unsupported_forge: {exc}",
                    "url": url,
                    "findings": [],
                    "languages_detected": list(languages or ()),
                }
            except MissingForgeTokenError as exc:
                return {
                    "error": f"missing_token: {exc}",
                    "url": url,
                    "findings": [],
                    "languages_detected": list(languages or ()),
                }
            except DiffTooLargeError as exc:
                return {
                    "error": (
                        f"diff_too_large: {exc.lines} lines exceeds "
                        f"limit {exc.limit}"
                    ),
                    "url": url,
                    "findings": [],
                    "languages_detected": list(languages or ()),
                }
            except ForgeAPIError as exc:
                return {
                    "error": f"forge_api_error: {exc}",
                    "url": url,
                    "findings": [],
                    "languages_detected": list(languages or ()),
                }

        return await anyio.to_thread.run_sync(_run)

    # ---------------------------------------------------------------
    # P10 — Tools agentiques (mode pmt-mcp)
    # ---------------------------------------------------------------

    @server.tool(
        description=(
            "**[START HERE FOR ANY MR/PR REVIEW]** Default entry "
            "point when the user asks to review, check, analyse, "
            "audit, comment on, or give feedback on a remote MR/PR "
            "URL (GitLab / GitHub / Bitbucket) — even with a short "
            "phrasing like 'review <url>', 'reviewe cette MR <url>', "
            "'check this PR <url>', 'fait une code review de <url>'. "
            "ALWAYS call this tool FIRST whenever a MR/PR URL is "
            "involved.\n"
            "\n"
            "Returns a textual plan (French by default, English if "
            "`language=\"en\"`) explaining how to deeply review the "
            "MR/PR by composing the other `walipr_*` tools step by "
            "step. PERFORMS NO NETWORK CALL AND NO LLM CALL — it is "
            "instant and free.\n"
            "\n"
            "After receiving the plan you MUST follow it in order: "
            "(1) `walipr_get_mr_metadata` for the intent, (2) "
            "`walipr_get_mr_diff` for the changes, (3) "
            "`walipr_get_mr_file` (or your native `Read`/`Grep` if "
            "the repo is cloned locally) to load full file context "
            "for each non-trivial file, (4) classify findings as "
            "CRITICAL/HIGH/MEDIUM/LOW, (5) comment ONLY on added "
            "(`+`) lines, (6) `walipr_submit_mr_review` to post the "
            "findings as drafts, (7) `walipr_publish_mr_review` to "
            "submit the grouped review.\n"
            "\n"
            "DO NOT use the legacy `review_merge_request` tool "
            "unless the user EXPLICITLY says 'quick', 'shallow', "
            "'one-shot', 'rapide' or 'legacy mode' — the legacy "
            "tool sees only the diff hors-contexte and routinely "
            "misses real bugs."
        ),
    )
    async def walipr_review_mr_orchestrate(
        ctx: Context,
        url: str,
        language: str = "fr",
    ) -> dict[str, Any]:
        from .agentic import build_orchestrate_payload
        from .forges.url import UnsupportedForgeError

        def _run() -> dict[str, Any]:
            try:
                return build_orchestrate_payload(url, language=language)
            except UnsupportedForgeError as exc:
                return {
                    "error": f"unsupported_forge: {exc}",
                    "url": url,
                }

        return await anyio.to_thread.run_sync(_run)

    @server.tool(
        description=(
            "**MODE AGENTIQUE.** Fetches the metadata of a remote "
            "merge/pull request: title, description, source branch, "
            "target branch, source SHA, web URL, and total diff "
            "size in lines. Does NOT include the diff itself "
            "(use `walipr_get_mr_diff` for that — separating the "
            "two saves tokens when the agent only needs the "
            "context). Token resolution is identical to "
            "`review_merge_request` (`token=` arg → "
            "`WALIPR_<FORGE>_TOKEN` → universal alias). On error "
            "returns `{error: \"<typed_prefix>: <msg>\", url}` "
            "without raising."
        ),
    )
    async def walipr_get_mr_metadata(
        ctx: Context,
        url: str,
        token: Optional[str] = None,
    ) -> dict[str, Any]:
        from .agentic import run_get_mr_metadata
        from .forges.auth import MissingForgeTokenError
        from .forges.errors import ForgeAPIError
        from .forges.url import UnsupportedForgeError

        def _run() -> dict[str, Any]:
            try:
                return run_get_mr_metadata(
                    url, explicit_token=token,
                )
            except UnsupportedForgeError as exc:
                return {"error": f"unsupported_forge: {exc}", "url": url}
            except MissingForgeTokenError as exc:
                return {"error": f"missing_token: {exc}", "url": url}
            except ForgeAPIError as exc:
                return {"error": f"forge_api_error: {exc}", "url": url}

        return await anyio.to_thread.run_sync(_run)

    @server.tool(
        description=(
            "**MODE AGENTIQUE.** Fetches the unified diff of a remote "
            "MR/PR plus a per-file summary (path, is_new, is_deleted, "
            "is_renamed, is_binary, hunks_count). Soft-fails with "
            "`{error: \"diff_too_large: ...\"}` when the diff "
            "exceeds `max_diff_lines` (default 5000). Use the "
            "returned `files` list to decide which files deserve a "
            "deeper read via `walipr_get_mr_file` or your own "
            "`Read`. The full unified diff is in `diff_unified`."
        ),
    )
    async def walipr_get_mr_diff(
        ctx: Context,
        url: str,
        max_diff_lines: int = 5000,
        token: Optional[str] = None,
    ) -> dict[str, Any]:
        from .agentic import run_get_mr_diff
        from .forges.auth import MissingForgeTokenError
        from .forges.errors import DiffTooLargeError, ForgeAPIError
        from .forges.url import UnsupportedForgeError

        def _run() -> dict[str, Any]:
            try:
                return run_get_mr_diff(
                    url,
                    max_diff_lines=max_diff_lines,
                    explicit_token=token,
                )
            except UnsupportedForgeError as exc:
                return {"error": f"unsupported_forge: {exc}", "url": url}
            except MissingForgeTokenError as exc:
                return {"error": f"missing_token: {exc}", "url": url}
            except DiffTooLargeError as exc:
                return {
                    "error": (
                        f"diff_too_large: {exc.lines} lines exceeds "
                        f"limit {exc.limit}"
                    ),
                    "url": url,
                }
            except ForgeAPIError as exc:
                return {"error": f"forge_api_error: {exc}", "url": url}

        return await anyio.to_thread.run_sync(_run)

    @server.tool(
        description=(
            "**MODE AGENTIQUE.** Fetches the full content of a file "
            "from the MR/PR's repository at a specific revision. "
            "`ref` accepts the human aliases `\"head\"` (default — "
            "the MR source SHA, what the author proposes) or "
            "`\"base\"` (the target branch tip, what's currently "
            "merged), or a raw SHA / branch / tag. Use this to "
            "give yourself the cross-context the diff alone cannot "
            "show: full file structure, surrounding methods, "
            "imports, etc. PREFER your native `Read` tool when "
            "the repo is cloned locally — only use this tool when "
            "the repo is remote-only. On error returns "
            "`{error: \"file_not_found: ...\" | \"forge_api_error: "
            "...\", url, path, ref}`."
        ),
    )
    async def walipr_get_mr_file(
        ctx: Context,
        url: str,
        path: str,
        ref: str = "head",
        token: Optional[str] = None,
    ) -> dict[str, Any]:
        from .agentic import run_get_mr_file
        from .forges.auth import MissingForgeTokenError
        from .forges.errors import (
            ForgeAPIError,
            ForgeNotFoundError,
        )
        from .forges.url import UnsupportedForgeError

        def _run() -> dict[str, Any]:
            try:
                return run_get_mr_file(
                    url,
                    path,
                    ref=ref,
                    explicit_token=token,
                )
            except UnsupportedForgeError as exc:
                return {
                    "error": f"unsupported_forge: {exc}",
                    "url": url, "path": path, "ref": ref,
                }
            except MissingForgeTokenError as exc:
                return {
                    "error": f"missing_token: {exc}",
                    "url": url, "path": path, "ref": ref,
                }
            except ForgeNotFoundError as exc:
                return {
                    "error": f"file_not_found: {exc}",
                    "url": url, "path": path, "ref": ref,
                }
            except ForgeAPIError as exc:
                return {
                    "error": f"forge_api_error: {exc}",
                    "url": url, "path": path, "ref": ref,
                }

        return await anyio.to_thread.run_sync(_run)

    @server.tool(
        description=(
            "**MODE AGENTIQUE — étape finale.** Submits a code "
            "review to the remote MR/PR.\n"
            "\n"
            "**By default (`draft=True`)**, comments are added as "
            "DRAFTS (equivalent of GitLab UI 'Add to review' "
            "instead of 'Add comment now'). Drafts are NOT visible "
            "to the reviewed user yet — call "
            "`walipr_publish_mr_review(url)` afterwards to publish "
            "them all at once as a SINGLE grouped review (1 "
            "notification instead of N). Recommended workflow.\n"
            "\n"
            "Pass `draft=False` for the legacy behaviour (immediate "
            "publication, 1 notification per comment).\n"
            "\n"
            "Each finding must be `{file_path: str, line: int, "
            "severity: str, body: str, suggestion?: str}` where "
            "`severity` is CRITICAL/HIGH/MEDIUM/LOW (or "
            "info/minor/major/blocker — both accepted). Findings "
            "missing `file_path`/`line`/`body` are silently "
            "skipped. A failure on a single comment does NOT stop "
            "the loop — failures are collected in `failures`. Pass "
            "`comments=[]` to post only the `summary` (useful for "
            "an approval-only review).\n"
            "\n"
            "Forge support for drafts:\n"
            "  - **GitLab**: native (`draft_notes` API, persists "
            "server-side until publish).\n"
            "  - **GitHub**: emulated via Pending Review (one "
            "review per client session — works if you call submit "
            "+ publish in the same MCP turn).\n"
            "  - **Bitbucket**: emulated via in-memory buffer in "
            "the client instance. Same caveat as GitHub. Does not "
            "survive a process restart.\n"
            "\n"
            "Requires write scope on the token."
        ),
    )
    async def walipr_submit_mr_review(
        ctx: Context,
        url: str,
        summary: str = "",
        comments: Optional[list[dict[str, Any]]] = None,
        draft: bool = True,
        token: Optional[str] = None,
    ) -> dict[str, Any]:
        from .agentic import run_submit_mr_review
        from .forges.auth import MissingForgeTokenError
        from .forges.errors import ForgeAPIError
        from .forges.url import UnsupportedForgeError

        def _run() -> dict[str, Any]:
            try:
                return run_submit_mr_review(
                    url,
                    summary,
                    comments or [],
                    draft=draft,
                    explicit_token=token,
                )
            except UnsupportedForgeError as exc:
                return {"error": f"unsupported_forge: {exc}", "url": url}
            except MissingForgeTokenError as exc:
                return {"error": f"missing_token: {exc}", "url": url}
            except ForgeAPIError as exc:
                return {"error": f"forge_api_error: {exc}", "url": url}

        return await anyio.to_thread.run_sync(_run)

    @server.tool(
        description=(
            "**MODE AGENTIQUE — publication des drafts.** Publishes "
            "all draft comments previously created via "
            "`walipr_submit_mr_review(draft=True)` as a SINGLE "
            "grouped review on the MR/PR. Equivalent of clicking "
            "'Submit review' in the GitLab/GitHub UI.\n"
            "\n"
            "Returns `{published: int, error: str}` where "
            "`published` is the number of drafts published (best-"
            "effort: GitLab returns the exact count, GitHub returns "
            "1 per submitted review). On error returns a typed "
            "prefix (`unsupported_forge:`, `missing_token:`, "
            "`not_supported:`, `forge_api_error:`).\n"
            "\n"
            "**Note on session scope**: GitLab works fully because "
            "drafts live server-side. For GitHub and Bitbucket, the "
            "publish only succeeds if it happens in the same MCP "
            "session as the submit (same forge client instance). "
            "If unsure, prefer `walipr_submit_mr_review(draft=False)` "
            "for non-GitLab forges to avoid surprises."
        ),
    )
    async def walipr_publish_mr_review(
        ctx: Context,
        url: str,
        token: Optional[str] = None,
    ) -> dict[str, Any]:
        from .agentic import run_publish_mr_review
        from .forges.auth import MissingForgeTokenError
        from .forges.errors import ForgeAPIError
        from .forges.url import UnsupportedForgeError

        def _run() -> dict[str, Any]:
            try:
                return run_publish_mr_review(
                    url, explicit_token=token,
                )
            except UnsupportedForgeError as exc:
                return {"error": f"unsupported_forge: {exc}", "url": url}
            except MissingForgeTokenError as exc:
                return {"error": f"missing_token: {exc}", "url": url}
            except ForgeAPIError as exc:
                return {"error": f"forge_api_error: {exc}", "url": url}

        return await anyio.to_thread.run_sync(_run)

    return server


def run_stdio(config_path: Path = DEFAULT_CONFIG_PATH) -> None:
    """Entry point invoqué par ``bughound mcp-serve --agent walipr``."""
    server = build_server(config_path)
    server.run()
