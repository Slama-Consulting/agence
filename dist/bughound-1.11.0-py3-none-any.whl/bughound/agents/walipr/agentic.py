"""Helpers WaliPR Palier 10 — mode agentique.

Au lieu d'un seul tool MCP one-shot (``review_merge_request``) qui
encapsule tout le pipeline (fetch diff → LLM → JSON → post), on
expose une **série de tools atomiques** que le LLM hôte (Cursor,
Claude Desktop, GitHub Copilot…) orchestre lui-même. Inspiré de
``pmt-mcp`` qui obtient des reviews bien plus profondes en laissant
l'agent client utiliser ses propres ``Read`` / ``Grep`` pour aller
chercher le contexte autour des hunks du diff.

Ce module expose des helpers **synchrones et purs** (pas d'I/O MCP,
pas de ``ctx``) qui sont câblés sur des tools FastMCP par
:mod:`bughound.agents.walipr.mcp_server`. Les helpers prennent un
``ForgeClient`` injectable pour rester testables sans réseau.

Tools couverts :

- :func:`build_orchestrate_payload` — plan textuel (aucun I/O réseau)
  pour le tool ``walipr_review_mr_orchestrate``.
- :func:`run_get_mr_metadata` — pour ``walipr_get_mr_metadata``.
- :func:`run_get_mr_diff` — pour ``walipr_get_mr_diff``.
- :func:`run_get_mr_file` — pour ``walipr_get_mr_file``.
- :func:`run_submit_mr_review` — pour ``walipr_submit_mr_review``.

Le tool legacy ``review_merge_request`` reste intact et coexiste
(décision utilisateur Palier 10).
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Iterable, Optional

from .diff import parse_unified_diff
from .forges.auth import resolve_token
from .forges.base import ForgeClient, MergeRequestData
from .forges.bitbucket import BitbucketForgeClient
from .forges.errors import (
    DiffTooLargeError,
    ForgeAPIError,
    ForgeNotFoundError,
)
from .forges.github import GitHubForgeClient
from .forges.gitlab import GitLabForgeClient
from .forges.url import ForgeKind, ForgeRef, parse_mr_url


# ---------------------------------------------------------------------------
# Forge client factory (mockable côté tests)
# ---------------------------------------------------------------------------


def build_forge_client(ref: ForgeRef, token: str) -> ForgeClient:
    """Construit le :class:`ForgeClient` REST adapté à la forge cible.

    Identique à ``mr_review._build_forge_client`` mais exposé
    publiquement pour que les tools agentiques puissent l'utiliser
    sans dépendre de ``mr_review`` (qui tire ``review_diff`` et donc
    le LLM — pas voulu en mode agentique).
    """
    if ref.kind is ForgeKind.GITLAB:
        return GitLabForgeClient(token=token)
    if ref.kind is ForgeKind.GITHUB:
        return GitHubForgeClient(token=token)
    if ref.kind in (ForgeKind.BITBUCKET_CLOUD, ForgeKind.BITBUCKET_SERVER):
        return BitbucketForgeClient(token=token)
    raise ValueError(f"No forge client for kind {ref.kind!r}")


# ---------------------------------------------------------------------------
# Plan textuel (orchestrate)
# ---------------------------------------------------------------------------


_PLAN_FR = """\
# Plan de review WaliPR (mode agentique)

═══════════════════════════════════════════════════════════════════
RÈGLE D'OR — PORTÉE DE LA REVIEW
═══════════════════════════════════════════════════════════════════

**Tu ne reviewes QUE les changements introduits par cette MR/PR.**
PAS le code pré-existant. Si une fonction non touchée par le diff
contient un bug ancien, ce n'est PAS le sujet de cette review.

- ✅ Reviewer : les lignes `+` (ajoutées) et `-` (supprimées) du diff.
- ❌ Ne PAS reviewer : les lignes de contexte (lignes ` ` dans le diff)
  ni les autres parties du fichier non touchées par le diff.
- 🎯 Le contexte (fichier complet, call-sites, tests) sert
  EXCLUSIVEMENT à **comprendre l'impact** des changements — pas à
  être commenté pour lui-même.

Tout commentaire que tu postes DOIT pointer sur une ligne précise
issue du diff (numéro de ligne `+` côté nouvelle version).

═══════════════════════════════════════════════════════════════════
ÉTAPES
═══════════════════════════════════════════════════════════════════

À chaque étape, tu peux aussi utiliser tes propres outils
(`Read`, `Grep`, etc.) si le repo est cloné en local.

1. Appelle `walipr_get_mr_metadata(url)` pour comprendre l'**intention**
   de la MR : titre, description, branches, auteur, commits. Le titre
   et la description t'indiquent ce que la MR est censée accomplir —
   tu vas vérifier si les changements répondent bien à cette intention.

2. Appelle `walipr_get_mr_diff(url)` pour récupérer le diff unifié et
   la liste des fichiers touchés. **C'est ta source de vérité** pour
   savoir ce qui doit être reviewé.

3. Pour chaque fichier modifié non-trivial, charge du contexte
   **uniquement pour comprendre l'impact** des hunks du diff :
   a. Si le repo est cloné en local : ouvre le fichier avec ton outil
      `Read` natif pour voir le code complet (plus rapide, pas
      d'appel réseau).
   b. Sinon : appelle `walipr_get_mr_file(url, path, ref="head")` pour
      voir le fichier complet à la SHA de la MR.
   c. Si les lignes modifiées font référence à des classes/méthodes
      définies ailleurs, utilise `Grep` ou `walipr_get_mr_file` sur
      les fichiers connexes (call-sites, tests, configs) pour
      comprendre comment le changement affecte le reste du code.

   ⚠️ **N'analyse PAS le fichier complet ligne par ligne.** Le
   contexte est là pour t'aider à juger les CHANGEMENTS, pas pour
   trouver des bugs anciens. Si tu vois un problème dans du code
   pré-existant non touché par la MR : ignore-le ou mentionne-le
   uniquement dans le `summary` global, jamais en commentaire inline.

4. Analyse les **changements** avec une approche **Principal Software
   Engineer**. Pose-toi systématiquement la question : *« la MODIF
   introduit-elle un problème ? »* (pas : *« le code existant est-il
   parfait ? »*).
   - **Bugs introduits par le diff** : logique cassée, cas limites
     mal gérés, race conditions, off-by-one, null-safety dégradée,
     gestion d'erreur supprimée/affaiblie.
   - **Sécurité régressée** : injection introduite, contrôle d'accès
     supprimé, secret en dur ajouté, désérialisation non sûre.
   - **Performance dégradée** : N+1 ajouté, allocation inutile dans
     une hot loop modifiée, I/O bloquant introduit.
   - **Architecture cassée** : violation SOLID introduite, couplage
     excessif ajouté, dette technique non justifiée, contrat public
     cassé sans bump de version.
   - **Lisibilité de la modif** : noms ambigus dans le NOUVEAU code,
     valeur magique introduite, code mort ajouté.

   Catégorise chaque finding en **CRITICAL / HIGH / MEDIUM / LOW**.

5. **Règles strictes pour les commentaires inline** :
   - 🎯 Chaque commentaire DOIT pointer sur une ligne `+` (ajoutée)
     ou immédiatement adjacente à un `-` (supprimée) du diff. Si le
     numéro de ligne ne fait pas partie d'un hunk modifié, **ne
     poste pas le commentaire**.
   - ❌ Pas de commentaire sur les lignes de contexte (lignes ` `
     dans le diff).
   - ❌ Pas de commentaire sur des fichiers non listés dans
     `walipr_get_mr_diff(url).files`.
   - ❌ **Ne demande pas** à l'utilisateur de « vérifier »,
     « confirmer », « s'assurer » : soit tu as un constat actionnable,
     soit tu n'écris rien.

6. Quand ta review est complète, appelle :

   `walipr_submit_mr_review(url, summary, comments)`

   avec :
   - `summary` : 1-2 phrases résumant le changement et ton verdict
     global. C'est ici (et UNIQUEMENT ici) que tu peux mentionner
     une remarque sur du code pré-existant si elle est pertinente
     pour comprendre la MR.
   - `comments` : liste d'objets `{file_path, line, severity, body,
     suggestion?}`. `severity` ∈ {CRITICAL, HIGH, MEDIUM, LOW}. Le
     `line` doit être un numéro de ligne **présent dans un hunk du
     diff** (côté nouvelle version).

   Si la MR est parfaite après analyse approfondie, passe `comments=[]`
   — `summary` sera quand même posté en commentaire global pour
   indiquer que la review a eu lieu.

   Par défaut, les commentaires sont créés en **drafts** (équivalent
   « Add to review » sur GitLab) — ils ne sont PAS encore visibles
   au reviewé.

7. Termine en appelant :

   `walipr_publish_mr_review(url)`

   pour publier tous les drafts d'un coup en une **review groupée**
   (1 seule notification au lieu de N). C'est l'équivalent du
   bouton « Submit review ». Si tu veux laisser l'utilisateur
   relire/éditer/supprimer les drafts dans l'UI GitLab/GitHub avant
   publication, **n'appelle pas** ce tool — l'utilisateur cliquera
   « Submit review » lui-même.
"""


_PLAN_EN = """\
# WaliPR review plan (agentic mode)

═══════════════════════════════════════════════════════════════════
GOLDEN RULE — REVIEW SCOPE
═══════════════════════════════════════════════════════════════════

**You only review the changes introduced by THIS MR/PR.** NOT the
pre-existing code. If an untouched function contains an old bug,
it is NOT the subject of this review.

- ✅ Review: lines `+` (added) and `-` (removed) in the diff.
- ❌ Do NOT review: context lines (lines starting with ` ` in the
  diff) nor other parts of the file untouched by the diff.
- 🎯 Context (full file, call-sites, tests) serves EXCLUSIVELY to
  **understand the impact** of the changes — never to be commented
  on for its own sake.

Every comment you post MUST point to a specific line that is part
of the diff (line number on the new side `+`).

═══════════════════════════════════════════════════════════════════
STEPS
═══════════════════════════════════════════════════════════════════

At each step you may also use your own native tools (`Read`, `Grep`,
…) if the repo is cloned locally.

1. Call `walipr_get_mr_metadata(url)` to understand the **intent** of
   the MR: title, description, branches, author, commits. The title
   and description tell you what the MR is meant to accomplish — you
   will check whether the changes match this intent.

2. Call `walipr_get_mr_diff(url)` to retrieve the unified diff and the
   list of touched files. **This is your source of truth** for what
   needs to be reviewed.

3. For each non-trivial modified file, load context **only to
   understand the impact** of the diff hunks:
   a. If the repo is cloned locally: open the file with your native
      `Read` tool to see the full code (faster, no network).
   b. Otherwise: call `walipr_get_mr_file(url, path, ref="head")` to
      retrieve the full file content at the MR's SHA.
   c. If the modified lines reference classes/methods defined
      elsewhere, use `Grep` or `walipr_get_mr_file` on related files
      (call-sites, tests, configs) to understand how the change
      affects the rest of the code.

   ⚠️ **Do NOT analyse the full file line by line.** Context is
   there to help you judge the CHANGES, not to find old bugs. If
   you spot an issue in pre-existing code untouched by the MR:
   ignore it or mention it only in the global `summary`, never as
   an inline comment.

4. Analyse the **changes** with a **Principal Software Engineer**
   mindset. Always ask yourself: *"does THIS CHANGE introduce a
   problem?"* (not: *"is the existing code perfect?"*).
   - **Bugs introduced by the diff**: broken logic, mishandled edge
     cases, race conditions, off-by-one, weakened null-safety,
     removed/weakened error handling.
   - **Regressed security**: injection introduced, removed access
     control, hardcoded secret added, unsafe deserialization.
   - **Degraded performance**: added N+1, useless allocation in a
     modified hot loop, blocking I/O introduced.
   - **Broken architecture**: introduced SOLID violation, added
     excessive coupling, unjustified tech debt, broken public
     contract without version bump.
   - **Readability of the change**: ambiguous names in the NEW
     code, magic value introduced, added dead code.

   Tag each finding as **CRITICAL / HIGH / MEDIUM / LOW**.

5. **Strict rules for inline comments**:
   - 🎯 Each comment MUST point to a `+` (added) line, or
     immediately adjacent to a `-` (removed) line, in the diff.
     If the line number is not part of a modified hunk, **do not
     post the comment**.
   - ❌ No comment on context lines (lines starting with ` ` in
     the diff).
   - ❌ No comment on files not listed in
     `walipr_get_mr_diff(url).files`.
   - ❌ **Do not** ask the user to "check", "confirm", or "ensure"
     anything: either you have an actionable finding, or you
     write nothing.

6. When your review is complete, call:

   `walipr_submit_mr_review(url, summary, comments)`

   with:
   - `summary`: 1-2 sentences summarising the change and your
     overall verdict. This is the only place where you may mention
     a remark on pre-existing code if it is relevant to understand
     the MR.
   - `comments`: list of `{file_path, line, severity, body,
     suggestion?}` objects. `severity` ∈ {CRITICAL, HIGH, MEDIUM,
     LOW}. The `line` must be a line number **present in a hunk of
     the diff** (new side).

   If the MR is perfect after deep analysis, pass `comments=[]` —
   `summary` will still be posted as a global comment to record that
   the review happened.

   By default, comments are created as **drafts** (equivalent of
   GitLab UI "Add to review") — they are NOT visible to the
   reviewed user yet.

7. Finish by calling:

   `walipr_publish_mr_review(url)`

   to publish all drafts at once as a **grouped review** (1 single
   notification instead of N). This is the equivalent of the
   "Submit review" button. If you want to let the user
   review/edit/delete the drafts in the GitLab/GitHub UI before
   publishing, **do not call** this tool — the user will click
   "Submit review" themselves.
"""


_TOOLS_TO_USE = [
    "walipr_get_mr_metadata",
    "walipr_get_mr_diff",
    "walipr_get_mr_file",
    "walipr_submit_mr_review",
    "walipr_publish_mr_review",
]


def build_orchestrate_payload(url: str, *, language: str = "fr") -> dict[str, Any]:
    """Retourne le payload du tool ``walipr_review_mr_orchestrate``.

    **Aucun appel réseau, aucun appel LLM.** On valide l'URL via
    :func:`parse_mr_url` (pour fail-fast sur les URLs malformées) et
    on retourne le plan textuel. Le LLM hôte se charge ensuite
    d'appeler les autres tools dans l'ordre.

    Si ``language`` n'est ni ``"fr"`` ni ``"en"``, on retombe sur
    ``"fr"`` (cohérent avec ``review.py::_coerce_language``).
    """
    ref = parse_mr_url(url)  # peut lever UnsupportedForgeError
    lang = "en" if (language or "").strip().lower() == "en" else "fr"
    plan = _PLAN_EN if lang == "en" else _PLAN_FR
    return {
        "url": url,
        "language": lang,
        "forge": ref.kind.value,
        "project": ref.project,
        "iid": ref.iid,
        "plan": plan,
        "tools_to_use": list(_TOOLS_TO_USE),
    }


# ---------------------------------------------------------------------------
# walipr_get_mr_metadata
# ---------------------------------------------------------------------------


def _serialize_mr_metadata(mr_data: MergeRequestData) -> dict[str, Any]:
    return {
        "url": mr_data.ref.canonical_url,
        "title": mr_data.title,
        "description": mr_data.description,
        "source_branch": mr_data.source_branch,
        "target_branch": mr_data.target_branch,
        "source_sha": mr_data.source_sha,
        "base_sha": mr_data.base_sha,
        "web_url": mr_data.web_url,
        "diff_size_lines": mr_data.diff_size_lines,
    }


def run_get_mr_metadata(
    url: str,
    *,
    explicit_token: Optional[str] = None,
    forge_client: Optional[ForgeClient] = None,
) -> dict[str, Any]:
    """Helper synchrone pour le tool ``walipr_get_mr_metadata``.

    Récupère les métadonnées de la MR sans le diff (le diff arrive
    dans :func:`run_get_mr_diff`). En pratique, l'API forge renvoie
    quand même le diff dans ``fetch_mr`` — on l'inclut dans
    ``mr_data`` pour calculer ``diff_size_lines`` mais on ne le
    sérialise pas (économie de tokens côté agent).

    ``forge_client`` est injectable pour les tests (sinon construit
    via :func:`build_forge_client` + :func:`resolve_token`).
    """
    ref = parse_mr_url(url)
    if forge_client is None:
        token = resolve_token(ref.kind, explicit_token=explicit_token)
        forge_client = build_forge_client(ref, token)
    mr_data = forge_client.fetch_mr(ref)
    return _serialize_mr_metadata(mr_data)


# ---------------------------------------------------------------------------
# walipr_get_mr_diff
# ---------------------------------------------------------------------------


def run_get_mr_diff(
    url: str,
    *,
    max_diff_lines: int = 5000,
    explicit_token: Optional[str] = None,
    forge_client: Optional[ForgeClient] = None,
) -> dict[str, Any]:
    """Helper pour le tool ``walipr_get_mr_diff``.

    Récupère le diff unifié + la liste des fichiers touchés (avec
    métadonnées légères : new/deleted/renamed/binary, count des
    hunks). Soft-fail :class:`DiffTooLargeError` si le diff dépasse
    ``max_diff_lines``.
    """
    ref = parse_mr_url(url)
    if forge_client is None:
        token = resolve_token(ref.kind, explicit_token=explicit_token)
        forge_client = build_forge_client(ref, token)
    mr_data = forge_client.fetch_mr(ref)
    if mr_data.diff_size_lines > max_diff_lines:
        raise DiffTooLargeError(
            lines=mr_data.diff_size_lines, limit=max_diff_lines,
        )
    file_diffs = parse_unified_diff(mr_data.diff_unified)
    files_summary: list[dict[str, Any]] = []
    for f in file_diffs:
        files_summary.append({
            "path": f.path,
            "old_path": f.old_path,
            "is_new": f.is_new,
            "is_deleted": f.is_deleted,
            "is_renamed": f.is_renamed,
            "is_binary": f.is_binary,
            "hunks_count": len(f.hunks),
        })
    return {
        "url": mr_data.ref.canonical_url,
        "source_sha": mr_data.source_sha,
        "diff_size_lines": mr_data.diff_size_lines,
        "files": files_summary,
        "diff_unified": mr_data.diff_unified,
    }


# ---------------------------------------------------------------------------
# walipr_get_mr_file
# ---------------------------------------------------------------------------


def _resolve_ref_alias(mr_data: MergeRequestData, ref: str) -> str:
    """Convertit un alias humain (``"head"``/``"base"``) en SHA / branch.

    - ``"head"`` (défaut) → ``source_sha`` (la version proposée par la MR).
    - ``"base"`` → ``base_sha`` si dispo, sinon ``target_branch``.
    - Sinon : utilisé tel quel (l'agent peut passer un SHA explicite).
    """
    alias = (ref or "").strip().lower()
    if alias == "head" or not alias:
        return mr_data.source_sha
    if alias == "base":
        return mr_data.base_sha or mr_data.target_branch
    return ref


def run_get_mr_file(
    url: str,
    path: str,
    *,
    ref: str = "head",
    explicit_token: Optional[str] = None,
    forge_client: Optional[ForgeClient] = None,
) -> dict[str, Any]:
    """Helper pour le tool ``walipr_get_mr_file``.

    Récupère le contenu **complet** d'un fichier au SHA de la MR. Sert
    à donner du contexte autour des hunks (le diff seul est rarement
    suffisant pour juger un changement).

    ``ref`` accepte les alias ``"head"`` / ``"base"`` ou un SHA brut.
    """
    forge_ref = parse_mr_url(url)
    if forge_client is None:
        token = resolve_token(forge_ref.kind, explicit_token=explicit_token)
        forge_client = build_forge_client(forge_ref, token)
    mr_data = forge_client.fetch_mr(forge_ref)
    sha = _resolve_ref_alias(mr_data, ref)
    content = forge_client.fetch_file(forge_ref, path, sha)
    return {
        "url": mr_data.ref.canonical_url,
        "path": path,
        "ref": ref,
        "sha": sha,
        "content": content,
        "size_bytes": len(content.encode("utf-8")),
    }


# ---------------------------------------------------------------------------
# walipr_submit_mr_review
# ---------------------------------------------------------------------------


def _validate_comment(entry: Any) -> Optional[dict[str, Any]]:
    """Valide un dict comment + normalise. Retourne ``None`` si invalide.

    Forme attendue : ``{file_path: str, line: int, severity: str,
    body: str, suggestion?: str}``. Tolère ``severity`` en
    minuscules ou en ``info|minor|major|blocker`` (mappé vers
    ``LOW|MEDIUM|HIGH|CRITICAL`` informativement).
    """
    if not isinstance(entry, dict):
        return None
    file_path = entry.get("file_path") or entry.get("file")
    if not isinstance(file_path, str) or not file_path.strip():
        return None
    line = entry.get("line")
    try:
        line_i = int(line) if line is not None else None
    except (TypeError, ValueError):
        return None
    if line_i is None or line_i < 1:
        return None
    body = entry.get("body") or entry.get("message")
    if not isinstance(body, str) or not body.strip():
        return None
    severity = entry.get("severity")
    if not isinstance(severity, str):
        severity = "MEDIUM"
    suggestion = entry.get("suggestion")
    if isinstance(suggestion, str) and suggestion.strip():
        suggestion_str: Optional[str] = suggestion.strip()
    else:
        suggestion_str = None
    return {
        "file_path": file_path.strip(),
        "line": line_i,
        "severity": severity.strip(),
        "body": body.strip(),
        "suggestion": suggestion_str,
    }


def _render_inline_body_agentic(comment: dict[str, Any]) -> str:
    """Rend un commentaire inline pour ``walipr_submit_mr_review``.

    Format markdown court (la note est posée à côté de la ligne).
    Pas le même format que :func:`mr_review._render_inline_body`
    (qui utilise des emojis / categories du LLM legacy) — ici on
    reste sobre et factuel.
    """
    parts = [
        f"**WaliPR** [{comment['severity']}]",
        "",
        comment["body"],
    ]
    if comment.get("suggestion"):
        parts.append("")
        parts.append(f"**Suggestion** : {comment['suggestion']}")
    return "\n".join(parts)


def run_submit_mr_review(
    url: str,
    summary: str,
    comments: Iterable[Any],
    *,
    draft: bool = True,
    explicit_token: Optional[str] = None,
    forge_client: Optional[ForgeClient] = None,
) -> dict[str, Any]:
    """Helper pour le tool ``walipr_submit_mr_review``.

    Itère sur ``comments`` et poste un commentaire inline par finding
    valide. Si ``summary`` est non vide, poste aussi un commentaire
    général.

    **P10.2 — Mode drafts par défaut** (``draft=True``) : les
    commentaires ne sont **pas publiés immédiatement** ; ils sont
    créés en draft (équivalent UI GitLab « Add to review »). Le LLM
    hôte (ou l'utilisateur) appelle ensuite
    :func:`run_publish_mr_review` (tool ``walipr_publish_mr_review``)
    pour les publier d'un coup. Beaucoup plus propre côté reviewé :
    1 seule notification au lieu d'1 par commentaire.

    Si ``draft=False``, l'ancien comportement est conservé :
    publication immédiate via ``post_comment`` / ``post_inline_comment``
    (1 notif par commentaire, pas de regroupement).

    Robustesse : un échec individuel sur un finding (ligne hors diff,
    auth scope insuffisant…) **n'arrête pas** la boucle. Les échecs
    sont collectés dans ``failures`` et retournés à l'agent.
    """
    ref = parse_mr_url(url)
    if forge_client is None:
        token = resolve_token(ref.kind, explicit_token=explicit_token)
        forge_client = build_forge_client(ref, token)
    mr_data = forge_client.fetch_mr(ref)

    # Comment global (summary)
    comment_url = ""
    summary_posted = False
    if isinstance(summary, str) and summary.strip():
        try:
            if draft:
                forge_client.post_global_draft(ref, summary.strip())
                summary_posted = True
                # Pas d'URL publique pour un draft
                comment_url = ""
            else:
                outcome = forge_client.post_comment(ref, summary.strip())
                comment_url = outcome.url
                summary_posted = True
        except Exception:
            summary_posted = False
            comment_url = ""

    # Inline comments
    posted_inline = 0
    attempted = 0
    skipped = 0
    failures: list[dict[str, Any]] = []
    for raw in comments or []:
        normalized = _validate_comment(raw)
        if normalized is None:
            skipped += 1
            continue
        attempted += 1
        body = _render_inline_body_agentic(normalized)
        try:
            if draft:
                forge_client.post_inline_draft(
                    ref,
                    mr_data,
                    normalized["file_path"],
                    int(normalized["line"]),
                    body,
                )
            else:
                forge_client.post_inline_comment(
                    ref,
                    mr_data,
                    normalized["file_path"],
                    int(normalized["line"]),
                    body,
                )
            posted_inline += 1
        except Exception as exc:  # noqa: BLE001
            failures.append({
                "file_path": normalized["file_path"],
                "line": normalized["line"],
                "error": f"{type(exc).__name__}: {exc}",
            })
    return {
        "url": mr_data.ref.canonical_url,
        "draft_mode": draft,
        "summary_posted": summary_posted,
        "comment_url": comment_url,
        "posted_inline": posted_inline,
        "attempted_inline": attempted,
        "skipped_invalid": skipped,
        "failures": failures,
        # Hint actionnable pour l'agent quand on est en mode drafts.
        "next_action": (
            "Call walipr_publish_mr_review(url) to publish all drafts "
            "as a single review (recommended), OR let the user click "
            "'Submit review' in the forge UI."
        ) if draft else "",
    }


def run_publish_mr_review(
    url: str,
    *,
    explicit_token: Optional[str] = None,
    forge_client: Optional[ForgeClient] = None,
) -> dict[str, Any]:
    """Helper pour le tool ``walipr_publish_mr_review`` (P10.2).

    Publie tous les drafts en attente sur la MR (équivalent UI
    GitLab « Submit review »). Délègue à
    :meth:`ForgeClient.publish_drafts` pour la mécanique
    forge-spécifique :

    - **GitLab** : ``PUT /draft_notes/bulk_publish`` (drafts natifs).
    - **GitHub** : submit la pending review courante via
      ``POST /reviews/:rid/events`` (event=COMMENT).
    - **Bitbucket** : flush du buffer mémoire (drafts simulés —
      attention, ne survivent pas à un nouveau process / nouveau
      client).

    **Important** : pour GitHub et Bitbucket, le résultat dépend du
    fait que le client soit la même instance que celle ayant créé
    les drafts. Comme :func:`build_forge_client` est appelé par
    chaque tool MCP, l'instance change entre tools — donc en
    pratique pour ces deux forges il faut soit :

    - utiliser ``walipr_submit_mr_review(draft=False)`` (publication
      immédiate),
    - OU faire submit + publish dans le **même appel tool** (n'est
      pas le scope de ce palier — palier futur).

    GitLab fonctionne pleinement car les drafts sont stockés
    server-side, pas dans le client.
    """
    ref = parse_mr_url(url)
    if forge_client is None:
        token = resolve_token(ref.kind, explicit_token=explicit_token)
        forge_client = build_forge_client(ref, token)
    try:
        published = forge_client.publish_drafts(ref)
        return {
            "url": ref.canonical_url,
            "published": int(published),
            "error": "",
        }
    except NotImplementedError as exc:
        return {
            "url": ref.canonical_url,
            "published": 0,
            "error": f"not_supported: {exc}",
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "url": ref.canonical_url,
            "published": 0,
            "error": f"{type(exc).__name__}: {exc}",
        }


__all__ = [
    "build_forge_client",
    "build_orchestrate_payload",
    "run_get_mr_diff",
    "run_get_mr_file",
    "run_get_mr_metadata",
    "run_publish_mr_review",
    "run_submit_mr_review",
]
