"""Sélection multi-langues des standards de code pour WaliPR.

Pipeline :

1. :func:`detect_languages` — itère les :class:`FileDiff`, mappe chaque
   extension à un langage connu, dédup et trie alpha. Les fichiers sans
   extension supportée sont ignorés (mais comptés dans
   :class:`StandardsBundle.files_uncovered`).
2. :func:`load_standards_for_languages` — concatène les fichiers
   ``standards_<lang>.md`` embarqués dans le package, en ajoutant un
   en-tête ``## Standards <Langage>`` par jeu.
3. :func:`build_standards_bundle` — combinaison auto pour un diff
   donné (utilisée comme fallback quand l'utilisateur ne passe pas
   d'override ``standards=`` ou ``languages=``).

Les fichiers MD sont lus via ``Path(__file__).parent / "standards_<lang>.md"``
pour rester cohérent avec :func:`mcp_server._load_standards_kotlin`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Mapping, Optional

from .diff import FileDiff


# ---------------------------------------------------------------------------
# Mapping extension → langage
# ---------------------------------------------------------------------------
#
# Clé : extension (lowercase, avec point initial).
# Valeur : nom du langage tel qu'utilisé dans le nom de fichier
# ``standards_<lang>.md`` ET dans la sortie ``languages_detected``.
#
# Pour ajouter un langage : (1) déposer ``standards_<lang>.md`` à côté
# de ce module, (2) ajouter ses extensions ici. Le label visible
# (titre Markdown) est défini dans :data:`_LANG_LABELS` plus bas.

_LANG_BY_EXT: Mapping[str, str] = {
    ".kt": "kotlin",
    ".kts": "kotlin",
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "typescript",  # même jeu de standards que TS
    ".jsx": "typescript",
    ".java": "java",
}

_LANG_LABELS: Mapping[str, str] = {
    "kotlin": "Kotlin",
    "python": "Python",
    "typescript": "TypeScript / JavaScript",
    "java": "Java",
}

# Liste des langages avec un fichier de standards livré (utile pour la
# validation de l'override CLI ``--standards``). Calculé par
# :func:`available_languages` pour rester source-of-truth = filesystem.


_PACKAGE_DIR = Path(__file__).resolve().parent


@dataclass(frozen=True)
class StandardsBundle:
    """Résultat de la sélection multi-langues pour un diff donné."""

    languages: tuple[str, ...]
    text: str
    files_covered: int
    files_uncovered: tuple[str, ...] = field(default_factory=tuple)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extension_of(path: str) -> str:
    """Retourne l'extension lowercase (avec le point), ou ``""`` si aucune."""
    # On évite Path() pour rester tolérant aux séparateurs Windows
    # éventuels qui apparaîtraient dans un diff (rare, mais possible).
    name = path.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    if "." not in name:
        return ""
    # Cas ``.dotfile`` (pas d'extension utile) → dernier point seulement
    # s'il n'est pas en tête de nom.
    if name.startswith(".") and name.count(".") == 1:
        return ""
    return "." + name.rsplit(".", 1)[-1].lower()


def available_languages() -> tuple[str, ...]:
    """Liste des langages avec un fichier ``standards_<lang>.md`` présent.

    Source of truth = filesystem (pas le mapping). Permet de valider
    un override utilisateur sans risquer de référencer un MD absent.

    Les fichiers `standards_<lang>_extras.md` (P10 — conventions
    officielles complémentaires, voir `standards_kotlin_extras.md`)
    sont **exclus** : ce ne sont pas des langages séparés mais des
    suppléments chargés automatiquement quand le langage de base
    est sélectionné (cf. :func:`load_standards_for_languages`).
    """
    found: list[str] = []
    for path in sorted(_PACKAGE_DIR.glob("standards_*.md")):
        # ``standards_kotlin.md`` → ``kotlin``
        stem = path.stem  # ``standards_kotlin``
        if not stem.startswith("standards_"):
            continue
        lang = stem[len("standards_") :]
        # Skip les fichiers d'extras (P10) : ce sont des compléments
        # rattachés à un langage de base via le suffixe ``_extras``,
        # pas des langages indépendants.
        if not lang or lang.endswith("_extras"):
            continue
        found.append(lang)
    return tuple(found)


def detect_languages(file_diffs: Iterable[FileDiff]) -> list[str]:
    """Détecte les langages couverts par un diff.

    Retourne une liste **dédupliquée et triée alphabétiquement** pour
    que le rendu et les tests soient déterministes. Les fichiers sans
    extension reconnue sont silencieusement ignorés (comptés ailleurs
    via :func:`files_uncovered_for`).
    """
    seen: set[str] = set()
    for f in file_diffs:
        ext = _extension_of(f.path)
        lang = _LANG_BY_EXT.get(ext)
        if lang:
            seen.add(lang)
    return sorted(seen)


def files_uncovered_for(file_diffs: Iterable[FileDiff]) -> list[str]:
    """Liste les chemins du diff dont l'extension n'a aucun standard.

    Exclut les binaires (déjà skippés par :mod:`.review`) et les
    fichiers sans hunks (renames purs, métadonnées).
    """
    out: list[str] = []
    for f in file_diffs:
        if f.is_binary or not f.hunks:
            continue
        ext = _extension_of(f.path)
        if ext not in _LANG_BY_EXT:
            out.append(f.path)
    return out


def load_standards_for_languages(languages: Iterable[str]) -> str:
    """Concatène les MD ``standards_<lang>.md`` pour ``languages``.

    Chaque MD est précédé d'un en-tête ``## Standards <Label>`` (le
    label venant de :data:`_LANG_LABELS`, ou capitalisé à défaut).
    Les langages absents du filesystem sont silencieusement ignorés
    (à l'appelant de valider via :func:`available_languages` s'il
    veut un comportement strict).

    P10 — Si un fichier ``standards_<lang>_extras.md`` existe à côté
    (conventions officielles complémentaires, ex.
    ``standards_kotlin_extras.md`` qui synthétise Kotlin Coding
    Conventions + Android Style Guide + API Guidelines + Coroutines
    best practices), il est automatiquement concaténé après le
    fichier de base avec son propre header
    ``## Standards <Label> — conventions officielles``. Permet
    d'enrichir le prompt sans toucher au fichier projet.
    """
    parts: list[str] = []
    seen: set[str] = set()
    for lang in languages:
        if not isinstance(lang, str):
            continue
        key = lang.strip().lower()
        if not key or key in seen:
            continue
        seen.add(key)
        md_path = _PACKAGE_DIR / f"standards_{key}.md"
        if not md_path.exists():
            continue
        try:
            body = md_path.read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if not body:
            continue
        label = _LANG_LABELS.get(key, key.capitalize())
        parts.append(f"## Standards {label}\n\n{body}")

        # P10 — extras officiels (chargés silencieusement si présents).
        extras_path = _PACKAGE_DIR / f"standards_{key}_extras.md"
        if extras_path.exists():
            try:
                extras_body = extras_path.read_text(encoding="utf-8").strip()
            except OSError:
                extras_body = ""
            if extras_body:
                parts.append(
                    f"## Standards {label} — conventions officielles\n\n"
                    f"{extras_body}"
                )
    return "\n\n".join(parts)


def build_standards_bundle(
    file_diffs: Iterable[FileDiff],
    *,
    languages_override: Optional[Iterable[str]] = None,
) -> StandardsBundle:
    """Construit le bundle de standards pour ``file_diffs``.

    - Si ``languages_override`` est fourni : utilisé tel quel (après
      normalisation lowercase + dédup, ordre conservé). Pas de
      détection auto.
    - Sinon : détection auto via :func:`detect_languages`.

    Le ``text`` peut être vide si aucun langage supporté n'est
    couvert ; dans ce cas l'appelant (review) doit prévoir un
    fallback « pas de standards spécifiques ».
    """
    file_list = list(file_diffs)

    if languages_override is not None:
        # Override explicite : on respecte l'ordre fourni, mais on
        # dédup (lowercase) et on filtre les valeurs vides.
        ordered: list[str] = []
        seen: set[str] = set()
        for lang in languages_override:
            if not isinstance(lang, str):
                continue
            key = lang.strip().lower()
            if not key or key in seen:
                continue
            seen.add(key)
            ordered.append(key)
        languages = ordered
    else:
        languages = detect_languages(file_list)

    text = load_standards_for_languages(languages)
    uncovered = tuple(files_uncovered_for(file_list)) if languages_override is None else ()
    # Quand override : la couverture n'a plus le même sens (l'utilisateur
    # impose un jeu indépendamment du diff) → on n'expose pas
    # ``files_uncovered``.
    covered = len(file_list) - len(uncovered) if languages_override is None else len(file_list)

    return StandardsBundle(
        languages=tuple(languages),
        text=text,
        files_covered=covered,
        files_uncovered=uncovered,
    )
