"""Cache disque pour les revues WaliPR (P6).

Évite les appels LLM redondants en sérialisant le ``ReviewResult`` sur
disque, indexé par une clé composite déterministe :

    SHA-256(diff_brut + standards_bundle + langues_triées + nom_modèle)

Si l'un de ces éléments change, la clé change et le cache est invalidé
naturellement (pas de TTL strict requis pour cette dimension).

Stockage : ``<repo_root>/.walipr-cache/<key>.json`` (gitignoré
automatiquement, cf. :func:`ensure_gitignore_entry`).

TTL : 7 jours par défaut (paramétrable). Au-delà, l'entrée est
considérée expirée et le cache est traité comme un MISS.

Le cache est **opt-in** : la CLI et le MCP ne l'activent que si
l'utilisateur passe ``--cache`` / ``use_cache=True``. Aucun
comportement par défaut n'est modifié.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .review import ReviewFinding, ReviewResult, SuggestedPatch

log = logging.getLogger(__name__)


CACHE_DIRNAME = ".walipr-cache"
DEFAULT_TTL_SECONDS = 7 * 24 * 3600  # 7 jours
_CACHE_VERSION = 1  # bump si le format JSON change de façon non rétro-compat


# ---------------------------------------------------------------------------
# Clé de cache
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class ReviewCacheKey:
    """Composantes de la clé composite (avant hash)."""

    diff_text: str
    standards_text: str
    languages: tuple[str, ...]
    model_name: str

    def compute(self) -> str:
        """Calcule le SHA-256 hex de la clé composite.

        Les langues sont triées avant hash pour stabilité (l'ordre ne
        doit pas changer la clé).
        """
        h = hashlib.sha256()
        h.update(b"walipr-cache-v")
        h.update(str(_CACHE_VERSION).encode("utf-8"))
        h.update(b"\x00")
        h.update(b"diff:")
        h.update(self.diff_text.encode("utf-8", errors="replace"))
        h.update(b"\x00")
        h.update(b"standards:")
        h.update(self.standards_text.encode("utf-8", errors="replace"))
        h.update(b"\x00")
        h.update(b"languages:")
        h.update(",".join(sorted(self.languages)).encode("utf-8"))
        h.update(b"\x00")
        h.update(b"model:")
        h.update(self.model_name.encode("utf-8"))
        return h.hexdigest()


def compute_key(
    *,
    diff_text: str,
    standards_text: str,
    languages: tuple[str, ...],
    model_name: str,
) -> str:
    """Helper de surface (équivalent à ``ReviewCacheKey(...).compute()``)."""
    return ReviewCacheKey(
        diff_text=diff_text,
        standards_text=standards_text,
        languages=languages,
        model_name=model_name,
    ).compute()


# ---------------------------------------------------------------------------
# Sérialisation ReviewResult ↔ JSON
# ---------------------------------------------------------------------------


def _suggested_patch_to_dict(p: Optional[SuggestedPatch]) -> Optional[dict[str, Any]]:
    if p is None:
        return None
    return {
        "unified_diff": p.unified_diff,
        "file": p.file,
        "line_start": p.line_start,
        "line_end": p.line_end,
        "replacement": p.replacement,
    }


def _suggested_patch_from_dict(
    data: Optional[dict[str, Any]],
) -> Optional[SuggestedPatch]:
    if not isinstance(data, dict):
        return None
    return SuggestedPatch(
        unified_diff=data.get("unified_diff"),
        file=data.get("file"),
        line_start=data.get("line_start"),
        line_end=data.get("line_end"),
        replacement=data.get("replacement"),
    )


def _finding_to_dict(f: ReviewFinding) -> dict[str, Any]:
    return {
        "file": f.file,
        "line": f.line,
        "severity": f.severity,
        "category": f.category,
        "message": f.message,
        "suggestion": f.suggestion,
        "suggested_patch": _suggested_patch_to_dict(f.suggested_patch),
    }


def _finding_from_dict(data: dict[str, Any]) -> Optional[ReviewFinding]:
    file = data.get("file")
    message = data.get("message")
    if not isinstance(file, str) or not isinstance(message, str):
        return None
    severity = data.get("severity")
    if severity not in ("info", "minor", "major", "blocker"):
        severity = "info"
    category = data.get("category") or "other"
    line = data.get("line")
    if not (line is None or isinstance(line, int)):
        line = None
    suggestion = data.get("suggestion")
    if not (suggestion is None or isinstance(suggestion, str)):
        suggestion = None
    return ReviewFinding(
        file=file,
        line=line,
        severity=severity,  # type: ignore[arg-type]
        category=str(category),
        message=message,
        suggestion=suggestion,
        suggested_patch=_suggested_patch_from_dict(data.get("suggested_patch")),
    )


def _result_to_dict(result: ReviewResult) -> dict[str, Any]:
    return {
        "summary": result.summary,
        "score": result.score,
        "languages": list(result.languages),
        "findings": [_finding_to_dict(f) for f in result.findings],
    }


def _result_from_dict(data: dict[str, Any]) -> ReviewResult:
    summary = data.get("summary")
    if not isinstance(summary, str):
        summary = "(résumé manquant)"
    score = data.get("score")
    if not (score is None or isinstance(score, (int, float))):
        score = None
    languages_raw = data.get("languages") or []
    if not isinstance(languages_raw, list):
        languages_raw = []
    findings_raw = data.get("findings") or []
    if not isinstance(findings_raw, list):
        findings_raw = []
    findings: list[ReviewFinding] = []
    for entry in findings_raw:
        if isinstance(entry, dict):
            f = _finding_from_dict(entry)
            if f is not None:
                findings.append(f)
    return ReviewResult(
        summary=summary,
        score=float(score) if score is not None else None,
        languages=tuple(str(x) for x in languages_raw),
        findings=tuple(findings),
    )


# ---------------------------------------------------------------------------
# Couche disque
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class CacheEntry:
    """Entrée matérialisée sur disque (résultat + métadonnées)."""

    key: str
    stored_at: float  # epoch seconds
    result: ReviewResult


def cache_dir_for(repo_root: Path) -> Path:
    """Résout ``<repo_root>/.walipr-cache`` (sans le créer)."""
    return Path(repo_root).resolve() / CACHE_DIRNAME


def _entry_path(cache_dir: Path, key: str) -> Path:
    return cache_dir / f"{key}.json"


def load_entry(
    repo_root: Path,
    key: str,
    *,
    ttl_seconds: int = DEFAULT_TTL_SECONDS,
    now: Optional[float] = None,
) -> Optional[CacheEntry]:
    """Charge l'entrée si elle existe ET n'est pas expirée. None sinon.

    Une entrée corrompue (JSON invalide, champs manquants) est traitée
    comme absente — on log au niveau ``warning`` mais on ne lève pas.
    """
    path = _entry_path(cache_dir_for(repo_root), key)
    if not path.is_file():
        return None
    try:
        raw = path.read_text(encoding="utf-8")
        data = json.loads(raw)
    except (OSError, json.JSONDecodeError) as exc:
        log.warning("cache entry %s unreadable: %s", path, exc)
        return None
    if not isinstance(data, dict):
        return None
    stored_at = data.get("stored_at")
    if not isinstance(stored_at, (int, float)):
        return None
    current = now if now is not None else time.time()
    if current - float(stored_at) > ttl_seconds:
        return None
    result_data = data.get("result")
    if not isinstance(result_data, dict):
        return None
    return CacheEntry(
        key=str(data.get("key") or key),
        stored_at=float(stored_at),
        result=_result_from_dict(result_data),
    )


def store_entry(
    repo_root: Path,
    key: str,
    result: ReviewResult,
    *,
    now: Optional[float] = None,
) -> Path:
    """Persiste ``result`` sous la clé ``key``.

    Crée ``.walipr-cache/`` si besoin et ajoute l'entrée gitignore
    one-shot (cf. :func:`ensure_gitignore_entry`). Renvoie le chemin
    écrit.
    """
    repo = Path(repo_root).resolve()
    cache_dir = cache_dir_for(repo)
    cache_dir.mkdir(parents=True, exist_ok=True)
    ensure_gitignore_entry(repo)
    path = _entry_path(cache_dir, key)
    payload = {
        "version": _CACHE_VERSION,
        "key": key,
        "stored_at": float(now if now is not None else time.time()),
        "result": _result_to_dict(result),
    }
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return path


# ---------------------------------------------------------------------------
# Maintenance
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class PurgeOutcome:
    """Résultat d'une purge (totale ou TTL-only)."""

    removed: int
    kept: int
    cache_dir: Path


def purge_all(repo_root: Path) -> PurgeOutcome:
    """Supprime toutes les entrées ``*.json`` du répertoire de cache.

    Le répertoire ``.walipr-cache/`` lui-même est conservé (utile pour
    garder le suivi gitignore intact).
    """
    cache_dir = cache_dir_for(repo_root)
    if not cache_dir.is_dir():
        return PurgeOutcome(removed=0, kept=0, cache_dir=cache_dir)
    removed = 0
    for entry in cache_dir.glob("*.json"):
        try:
            entry.unlink()
            removed += 1
        except OSError as exc:
            log.warning("cannot remove %s: %s", entry, exc)
    return PurgeOutcome(removed=removed, kept=0, cache_dir=cache_dir)


def purge_expired(
    repo_root: Path,
    *,
    ttl_seconds: int = DEFAULT_TTL_SECONDS,
    now: Optional[float] = None,
) -> PurgeOutcome:
    """Supprime uniquement les entrées plus vieilles que ``ttl_seconds``."""
    cache_dir = cache_dir_for(repo_root)
    if not cache_dir.is_dir():
        return PurgeOutcome(removed=0, kept=0, cache_dir=cache_dir)
    current = now if now is not None else time.time()
    removed = 0
    kept = 0
    for entry in cache_dir.glob("*.json"):
        try:
            data = json.loads(entry.read_text(encoding="utf-8"))
            stored_at = data.get("stored_at")
            if (
                isinstance(stored_at, (int, float))
                and current - float(stored_at) <= ttl_seconds
            ):
                kept += 1
                continue
        except (OSError, json.JSONDecodeError):
            # Entrée corrompue → on la traite comme expirée.
            pass
        try:
            entry.unlink()
            removed += 1
        except OSError as exc:
            log.warning("cannot remove %s: %s", entry, exc)
    return PurgeOutcome(removed=removed, kept=kept, cache_dir=cache_dir)


# ---------------------------------------------------------------------------
# .gitignore one-shot
# ---------------------------------------------------------------------------


_GITIGNORE_LINE = ".walipr-cache/"
_GITIGNORE_HEADER = "# WaliPR review cache (auto-added by --cache)"


def ensure_gitignore_entry(repo_root: Path) -> bool:
    """Ajoute ``.walipr-cache/`` à ``<repo>/.gitignore`` si absent.

    Idempotent : si la ligne (ou ``.walipr-cache``, ``/.walipr-cache/``…)
    existe déjà, ne fait rien. Si ``.gitignore`` n'existe pas, le crée.
    Renvoie ``True`` si une modification a eu lieu.

    Échoue silencieusement (renvoie ``False``) si l'écriture est
    impossible — le cache reste fonctionnel sans gitignore.
    """
    repo = Path(repo_root).resolve()
    gi = repo / ".gitignore"
    needles = (".walipr-cache", ".walipr-cache/", "/.walipr-cache", "/.walipr-cache/")
    try:
        if gi.is_file():
            existing = gi.read_text(encoding="utf-8", errors="replace")
            for line in existing.splitlines():
                stripped = line.strip()
                if stripped in needles:
                    return False
            sep = "" if existing.endswith("\n") else "\n"
            gi.write_text(
                existing
                + f"{sep}\n{_GITIGNORE_HEADER}\n{_GITIGNORE_LINE}\n",
                encoding="utf-8",
            )
            return True
        else:
            gi.write_text(
                f"{_GITIGNORE_HEADER}\n{_GITIGNORE_LINE}\n",
                encoding="utf-8",
            )
            return True
    except OSError as exc:
        log.warning("cannot update %s: %s", gi, exc)
        return False
