"""Résolution de tokens d'authentification multi-forges (P7.2).

Ordre de priorité (premier match gagne) :

1. ``explicit_token`` (passé en argument, ex. depuis CLI/MCP).
2. ``WALIPR_<FORGE>_TOKEN`` (variable spécifique à WaliPR ; isole
   les credentials WaliPR des credentials globaux).
3. Alias universel : ``GITLAB_TOKEN``, ``GITHUB_TOKEN``,
   ``BITBUCKET_TOKEN`` (ce que les outils tiers exportent déjà).

Si aucune source ne fournit un token non vide, lève
:class:`MissingForgeTokenError` avec un message qui indique
explicitement quelle variable exporter.

**Hors scope P7.2** : Playwright/keyring (différé en P7-bis si
besoin). Les tokens sont uniquement lus depuis l'environnement, ce
qui suffit dans 100 % des contextes CI/dev courants et garde la dep
list aussi mince qu'avant.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

from .url import ForgeKind


# Mapping (forge → (var spécifique, alias universel)).
_TOKEN_VARS: dict[ForgeKind, tuple[str, str]] = {
    ForgeKind.GITLAB: ("WALIPR_GITLAB_TOKEN", "GITLAB_TOKEN"),
    ForgeKind.GITHUB: ("WALIPR_GITHUB_TOKEN", "GITHUB_TOKEN"),
    ForgeKind.BITBUCKET_CLOUD: (
        "WALIPR_BITBUCKET_TOKEN", "BITBUCKET_TOKEN",
    ),
    ForgeKind.BITBUCKET_SERVER: (
        "WALIPR_BITBUCKET_TOKEN", "BITBUCKET_TOKEN",
    ),
}


_FORGE_LABEL: dict[ForgeKind, str] = {
    ForgeKind.GITLAB: "GitLab",
    ForgeKind.GITHUB: "GitHub",
    ForgeKind.BITBUCKET_CLOUD: "Bitbucket Cloud",
    ForgeKind.BITBUCKET_SERVER: "Bitbucket Server",
}


@dataclass
class MissingForgeTokenError(RuntimeError):
    """Aucun token n'a été trouvé pour la forge demandée.

    Le message d'erreur indique précisément la variable d'environnement
    à exporter, pour que l'utilisateur puisse corriger sans relire la
    doc.
    """

    forge: ForgeKind
    env_var: str
    fallback_env_vars: tuple[str, ...]

    def __str__(self) -> str:
        label = _FORGE_LABEL[self.forge]
        fallback = ", ".join(self.fallback_env_vars)
        return (
            f"No {label} token found. Export {self.env_var} "
            f"(preferred for WaliPR) or {fallback} "
            f"(universal alias). For {label}, create a personal "
            "access token with at least read_repository (and "
            "api/repo for posting comments) scopes."
        )


def resolve_token(
    forge: ForgeKind,
    *,
    explicit_token: Optional[str] = None,
) -> str:
    """Renvoie le token à utiliser pour la forge donnée.

    Args:
        forge: Famille de forge cible.
        explicit_token: Token passé explicitement (ex. via CLI ou MCP
            tool). Court-circuite l'environnement si non vide.

    Raises:
        MissingForgeTokenError: si aucune source ne fournit un token.
    """
    if explicit_token:
        return explicit_token

    primary_var, fallback_var = _TOKEN_VARS[forge]

    primary = os.environ.get(primary_var, "")
    if primary:
        return primary

    fallback = os.environ.get(fallback_var, "")
    if fallback:
        return fallback

    raise MissingForgeTokenError(
        forge=forge,
        env_var=primary_var,
        fallback_env_vars=(fallback_var,),
    )


__all__ = [
    "MissingForgeTokenError",
    "resolve_token",
]
