"""Client GitLab REST pour WaliPR (P7.4 + P8).

Endpoints utilisés (API v4) :

- ``GET /projects/<urlencoded_project>/merge_requests/<iid>`` —
  métadonnées (title, description, source/target branch, sha,
  web_url, ``diff_refs`` pour les commentaires inline P8).
- ``GET /projects/<urlencoded_project>/merge_requests/<iid>/diffs`` —
  liste des diffs par fichier. Paginée : on suit le header
  ``Link: rel="next"`` jusqu'à épuisement.
- ``POST /projects/<urlencoded_project>/merge_requests/<iid>/notes`` —
  pour ``post_comment`` (commentaire général, pas inline).
- ``POST /projects/<urlencoded_project>/merge_requests/<iid>/discussions``
  (P8) — pour ``post_inline_comment`` (commentaire posé sur une
  ligne précise du diff). Nécessite ``position`` complet
  (``base_sha``, ``head_sha``, ``start_sha``, ``new_path``,
  ``new_line``, ``position_type='text'``).

Auth : header ``PRIVATE-TOKEN`` (PAT). Pas de gestion OAuth pour
l'instant (suffit pour 100 % des usages CI/dev).

Le diff retourné par ``/diffs`` ne contient pas de header
``diff --git``, on le reconstitue par fichier pour rester compatible
avec :func:`bughound.agents.walipr.diff.parse_unified_diff`.
"""

from __future__ import annotations

from typing import Any, Iterable, Optional
from urllib.parse import quote

import httpx

from .base import ForgeClient, MergeRequestData, PostCommentResult
from .errors import ForgeAPIError, ForgeAuthError, ForgeNotFoundError
from .url import ForgeRef


_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


class GitLabForgeClient(ForgeClient):
    """Client REST GitLab utilisé par WaliPR P7.

    Args:
        token: Personal Access Token (scope ``read_api`` minimum ;
            ``api`` requis pour ``post_comment``).
        transport: Transport ``httpx`` optionnel (utilisé par les
            tests via :class:`httpx.MockTransport`). En prod, laissé
            à ``None`` → ``httpx`` choisit son transport HTTP par
            défaut.
        timeout: Timeout HTTP. Default 30 s (10 s connect).
    """

    def __init__(
        self,
        token: str,
        *,
        transport: Optional[httpx.BaseTransport] = None,
        timeout: httpx.Timeout = _DEFAULT_TIMEOUT,
    ) -> None:
        self._token = token
        self._transport = transport
        self._timeout = timeout

    # ------------------------------------------------------------------
    # ForgeClient interface
    # ------------------------------------------------------------------

    def fetch_mr(self, ref: ForgeRef) -> MergeRequestData:
        with self._make_client(ref.api_base) as http:
            metadata = self._get_json(
                http,
                f"/projects/{_encode_project(ref.project)}"
                f"/merge_requests/{ref.iid}",
            )
            diff_entries = self._get_paginated(
                http,
                f"/projects/{_encode_project(ref.project)}"
                f"/merge_requests/{ref.iid}/diffs",
            )

        # P8 — diff_refs pour les commentaires inline (position).
        diff_refs = metadata.get("diff_refs") or {}
        if not isinstance(diff_refs, dict):
            diff_refs = {}
        head_sha = str(metadata.get("sha") or "")
        base_sha = str(diff_refs.get("base_sha") or "")
        start_sha = str(diff_refs.get("start_sha") or base_sha)

        return MergeRequestData(
            ref=ref,
            title=str(metadata.get("title") or ""),
            description=str(metadata.get("description") or ""),
            source_branch=str(metadata.get("source_branch") or ""),
            target_branch=str(metadata.get("target_branch") or ""),
            source_sha=head_sha,
            web_url=str(metadata.get("web_url") or ""),
            diff_unified=_assemble_unified_diff(diff_entries),
            base_sha=base_sha,
            start_sha=start_sha,
        )

    def post_comment(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/projects/{_encode_project(ref.project)}"
                f"/merge_requests/{ref.iid}/notes",
                json={"body": body},
            )
        _raise_for_status(response)
        payload = response.json()
        note_id = str(payload.get("id", ""))
        return PostCommentResult(
            id=note_id,
            url=str(payload.get("web_url") or ""),
        )

    def post_inline_comment(
        self,
        ref: ForgeRef,
        mr_data: MergeRequestData,
        file: str,
        line: int,
        body: str,
    ) -> PostCommentResult:
        """Crée une discussion inline sur une ligne du diff (P8).

        Utilise l'endpoint ``POST /merge_requests/:iid/discussions``
        avec un objet ``position`` complet. Nécessite que ``mr_data``
        ait été obtenu via :meth:`fetch_mr` (qui peuple
        ``base_sha``/``start_sha``).
        """
        if not mr_data.base_sha or not mr_data.source_sha:
            raise ForgeAPIError(
                "Cannot post inline comment without diff_refs "
                "(base_sha/source_sha). Call fetch_mr first."
            )
        position = {
            "base_sha": mr_data.base_sha,
            "head_sha": mr_data.source_sha,
            "start_sha": mr_data.start_sha or mr_data.base_sha,
            "position_type": "text",
            "new_path": file,
            "new_line": int(line),
        }
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/projects/{_encode_project(ref.project)}"
                f"/merge_requests/{ref.iid}/discussions",
                json={"body": body, "position": position},
            )
        _raise_for_status(response)
        payload = response.json()
        discussion_id = str(payload.get("id", ""))
        # Première note de la discussion (l'API répond sur le bundle).
        notes = payload.get("notes") or []
        note_url = ""
        if isinstance(notes, list) and notes:
            first = notes[0]
            if isinstance(first, dict):
                note_url = str(first.get("web_url") or "")
        return PostCommentResult(id=discussion_id, url=note_url)

    # ------------------------------------------------------------------
    # P10.2 — Drafts natifs GitLab (« Add to review »)
    # ------------------------------------------------------------------

    def post_global_draft(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        """Crée un commentaire global draft sur la MR (P10.2).

        Endpoint : ``POST /merge_requests/:iid/draft_notes`` avec
        ``{"note": body}``. Le draft est privé jusqu'à
        :meth:`publish_drafts` (qui appelle l'endpoint
        ``bulk_publish``).
        """
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/projects/{_encode_project(ref.project)}"
                f"/merge_requests/{ref.iid}/draft_notes",
                json={"note": body},
            )
        _raise_for_status(response)
        payload = response.json()
        return PostCommentResult(
            id=str(payload.get("id", "")),
            url="",  # Les draft notes n'ont pas d'URL publique
        )

    def post_inline_draft(
        self,
        ref: ForgeRef,
        mr_data: MergeRequestData,
        file: str,
        line: int,
        body: str,
    ) -> PostCommentResult:
        """Crée un commentaire inline draft sur la ligne du diff (P10.2).

        Endpoint : ``POST /merge_requests/:iid/draft_notes`` avec un
        objet ``position`` complet (mêmes champs que pour les
        discussions inline P8). Nécessite que ``mr_data`` ait été
        obtenu via :meth:`fetch_mr` (qui peuple ``base_sha``/
        ``start_sha``).
        """
        if not mr_data.base_sha or not mr_data.source_sha:
            raise ForgeAPIError(
                "Cannot post inline draft without diff_refs "
                "(base_sha/source_sha). Call fetch_mr first."
            )
        position = {
            "base_sha": mr_data.base_sha,
            "head_sha": mr_data.source_sha,
            "start_sha": mr_data.start_sha or mr_data.base_sha,
            "position_type": "text",
            "new_path": file,
            "new_line": int(line),
        }
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/projects/{_encode_project(ref.project)}"
                f"/merge_requests/{ref.iid}/draft_notes",
                json={"note": body, "position": position},
            )
        _raise_for_status(response)
        payload = response.json()
        return PostCommentResult(
            id=str(payload.get("id", "")),
            url="",
        )

    def publish_drafts(self, ref: ForgeRef) -> int:
        """Publie tous les drafts en attente (P10.2).

        Endpoint : ``PUT /merge_requests/:iid/draft_notes/bulk_publish``.
        Retourne le nombre de drafts publiés. L'API GitLab ne renvoie
        pas ce compte directement → on lit la liste avant via ``GET
        /draft_notes`` et on fait la diff avec une re-lecture après.
        Comme c'est un effort best-effort, en cas d'erreur de comptage
        on retourne 0 mais le bulk_publish a quand même réussi.
        """
        # Compter les drafts AVANT publication (ils disparaissent de
        # la liste après publish).
        count = 0
        with self._make_client(ref.api_base) as http:
            try:
                list_resp = http.get(
                    f"/projects/{_encode_project(ref.project)}"
                    f"/merge_requests/{ref.iid}/draft_notes",
                )
                if 200 <= list_resp.status_code < 300:
                    data = list_resp.json()
                    if isinstance(data, list):
                        count = len(data)
            except Exception:  # pragma: no cover
                count = 0
            response = http.put(
                f"/projects/{_encode_project(ref.project)}"
                f"/merge_requests/{ref.iid}/draft_notes/bulk_publish",
            )
        _raise_for_status(response)
        return count

    def fetch_file(self, ref: ForgeRef, path: str, sha: str) -> str:
        """Récupère le contenu d'un fichier au SHA donné (P10).

        Endpoint : ``GET /projects/<urlencoded>/repository/files/<urlencoded_path>/raw?ref=<sha>``.
        Renvoie le texte brut. ``path`` est URL-encodé (slashes inclus
        → ``%2F``) ; ``sha`` peut être un SHA Git, un nom de branche
        ou un tag.
        """
        encoded_path = quote(path, safe="")
        with self._make_client(ref.api_base) as http:
            response = http.get(
                f"/projects/{_encode_project(ref.project)}"
                f"/repository/files/{encoded_path}/raw",
                params={"ref": sha},
            )
        _raise_for_status(response)
        return response.text

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _make_client(self, base_url: str) -> httpx.Client:
        return httpx.Client(
            base_url=base_url,
            headers={
                "PRIVATE-TOKEN": self._token,
                "Accept": "application/json",
                "User-Agent": "WaliPR/1.8",
            },
            timeout=self._timeout,
            transport=self._transport,
        )

    def _get_json(self, http: httpx.Client, path: str) -> dict[str, Any]:
        response = http.get(path)
        _raise_for_status(response)
        data = response.json()
        if not isinstance(data, dict):
            raise ForgeAPIError(
                f"Unexpected response shape for {path}: {type(data)!r}"
            )
        return data

    def _get_paginated(
        self, http: httpx.Client, path: str,
    ) -> list[dict[str, Any]]:
        """Suit les liens ``rel="next"`` jusqu'à épuisement."""
        items: list[dict[str, Any]] = []
        url: Optional[str] = path
        while url:
            response = http.get(url)
            _raise_for_status(response)
            page = response.json()
            if isinstance(page, list):
                items.extend(p for p in page if isinstance(p, dict))
            url = _next_link(response)
        return items


# ---------------------------------------------------------------------------
# Helpers de bas niveau (testables isolément si besoin)
# ---------------------------------------------------------------------------


def _encode_project(project: str) -> str:
    """URL-encode un chemin de projet GitLab (``a/b/c`` → ``a%2Fb%2Fc``)."""
    return quote(project, safe="")


def _next_link(response: httpx.Response) -> Optional[str]:
    """Extrait l'URL ``rel="next"`` du header ``Link`` (RFC 5988).

    Renvoie ``None`` si absent ou mal formé.
    """
    link = response.headers.get("Link") or response.headers.get("link")
    if not link:
        return None
    for part in link.split(","):
        chunk = part.strip()
        if 'rel="next"' not in chunk and "rel=next" not in chunk:
            continue
        # Format : `<url>; rel="next"`.
        start = chunk.find("<")
        end = chunk.find(">")
        if start != -1 and end > start:
            return chunk[start + 1 : end]
    return None


def _assemble_unified_diff(
    entries: Iterable[dict[str, Any]],
) -> str:
    """Reconstruit un diff unifié multi-fichiers depuis l'API GitLab.

    L'API ne renvoie pas de ligne ``diff --git ...`` — on l'ajoute,
    plus les lignes ``--- a/...`` / ``+++ b/...`` quand pertinent.
    """
    lines: list[str] = []
    for entry in entries:
        old_path = str(entry.get("old_path") or "")
        new_path = str(entry.get("new_path") or "")
        diff = str(entry.get("diff") or "")
        if not (old_path or new_path):
            continue
        # Header style git.
        path_a = old_path or new_path
        path_b = new_path or old_path
        lines.append(f"diff --git a/{path_a} b/{path_b}")
        if entry.get("new_file"):
            lines.append(f"--- /dev/null")
            lines.append(f"+++ b/{path_b}")
        elif entry.get("deleted_file"):
            lines.append(f"--- a/{path_a}")
            lines.append(f"+++ /dev/null")
        else:
            lines.append(f"--- a/{path_a}")
            lines.append(f"+++ b/{path_b}")
        # Contenu du diff (déjà au format unifié, hunks @@ inclus).
        if diff:
            lines.append(diff.rstrip("\n"))
    return "\n".join(lines) + ("\n" if lines else "")


def _raise_for_status(response: httpx.Response) -> None:
    """Mappe les codes HTTP vers la hiérarchie :mod:`.errors`."""
    code = response.status_code
    if 200 <= code < 300:
        return
    text = response.text[:200] if response.text else ""
    if code in (401, 403):
        raise ForgeAuthError(f"GitLab auth failed ({code}): {text}")
    if code == 404:
        raise ForgeNotFoundError(f"GitLab resource not found: {text}")
    raise ForgeAPIError(f"GitLab API error ({code}): {text}")


__all__ = ["GitLabForgeClient"]
