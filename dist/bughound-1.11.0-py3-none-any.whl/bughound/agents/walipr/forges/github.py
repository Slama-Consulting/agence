"""Client GitHub REST pour WaliPR (P7.5 + P8).

Endpoints utilisés :

- ``GET /repos/{owner}/{repo}/pulls/{number}`` (Accept: JSON) →
  metadata (title, body, head/base ref, head sha, html_url).
- ``GET /repos/{owner}/{repo}/pulls/{number}`` (Accept:
  ``application/vnd.github.diff``) → diff unifié complet en une
  seule requête (déjà avec headers ``diff --git``).
- ``POST /repos/{owner}/{repo}/issues/{number}/comments`` →
  commentaire général sur la PR (côté API, une PR est une issue).
- ``POST /repos/{owner}/{repo}/pulls/{number}/comments`` (P8) →
  commentaire inline sur une ligne du diff (nécessite
  ``commit_id`` = ``head.sha`` + ``path`` + ``line`` + ``side``).

Auth : header ``Authorization: token <PAT>`` (compatible avec les
fine-grained tokens via ``Authorization: Bearer ...``, on garde
``token`` pour rester compat avec les classic PAT).
"""

from __future__ import annotations

from typing import Any, Optional

import httpx

from .base import ForgeClient, MergeRequestData, PostCommentResult
from .errors import ForgeAPIError, ForgeAuthError, ForgeNotFoundError
from .url import ForgeRef


_DEFAULT_TIMEOUT = httpx.Timeout(30.0, connect=10.0)


class GitHubForgeClient(ForgeClient):
    """Client REST GitHub utilisé par WaliPR P7.

    Args:
        token: Personal Access Token (scope ``repo`` minimum pour les
            repos privés ; ``public_repo`` suffit pour les publics).
        transport: Transport ``httpx`` optionnel (tests).
        timeout: Timeout HTTP. Default 30 s.
    """

    def __init__(
        self,
        token: str,
        *,
        transport: Optional[httpx.BaseTransport] = None,
        timeout: httpx.Timeout = _DEFAULT_TIMEOUT,
    ) -> None:
        self._token = token
        self._transport = transport
        self._timeout = timeout
        # P10.2 — state d'une pending review GitHub (drafts).
        self._pending_review_id: Optional[int] = None
        self._pending_review_body: Optional[str] = None

    # ------------------------------------------------------------------
    # ForgeClient interface
    # ------------------------------------------------------------------

    def fetch_mr(self, ref: ForgeRef) -> MergeRequestData:
        with self._make_client(ref.api_base) as http:
            metadata = self._get_pr_json(http, ref)
            diff_text = self._get_pr_diff(http, ref)

        head = metadata.get("head") or {}
        base = metadata.get("base") or {}
        return MergeRequestData(
            ref=ref,
            title=str(metadata.get("title") or ""),
            description=str(metadata.get("body") or ""),
            source_branch=str(head.get("ref") or ""),
            target_branch=str(base.get("ref") or ""),
            source_sha=str(head.get("sha") or ""),
            web_url=str(metadata.get("html_url") or ""),
            diff_unified=diff_text,
        )

    def post_comment(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/repos/{ref.project}/issues/{ref.iid}/comments",
                json={"body": body},
            )
        _raise_for_status(response)
        payload = response.json()
        return PostCommentResult(
            id=str(payload.get("id", "")),
            url=str(payload.get("html_url") or ""),
        )

    def post_inline_comment(
        self,
        ref: ForgeRef,
        mr_data: MergeRequestData,
        file: str,
        line: int,
        body: str,
    ) -> PostCommentResult:
        """Crée un review-comment inline sur la ligne du diff (P8).

        Utilise l'endpoint ``POST /pulls/:n/comments`` avec
        ``commit_id`` = ``mr_data.source_sha`` (HEAD de la PR). Le
        ``side="RIGHT"`` cible toujours la version nouvelle (les
        findings WaliPR pointent les ajouts).
        """
        if not mr_data.source_sha:
            raise ForgeAPIError(
                "Cannot post inline comment without source_sha. "
                "Call fetch_mr first."
            )
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/repos/{ref.project}/pulls/{ref.iid}/comments",
                json={
                    "body": body,
                    "commit_id": mr_data.source_sha,
                    "path": file,
                    "line": int(line),
                    "side": "RIGHT",
                },
            )
        _raise_for_status(response)
        payload = response.json()
        return PostCommentResult(
            id=str(payload.get("id", "")),
            url=str(payload.get("html_url") or ""),
        )

    # ------------------------------------------------------------------
    # P10.2 — Drafts via Pending Review GitHub
    # ------------------------------------------------------------------
    #
    # GitHub n'a pas exactement des « draft notes » au sens GitLab. La
    # mécanique équivalente est la **Pending Review** :
    #
    # 1. ``POST /pulls/:n/reviews`` sans ``event`` → review en
    #    PENDING, on récupère son ``id`` (rid).
    # 2. ``POST /pulls/:n/reviews/:rid/comments`` pour ajouter des
    #    inline comments à la pending review.
    # 3. ``POST /pulls/:n/reviews/:rid/events`` avec ``event:
    #    "COMMENT"`` pour submit (« Finish your review » UI).
    #
    # Le ``rid`` est stocké comme attribut d'instance — un client =
    # une session de review (nouvelle instance à chaque
    # :func:`build_forge_client`).

    def post_global_draft(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        """Stocke le body global pour la pending review (P10.2).

        GitHub permet UN body par review. Si appelé plusieurs fois,
        on concatène avec un saut de ligne. Le body est posté via
        :meth:`publish_drafts`.
        """
        self._ensure_pending_review(ref)
        if self._pending_review_body:
            self._pending_review_body = (
                f"{self._pending_review_body}\n\n{body}"
            )
        else:
            self._pending_review_body = body
        return PostCommentResult(id="pending-global", url="")

    def post_inline_draft(
        self,
        ref: ForgeRef,
        mr_data: MergeRequestData,
        file: str,
        line: int,
        body: str,
    ) -> PostCommentResult:
        """Ajoute un comment inline à la pending review (P10.2).

        Endpoint : ``POST /repos/.../pulls/:n/reviews/:rid/comments``
        avec ``{body, path, line, side="RIGHT"}``.
        """
        if not mr_data.source_sha:
            raise ForgeAPIError(
                "Cannot post inline draft without source_sha. "
                "Call fetch_mr first."
            )
        rid = self._ensure_pending_review(ref)
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/repos/{ref.project}/pulls/{ref.iid}"
                f"/reviews/{rid}/comments",
                json={
                    "body": body,
                    "path": file,
                    "line": int(line),
                    "side": "RIGHT",
                },
            )
        _raise_for_status(response)
        payload = response.json()
        return PostCommentResult(
            id=str(payload.get("id", "")),
            url="",  # Pas d'URL publique tant que la review est pending
        )

    def publish_drafts(self, ref: ForgeRef) -> int:
        """Submit la pending review = équivalent « Submit review ».

        Endpoint : ``POST /repos/.../pulls/:n/reviews/:rid/events``
        avec ``{event: "COMMENT", body: <body global>}``. Reset le
        state local après succès.

        Retourne 1 si une pending review était présente et a été
        publiée, 0 sinon. L'API ne retourne pas le nombre exact de
        comments groupés (c'est une review unique du point de vue UX).
        """
        if self._pending_review_id is None:
            return 0
        rid = self._pending_review_id
        body = self._pending_review_body or ""
        payload: dict[str, Any] = {"event": "COMMENT"}
        if body:
            payload["body"] = body
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/repos/{ref.project}/pulls/{ref.iid}"
                f"/reviews/{rid}/events",
                json=payload,
            )
        _raise_for_status(response)
        # Reset state pour permettre une nouvelle review sur la même
        # instance (rare mais possible).
        self._pending_review_id = None
        self._pending_review_body = None
        return 1

    def _ensure_pending_review(self, ref: ForgeRef) -> int:
        """Crée la pending review au plus tôt et cache son id.

        Idempotent : si ``self._pending_review_id`` existe déjà, on
        le retourne sans appel réseau.
        """
        if self._pending_review_id is not None:
            return self._pending_review_id
        with self._make_client(ref.api_base) as http:
            response = http.post(
                f"/repos/{ref.project}/pulls/{ref.iid}/reviews",
                json={"comments": []},  # Pas d'``event`` → PENDING
            )
        _raise_for_status(response)
        payload = response.json()
        rid = int(payload.get("id", 0))
        self._pending_review_id = rid
        return rid

    def fetch_file(self, ref: ForgeRef, path: str, sha: str) -> str:
        """Récupère le contenu brut d'un fichier au SHA donné (P10).

        Endpoint : ``GET /repos/{owner}/{repo}/contents/{path}?ref={sha}``
        avec ``Accept: application/vnd.github.raw`` (l'API renvoie le
        texte directement sans wrapping JSON base64).
        """
        with self._make_client(ref.api_base) as http:
            response = http.get(
                f"/repos/{ref.project}/contents/{path}",
                params={"ref": sha},
                headers={"Accept": "application/vnd.github.raw"},
            )
        _raise_for_status(response)
        return response.text

    # ------------------------------------------------------------------
    # HTTP helpers
    # ------------------------------------------------------------------

    def _make_client(self, base_url: str) -> httpx.Client:
        return httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"token {self._token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
                "User-Agent": "WaliPR/1.8",
            },
            timeout=self._timeout,
            transport=self._transport,
        )

    def _get_pr_json(
        self, http: httpx.Client, ref: ForgeRef,
    ) -> dict[str, Any]:
        response = http.get(
            f"/repos/{ref.project}/pulls/{ref.iid}",
        )
        _raise_for_status(response)
        data = response.json()
        if not isinstance(data, dict):
            raise ForgeAPIError(
                "Unexpected GitHub PR payload (not a dict)"
            )
        return data

    def _get_pr_diff(
        self, http: httpx.Client, ref: ForgeRef,
    ) -> str:
        response = http.get(
            f"/repos/{ref.project}/pulls/{ref.iid}",
            headers={"Accept": "application/vnd.github.diff"},
        )
        _raise_for_status(response)
        return response.text


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _raise_for_status(response: httpx.Response) -> None:
    code = response.status_code
    if 200 <= code < 300:
        return
    text = response.text[:200] if response.text else ""
    if code in (401, 403):
        raise ForgeAuthError(f"GitHub auth failed ({code}): {text}")
    if code == 404:
        raise ForgeNotFoundError(f"GitHub resource not found: {text}")
    raise ForgeAPIError(f"GitHub API error ({code}): {text}")


__all__ = ["GitHubForgeClient"]
