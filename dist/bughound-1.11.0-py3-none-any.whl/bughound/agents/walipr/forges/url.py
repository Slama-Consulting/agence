"""Parser d'URL de merge/pull request multi-forges.

Trois familles supportées :

- **GitLab** (cloud + on-prem) : ``.../<project_path>/-/merge_requests/<iid>``
- **GitHub** (cloud + Enterprise Server) : ``.../<owner>/<repo>/pull/<iid>``
- **Bitbucket Cloud** : ``bitbucket.org/<ws>/<repo>/pull-requests/<iid>``
- **Bitbucket Server** : ``.../projects/<KEY>/repos/<slug>/pull-requests/<iid>``

La détection est purement structurelle (regex sur le ``path``), donc
elle fonctionne sur n'importe quel host on-prem sans liste blanche
d'hôtes hardcodée.

Le résultat est un :class:`ForgeRef` immuable, prêt à être passé aux
clients :mod:`bughound.agents.walipr.forges.gitlab`,
:mod:`.github` et :mod:`.bitbucket`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum
from urllib.parse import urlparse


class ForgeKind(Enum):
    """Famille de forge identifiée par :func:`parse_mr_url`."""

    GITLAB = "gitlab"
    GITHUB = "github"
    BITBUCKET_CLOUD = "bitbucket_cloud"
    BITBUCKET_SERVER = "bitbucket_server"


class UnsupportedForgeError(ValueError):
    """L'URL fournie ne correspond à aucune forge supportée.

    Englobe : URL vide, schéma non-HTTP(S), host inconnu, segment
    manquant, identifiant non numérique. Hérite de ``ValueError`` pour
    rester capturable en bloc côté CLI/MCP.
    """


@dataclass(frozen=True)
class ForgeRef:
    """Référence canonique d'une MR/PR distante.

    Attributes:
        kind: Famille de forge (GitLab, GitHub, Bitbucket Cloud/Server).
        host: Host de l'instance (ex. ``gitlab.com``,
            ``gitlabee.dt.renault.com``).
        api_base: URL racine de l'API REST (ex.
            ``https://gitlab.com/api/v4``).
        project: Chemin du projet/repo (ex. ``group/sub/proj`` pour
            GitLab, ``owner/repo`` pour GitHub, ``PROJ/repo`` pour
            Bitbucket Server).
        iid: Identifiant numérique de la MR/PR.
        scheme: ``"https"`` quasi systématiquement (mais on garde la
            valeur de l'URL d'origine pour les rares déploiements
            internes en HTTP).
    """

    kind: ForgeKind
    host: str
    api_base: str
    project: str
    iid: int
    scheme: str = field(default="https")

    @property
    def canonical_url(self) -> str:
        """URL web stable de la MR/PR (sans ancre ``/diffs`` etc.).

        Utilisée par le cache P7 comme composante de la clé.
        """
        if self.kind is ForgeKind.GITLAB:
            return (
                f"{self.scheme}://{self.host}/{self.project}"
                f"/-/merge_requests/{self.iid}"
            )
        if self.kind is ForgeKind.GITHUB:
            return (
                f"{self.scheme}://{self.host}/{self.project}"
                f"/pull/{self.iid}"
            )
        if self.kind is ForgeKind.BITBUCKET_CLOUD:
            return (
                f"{self.scheme}://{self.host}/{self.project}"
                f"/pull-requests/{self.iid}"
            )
        # Bitbucket Server : le project est "KEY/slug".
        key, _, slug = self.project.partition("/")
        return (
            f"{self.scheme}://{self.host}/projects/{key}"
            f"/repos/{slug}/pull-requests/{self.iid}"
        )


# ---------------------------------------------------------------------------
# Regexes de détection (insensibles à un éventuel slash final)
# ---------------------------------------------------------------------------

# GitLab : <project_path>/-/merge_requests/<iid>[/...]
_GITLAB_RE = re.compile(
    r"^/(?P<project>.+?)/-/merge_requests/(?P<iid>\d+)(?:/.*)?/?$"
)

# GitHub : <owner>/<repo>/pull/<iid>[/...]
_GITHUB_RE = re.compile(
    r"^/(?P<project>[^/]+/[^/]+)/pull/(?P<iid>\d+)(?:/.*)?/?$"
)

# Bitbucket Cloud : <ws>/<repo>/pull-requests/<iid>[/...]
_BB_CLOUD_RE = re.compile(
    r"^/(?P<project>[^/]+/[^/]+)/pull-requests/(?P<iid>\d+)(?:/.*)?/?$"
)

# Bitbucket Server : projects/<KEY>/repos/<slug>/pull-requests/<iid>[/...]
_BB_SERVER_RE = re.compile(
    r"^/projects/(?P<key>[^/]+)/repos/(?P<slug>[^/]+)"
    r"/pull-requests/(?P<iid>\d+)(?:/.*)?/?$"
)


def _is_bitbucket_cloud_host(host: str) -> bool:
    return host == "bitbucket.org"


def _gitlab_api_base(scheme: str, host: str) -> str:
    return f"{scheme}://{host}/api/v4"


def _github_api_base(scheme: str, host: str) -> str:
    # github.com → api.github.com ; Enterprise Server → <host>/api/v3.
    if host == "github.com":
        return "https://api.github.com"
    return f"{scheme}://{host}/api/v3"


def _bitbucket_cloud_api_base() -> str:
    return "https://api.bitbucket.org/2.0"


def _bitbucket_server_api_base(scheme: str, host: str) -> str:
    return f"{scheme}://{host}/rest/api/1.0"


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def parse_mr_url(url: str) -> ForgeRef:
    """Parse une URL de MR/PR et renvoie un :class:`ForgeRef`.

    Raises:
        UnsupportedForgeError: si l'URL est vide, mal formée, ou ne
            correspond à aucune des trois familles supportées.
    """
    if not url or not isinstance(url, str):
        raise UnsupportedForgeError("URL is empty")

    parsed = urlparse(url.strip())
    if parsed.scheme not in ("http", "https"):
        raise UnsupportedForgeError(
            f"Unsupported URL scheme: {parsed.scheme!r}"
        )
    host = parsed.netloc
    if not host:
        raise UnsupportedForgeError(f"URL has no host: {url!r}")
    path = parsed.path or "/"

    # Bitbucket Server doit être tenté AVANT GitHub : son /projects/.../
    # n'a aucun rapport avec les pull-requests GitHub mais le path
    # /pull-requests pourrait théoriquement collisionner.
    bb_server_match = _BB_SERVER_RE.match(path)
    if bb_server_match:
        return ForgeRef(
            kind=ForgeKind.BITBUCKET_SERVER,
            host=host,
            api_base=_bitbucket_server_api_base(parsed.scheme, host),
            project=(
                f"{bb_server_match.group('key')}"
                f"/{bb_server_match.group('slug')}"
            ),
            iid=int(bb_server_match.group("iid")),
            scheme=parsed.scheme,
        )

    if _is_bitbucket_cloud_host(host):
        bb_cloud_match = _BB_CLOUD_RE.match(path)
        if bb_cloud_match:
            return ForgeRef(
                kind=ForgeKind.BITBUCKET_CLOUD,
                host=host,
                api_base=_bitbucket_cloud_api_base(),
                project=bb_cloud_match.group("project"),
                iid=int(bb_cloud_match.group("iid")),
                scheme=parsed.scheme,
            )
        raise UnsupportedForgeError(f"Bitbucket Cloud URL invalid: {url!r}")

    # GitLab : reconnu structurellement par /-/merge_requests/.
    gitlab_match = _GITLAB_RE.match(path)
    if gitlab_match:
        return ForgeRef(
            kind=ForgeKind.GITLAB,
            host=host,
            api_base=_gitlab_api_base(parsed.scheme, host),
            project=gitlab_match.group("project"),
            iid=int(gitlab_match.group("iid")),
            scheme=parsed.scheme,
        )

    # GitHub : reconnu structurellement par /pull/.
    github_match = _GITHUB_RE.match(path)
    if github_match:
        return ForgeRef(
            kind=ForgeKind.GITHUB,
            host=host,
            api_base=_github_api_base(parsed.scheme, host),
            project=github_match.group("project"),
            iid=int(github_match.group("iid")),
            scheme=parsed.scheme,
        )

    raise UnsupportedForgeError(
        f"Unsupported or malformed merge/pull request URL: {url!r}"
    )


__all__ = [
    "ForgeKind",
    "ForgeRef",
    "UnsupportedForgeError",
    "parse_mr_url",
]
