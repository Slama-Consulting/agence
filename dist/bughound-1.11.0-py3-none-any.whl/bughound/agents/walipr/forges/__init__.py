"""Sous-package WaliPR — clients de forges (GitLab, GitHub, Bitbucket).

P7 ajoute la capacité de récupérer une MR/PR distante via l'API REST
de la forge correspondante, sans cloner le repo. Le sous-module
:mod:`url` parse les URL de MR ; les autres sous-modules
(:mod:`gitlab`, :mod:`github`, :mod:`bitbucket`) implémentent
l'interface :class:`base.ForgeClient`.
"""

from __future__ import annotations

from .url import ForgeKind, ForgeRef, UnsupportedForgeError, parse_mr_url

__all__ = [
    "ForgeKind",
    "ForgeRef",
    "UnsupportedForgeError",
    "parse_mr_url",
]
