"""Exceptions communes aux clients de forges (P7.3 / P7.4-P7.6).

Hiérarchie volontairement plate pour faciliter le ``except`` côté
orchestrator (P7.7) et CLI (P7.8) :

- :class:`ForgeAPIError` — erreur générique (HTTP 5xx, timeout, etc.).
- :class:`ForgeNotFoundError` — la MR/PR n'existe pas (HTTP 404).
- :class:`ForgeAuthError` — credentials invalides ou scopes manquants
  (HTTP 401/403).
- :class:`DiffTooLargeError` — soft-fail quand le diff dépasse
  ``--max-diff-lines`` (P7.7). Hérite de ``ForgeAPIError`` pour rester
  capturable globalement.
"""

from __future__ import annotations


class ForgeAPIError(RuntimeError):
    """Erreur générique côté API forge."""


class ForgeNotFoundError(ForgeAPIError):
    """La ressource (MR/PR) demandée n'existe pas."""


class ForgeAuthError(ForgeAPIError):
    """Authentification refusée ou scopes insuffisants."""


class DiffTooLargeError(ForgeAPIError):
    """Le diff dépasse la limite configurée (--max-diff-lines)."""

    def __init__(self, *, lines: int, limit: int) -> None:
        super().__init__(
            f"Diff size ({lines} lines) exceeds limit ({limit} lines). "
            "Use --max-diff-lines to raise the threshold or split the MR."
        )
        self.lines = lines
        self.limit = limit


__all__ = [
    "DiffTooLargeError",
    "ForgeAPIError",
    "ForgeAuthError",
    "ForgeNotFoundError",
]
