"""Capture et parsing de ``git diff`` pour WaliPR.

Trois entry points :

- :func:`run_local_diff(repo, range)` — ``git diff [range]`` brut.
- :func:`run_staged_diff(repo)` — ``git diff --cached`` brut.
- :func:`parse_unified_diff(text)` — parse en liste de :class:`FileDiff`.

Le parser est volontairement tolérant : il gère les entêtes
``diff --git``, ``rename from/to``, ``new file mode``,
``deleted file mode``, ``Binary files … differ``, et ignore
silencieusement le reste (``index abc..def``, ``similarity index``,
etc.). Les binaires arrivent avec ``hunks=()`` et ``is_binary=True``
(WaliPR ne les review pas — `review.py` les filtre).
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


class WaliPRDiffError(RuntimeError):
    """Erreur de capture du diff (repo invalide, git absent, range KO, …)."""


@dataclass(frozen=True)
class Hunk:
    """Hunk unifié d'un fichier (en-tête ``@@ -a,b +c,d @@`` + lignes)."""

    header: str
    old_start: int
    old_count: int
    new_start: int
    new_count: int
    lines: tuple[str, ...]


@dataclass(frozen=True)
class FileDiff:
    """Diff complet d'un fichier (chemin + hunks)."""

    path: str
    old_path: Optional[str]
    is_binary: bool
    is_new: bool
    is_deleted: bool
    is_renamed: bool
    hunks: tuple[Hunk, ...] = field(default_factory=tuple)


# ---------------------------------------------------------------------------
# Capture (subprocess)
# ---------------------------------------------------------------------------


def _run_git(repo: Path, args: list[str]) -> str:
    """Exécute ``git <args>`` dans ``repo`` et renvoie stdout (text)."""
    if not repo.exists():
        raise WaliPRDiffError(f"repo path does not exist: {repo}")
    if not (repo / ".git").exists() and not (repo / ".git").is_file():
        # Tolère les worktrees (.git fichier) — sinon on râle.
        raise WaliPRDiffError(f"not a git repository: {repo}")
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(repo),
            capture_output=True,
            text=True,
            check=False,
        )
    except FileNotFoundError as exc:
        raise WaliPRDiffError("git executable not found in PATH") from exc
    if result.returncode != 0:
        stderr = (result.stderr or "").strip()
        raise WaliPRDiffError(
            f"git {' '.join(args)} failed (rc={result.returncode}): {stderr}"
        )
    return result.stdout


def run_local_diff(repo: Path, diff_range: Optional[str] = None) -> str:
    """Exécute ``git diff [range]`` dans ``repo`` et renvoie la sortie brute.

    ``diff_range`` est passé tel quel à git (ex. ``"main..HEAD"``,
    ``"HEAD~3"``, ``"abc123..def456"``). Sans range, on récupère le
    diff working tree vs index (= modifications non staged).
    """
    args = ["diff", "--no-color", "--no-ext-diff"]
    if diff_range:
        args.append(diff_range)
    return _run_git(repo, args)


def run_staged_diff(repo: Path) -> str:
    """Exécute ``git diff --cached`` dans ``repo`` (= staged vs HEAD)."""
    return _run_git(repo, ["diff", "--cached", "--no-color", "--no-ext-diff"])


# ---------------------------------------------------------------------------
# Parser unifié
# ---------------------------------------------------------------------------

_DIFF_HEADER_RE = re.compile(r"^diff --git a/(?P<a>.+?) b/(?P<b>.+?)\s*$")
_HUNK_HEADER_RE = re.compile(
    r"^@@ -(?P<old_start>\d+)(?:,(?P<old_count>\d+))? "
    r"\+(?P<new_start>\d+)(?:,(?P<new_count>\d+))? @@.*$"
)
_RENAME_FROM_RE = re.compile(r"^rename from (?P<path>.+?)\s*$")
_RENAME_TO_RE = re.compile(r"^rename to (?P<path>.+?)\s*$")
_NEW_FILE_RE = re.compile(r"^new file mode \d+\s*$")
_DELETED_FILE_RE = re.compile(r"^deleted file mode \d+\s*$")
_BINARY_RE = re.compile(r"^Binary files .+ differ\s*$")
_TARGET_NEW_RE = re.compile(r"^\+\+\+ (?:b/)?(?P<path>.+?)\s*$")
_TARGET_OLD_RE = re.compile(r"^--- (?:a/)?(?P<path>.+?)\s*$")


def parse_unified_diff(text: str) -> list[FileDiff]:
    """Parse un diff unifié (sortie de ``git diff``) en :class:`FileDiff`."""
    if not text or not text.strip():
        return []

    files: list[FileDiff] = []
    lines = text.splitlines()
    i = 0
    n = len(lines)

    while i < n:
        line = lines[i]
        m = _DIFF_HEADER_RE.match(line)
        if not m:
            i += 1
            continue

        a_path = m.group("a")
        b_path = m.group("b")
        is_new = False
        is_deleted = False
        is_renamed = a_path != b_path
        is_binary = False
        rename_from: Optional[str] = None
        rename_to: Optional[str] = None
        hunks: list[Hunk] = []

        i += 1
        # Header lines until first hunk or next diff or EOF.
        while i < n:
            cur = lines[i]
            if cur.startswith("diff --git "):
                break
            if cur.startswith("@@ "):
                break
            if _NEW_FILE_RE.match(cur):
                is_new = True
            elif _DELETED_FILE_RE.match(cur):
                is_deleted = True
            elif _BINARY_RE.match(cur):
                is_binary = True
            elif (rf := _RENAME_FROM_RE.match(cur)) is not None:
                rename_from = rf.group("path")
                is_renamed = True
            elif (rt := _RENAME_TO_RE.match(cur)) is not None:
                rename_to = rt.group("path")
                is_renamed = True
            # ---/+++ headers : on les utilise pour confirmer le path
            # mais sans écraser a_path/b_path qui sont déjà fiables.
            i += 1

        # Hunks
        while i < n and lines[i].startswith("@@ "):
            hh = _HUNK_HEADER_RE.match(lines[i])
            if hh is None:
                # Hunk header malformé — on saute la ligne et on continue.
                i += 1
                continue
            old_start = int(hh.group("old_start"))
            old_count = int(hh.group("old_count") or "1")
            new_start = int(hh.group("new_start"))
            new_count = int(hh.group("new_count") or "1")
            header = lines[i]
            i += 1
            body: list[str] = []
            while i < n:
                nxt = lines[i]
                if nxt.startswith("diff --git ") or nxt.startswith("@@ "):
                    break
                body.append(nxt)
                i += 1
            hunks.append(
                Hunk(
                    header=header,
                    old_start=old_start,
                    old_count=old_count,
                    new_start=new_start,
                    new_count=new_count,
                    lines=tuple(body),
                )
            )

        # Path final : priorité au rename to / b_path.
        path = rename_to or b_path
        if is_deleted:
            path = a_path  # fichier supprimé → b est /dev/null
        old_path = rename_from or (a_path if is_renamed or is_deleted else None)

        files.append(
            FileDiff(
                path=path,
                old_path=old_path,
                is_binary=is_binary,
                is_new=is_new,
                is_deleted=is_deleted,
                is_renamed=is_renamed,
                hunks=tuple(hunks),
            )
        )

    return files
