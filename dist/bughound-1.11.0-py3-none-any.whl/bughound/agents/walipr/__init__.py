"""Agent WaliPR — revue de diff/PR (Kotlin first).

Ce sous-package enregistre l'agent ``walipr`` dans le registry global
:mod:`bughound.agents`. Le squelette est livré au Palier 3 (P3.1) ;
les modules :mod:`.diff` et :mod:`.review` sont remplis en P3.2-P3.3,
et le serveur MCP en P3.4.

Aucun import lourd n'est effectué ici : la factory ``_factory()`` ne
construit le serveur qu'au moment où ``mcp-serve --agent walipr`` est
invoqué, pour ne pas pénaliser le démarrage de SherleKhomes.
"""

from __future__ import annotations

from pathlib import Path

from .. import register


def _factory():  # type: ignore[no-untyped-def]
    """Construit le serveur FastMCP de WaliPR avec la config par défaut.

    WaliPR partage la même config que SherleKhomes (``~/.bughound/config.yaml``
    si présent, sinon ``./config/config.yaml``) — la section ``llm.*`` est
    la seule réellement utilisée par WaliPR au Palier 3.
    """
    from .mcp_server import build_server, DEFAULT_CONFIG_PATH

    user_global = Path("~/.bughound/config.yaml").expanduser()
    config_path = user_global if user_global.exists() else DEFAULT_CONFIG_PATH
    return build_server(config_path)


register("walipr", _factory)
