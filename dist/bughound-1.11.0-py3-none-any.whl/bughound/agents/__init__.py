"""Registry des agents MCP exposés par BugHound.

Chaque agent (sherlekhomes, walipr, …) enregistre une factory qui
construit son propre :class:`FastMCP`. Le CLI ``mcp-serve --agent``
récupère la factory ici, l'invoque, et lance le serveur stdio.

Le registry est volontairement minimaliste — pas d'auto-découverte,
pas de plugin entry-points : on importe les sous-packages connus
dans :func:`_bootstrap` pour déclencher leurs ``register()``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Callable, Dict

if TYPE_CHECKING:  # pragma: no cover - typing only
    from mcp.server.fastmcp import FastMCP


AgentFactory = Callable[[], "FastMCP"]

_REGISTRY: Dict[str, AgentFactory] = {}
_BOOTSTRAPPED = False


def register(name: str, factory: AgentFactory) -> None:
    """Enregistre un agent sous ``name``. Re-register écrase silencieusement."""
    if not name or not name.strip():
        raise ValueError("agent name must be a non-empty string")
    _REGISTRY[name] = factory


def list_agents() -> list[str]:
    """Liste triée des agents disponibles (après bootstrap)."""
    _bootstrap()
    return sorted(_REGISTRY)


def get_agent(name: str):  # type: ignore[no-untyped-def]
    """Construit et renvoie le serveur FastMCP de l'agent ``name``.

    Lève :class:`KeyError` si l'agent n'est pas enregistré (le CLI le
    convertit en :class:`typer.BadParameter` pour l'utilisateur).
    """
    _bootstrap()
    try:
        factory = _REGISTRY[name]
    except KeyError as exc:
        raise KeyError(
            f"unknown agent {name!r} — known agents: {sorted(_REGISTRY)}"
        ) from exc
    return factory()


def _bootstrap() -> None:
    """Importe les sous-packages connus pour déclencher leurs ``register()``.

    Idempotent : la deuxième invocation est un no-op. Tolère les
    ImportError d'agents optionnels (ex. ``walipr`` absent au Palier 1)
    pour ne jamais casser le démarrage de SherleKhomes.
    """
    global _BOOTSTRAPPED
    if _BOOTSTRAPPED:
        return
    # SherleKhomes — toujours présent.
    from . import sherlekhomes  # noqa: F401
    # WaliPR — sera ajouté au Palier 2+. Tolérant pour l'instant.
    try:
        from . import walipr  # noqa: F401
    except ImportError:
        pass
    _BOOTSTRAPPED = True
