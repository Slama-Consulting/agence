"""``best`` handoff: prepare artefacts and a ready-to-execute prompt.

This module is the implementation of the ``best`` analysis mode. Unlike
``legacy`` and ``monolithic`` modes, **no LLM call is made here**. The
goal is to stop after BugHound's deterministic ingestion (ticket + logs
+ video timing) and produce a self-contained prompt that the *external*
LLM (Copilot Chat, Claude Desktop…) can execute inside its own,
single context.

The contract is "single-context strict" — BugHound never blocks. Even
when the description, logs or timing are missing, this module still
produces the prompt with explicit ``[MANQUANT — demander à
l'utilisateur dans le chat]`` markers; the prompt then instructs the
LLM to ask the user in-chat for the missing pieces.
"""

from __future__ import annotations

import json
import logging
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from ..core.models import LogWindow, ResolvedProject, Ticket
from ..utils.fs import ensure_dir, safe_filename
from ..workspace import ANALYSE_SUBDIR, TicketWorkspace

log = logging.getLogger(__name__)


# --- Fix A: hide logs.txt from VS Code's auto-indexing --------------------
# VS Code's Electron renderer crashes (entire window terminates) when a
# multi-hundred-MB plain-text file lives inside the workspace, even when
# nobody opens it explicitly. Reasons:
#   - the file watcher (chokidar) keeps a stat handle on every file,
#   - the search index walks every file under 10 MB *and* attempts a
#     header-read on bigger ones,
#   - extensions (Pylance, Copilot, ESLint…) each spawn their own walker.
# We therefore drop ``logs.txt`` *outside* the visible project tree, in
# a hidden ``.bughound/<TICKET>/`` subdirectory, and emit a
# ``.vscode/settings.json`` that explicitly excludes ``.bughound`` from
# every watcher / search / explorer surface. This is the single biggest
# stability fix for the ``best`` mode on real-world Android dumpstates.
_BUGHOUND_HIDDEN_SUBDIR = ".bughound"
_VSCODE_DIR = ".vscode"
_VSCODE_SETTINGS_FILE = "settings.json"

# Glob-like exclusions written into ``.vscode/settings.json``. Keys are
# stable VS Code settings, values are dicts of ``"<glob>": True``.
_VSCODE_EXCLUSIONS: tuple[str, ...] = (
    f"**/{_BUGHOUND_HIDDEN_SUBDIR}",
    f"**/{_BUGHOUND_HIDDEN_SUBDIR}/**",
)


def _ensure_vscode_excludes(project_root: Path) -> None:
    """Make sure ``<project_root>/.vscode/settings.json`` excludes the
    hidden ``.bughound/`` subtree from every VS Code indexing surface.

    Merges with any pre-existing settings file (we only *add* keys, we
    never overwrite the user's own configuration). Silently no-ops on
    I/O errors — the worst case is a slightly noisier VS Code, not a
    crash, and we never want this helper to abort the handoff.
    """

    vscode_dir = project_root / _VSCODE_DIR
    settings_path = vscode_dir / _VSCODE_SETTINGS_FILE

    existing: dict = {}
    if settings_path.exists():
        try:
            with settings_path.open("r", encoding="utf-8") as fh:
                # ``settings.json`` officially supports JSON-with-comments
                # (a.k.a. JSONC). We avoid pulling a JSONC parser as a
                # dep: when the file has comments we just skip merging
                # rather than corrupt the user's config.
                existing = json.load(fh)
                if not isinstance(existing, dict):
                    existing = {}
        except (OSError, ValueError):
            log.debug(
                "best handoff: %s exists but is not plain JSON; "
                "leaving it untouched.",
                settings_path,
            )
            return

    changed = False
    for setting_key in (
        "files.watcherExclude",
        "search.exclude",
        "files.exclude",
    ):
        bucket = existing.get(setting_key)
        if not isinstance(bucket, dict):
            bucket = {}
            existing[setting_key] = bucket
        for glob in _VSCODE_EXCLUSIONS:
            if bucket.get(glob) is not True:
                bucket[glob] = True
                changed = True

    if not changed:
        return

    try:
        ensure_dir(vscode_dir)
        with settings_path.open("w", encoding="utf-8") as fh:
            json.dump(existing, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
    except OSError as exc:
        log.warning(
            "best handoff: failed to write %s: %s", settings_path, exc,
        )


def _ensure_gitignore_excludes(project_root: Path) -> None:
    """Append a ``.bughound/`` line to ``.gitignore`` when missing.

    Keeps the hidden working dir out of git status / commits without
    touching any other rule. Silently no-ops on I/O errors.
    """

    gitignore = project_root / ".gitignore"
    line = f"{_BUGHOUND_HIDDEN_SUBDIR}/"
    try:
        existing = gitignore.read_text(encoding="utf-8") if gitignore.exists() else ""
    except OSError:
        return
    if any(stripped == line or stripped == _BUGHOUND_HIDDEN_SUBDIR
           for stripped in (l.strip() for l in existing.splitlines())):
        return
    try:
        with gitignore.open("a", encoding="utf-8") as fh:
            if existing and not existing.endswith("\n"):
                fh.write("\n")
            fh.write(f"# BugHound hidden working directory\n{line}\n")
    except OSError as exc:
        log.debug("best handoff: failed to update %s: %s", gitignore, exc)


# --- Fix C-bis: hourly slicing for very large logs.txt --------------------
# Even after dumpstate SYSTEM LOG extraction, behavioral logs can stay
# above 50 Mo (CCSEXT-235722: 272 Mo after extraction). At that size,
# any single ``grep_search`` from VS Code Copilot allocates the full
# file as UTF-16 strings in the renderer (× 2 vs disk size), pushing
# Electron past its heap limit. We mitigate by pre-slicing the file
# into 5-minute hourly chunks and pointing the prompt at the slice
# closest to ``video_anchor`` rather than the global file.
_SLICE_THRESHOLD_BYTES = 30 * 1024 * 1024  # 30 MiB
_SLICE_WINDOW_MINUTES = 5
# Android logcat threadtime line opens with ``MM-DD HH:MM:SS.mmm``.
# Year is missing (logcat doesn't print it) — we slice on HH:MM only,
# which is sufficient for our purposes.
_LOGCAT_TIMESTAMP_RE = re.compile(
    r"^(?P<mo>\d{2})-(?P<d>\d{2})\s+(?P<h>\d{2}):(?P<mi>\d{2}):"
)


def _slice_minute_bucket(hour: int, minute: int) -> str:
    """Round ``HH:MM`` down to the nearest ``_SLICE_WINDOW_MINUTES``
    boundary and format as ``HHhMM``."""

    bucket = (minute // _SLICE_WINDOW_MINUTES) * _SLICE_WINDOW_MINUTES
    return f"{hour:02d}h{bucket:02d}"


def slice_logs_by_minute(
    src: Path,
    dst_dir: Path,
    *,
    window_minutes: int = _SLICE_WINDOW_MINUTES,
) -> list[tuple[str, Path, int, int]]:
    """Stream ``src`` line by line and write 5-minute slices into ``dst_dir``.

    Returns a list of ``(bucket_label, slice_path, line_count,
    byte_size)`` tuples sorted by ``bucket_label``. Lines without a
    parseable logcat timestamp are appended to the most recent open
    bucket (so multi-line stack traces stay grouped with their header
    line). When no line ever yields a timestamp, the function returns
    an empty list and no slice is written.

    Memory profile: O(1) — we keep at most one writer open at a time
    and never load the source file in memory.
    """

    ensure_dir(dst_dir)
    if window_minutes <= 0 or window_minutes > 60:
        raise ValueError("window_minutes must be in 1..60")

    buckets: dict[str, dict] = {}
    current_label: Optional[str] = None
    current_writer = None
    current_path: Optional[Path] = None

    def _open(label: str) -> tuple[Path, "object"]:  # type: ignore[name-defined]
        path = dst_dir / f"logs_{label}.txt"
        # Append mode: a bucket may be revisited on log lines that come
        # back in time (rare on logcat but possible across day rollover).
        return path, path.open("a", encoding="utf-8")

    try:
        with src.open("r", encoding="utf-8", errors="replace") as fin:
            for line in fin:
                m = _LOGCAT_TIMESTAMP_RE.match(line)
                if m is not None:
                    bucket_min = (
                        int(m.group("mi")) // window_minutes
                    ) * window_minutes
                    label = f"{int(m.group('h')):02d}h{bucket_min:02d}"
                    if label != current_label:
                        if current_writer is not None:
                            current_writer.close()
                        current_path, current_writer = _open(label)
                        current_label = label
                        if label not in buckets:
                            buckets[label] = {
                                "path": current_path,
                                "lines": 0,
                                "bytes": 0,
                            }
                if current_writer is None:
                    # No timestamp yet — we drop pre-amble lines (file
                    # header, separators) that precede any logcat line.
                    continue
                current_writer.write(line)
                buckets[current_label]["lines"] += 1  # type: ignore[index]
                buckets[current_label]["bytes"] += len(  # type: ignore[index]
                    line.encode("utf-8")
                )
    finally:
        if current_writer is not None:
            current_writer.close()

    out: list[tuple[str, Path, int, int]] = []
    for label in sorted(buckets):
        info = buckets[label]
        out.append((label, info["path"], info["lines"], info["bytes"]))
    return out


def _bucket_for_anchor(anchor_text: Optional[str]) -> Optional[str]:
    """Convert a free-text ``video_anchor`` (e.g. ``"vers 10:06"``,
    ``"horloge 14:32 → 14:35"``) into a slice bucket label
    (``"10h05"``)."""

    if not anchor_text:
        return None
    m = re.search(r"(?P<h>(?:[01]\d|2[0-3])):(?P<m>[0-5]\d)", anchor_text)
    if m is None:
        return None
    return _slice_minute_bucket(int(m.group("h")), int(m.group("m")))


def _write_slice_index(
    index_path: Path,
    *,
    ticket_key: str,
    slices: list[tuple[str, Path, int, int]],
    anchor_bucket: Optional[str],
) -> None:
    """Write a small ``INDEX.md`` listing all slices + their byte size.

    Helps the LLM (and the human) understand which chunk to query for
    a given wall-clock window.
    """

    lines: list[str] = [
        f"# Slices logs — {ticket_key}",
        "",
        f"`logs.txt` était trop volumineux ({_SLICE_THRESHOLD_BYTES // (1024 * 1024)} Mo+) "
        f"pour être requêté en sécurité par VS Code (crash Electron).",
        "",
        f"Il a été pré-découpé en fenêtres de {_SLICE_WINDOW_MINUTES} minutes.",
        "Chaque slice est un fichier autonome de quelques Mo,",
        "**toujours** à requêter via tes outils paginés (jamais ouvrir).",
        "",
        "| Slice | Fichier | Lignes | Taille |",
        "|---|---|---:|---:|",
    ]
    for label, path, line_count, byte_size in slices:
        marker = " ← bug" if label == anchor_bucket else ""
        size_mb = byte_size / (1024 * 1024)
        size_label = f"{size_mb:.1f} Mo" if size_mb >= 0.1 else f"{byte_size} o"
        lines.append(
            f"| `{label}`{marker} | `{path.name}` | {line_count:,} | {size_label} |"
        )
    lines.append("")
    try:
        index_path.write_text("\n".join(lines), encoding="utf-8")
    except OSError as exc:
        log.warning(
            "best handoff: failed to write slice index %s: %s",
            index_path,
            exc,
        )


# --- Fix B: timing parsing from ticket description ------------------------
# Patterns that try to mine a wall-clock ``HH:MM`` (or ``HH:MM:SS``)
# from a free-text description. Order matters — the most specific
# patterns (``around HH:MM``, ``à HH:MM``…) come first so a generic
# bare ``HH:MM`` deep in the text doesn't pre-empt a clearly tagged
# one. We require the hour to be 00–23 to avoid false positives on
# version numbers, build IDs, etc.
_HHMM = r"(?P<h>(?:[01]\d|2[0-3])):(?P<m>[0-5]\d)(?::(?P<s>[0-5]\d))?"
_TIMING_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(rf"\baround\s+{_HHMM}\b", re.IGNORECASE),
    re.compile(rf"\bat\s+{_HHMM}\b", re.IGNORECASE),
    re.compile(rf"\bvers\s+{_HHMM}\b", re.IGNORECASE),
    re.compile(rf"\bautour\s+de\s+{_HHMM}\b", re.IGNORECASE),
    re.compile(rf"\bà\s+{_HHMM}\b", re.IGNORECASE),
    re.compile(rf"~\s*{_HHMM}\b"),
    # Markdown emphasis: *10:06* or **10:06** — typical in Jira.
    re.compile(rf"\*+{_HHMM}\*+"),
)


def parse_timing_from_description(text: Optional[str]) -> Optional[str]:
    """Extract a ``HH:MM[:SS]`` wall-clock from a ticket description.

    Returns the matched timestamp as a string when one of the
    :data:`_TIMING_PATTERNS` succeeds, ``None`` otherwise. The first
    pattern that matches wins (patterns ordered most-specific first).

    This is the deterministic complement to the OCR-based video clock:
    when the video has no readable display time, the ticket reporter
    often types the wall-clock directly into the description (« Logs:
    around 10:06 »). Mining it lets the rest of the pipeline window
    the logs without ever needing OCR samples.
    """

    if not text:
        return None
    for pattern in _TIMING_PATTERNS:
        m = pattern.search(text)
        if m is None:
            continue
        h, mi = m.group("h"), m.group("m")
        s = m.group("s")
        return f"{h}:{mi}:{s}" if s else f"{h}:{mi}"
    return None


# --- Fix C: Android dumpstate SYSTEM LOG extraction -----------------------
# Real Android dumpstate files (`bugreport-*.txt`, `dumpstate_*.txt`)
# can reach hundreds of MB. The actual logcat content lives in a
# single named section delimited by:
#
#   ------ SYSTEM LOG (logcat -v threadtime …) ------
#   …
#   ------ N.Ns was the duration of 'SYSTEM LOG' ------
#
# Everything outside that section (kmsg, dumpsys, smaps, blocked
# processes, …) is uninteresting for behavioral debugging and is what
# bloats the file most. When BugHound detects a dumpstate, we strip it
# down to the SYSTEM LOG section before handing it to the LLM.
_DUMPSTATE_SIGNATURE = re.compile(
    r"^==\s*dumpstate:\s*\d{4}-\d{2}-\d{2}",
    re.MULTILINE,
)
_SYSTEM_LOG_START = re.compile(r"^------ SYSTEM LOG ", re.IGNORECASE)
_SYSTEM_LOG_END = re.compile(
    r"^------ [\d.]+s was the duration of 'SYSTEM LOG'",
    re.IGNORECASE,
)


def _looks_like_android_dumpstate(path: Path) -> bool:
    """Return ``True`` iff the file's first KB carries the canonical
    Android dumpstate header (``== dumpstate: YYYY-MM-DD …``)."""

    try:
        with path.open("rb") as fh:
            head = fh.read(4096).decode("utf-8", errors="replace")
    except OSError:
        return False
    return bool(_DUMPSTATE_SIGNATURE.search(head))


def extract_android_system_log(src: Path, dst: Path) -> Optional[Path]:
    """Stream-extract the SYSTEM LOG section of an Android dumpstate.

    Reads ``src`` line by line (memory-safe: never loads the full
    multi-hundred-MB file in RAM) and writes only the first SYSTEM LOG
    section to ``dst``. Returns ``dst`` on success, ``None`` when no
    section was found (in which case ``dst`` is removed if it was
    created).
    """

    inside = False
    written = 0
    try:
        with src.open("r", encoding="utf-8", errors="replace") as fin, \
             dst.open("w", encoding="utf-8") as fout:
            for line in fin:
                if not inside:
                    if _SYSTEM_LOG_START.search(line):
                        inside = True
                        fout.write(line)
                        written += 1
                else:
                    fout.write(line)
                    written += 1
                    if _SYSTEM_LOG_END.search(line):
                        break
    except OSError as exc:
        log.warning("SYSTEM LOG extraction failed (%s → %s): %s", src, dst, exc)
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return None

    if written == 0:
        try:
            dst.unlink(missing_ok=True)
        except OSError:
            pass
        return None
    return dst


# Markers searched (in order) when walking up from the CWD to find the
# root of the *target* project that the user wants to debug. The first
# parent that contains any of these wins. ``CLAUDE.md`` is first because
# it is a strong, explicit signal in this codebase.
_PROJECT_MARKERS: tuple[str, ...] = (
    "CLAUDE.md",
    ".git",
    "pyproject.toml",
    "build.gradle",
    "build.gradle.kts",
    "package.json",
)


# Sentinel rendered in the prompt for any field BugHound could not
# resolve deterministically. The LLM (Copilot) is instructed up-front to
# treat any ``[MANQUANT]`` it bumps into as "ask the user in this chat".
_MISSING_MARKER = "[MANQUANT — demander à l'utilisateur dans le chat]"


# Header always prepended to the prompt. Tells the LLM how to behave
# when it encounters a ``[MANQUANT]`` marker — namely, never leave the
# current chat, never re-invoke BugHound, just ask the user.
#
# Also includes the **mandatory** read-protocol for ``logs.txt``: the
# file routinely reaches 50+ Mo / 250 000+ lignes on real Renault HU
# tickets, which is enough to crash the VS Code Electron renderer when
# opened in the editor (observed on CCSEXT-235266 — "window terminated
# unexpectedly, reason: clean-exit"). The LLM **must** therefore use
# its internal file-read tool (read_file / get_file_content / MCP Read
# / equivalent) and read only ranges or grep-style queries.
_LLM_INSTRUCTIONS_BLOCK = (
    "Avant de commencer l'analyse, vérifie chaque info marquée "
    "`[MANQUANT]` ci-dessous. Ne sors pas du chat, ne relance pas "
    "BugHound — reste dans cette conversation.\n\n"
    "**RÈGLE CLARIFICATIONS — UNE SEULE FOIS, STRUCTURÉ** :\n"
    "- **Si AUCUN champ `[MANQUANT]` n'est présent** : enchaîne "
    "directement les étapes 1→7 sans poser aucune question. Si "
    "pendant l'analyse il te manque une info, fais une hypothèse "
    "raisonnable et documente-la dans la section *🤔 Hypothèses* "
    "du rapport final — **pas de question au fil de l'eau**.\n"
    "- **Si AU MOINS UN champ `[MANQUANT]`** : pose **une seule "
    "fois, en début d'analyse**, un message structuré qui regroupe "
    "**toutes** les questions (1 à 4 max). Format auto-adaptatif "
    "selon ton client :\n"
    "    - **Si tu disposes d'un tool natif d'élicitation "
    "      structurée** (`AskUserQuestion` de Claude Code / "
    "      Anthropic, formulaire d'élicitation Cursor, équivalent "
    "      Claude Desktop) : utilise-le avec 1 à 4 questions à "
    "      choix-multiples. Pour chaque champ manquant, propose 2 "
    "      à 4 options plausibles + l'option « Autre » (champ "
    "      libre). Recommande systématiquement la valeur la plus "
    "      probable en première position avec « (Recommandé) ».\n"
    "    - **Sinon** (Copilot, terminal, ou client sans "
    "      élicitation native) : produis **un seul message "
    "      markdown** strictement formaté ainsi :\n"
    "      ```markdown\n"
    "      ## ❓ Infos manquantes — <TICKET>\n"
    "      Réponds en un seul message avec la syntaxe `q1=2 "
    "      q2=autre:vers 10:06` (numéro d'option, ou "
    "      `autre:<texte>`).\n"
    "      ### q1 — <champ manquant 1>\n"
    "      1. <option recommandée>\n"
    "      2. <option alternative>\n"
    "      3. Autre : `___________`\n"
    "      ### q2 — <champ manquant 2>\n"
    "      1. …\n"
    "      ```\n"
    "- **Une fois la réponse utilisateur reçue**, exécute "
    "directement les étapes 1→7 **sans nouveau message "
    "intermédiaire**, sans plan, sans validation supplémentaire.\n"
    "- **Interdiction stricte** de poser des questions au fil de "
    "l'eau pendant les étapes 1→7. Toute info qui manque pendant "
    "l'exécution → hypothèse documentée dans *🤔 Hypothèses* du "
    "rapport, **pas de nouvelle question**.\n\n"
    "**RÈGLE ABSOLUE — `./logs.txt` ne s'ouvre JAMAIS** :\n"
    "Ce fichier peut peser de quelques Mo à plusieurs **centaines de "
    "Mo** (cas réels observés : 50 Mo → 450 Mo, 200 000 à 3 500 000 "
    "lignes). C'est **normal** et **attendu** : ne le considère "
    "**jamais** comme un fichier à ouvrir, c'est un **dataset à "
    "requêter par chunks**. Ce workflow fonctionne très bien dans la "
    "pratique sur des logs de plusieurs centaines de Mo tant que la "
    "règle ci-dessous est respectée à la lettre.\n"
    "- **INTERDIT** : ouvrir `logs.txt` dans l'éditeur VS Code "
    "(`open`, `vscode.workspace.openTextDocument`, double-clic, "
    "`Ctrl+P`, drag-and-drop dans l'onglet, etc.). L'éditeur "
    "Electron sature en mémoire et crashe la fenêtre — bug observé "
    "sur CCSEXT-235266.\n"
    "- **INTERDIT** : `cat`, `head`, `tail`, `grep`, `wc -l`, "
    "`awk`, `sed`, `less`, `more`, `tac`, `nl`, ou tout autre "
    "outil terminal sur `logs.txt`. Les sorties brutes saturent le "
    "contexte du chat (3,4 M lignes ≈ centaines de Mo de tokens) "
    "et provoquent des crashs de session.\n"
    "- **OBLIGATOIRE** : utilise **exclusivement** tes outils "
    "internes paginés qui retournent des résultats **tronqués "
    "automatiquement** : `read_file` avec `startLine`/`endLine` "
    "(VS Code Copilot), `grep_search` (VS Code Copilot), MCP "
    "`Read` avec `offset`/`limit`, ou équivalent côté hôte. Ces "
    "outils lisent le fichier **par blocs sans le charger en "
    "RAM**, exactement comme on travaillerait sur une base de "
    "données.\n"
    "- Plafonne chaque lecture à **200 lignes maximum**. Si tu as "
    "besoin de plus, fais plusieurs lectures ciblées avec des "
    "ranges précis ou affine ta requête de recherche par mots-clés.\n"
    "- **Budget total** : ne dépasse pas **~500 lignes de logs "
    "injectées dans le contexte sur l'ensemble de l'analyse**. "
    "Au-delà tu risques de faire crasher la session "
    "(CCSEXT-235722 : Copilot s'est figé après plusieurs `grep` "
    "successifs cumulant trop de lignes).\n"
    "- **Stratégie obligatoire** :\n"
    "    1. Une **première recherche** par mot-clé ultra-spécifique "
    "       (nom de classe, exception, identifiant fonctionnel propre "
    "       au bug) limitée à **30 hits maximum** (`max_results: 30`).\n"
    "    2. Sélectionne **3 à 5 numéros de ligne** parmi ces hits — "
    "       ceux qui semblent les plus proches du bug.\n"
    "    3. **Une seule lecture ciblée** par numéro retenu, ±20 "
    "       lignes autour du hit (`read_file` avec range étroit).\n"
    "    4. **N'élargis pas** la recherche initiale par d'autres "
    "       `grep` plus généraux : zoome sur ce que tu as déjà au "
    "       lieu d'accumuler. Si vraiment insuffisant, demande à "
    "       l'utilisateur dans le chat.\n"
    "- Ne lis jamais le fichier linéairement, n'agrège pas, ne "
    "    compte pas le nombre de lignes.\n"
    "- **Si BugHound a pré-découpé les logs en slices** "
    "(`.bughound/<TICKET>/logs/logs_HHhMM.txt` + `INDEX.md`) : "
    "requête **uniquement le slice qui couvre l'heure du bug**. "
    "Chaque slice fait quelques Mo, donc même un grep_search reste "
    "sûr. Ne grep jamais le `logs.txt` global quand des slices "
    "existent."
)


# The full debug workflow the user wants Copilot to execute. Kept as a
# single ``.format``-able string so callers only have to substitute the
# four placeholders (``ticket_key``, ``description_line``,
# ``video_anchor_line``, ``logs_line``, ``analysis_path``).
BEST_PROMPT_TEMPLATE = """{llm_instructions}

J'ai un bug dans le ticket {ticket_key} :
{description_line}
{video_anchor_line}
{logs_line}

## Workflow de debug standard

Applique exactement le workflow suivant, sans sauter d'étape, et
produis à la fin un fichier `analysis_{ticket_key}_<AAAA-MM-JJ>.md`
dans `{analysis_path}` qui résume l'analyse.

### 1. Analyse des logs

- **Règle absolue** : pour `./logs.txt`, n'utilise **ni l'éditeur
  VS Code, ni le terminal** (`cat` / `head` / `tail` / `grep` /
  `wc` / `awk` / `sed` / `less` interdits). Utilise **uniquement**
  tes outils internes paginés (`read_file` avec ranges,
  `grep_search`, MCP `Read` avec `offset`/`limit`).
- **Budget strict** : ≤ 500 lignes de logs cumulées dans le
  contexte sur toute l'étape. Au-delà = risque de crash de
  session (cf. CCSEXT-235722).
- **Stratégie en 4 étapes, sans dévier** :
  1. **Une seule recherche initiale** par mot-clé ultra-spécifique
     (nom de classe, exception, identifiant fonctionnel propre au
     bug). Limite à **30 hits maximum** (`max_results: 30`).
  2. **Sélectionne 3 à 5 numéros de ligne** parmi ces hits — ceux
     qui semblent les plus proches du bug.
  3. **Une lecture ciblée** par numéro retenu, ±20 lignes autour
     (`read_file` range étroit).
  4. **Ne relance pas** un `grep`/`grep_search` plus large pour
     accumuler plus de hits. Zoome sur ce que tu as déjà. Si
     vraiment insuffisant, demande à l'utilisateur dans le chat.
- Ne fais jamais de lecture linéaire du fichier, ni d'agrégat type
  `wc -l`, ni de `grep | head -100`.
- Identifie les exceptions, stack traces, warnings et messages
  d'erreur qui précèdent immédiatement l'instant du bug.
- Cite verbatim 3 à 6 lignes de logs qui constituent la preuve la
  plus forte de la cause racine (pas de paraphrase).
- Reconstruis la timeline OK/KO : 4 à 8 étapes numérotées, chacune
  marquée `✔` (déroulement nominal) ou `✖` (déraillement).

### 2. Analyse du code

- À partir des classes/méthodes/lignes mentionnées dans les logs,
  ouvre les fichiers correspondants dans le projet courant.
- Lis le code autour des lignes incriminées pour comprendre la
  logique métier impliquée.
- Identifie la cause racine technique : quelle invariant est
  violée, quel chemin d'exécution mène au bug, quelle valeur est
  inattendue.

### 3. Suspicion inter-module

- Évalue si la cause racine est strictement contenue dans le
  module immédiatement responsable, ou si elle implique des
  dépendances en amont (config, repository, service partagé,
  framework).
- Liste les zones à risque de régression : packages/fichiers qui
  pourraient être affectés par le correctif.

### 4. Proposition de correctif

- Propose un patch concret et minimal qui corrige la cause racine
  sans surajouter de fonctionnalités.
- Justifie en quoi ce patch résout précisément le déraillement
  observé dans la timeline.
- Indique le score de confiance (0.0 à 1.0) que tu accordes au
  fix, à la cause racine, à la zone de régression, et à la
  localisation du fix (in_module vs outside_module).

### 5. Vérification Git (commandes suggérées)

- Suggère les commandes git à exécuter pour vérifier l'état du
  dépôt avant et après le patch :
  - `git status` pour voir les fichiers modifiés
  - `git diff <fichier>` pour relire le patch
  - `git log -p <fichier> | head -200` pour vérifier l'historique
    récent des fichiers touchés
- **Ne lance pas ces commandes toi-même** : laisse l'utilisateur
  les exécuter et te recoller la sortie si besoin.

### 6. Checklist avant soumission

Coche explicitement (✔ / ✖) chaque point :

- [ ] La cause racine est étayée par au moins une citation
  verbatim de `logs.txt`.
- [ ] La timeline OK/KO contient au moins une étape `✔` et une
  étape `✖`.
- [ ] Le patch proposé compile dans le langage du projet (pas de
  syntaxe inventée).
- [ ] Les zones à risque de régression sont listées avec leur
  chemin/package.
- [ ] La méthode de reproduction est extraite en priorité du
  ticket ; les logs ne servent que de complément.

### 7. Résumé de fin d'analyse

Génère un fichier
`{analysis_path}/analysis_{ticket_key}_<AAAA-MM-JJ>.md` avec la
structure suivante :

```markdown
# Analyse {ticket_key}

## 🔍 Cause racine du bug

**FR (technique)** : <paragraphe FR avec classes/méthodes/lignes>

**EN (PO, ≤ 80 mots)** : <paragraphe EN court, sans jargon>

### Preuve (logs verbatim)

```
<3 à 6 lignes de logs verbatim>
```

### Timeline OK/KO

1. ✔ <étape 1>
2. ✔ <étape 2>
3. ✖ <étape de déraillement>
4. ✖ <conséquence>

## 🛠️ Fix proposé

<description du patch + extrait du diff>

## 📊 Scores de confiance

| Métrique | Score |
|---|---|
| Cause racine | <0.0–1.0> |
| Régression | <0.0–1.0> |
| Fix | <0.0–1.0> |
| in_module | <0.0–1.0> |
| outside_module | <0.0–1.0> |

## ⚠️ Zones à risque de régression

- <chemin/package 1>
- <chemin/package 2>

## 🔁 Méthode de reproduction

<étapes extraites du ticket en priorité, complétées par les logs si besoin>

## 🤔 Hypothèses faites

<liste des hypothèses prises en cours d'analyse quand une info
manquait — par exemple « timing déduit du premier crash logcat »,
« composant supposé être X car pas mentionné dans le ticket ».
Si aucune hypothèse n'a été faite, écris simplement
`_Aucune — toutes les infos étaient présentes._`>
```

Quand tu as fini, indique simplement le chemin absolu du fichier
généré et arrête-toi là.
"""


@dataclass(frozen=True)
class BestHandoffPayload:
    """Self-contained result of the ``best`` ingestion handoff.

    Returned by :func:`prepare_best_handoff` and surfaced verbatim by
    the MCP tool / CLI so the calling LLM can execute :attr:`prompt`
    inside its own context. The other fields are diagnostic — they tell
    the user *where* BugHound put the artefacts on disk and *what* (if
    anything) was missing from the deterministic ingestion.
    """

    ticket_key: str
    ticket_title: str
    project_root: Path
    analysis_dir: Path
    logs_txt_path: Optional[Path]
    video_anchor: Optional[str]
    missing: list[str] = field(default_factory=list)
    prompt: str = ""


def detect_project_root(
    start: Path,
    fallback: Optional[Path] = None,
) -> Path:
    """Walk up from ``start`` until a project marker is found.

    Markers are checked in :data:`_PROJECT_MARKERS` order and the first
    parent containing *any* of them is returned. When no marker is hit
    all the way up to ``/``, ``fallback`` (if provided) is returned;
    otherwise ``start`` itself is returned as a best-effort guess.

    The returned path is always absolute and resolved.
    """

    start = Path(start).expanduser().resolve()
    candidate = start
    while True:
        for marker in _PROJECT_MARKERS:
            if (candidate / marker).exists():
                return candidate
        parent = candidate.parent
        if parent == candidate:
            # Reached filesystem root without finding any marker.
            if fallback is not None:
                return Path(fallback).expanduser().resolve()
            return start
        candidate = parent


def _format_line(label: str, value: Optional[str]) -> str:
    """Render a single placeholder line, with a ``[MANQUANT]`` marker
    when ``value`` is empty/None."""

    rendered = value.strip() if value else ""
    if not rendered:
        rendered = _MISSING_MARKER
    return f"{label}{rendered}"


def assemble_prompt(
    *,
    ticket_key: str,
    description: Optional[str],
    video_anchor: Optional[str],
    logs_txt_relpath: Optional[str],
    analysis_path: Path,
    slice_index_relpath: Optional[str] = None,
) -> str:
    """Build the full Copilot-ready prompt from the template.

    Each piece of information is rendered verbatim when present and
    replaced by ``[MANQUANT]`` when missing — there is a single
    template, no separate "fallback" prompt. The instruction header
    is always present.

    When ``slice_index_relpath`` is provided, the logs were too large
    to be queried as a single file and have been pre-cut into hourly
    slices. ``logs_txt_relpath`` then points to the slice covering
    ``video_anchor`` (the default chunk for the bug instant).
    """

    description_line = _format_line(
        "Description du ticket : ",
        description,
    )
    video_anchor_line = _format_line(
        "D'après la vidéo, le bug se produit à : ",
        video_anchor,
    )
    if logs_txt_relpath:
        if slice_index_relpath:
            logs_line = (
                f"La fenêtre de logs correspondante est pré-découpée en "
                f"slices de 5 minutes (cf. `{slice_index_relpath}`). "
                f"Slice par défaut (couvrant l'heure du bug) : "
                f"`{logs_txt_relpath}`. **Ne grep jamais le `logs.txt` "
                f"global** : il est trop gros pour VS Code Copilot. "
                f"Choisis un slice avant chaque requête."
            )
        else:
            logs_line = (
                f"La fenêtre de logs correspondante est dans `{logs_txt_relpath}`."
            )
    else:
        logs_line = (
            "La fenêtre de logs correspondante est dans : " + _MISSING_MARKER
        )

    return BEST_PROMPT_TEMPLATE.format(
        llm_instructions=_LLM_INSTRUCTIONS_BLOCK,
        ticket_key=ticket_key,
        description_line=description_line,
        video_anchor_line=video_anchor_line,
        logs_line=logs_line,
        analysis_path=str(analysis_path),
    )


def prepare_best_handoff(
    *,
    ticket: Ticket,
    log_window: Optional[LogWindow],
    anchor_summary: Optional[str],
    project_root_hint: Optional[Path] = None,
    resolved_project: Optional[ResolvedProject] = None,
    ticket_workspace: Optional[TicketWorkspace] = None,  # noqa: ARG001
    raw_log_paths: Optional[list[Path]] = None,
) -> BestHandoffPayload:
    """Orchestrate the deterministic part of the ``best`` mode.

    Steps:

    1. Detect the *target* project root (CWD walk-up first, then fall
       back to ``resolved_project.root`` if available).
    2. Create ``<project_root>/analyse/<TICKET>/`` (always, even when
       artefacts are missing — gives the LLM a place to write the
       final ``analysis_<KEY>_<DATE>.md``).
    3. Copy ``log_window.window_path`` to ``<project_root>/logs.txt``
       when the window exists and has at least one line. **Fallback**:
       when the window is missing/empty but ``raw_log_paths`` contains
       a real on-disk log file, copy the largest such file as-is to
       ``logs.txt`` — user contract: "if the windowed file is empty,
       hand the full log to the LLM rather than nothing".
    4. Compute the ``missing`` list (informational; the prompt is
       generated unconditionally).
    5. Assemble the prompt with ``[MANQUANT]`` markers where needed.

    The function never raises on missing inputs — it always returns a
    payload, with the prompt ready to be executed by the external LLM.
    """

    fallback_root = (
        Path(resolved_project.root) if resolved_project is not None else None
    )
    start = (
        Path(project_root_hint)
        if project_root_hint is not None
        else Path.cwd()
    )
    project_root = detect_project_root(start, fallback=fallback_root)

    safe_key = safe_filename(ticket.key)
    analysis_dir = project_root / ANALYSE_SUBDIR / safe_key
    ensure_dir(analysis_dir)

    # --- Fix A: hidden working directory + VS Code excludes ----------
    # Place ``logs.txt`` in ``<project_root>/.bughound/<TICKET>/`` (out
    # of the visible workspace) and tell VS Code to ignore that subtree
    # for watching/searching/exploring. This is what actually prevents
    # the Electron renderer from crashing on multi-hundred-MB logs.
    hidden_dir = project_root / _BUGHOUND_HIDDEN_SUBDIR / safe_key
    ensure_dir(hidden_dir)
    _ensure_vscode_excludes(project_root)
    _ensure_gitignore_excludes(project_root)

    # --- logs.txt -------------------------------------------------------
    # Strategy:
    # 1. Prefer the curated ``log_window`` (smallest, most relevant).
    # 2. Fallback: when the window is missing or empty, copy the
    #    largest raw log file on disk. Better to give the LLM the full
    #    log than nothing.
    logs_txt_path: Optional[Path] = None
    target = hidden_dir / "logs.txt"

    has_window = (
        log_window is not None
        and log_window.window_path is not None
        and Path(log_window.window_path).exists()
        and log_window.line_count > 0
    )
    if has_window:
        assert log_window is not None  # for type-checkers
        try:
            shutil.copyfile(log_window.window_path, target)
            logs_txt_path = target
        except OSError as exc:
            log.warning(
                "best handoff: failed to copy log window to %s: %s",
                target,
                exc,
            )
            logs_txt_path = None

    if logs_txt_path is None and raw_log_paths:
        candidates: list[Path] = []
        for raw in raw_log_paths:
            try:
                p = Path(raw)
                if p.exists() and p.is_file() and p.stat().st_size > 0:
                    candidates.append(p)
            except OSError:
                continue
        if candidates:
            biggest = max(candidates, key=lambda p: p.stat().st_size)
            # --- Fix C: pre-filter Android dumpstates -----------------
            # When the raw log is an Android dumpstate (CCSEXT-235722
            # case), strip everything but the SYSTEM LOG section before
            # copying. Often shrinks 250+ MB → 30-100 MB by dropping
            # the kernel/dumpsys/blocked-process noise.
            extracted_via_dumpstate = False
            if _looks_like_android_dumpstate(biggest):
                if extract_android_system_log(biggest, target) is not None:
                    logs_txt_path = target
                    extracted_via_dumpstate = True
                    log.info(
                        "best handoff: detected Android dumpstate, "
                        "extracted SYSTEM LOG from %s to %s (%d bytes).",
                        biggest,
                        target,
                        target.stat().st_size,
                    )
            if not extracted_via_dumpstate:
                try:
                    shutil.copyfile(biggest, target)
                    logs_txt_path = target
                    log.info(
                        "best handoff: log window empty, fell back to full "
                        "log file %s (%d bytes).",
                        biggest,
                        biggest.stat().st_size,
                    )
                except OSError as exc:
                    log.warning(
                        "best handoff: failed to copy raw log %s to %s: %s",
                        biggest,
                        target,
                        exc,
                    )
                    logs_txt_path = None

    # --- Fix B: timing fallback from ticket description --------------
    description = (ticket.description or "").strip()
    anchor = (anchor_summary or "").strip() or None
    if anchor is None:
        parsed = parse_timing_from_description(description)
        if parsed is not None:
            anchor = f"vers {parsed} (extrait de la description du ticket)"
            log.info(
                "best handoff: timing %s mined from ticket description.",
                parsed,
            )

    # --- Fix C-bis: slice oversized logs.txt by 5-minute buckets -----
    # Even after dumpstate SYSTEM LOG extraction, the file can stay
    # above 30 Mo (CCSEXT-235722: 272 Mo). Beyond that threshold any
    # single grep_search round saturates the VS Code renderer. We
    # pre-cut the file into 5-minute slices so the LLM can hit a
    # ~5 Mo chunk instead of the global file. The slice closest to
    # ``video_anchor`` is exposed in the prompt as the default.
    slice_dir: Optional[Path] = None
    slice_index: Optional[Path] = None
    sliced_logs_path: Optional[Path] = None
    if logs_txt_path is not None:
        try:
            size = logs_txt_path.stat().st_size
        except OSError:
            size = 0
        if size > _SLICE_THRESHOLD_BYTES:
            slice_dir = hidden_dir / "logs"
            try:
                slices = slice_logs_by_minute(logs_txt_path, slice_dir)
            except (OSError, ValueError) as exc:
                log.warning(
                    "best handoff: slicing %s failed: %s",
                    logs_txt_path,
                    exc,
                )
                slices = []
            if slices:
                anchor_bucket = _bucket_for_anchor(anchor)
                slice_index = slice_dir / "INDEX.md"
                _write_slice_index(
                    slice_index,
                    ticket_key=ticket.key,
                    slices=slices,
                    anchor_bucket=anchor_bucket,
                )
                # Choose the default slice the prompt will cite.
                # Prefer the bucket that covers the bug timestamp; fall
                # back to the largest slice when the anchor is missing
                # or its bucket wasn't produced (rare).
                chosen = next(
                    (
                        slice_path
                        for label, slice_path, _l, _b in slices
                        if label == anchor_bucket
                    ),
                    None,
                )
                if chosen is None:
                    chosen = max(slices, key=lambda t: t[3])[1]
                sliced_logs_path = chosen
                log.info(
                    "best handoff: %d slices written to %s, default=%s.",
                    len(slices),
                    slice_dir,
                    chosen.name,
                )

    # --- missing list (informational) --------------------------------
    missing: list[str] = []
    if not description:
        missing.append("description")
    if logs_txt_path is None:
        missing.append("logs")
    if anchor is None:
        missing.append("timing")

    # --- prompt ------------------------------------------------------
    # Prefer the per-bucket slice when it exists: a 5 Mo chunk is safe
    # to grep_search, the global 250+ Mo file isn't.
    primary_logs = sliced_logs_path or logs_txt_path
    logs_relpath: Optional[str] = None
    if primary_logs is not None:
        try:
            logs_relpath = "./" + str(primary_logs.relative_to(project_root))
        except ValueError:
            logs_relpath = str(primary_logs)

    slice_index_relpath: Optional[str] = None
    if slice_index is not None:
        try:
            slice_index_relpath = "./" + str(
                slice_index.relative_to(project_root)
            )
        except ValueError:
            slice_index_relpath = str(slice_index)

    prompt = assemble_prompt(
        ticket_key=ticket.key,
        description=description or None,
        video_anchor=anchor,
        logs_txt_relpath=logs_relpath,
        analysis_path=analysis_dir,
        slice_index_relpath=slice_index_relpath,
    )

    return BestHandoffPayload(
        ticket_key=ticket.key,
        ticket_title=ticket.title,
        project_root=project_root,
        analysis_dir=analysis_dir,
        logs_txt_path=logs_txt_path,
        video_anchor=anchor,
        missing=missing,
        prompt=prompt,
    )


__all__ = [
    "BEST_PROMPT_TEMPLATE",
    "BestHandoffPayload",
    "assemble_prompt",
    "detect_project_root",
    "extract_android_system_log",
    "parse_timing_from_description",
    "prepare_best_handoff",
    "slice_logs_by_minute",
]
