"""MCP sampling-aware LLM client.

This client routes BugHound's LLM calls through the MCP host's
``sampling/createMessage`` capability (``ctx.session.create_message``).
This is the proper MCP way to delegate reasoning to the host LLM
(Claude Code, Cursor, Claude Desktop, ...) without polluting the
JSON-RPC transport.

Why a new client (vs reusing :class:`MCPCopilotClient`) ?
:class:`MCPCopilotClient` was designed around the early ``ctx.elicit``
API that took a single string argument. The current MCP SDK (1.x)
requires a Pydantic schema and is geared towards user input collection,
not LLM completion. ``sampling/createMessage`` is the correct primitive
for "ask the host's LLM to complete this prompt".

The caller (typically a FastMCP tool handler) is responsible for
wiring the ``sample`` callback. From within an async tool that
receives a ``Context`` argument, that's typically:

    def _sample(system: str, user: str) -> str:
        from mcp.types import SamplingMessage, TextContent
        result = _from_thread.run(
            ctx.session.create_message,
            [SamplingMessage(role="user",
                             content=TextContent(type="text", text=user))],
            8000,           # max_tokens
            system_prompt=system,
        )
        if result.content.type == "text":
            return result.content.text
        return ""

    llm = MCPSamplingClient(sample=_sample)
"""

from __future__ import annotations

from typing import Callable, Optional

from .base import ChatMessage, LLMClient, LLMResponse


#: Signature for the "ask the host LLM to complete this prompt" side.
#: The caller passes ``system`` and ``user`` strings, the callback
#: returns the model's raw reply (typically JSON wrapped in prose).
#: The callback is allowed to return an empty string (treated as a
#: failed completion) but must not raise — the surrounding ``try`` in
#: the FastMCP tool handler is responsible for translating exceptions
#: into empty replies if needed.
SampleCallback = Callable[[str, str], str]


class MCPSamplingClient(LLMClient):
    """LLM client that delegates completions to the MCP host via sampling."""

    def __init__(self, *, sample: SampleCallback) -> None:
        self._sample = sample
        self._prompt_counter = 0

    def complete_json(
        self,
        *,
        system: str,
        user: str,
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        self._prompt_counter += 1
        prompt_id = f"P{self._prompt_counter:03d}"

        full_user = user
        if schema_hint:
            full_user = (
                f"{user}\n\n"
                f"Respond ONLY with a JSON object matching this schema:\n"
                f"{schema_hint}"
            )

        try:
            answer = self._sample(system, full_user)
        except Exception:  # pragma: no cover - host glitches
            answer = ""

        parsed = self._try_parse_json(answer)
        return LLMResponse(
            raw_text=answer,
            parsed=parsed,
            meta={"mode": "mcp-sampling", "prompt_id": prompt_id},
        )

    def complete_conversation(
        self,
        *,
        system: str,
        messages: list[ChatMessage],
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        if not messages:
            raise ValueError("complete_conversation requires at least one message")
        if messages[-1].role != "user":
            raise ValueError(
                "complete_conversation requires the last message to come from the user"
            )

        self._prompt_counter += 1
        prompt_id = f"P{self._prompt_counter:03d}"

        # Default implementation : flatten the transcript into a single
        # user prompt. A future iteration can pass a real list of
        # ``SamplingMessage`` to the host (the SDK supports it natively).
        serialised = self._serialise_conversation(messages)
        full_user = serialised
        if schema_hint:
            full_user = (
                f"{serialised}\n\n"
                f"Respond ONLY with a JSON object matching this schema:\n"
                f"{schema_hint}"
            )

        try:
            answer = self._sample(system, full_user)
        except Exception:  # pragma: no cover - host glitches
            answer = ""

        parsed = self._try_parse_json(answer)
        return LLMResponse(
            raw_text=answer,
            parsed=parsed,
            meta={
                "mode": "mcp-sampling",
                "prompt_id": prompt_id,
                "turns": len(messages),
            },
        )
