"""Command-line entry point: ``python -m bughound analyze PROJ-42``."""

from __future__ import annotations

import json
import logging
import os
import re
import shutil
from pathlib import Path
from typing import Optional

import typer
import yaml
from dotenv import load_dotenv
from rich.console import Console
from rich.logging import RichHandler

from . import __version__
from .analyzers import (
    AutoClarificationHandler,
    BestHandoffPayload,
    InteractiveClarificationHandler,
    MonolithicAnalyzer,
)
from .attachments import (
    AttachmentManager,
    CachingPasswordProvider,
    TerminalPasswordProvider,
)
from .attachments.handlers import ConfiguredHostEntry, build_default_registry
from .config import BugHoundConfig, load_config
from .jira_client import (
    JiraClient,
    WriteRefusedError,
    WriteResult,
    build_jira_client,
)
from .core.models import ResolvedProject as ResolvedProjectModel
from .llm import build_llm_client
from .logs import LogCorrelator, LogcatParser
from .pipeline import BugHoundPipeline
from .projects import CodebaseInspector, ProjectResolver
from .projects.resolver import ResolvedProject
from .reporter import write_report
from .video import OcrDetector, SceneChangeDetector, TesseractOcrEngine, VideoAnalyzer


def _to_model_resolved(r: ResolvedProject) -> ResolvedProjectModel:
    return ResolvedProjectModel(
        ticket_key=r.ticket_key,
        root=r.root,
        name=r.name,
        matched_on=r.matched_on,
        score=r.score,
    )


app = typer.Typer(
    help="BugHound — trace bugs from Jira tickets to logs and videos.",
    add_completion=False,
)
console = Console()


def _configure_logging(verbose: bool) -> None:
    # force=True so a second CLI invocation within the same process replaces
    # any handler inherited from a previous basicConfig call.
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(
            console=console,
            rich_tracebacks=True,
            show_path=False,
            markup=True,
        )],
        force=True,
    )
    # The CLI logs through the root logger indirectly (via modules); make sure
    # our own modules' loggers are at the requested level.
    logging.getLogger("bughound").setLevel(
        logging.DEBUG if verbose else logging.INFO
    )


def _build_video_analyzer(cfg: BugHoundConfig) -> Optional[VideoAnalyzer]:
    """Try to build a video analyzer. Fall back to ``None`` on missing deps."""
    scene = SceneChangeDetector(change_threshold=cfg.video.scene_change_threshold)

    engine = None
    try:
        engine = TesseractOcrEngine(
            tesseract_cmd=Path(cfg.video.tesseract_cmd) if cfg.video.tesseract_cmd else None,
        )
    except RuntimeError as exc:
        console.print(f"[yellow]OCR disabled: {exc}[/yellow]")

    ocr_detector = OcrDetector(engine) if engine is not None else None

    # Use with_defaults so the new DisplayTimeDetector is wired in too.
    return VideoAnalyzer.with_defaults(
        ocr_engine=engine,
        scene_detector=scene,
    ) if engine is not None else VideoAnalyzer(
        ocr_detector=ocr_detector, scene_detector=scene,
    )


def _load(
    config_path: Path,
    env_file: Optional[Path],
) -> BugHoundConfig:
    if env_file and env_file.exists():
        load_dotenv(env_file, override=False)
    return load_config(config_path)


def _build_jira(cfg: BugHoundConfig) -> JiraClient:
    return build_jira_client(
        mode=cfg.jira.mode,
        base_url=cfg.jira.base_url,
        email=cfg.jira.email,
        api_token=cfg.jira.api_token,
        browser_profile_dir=cfg.jira.browser_profile_dir,
        browser_headless_after_login=cfg.jira.browser_headless_after_login,
        write_allowed_projects=cfg.jira.write_allowed_projects,
    )


def _build_project_resolver(cfg: BugHoundConfig) -> ProjectResolver:
    return ProjectResolver(
        search_roots=cfg.projects.search_roots,
        fuzzy_threshold=cfg.projects.fuzzy_threshold,
    )


def _build_monolithic_analyzer(llm) -> MonolithicAnalyzer:  # type: ignore[no-untyped-def]
    """Wire a :class:`MonolithicAnalyzer` for terminal use.

    The handler picks itself based on stdin: a TTY gets an
    :class:`InteractiveClarificationHandler` that prompts via ``typer``;
    a piped/CI run falls back to the deterministic
    :class:`AutoClarificationHandler` so the pipeline never blocks.
    """
    import sys

    if sys.stdin.isatty():
        def _prompt(question: str, options: list[str]) -> str:
            console.print(
                f"[cyan]Question de l'analyseur :[/cyan] {question}"
            )
            if options:
                console.print(
                    "[dim]Options proposées :[/dim] "
                    + " | ".join(options)
                )
            try:
                return typer.prompt("Réponse", default="").strip()
            except typer.Abort:
                return ""

        handler = InteractiveClarificationHandler(prompt_fn=_prompt)
    else:
        handler = AutoClarificationHandler()
    return MonolithicAnalyzer(llm, clarification_handler=handler)


def _interactive_project_pick(cfg: BugHoundConfig) -> Optional[Path]:
    """List candidate project directories and let the user pick one.

    Returns the selected path, or ``None`` if the user bailed out or if no
    candidates were found. Only called when automatic resolution failed
    *and* ``projects.interactive_fallback`` is true *and* stdin is a TTY.
    """
    import sys
    candidates: list[Path] = []
    for root in cfg.projects.search_roots:
        root = Path(root).expanduser()
        if not root.exists():
            continue
        for child in sorted(root.iterdir()):
            if child.is_dir() and not child.name.startswith("."):
                candidates.append(child)

    if not candidates:
        console.print("[yellow]No project candidates found under search_roots.[/yellow]")
        return None
    if not sys.stdin.isatty():
        return None

    console.print("[cyan]Pick the project this ticket belongs to:[/cyan]")
    for i, p in enumerate(candidates, start=1):
        console.print(f"  [bold]{i}[/bold]. {p.name}  [dim]{p}[/dim]")
    console.print("  [bold]0[/bold]. skip (no code cross-reference)")

    while True:
        raw = typer.prompt("Choice", default="0")
        try:
            choice = int(raw)
        except ValueError:
            console.print("[red]Please enter a number.[/red]")
            continue
        if choice == 0:
            return None
        if 1 <= choice <= len(candidates):
            return candidates[choice - 1]
        console.print(f"[red]Out of range (0-{len(candidates)}).[/red]")


def _print_dry_run(result: WriteResult) -> None:
    console.print(
        f"[yellow]DRY-RUN[/yellow] {result.action} on "
        f"[bold]{result.target}[/bold] — re-run with [bold]--yes[/bold] to apply."
    )
    console.print("Payload:")
    console.print_json(data=result.payload)


# ---------------------------------------------------------------------------
# analyze
# ---------------------------------------------------------------------------


@app.command()
def analyze(
    ticket_key: str = typer.Argument(..., help="Jira ticket key, e.g. PROJ-42"),
    config: Path = typer.Option(
        Path("config/config.yaml"),
        "--config", "-c",
        help="Path to the BugHound YAML config file.",
    ),
    env_file: Optional[Path] = typer.Option(
        Path(".env"),
        "--env-file",
        help="Path to a .env file with secrets (JIRA_API_TOKEN, LLM_API_KEY).",
    ),
    workdir: Optional[Path] = typer.Option(
        None,
        "--workdir", "-w",
        help="Override the output directory from config.",
    ),
    project_path: Optional[Path] = typer.Option(
        None,
        "--project-path", "-p",
        help="Force the local project directory (bypasses auto-resolution).",
    ),
    monolithic: bool = typer.Option(
        False,
        "--monolithic/--no-monolithic",
        help=(
            "Use the single-conversation analyser instead of the legacy "
            "chain of stateless LLM calls. Faster on native multi-turn "
            "backends, with optional clarification rounds. "
            "(Deprecated alias for ``--mode monolithic``.)"
        ),
    ),
    mode: str = typer.Option(
        "best",
        "--mode",
        help=(
            "Analysis mode: 'best' (default — single-context handoff, "
            "no LLM call inside BugHound), 'legacy' (chained LLM calls) "
            "or 'monolithic' (one multi-turn LLM call). 'best' is "
            "recommended: it preserves the external chat LLM's context "
            "window by delegating the whole analysis to it."
        ),
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Run the full BugHound pipeline on a Jira ticket."""
    _configure_logging(verbose)
    cfg = _load(config, env_file)
    out_dir = workdir or cfg.output.workdir
    out_dir = Path(out_dir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    jira = _build_jira(cfg)
    llm = build_llm_client(
        mode=cfg.llm.mode,
        provider=cfg.llm.provider,
        model=cfg.llm.model,
        api_key=cfg.llm.api_key,
    )
    video_analyzer = _build_video_analyzer(cfg)
    resolver = _build_project_resolver(cfg)

    # Pre-resolve so that the CLI can handle the interactive fallback
    # *before* we start the (much slower) Jira + LLM work.
    project_override: Optional[ResolvedProject] = None
    if project_path is not None:
        root = Path(project_path).expanduser().resolve()
        project_override = ResolvedProject(
            ticket_key=ticket_key,
            root=root,
            name=root.name,
            matched_on="manual",
            score=1.0,
        )
        console.print(
            f"[cyan]Project[/cyan] forced to [bold]{project_override.root}[/bold]"
        )
    elif cfg.projects.interactive_fallback:
        # Peek at the cache; the pipeline will try a full resolve against
        # the ticket's components/labels once it has the ticket in hand.
        # If neither works, we'll fall back to an interactive pick *after*
        # the initial run sees an empty resolution.
        cached = resolver._lookup_cache(ticket_key)  # noqa: SLF001
        if cached is not None:
            console.print(f"[dim]Cached project:[/dim] {cached.root}")

    # Wrap the terminal prompt in a cache so the user only has to type the
    # password once per archive, even when the same archive is re-asked by
    # retry paths inside the extractor.
    password_provider = CachingPasswordProvider(TerminalPasswordProvider())
    artifactory_entries = [
        ConfiguredHostEntry(host=h.host, user=h.user, token=h.token)
        for h in cfg.artifactory.hosts
    ]
    attachment_manager = AttachmentManager(
        jira,
        password_provider=password_provider,
        url_handlers=build_default_registry(artifactory_entries=artifactory_entries),
    )

    # Reconcile the deprecated ``--monolithic`` flag with the new
    # ``--mode`` option. Setting both to incompatible values is an
    # error; otherwise ``--monolithic`` is honoured as a shortcut for
    # ``--mode monolithic``.
    if mode not in {"legacy", "monolithic", "best"}:
        raise typer.BadParameter(
            f"--mode must be 'legacy', 'monolithic' or 'best' (got {mode!r})"
        )
    # ``--monolithic`` (deprecated alias) maps to ``--mode monolithic``.
    # When the user passes ``--monolithic`` without an explicit ``--mode``,
    # ``mode`` still equals its default ``"best"`` here — we honour the
    # explicit ``--monolithic`` flag and override the default. We only
    # raise when the user set BOTH ``--monolithic`` AND a conflicting
    # explicit ``--mode legacy`` / ``--mode best``.
    if monolithic and mode in {"best", "legacy"}:
        effective_mode = "monolithic"
    elif monolithic and mode != "monolithic":
        raise typer.BadParameter(
            "--monolithic is incompatible with --mode " + repr(mode)
        )
    else:
        effective_mode = mode

    # ``best`` mode never invokes BugHound's own LLM. Skip building the
    # monolithic analyser entirely so we don't waste any resources.
    monolithic_analyzer = (
        _build_monolithic_analyzer(llm)
        if effective_mode == "monolithic"
        else None
    )
    pipeline = BugHoundPipeline(
        jira=jira,
        llm=llm,
        workdir=out_dir,
        attachment_manager=attachment_manager,
        video_analyzer=video_analyzer,
        correlator=LogCorrelator(
            parser=LogcatParser(),
            window_before_s=cfg.logs.window_before_s,
            window_after_s=cfg.logs.window_after_s,
        ),
        project_resolver=resolver,
        project_override=project_override,
        monolithic_analyzer=monolithic_analyzer,
        mode=effective_mode,
    )

    mode_label = {
        "legacy": "chaîne legacy",
        "monolithic": "monolithique",
        "best": "best (handoff Copilot)",
    }[effective_mode]
    console.print(
        "[bold yellow]🕵️ SherleKhomes[/bold yellow] — "
        "agent de l'agence [bold]Slama Consulting[/bold]"
    )
    console.print(
        f"[bold cyan]BugHound[/bold cyan] v{__version__} — analyzing "
        f"[bold]{ticket_key}[/bold] (mode jira=[yellow]{cfg.jira.mode}[/yellow]"
        f", analyseur=[yellow]{mode_label}[/yellow])"
    )
    console.print(f"[dim]Output directory:[/dim] {out_dir}")

    # Live step-by-step progress in the terminal. Keeping the format
    # identical to what the MCP server emits so the CLI experience and
    # the Copilot-Chat experience stay in lock-step.
    def _cli_progress(step: int, total: int, message: str) -> None:
        console.print(f"[bold cyan]\\[{step}/{total}][/bold cyan] {message}")

    result = pipeline.run(ticket_key, progress=_cli_progress)

    # ``best`` mode: BugHound stopped after deterministic ingestion.
    # Persist the prompt for later retrieval and surface it (and the
    # logs.txt path / missing pieces) to the user. No report writing.
    if isinstance(result, BestHandoffPayload):
        payload = result
        prompt_path = payload.analysis_dir / "handoff_prompt.md"
        try:
            prompt_path.write_text(payload.prompt, encoding="utf-8")
        except OSError as exc:
            console.print(
                f"[red]Could not persist handoff prompt:[/red] {exc}"
            )
        console.print(
            f"\n[green]✓ Mode best — artefacts prêts.[/green]"
        )
        console.print(f"  Workspace : [cyan]{payload.analysis_dir}[/cyan]")
        if payload.logs_txt_path is not None:
            console.print(
                f"  logs.txt  : [cyan]{payload.logs_txt_path}[/cyan]"
            )
        else:
            console.print("  logs.txt  : [yellow]absent[/yellow]")
        if payload.video_anchor:
            console.print(f"  Vidéo     : {payload.video_anchor}")
        if payload.missing:
            console.print(
                "  [yellow]Manquant :[/yellow] " + ", ".join(payload.missing)
            )
        console.print(
            f"  Prompt    : [cyan]{prompt_path}[/cyan]\n"
        )
        console.rule("[bold]Prompt Copilot[/bold]")
        console.print(payload.prompt)
        console.rule()
        return

    report = result

    # Interactive fallback: the pipeline couldn't resolve a project and
    # the user is on a TTY → let them pick one, then re-run just the
    # code cross-reference step (no need to re-fetch Jira / re-analyze).
    if (
        report.project is None
        and project_override is None
        and cfg.projects.interactive_fallback
    ):
        picked = _interactive_project_pick(cfg)
        if picked is not None:
            override = resolver.record_manual(report.ticket, picked)
            report.project = _to_model_resolved(override)
            insp = CodebaseInspector(override.root)
            haystack = "\n".join(
                line for ex in report.log_excerpts for line in ex.lines
            )
            if haystack:
                report.code_references = insp.cross_reference_logs(haystack)
            console.print(
                f"[green]✓ Cross-referenced[/green] against {override.root} "
                f"→ {len(report.code_references)} code ref(s)."
            )

    console.print("[cyan]Writing report…[/cyan]")
    workspace = pipeline.last_workspace
    md_path = write_report(
        report,
        out_dir,
        emit_json=cfg.output.emit_json,
        workspace=workspace,
    )
    console.print(f"[green]✓ Report written to[/green] {md_path}")
    if report.notes:
        console.print("[yellow]Notes:[/yellow]")
        for note in report.notes:
            console.print(f"  - {note}")

    # End-of-run confirmation: ask whether to discard the transient
    # artefacts (downloads, extracted, video frames) once the user has
    # had a chance to validate the report. Only when stdin is a TTY.
    if workspace is not None:
        import sys
        if sys.stdin.isatty():
            console.print(
                f"\n[bold]Artefacts temporaires[/bold] sous "
                f"[cyan]{workspace.root}[/cyan]"
            )
            if typer.confirm(
                "Supprimer les téléchargements / archives / frames vidéo "
                "(le rapport est conservé) ?",
                default=False,
            ):
                removed = workspace.cleanup_transients()
                console.print(
                    f"[green]✓ {len(removed)} dossier(s) transitoire(s) "
                    f"supprimé(s).[/green]"
                )
            else:
                console.print("[dim]Artefacts conservés en place.[/dim]")


# ---------------------------------------------------------------------------
# comment
# ---------------------------------------------------------------------------


@app.command()
def comment(
    ticket_key: str = typer.Argument(..., help="Ticket to comment on, e.g. CCSEXT-123"),
    body: str = typer.Option(..., "--body", "-b", help="Comment body (wiki markup)."),
    yes: bool = typer.Option(
        False, "--yes",
        help="Actually post the comment. Without this flag, runs in dry-run.",
    ),
    config: Path = typer.Option(Path("config/config.yaml"), "--config", "-c"),
    env_file: Optional[Path] = typer.Option(Path(".env"), "--env-file"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Add a comment to an existing Jira ticket (dry-run by default)."""
    _configure_logging(verbose)
    cfg = _load(config, env_file)
    jira = _build_jira(cfg)

    try:
        result = jira.add_comment(ticket_key, body, dry_run=not yes)
    except WriteRefusedError as exc:
        console.print(f"[red]Refused:[/red] {exc}")
        raise typer.Exit(code=2)

    if result.dry_run:
        _print_dry_run(result)
    else:
        console.print(
            f"[green]Comment posted[/green] on {result.target} "
            f"(id={result.key}) — {result.url}"
        )


# ---------------------------------------------------------------------------
# create
# ---------------------------------------------------------------------------


@app.command()
def create(
    project: str = typer.Option(..., "--project", "-p", help="Project key, e.g. CCSEXT"),
    title: str = typer.Option(..., "--title", "-t", help="Issue summary."),
    body: str = typer.Option(..., "--body", "-b", help="Issue description (wiki markup)."),
    issue_type: str = typer.Option("Bug", "--type", help="Issue type."),
    yes: bool = typer.Option(
        False, "--yes",
        help="Actually create the issue. Without this flag, runs in dry-run.",
    ),
    config: Path = typer.Option(Path("config/config.yaml"), "--config", "-c"),
    env_file: Optional[Path] = typer.Option(Path(".env"), "--env-file"),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Create a new Jira issue (dry-run by default)."""
    _configure_logging(verbose)
    cfg = _load(config, env_file)
    jira = _build_jira(cfg)

    try:
        result = jira.create_issue(
            project=project, title=title, body=body,
            issue_type=issue_type, dry_run=not yes,
        )
    except WriteRefusedError as exc:
        console.print(f"[red]Refused:[/red] {exc}")
        raise typer.Exit(code=2)

    if result.dry_run:
        _print_dry_run(result)
    else:
        console.print(
            f"[green]Issue created:[/green] {result.key} — {result.url}"
        )


# ---------------------------------------------------------------------------
# mcp-serve
# ---------------------------------------------------------------------------


def _resolve_mcp_config_path(explicit: Optional[Path]) -> Path:
    """Pick a config path that works regardless of the IDE's CWD.

    The MCP server is launched by the user's editor (VS Code, Claude
    Desktop, Cursor) with the workspace as CWD — typically NOT the
    BugHound checkout. A relative default like ``config/config.yaml``
    resolves against that workspace and breaks. We therefore:

    1. Honor an explicit ``--config`` path verbatim if provided.
    2. Otherwise fall back to ``~/.bughound/config.yaml`` (the
       canonical user-global location written by ``bughound setup``).
    3. As last resort, try ``./config/config.yaml`` for users who
       launch the server from the BugHound source tree directly.
    """
    if explicit is not None:
        return explicit
    user_global = Path("~/.bughound/config.yaml").expanduser()
    if user_global.exists():
        return user_global
    return Path("config/config.yaml")


@app.command(name="mcp-serve")
def mcp_serve(
    config: Optional[Path] = typer.Option(
        None,
        "--config", "-c",
        help=(
            "Path to the BugHound YAML config file. "
            "Defaults to ~/.bughound/config.yaml when present, "
            "else ./config/config.yaml."
        ),
    ),
    env_file: Optional[Path] = typer.Option(
        None,
        "--env-file",
        help=(
            "Path to a .env file with secrets (JIRA_API_TOKEN, "
            "LLM_API_KEY). Defaults to ~/.bughound/.env when present, "
            "else ./.env."
        ),
    ),
    agent: str = typer.Option(
        "sherlekhomes",
        "--agent",
        help=(
            "Quel agent MCP servir : 'sherlekhomes' (défaut, analyse "
            "de tickets Jira) ou un autre agent enregistré (futur "
            "'walipr' pour la review de PR/MR)."
        ),
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Run BugHound as an MCP server over stdio.

    Lets editors like VS Code (Copilot Chat) or Claude Desktop drive
    BugHound directly — the user just asks "analyse CCSEXT-42" in the
    chat and the rendered report comes back inline.
    """
    # MCP stdio uses stdout for JSON-RPC. ANY non-JSON byte on stdout
    # corrupts the channel and the host (VS Code, Claude Desktop) emits
    # `Failed to parse message: …` warnings, which in turn make agents
    # hallucinate (e.g. fabricating local config.yaml files). All logs
    # MUST go to stderr. We bypass _configure_logging() — which targets
    # the default Console (stdout) — and force stderr instead.
    err_console = Console(stderr=True)
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.WARNING,
        format="%(message)s",
        datefmt="[%X]",
        handlers=[RichHandler(
            console=err_console,
            rich_tracebacks=True,
            show_path=False,
            markup=True,
        )],
        force=True,
    )
    logging.getLogger("bughound").setLevel(
        logging.DEBUG if verbose else logging.INFO
    )

    config = _resolve_mcp_config_path(config)

    # Load .env so Jira/LLM secrets are available to the pipeline. The
    # MCP server itself reloads the YAML config on every tool call, so
    # edits to config.yaml take effect without restarting the server.
    if env_file is None:
        user_env = Path("~/.bughound/.env").expanduser()
        env_file = user_env if user_env.exists() else Path(".env")
    if env_file and env_file.exists():
        load_dotenv(env_file, override=False)

    # Dispatch vers l'agent demandé. SherleKhomes garde son chemin
    # historique direct (run_stdio(config)) pour 0 régression : même
    # comportement, même résolution de config_path. Les autres agents
    # passent par le registry et ignorent --config (chaque agent gère
    # sa propre source de configuration).
    if agent == "sherlekhomes":
        from .agents.sherlekhomes.mcp_server import run_stdio
        run_stdio(config)
        return

    from . import agents as _agents
    try:
        server = _agents.get_agent(agent)
    except KeyError as exc:
        raise typer.BadParameter(
            f"Agent inconnu : {agent!r}. "
            f"Agents disponibles : {', '.join(_agents.list_agents())}."
        ) from exc
    server.run()


# ---------------------------------------------------------------------------
# WaliPR — review-diff / review-staged
# ---------------------------------------------------------------------------


def _parse_standards_csv(value: Optional[str]) -> Optional[list[str]]:
    """Parse l'option ``--standards a,b,c`` et valide les langages.

    Renvoie ``None`` si ``value`` est ``None`` ou vide (= pas
    d'override, on laisse l'auto-détection). Lève ``typer.BadParameter``
    si un langage inconnu est demandé (validation contre la
    source-of-truth :func:`available_languages`).
    """
    if value is None:
        return None
    raw = [item.strip().lower() for item in value.split(",")]
    cleaned = [item for item in raw if item]
    if not cleaned:
        return None
    from .agents.walipr.standards import available_languages

    known = set(available_languages())
    unknown = [item for item in cleaned if item not in known]
    if unknown:
        raise typer.BadParameter(
            f"Langage(s) inconnu(s) : {', '.join(unknown)}. "
            f"Valeurs supportées : {', '.join(sorted(known))}."
        )
    # Dédup en conservant l'ordre fourni par l'utilisateur (cohérent
    # avec build_standards_bundle en mode override).
    seen: set[str] = set()
    out: list[str] = []
    for item in cleaned:
        if item not in seen:
            seen.add(item)
            out.append(item)
    return out


def _validate_review_language(value: str) -> str:
    """Valide ``--language`` : ``fr`` ou ``en`` uniquement.

    Casing/whitespace tolérants. Toute autre valeur lève
    :class:`typer.BadParameter` (exit 2). On ne tolère pas
    silencieusement un langage inconnu côté CLI : c'est un choix
    explicite de l'utilisateur.
    """
    normalized = (value or "").strip().lower()
    if normalized not in ("fr", "en"):
        raise typer.BadParameter(
            f"Valeur inconnue pour --language : {value!r}. "
            "Valeurs supportées : fr, en."
        )
    return normalized


def _render_walipr_result(payload: dict) -> None:
    """Affiche un résultat WaliPR (issu de _run_review_local/_staged) joliment."""
    if "error" in payload:
        console.print(f"[red]✖ Erreur WaliPR :[/red] {payload['error']}")
        return

    score = payload.get("score")
    summary = payload.get("summary") or "(résumé manquant)"
    findings = payload.get("findings") or []
    languages = payload.get("languages_detected") or []

    score_str = f"{score:.2f}" if isinstance(score, (int, float)) else "—"
    languages_str = ", ".join(languages) if languages else "(aucun)"
    console.print(
        f"\n[bold]Repo[/bold] : {payload.get('repo')}  "
        f"[bold]Range[/bold] : {payload.get('range') or '(working tree)'}  "
        f"[bold]Fichiers reviewés[/bold] : "
        f"{payload.get('files_reviewed', 0)}/{payload.get('files_total', 0)}  "
        f"[bold]Score[/bold] : {score_str}"
    )
    console.print(f"[bold]Langages détectés[/bold] : {languages_str}")
    cache_status = payload.get("cache_status")
    if cache_status == "hit":
        console.print("[green]Cache : HIT[/green] (résultat servi sans appel LLM)")
    elif cache_status == "miss":
        console.print("[dim]Cache : MISS (résultat persisté)[/dim]")
    console.print(f"\n[bold]Résumé[/bold] : {summary}\n")

    if not findings:
        console.print("[green]✓ Aucun finding.[/green]")
        return

    console.print(f"[bold]Findings ({len(findings)}) :[/bold]")
    severity_colors = {
        "blocker": "red",
        "major": "yellow",
        "minor": "cyan",
        "info": "white",
    }
    for f in findings:
        sev = f.get("severity", "info")
        col = severity_colors.get(sev, "white")
        line = f.get("line")
        loc = f"{f.get('file')}:{line}" if line else f.get("file")
        console.print(
            f"  [{col}]\\[{sev}][/{col}] [{f.get('category')}] "
            f"{loc} — {f.get('message')}"
        )
        if f.get("suggestion"):
            console.print(f"    [dim]→ {f['suggestion']}[/dim]")
        if f.get("suggested_patch"):
            console.print("    [dim]· patch suggéré disponible[/dim]")


def _apply_trivial_findings(payload: dict, *, repo_root: Path) -> dict:
    """Applique en working-tree les findings ``info``/``minor`` avec patch
    valide (P5.5).

    Renvoie un récap ``{applied, skipped_severity, skipped_no_patch,
    failed, details: [...]}`` qu'on peut afficher en CLI ou inclure
    dans un JSON.
    """
    from .agents.walipr.patches import (
        ApplyOutcome,
        apply_to_workdir,
        coerce_suggested_patch,
        is_severity_auto_appliable,
    )

    findings = payload.get("findings") or []
    applied = 0
    skipped_severity = 0
    skipped_no_patch = 0
    failed = 0
    details: list[dict] = []

    for entry in findings:
        sev = entry.get("severity", "info")
        loc = entry.get("file")
        if not is_severity_auto_appliable(sev):
            skipped_severity += 1
            details.append({
                "file": loc, "severity": sev, "applied": False,
                "reason": "severity above auto-apply threshold",
            })
            continue
        patch = coerce_suggested_patch(entry.get("suggested_patch"))
        if patch is None:
            skipped_no_patch += 1
            details.append({
                "file": loc, "severity": sev, "applied": False,
                "reason": "no applicable patch",
            })
            continue
        outcome: ApplyOutcome = apply_to_workdir(patch, repo_root=repo_root)
        if outcome.applied:
            applied += 1
        else:
            failed += 1
        details.append({
            "file": outcome.file or loc,
            "severity": sev,
            "applied": outcome.applied,
            "reason": outcome.reason,
        })

    return {
        "applied": applied,
        "skipped_severity": skipped_severity,
        "skipped_no_patch": skipped_no_patch,
        "failed": failed,
        "details": details,
    }


def _render_apply_recap(recap: dict) -> None:
    """Affiche un récap après ``--apply-trivial``."""
    console.print(
        f"\n[bold]Auto-apply[/bold] : "
        f"[green]{recap['applied']} appliqué(s)[/green], "
        f"[yellow]{recap['skipped_severity']} skip (sévérité)[/yellow], "
        f"[dim]{recap['skipped_no_patch']} skip (pas de patch)[/dim], "
        f"[red]{recap['failed']} échec(s)[/red]"
    )
    for d in recap.get("details", []):
        if not d.get("applied") and d.get("reason") not in (
            "severity above auto-apply threshold",
            "no applicable patch",
        ):
            console.print(
                f"  [red]✖[/red] {d.get('file')} — {d.get('reason')}"
            )


@app.command(name="review-diff")
def review_diff_cmd(
    repo: Optional[Path] = typer.Argument(
        None,
        help="Chemin du repo Git à reviewer. Défaut : répertoire courant.",
    ),
    range: Optional[str] = typer.Option(
        None,
        "--range",
        help="Range git diff (ex. 'main..HEAD', 'HEAD~3'). "
        "Défaut : working tree vs index.",
    ),
    standards: Optional[str] = typer.Option(
        None,
        "--standards",
        help="Liste CSV de langages forçant le jeu de standards "
        "(ex. 'kotlin,python'). Défaut : auto-détection par "
        "extension. Langages supportés : kotlin, python, "
        "typescript, java.",
    ),
    config: Optional[Path] = typer.Option(
        None,
        "--config", "-c",
        help="Path to the BugHound YAML config file.",
    ),
    env_file: Optional[Path] = typer.Option(
        None,
        "--env-file",
        help="Path to a .env file with secrets (LLM_API_KEY, …).",
    ),
    json_out: bool = typer.Option(
        False,
        "--json",
        help="Sortie JSON brute (pour pipe / CI) au lieu du rendu coloré.",
    ),
    apply_trivial: bool = typer.Option(
        False,
        "--apply-trivial",
        help="Applique automatiquement dans le working-tree les findings "
        "info/minor qui fournissent un suggested_patch valide (P5). "
        "Les sévérités major/blocker ne sont jamais auto-appliquées.",
    ),
    cache: bool = typer.Option(
        False,
        "--cache",
        help="Active le cache disque .walipr-cache/ (P6). HIT si un diff "
        "identique a déjà été reviewé < 7 jours avec les mêmes "
        "standards/langues/modèle. Opt-in.",
    ),
    language: str = typer.Option(
        "fr",
        "--language",
        help="Langue de sortie de la revue (`message`, `suggestion`, "
        "résumés). Valeurs : `fr` (défaut) ou `en`.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Review d'un ``git diff [--range R]`` sur un repo local (WaliPR)."""
    from .agents.walipr.mcp_server import _run_review_local

    _configure_logging(verbose)
    languages = _parse_standards_csv(standards)
    review_language = _validate_review_language(language)
    config = _resolve_mcp_config_path(config)
    if env_file is None:
        user_env = Path("~/.bughound/.env").expanduser()
        env_file = user_env if user_env.exists() else Path(".env")
    if env_file and env_file.exists():
        load_dotenv(env_file, override=False)

    cfg = load_config(config)
    repo_path = (repo or Path.cwd()).expanduser().resolve()
    try:
        result = _run_review_local(
            repo_path, range, cfg, languages=languages, cache_enabled=cache,
            language=review_language,
        )
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]✖ {exc}[/red]")
        raise typer.Exit(code=2) from exc

    if apply_trivial:
        recap = _apply_trivial_findings(result, repo_root=repo_path)
        result["apply_recap"] = recap

    if json_out:
        console.print_json(data=result)
    else:
        _render_walipr_result(result)
        if apply_trivial:
            _render_apply_recap(result["apply_recap"])


@app.command(name="review-staged")
def review_staged_cmd(
    repo: Optional[Path] = typer.Argument(
        None,
        help="Chemin du repo Git à reviewer. Défaut : répertoire courant.",
    ),
    standards: Optional[str] = typer.Option(
        None,
        "--standards",
        help="Liste CSV de langages forçant le jeu de standards "
        "(ex. 'kotlin,python'). Défaut : auto-détection par "
        "extension. Langages supportés : kotlin, python, "
        "typescript, java.",
    ),
    config: Optional[Path] = typer.Option(
        None,
        "--config", "-c",
        help="Path to the BugHound YAML config file.",
    ),
    env_file: Optional[Path] = typer.Option(
        None,
        "--env-file",
        help="Path to a .env file with secrets (LLM_API_KEY, …).",
    ),
    json_out: bool = typer.Option(
        False,
        "--json",
        help="Sortie JSON brute (pour pipe / CI / hook pre-commit).",
    ),
    apply_trivial: bool = typer.Option(
        False,
        "--apply-trivial",
        help="Applique automatiquement dans le working-tree les findings "
        "info/minor qui fournissent un suggested_patch valide (P5).",
    ),
    cache: bool = typer.Option(
        False,
        "--cache",
        help="Active le cache disque .walipr-cache/ (P6). Idéal en pré-"
        "commit : si rien n'a changé depuis la dernière revue (< 7j, "
        "mêmes standards/langues/modèle), évite l'appel LLM. Opt-in.",
    ),
    language: str = typer.Option(
        "fr",
        "--language",
        help="Langue de sortie de la revue (`message`, `suggestion`, "
        "résumés). Valeurs : `fr` (défaut) ou `en`.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Review des changements staged (``git diff --cached``) — WaliPR."""
    from .agents.walipr.mcp_server import _run_review_staged

    _configure_logging(verbose)
    languages = _parse_standards_csv(standards)
    review_language = _validate_review_language(language)
    config = _resolve_mcp_config_path(config)
    if env_file is None:
        user_env = Path("~/.bughound/.env").expanduser()
        env_file = user_env if user_env.exists() else Path(".env")
    if env_file and env_file.exists():
        load_dotenv(env_file, override=False)

    cfg = load_config(config)
    repo_path = (repo or Path.cwd()).expanduser().resolve()
    try:
        result = _run_review_staged(
            repo_path, cfg, languages=languages, cache_enabled=cache,
            language=review_language,
        )
    except Exception as exc:  # noqa: BLE001
        console.print(f"[red]✖ {exc}[/red]")
        raise typer.Exit(code=2) from exc

    if apply_trivial:
        recap = _apply_trivial_findings(result, repo_root=repo_path)
        result["apply_recap"] = recap

    if json_out:
        console.print_json(data=result)
    else:
        _render_walipr_result(result)
        if apply_trivial:
            _render_apply_recap(result["apply_recap"])


@app.command(name="review-mr")
def review_mr_cmd(
    url: str = typer.Argument(
        ...,
        help="URL de la merge/pull request à reviewer "
        "(GitLab, GitHub ou Bitbucket).",
    ),
    standards: Optional[str] = typer.Option(
        None,
        "--standards",
        help="Liste CSV de langages forçant le jeu de standards "
        "(ex. 'kotlin,python'). Défaut : auto-détection par "
        "extension. Langages supportés : kotlin, python, "
        "typescript, java.",
    ),
    config: Optional[Path] = typer.Option(
        None,
        "--config", "-c",
        help="Path to the BugHound YAML config file.",
    ),
    env_file: Optional[Path] = typer.Option(
        None,
        "--env-file",
        help="Path to a .env file with secrets (LLM_API_KEY, "
        "WALIPR_GITLAB_TOKEN, WALIPR_GITHUB_TOKEN, "
        "WALIPR_BITBUCKET_TOKEN).",
    ),
    json_out: bool = typer.Option(
        False,
        "--json",
        help="Sortie JSON brute (pour pipe / CI) au lieu du rendu coloré.",
    ),
    cache: bool = typer.Option(
        False,
        "--cache",
        help="Active le cache disque .walipr-cache/ (P6/P7). HIT si la "
        "même MR (même source_sha) a déjà été reviewée < 7 jours avec "
        "les mêmes standards/langues/modèle. Opt-in.",
    ),
    post_comment: bool = typer.Option(
        False,
        "--post-comment",
        help="Poste UN seul commentaire global (résumé + score + "
        "findings) sur la MR/PR. Opt-in. Mutuellement exclusif avec "
        "--post-inline.",
    ),
    post_inline: bool = typer.Option(
        False,
        "--post-inline",
        help="Poste UN commentaire inline par finding ayant une ligne "
        "valide, directement à côté de la ligne concernée du diff "
        "(P8). Opt-in. Mutuellement exclusif avec --post-comment. "
        "Le token doit avoir les scopes d'écriture "
        "(api / repo / write).",
    ),
    max_diff_lines: int = typer.Option(
        5000,
        "--max-diff-lines",
        help="Limite douce sur la taille du diff (lignes ajoutées + "
        "supprimées). Au-delà, la commande échoue avec un message clair "
        "avant tout appel LLM. Défaut : 5000.",
    ),
    token: Optional[str] = typer.Option(
        None,
        "--token",
        help="Token forge explicite (court-circuite l'environnement). "
        "À éviter sur la ligne de commande, préférer une env var.",
    ),
    language: str = typer.Option(
        "fr",
        "--language",
        help="Langue de sortie de la revue (`message`, `suggestion`, "
        "résumés). Valeurs : `fr` (défaut) ou `en`. Recommandé `en` "
        "pour les MR/PR dont l'audience est anglophone.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Review d'une merge/pull request distante (P7) — WaliPR.

    Récupère le diff via l'API REST (GitLab, GitHub ou Bitbucket),
    le passe à WaliPR, et optionnellement poste un commentaire de
    synthèse sur la MR/PR.

    Le token est lu (par ordre de priorité) depuis ``--token``,
    ``WALIPR_<FORGE>_TOKEN`` ou l'alias universel
    (``GITLAB_TOKEN``/``GITHUB_TOKEN``/``BITBUCKET_TOKEN``).
    """
    from .agents.walipr.forges.errors import (
        DiffTooLargeError, ForgeAPIError,
    )
    from .agents.walipr.forges.auth import MissingForgeTokenError
    from .agents.walipr.forges.url import UnsupportedForgeError
    from .agents.walipr.mr_review import (
        result_to_dict, review_merge_request,
    )

    _configure_logging(verbose)
    if post_comment and post_inline:
        raise typer.BadParameter(
            "--post-comment and --post-inline are mutually exclusive: "
            "either post one global comment, or one comment per "
            "finding line, not both.",
        )
    languages = _parse_standards_csv(standards)
    review_language = _validate_review_language(language)
    config = _resolve_mcp_config_path(config)
    if env_file is None:
        user_env = Path("~/.bughound/.env").expanduser()
        env_file = user_env if user_env.exists() else Path(".env")
    if env_file and env_file.exists():
        load_dotenv(env_file, override=False)

    cfg = load_config(config)
    try:
        outcome = review_merge_request(
            url=url,
            explicit_token=token,
            model_name=cfg.llm.model,
            languages=languages,
            use_cache=cache,
            cache_root=Path.cwd() if cache else None,
            post_comment=post_comment,
            post_inline=post_inline,
            max_diff_lines=max_diff_lines,
            config=cfg,
            language=review_language,
        )
    except UnsupportedForgeError as exc:
        console.print(f"[red]✖ Unsupported MR URL: {exc}[/red]")
        raise typer.Exit(code=2) from exc
    except MissingForgeTokenError as exc:
        console.print(f"[red]✖ {exc}[/red]")
        raise typer.Exit(code=2) from exc
    except DiffTooLargeError as exc:
        console.print(f"[red]✖ {exc}[/red]")
        raise typer.Exit(code=2) from exc
    except ForgeAPIError as exc:
        console.print(f"[red]✖ Forge API error: {exc}[/red]")
        raise typer.Exit(code=2) from exc

    payload = result_to_dict(outcome)
    payload["files_total"] = len(
        outcome.mr_data.diff_unified.split("diff --git")
    ) - 1
    payload["files_reviewed"] = payload["files_total"]

    if json_out:
        console.print_json(data=payload)
    else:
        _render_walipr_result(payload)
        if outcome.comment_posted:
            console.print(
                f"[green]✔ Commentaire posté sur la MR : "
                f"{outcome.comment_url or '(sans URL)'}[/green]"
            )
        if post_inline:
            posted = outcome.inline_comments_posted
            attempted = outcome.inline_comments_attempted
            if attempted == 0:
                console.print(
                    "[yellow]⚠ Aucun finding localisable (line=null) — "
                    "aucun commentaire inline posté.[/yellow]"
                )
            elif posted == attempted:
                console.print(
                    f"[green]✔ {posted}/{attempted} commentaires "
                    f"inline postés sur la MR.[/green]"
                )
            else:
                console.print(
                    f"[yellow]⚠ {posted}/{attempted} commentaires "
                    f"inline postés (les autres ont échoué — voir "
                    f"--verbose).[/yellow]"
                )


@app.command(name="cache-clear")
def cache_clear_cmd(
    repo: Optional[Path] = typer.Argument(
        None,
        help="Chemin du repo dont on purge le cache. Défaut : répertoire courant.",
    ),
    expired_only: bool = typer.Option(
        False,
        "--expired-only",
        help="Ne supprime que les entrées plus vieilles que le TTL (défaut 7j).",
    ),
    json_out: bool = typer.Option(
        False,
        "--json",
        help="Sortie JSON brute (pour pipe / CI).",
    ),
) -> None:
    """Purge le cache .walipr-cache/ d'un repo (P6)."""
    from .agents.walipr.cache import purge_all, purge_expired

    repo_path = (repo or Path.cwd()).expanduser().resolve()
    if expired_only:
        outcome = purge_expired(repo_path)
        mode = "expired-only"
    else:
        outcome = purge_all(repo_path)
        mode = "all"

    payload = {
        "repo": str(repo_path),
        "cache_dir": str(outcome.cache_dir),
        "mode": mode,
        "removed": outcome.removed,
        "kept": outcome.kept,
    }
    if json_out:
        console.print_json(data=payload)
    else:
        console.print(
            f"[bold]Cache[/bold] : {outcome.cache_dir}\n"
            f"  Mode : {mode}\n"
            f"  Entrées supprimées : [cyan]{outcome.removed}[/cyan]\n"
            f"  Entrées conservées : [cyan]{outcome.kept}[/cyan]"
        )


# ---------------------------------------------------------------------------
# discard
# ---------------------------------------------------------------------------


@app.command()
def discard(
    ticket_key: str = typer.Argument(..., help="Ticket whose transient artefacts to delete."),
    config: Path = typer.Option(Path("config/config.yaml"), "--config", "-c"),
    env_file: Optional[Path] = typer.Option(Path(".env"), "--env-file"),
    yes: bool = typer.Option(
        False, "--yes",
        help="Skip the confirmation prompt.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Delete a ticket's downloads / extracted / video frames (keeps the report)."""
    from .workspace import TicketWorkspace

    _configure_logging(verbose)
    cfg = _load(config, env_file)
    out_dir = Path(cfg.output.workdir).expanduser()
    workspace = TicketWorkspace.for_ticket(out_dir, ticket_key)

    if not workspace.root.exists():
        console.print(
            f"[yellow]Aucun dossier d'analyse trouvé pour {ticket_key} "
            f"(attendu : {workspace.root}).[/yellow]"
        )
        raise typer.Exit(code=1)

    console.print(
        f"[bold]Workspace :[/bold] [cyan]{workspace.root}[/cyan]"
    )
    if not yes and not typer.confirm(
        "Supprimer downloads / extracted / video_analysis (rapport conservé) ?",
        default=False,
    ):
        console.print("[dim]Annulé.[/dim]")
        return

    removed = workspace.cleanup_transients()
    console.print(
        f"[green]✓ {len(removed)} dossier(s) supprimé(s).[/green] "
        f"Rapport conservé : {workspace.report_md}"
    )


# ---------------------------------------------------------------------------
# setup
# ---------------------------------------------------------------------------


_SETUP_HOME = Path("~/.bughound").expanduser()


_AGENT_DESCRIPTIONS: dict[str, str] = {
    "sherlekhomes": "analyse de tickets Jira",
    "walipr": "review de PR/MR (GitHub + GitLab)",
}


# Forges que ``bughound setup --with-walipr`` propose à l'utilisateur.
# Bitbucket Cloud et Server partagent la même variable
# ``WALIPR_BITBUCKET_TOKEN`` (cf. ``forges/auth.py::_TOKEN_VARS``), d'où
# trois entrées et non quatre.
_WALIPR_FORGE_LABELS: dict[str, tuple[str, str, str]] = {
    "gitlab": (
        "GitLab",
        "WALIPR_GITLAB_TOKEN",
        "PAT — scopes : read_repository (review) + api (post-comment).",
    ),
    "github": (
        "GitHub",
        "WALIPR_GITHUB_TOKEN",
        "PAT — scopes : repo (privé) ou public_repo (public).",
    ),
    "bitbucket": (
        "Bitbucket (Cloud ou Server)",
        "WALIPR_BITBUCKET_TOKEN",
        "App Password (Cloud) ou HTTP Access Token (Server) — scopes : pullrequest read+write.",
    ),
}


def _render_user_config_yaml(
    *,
    mode: str,
    base_url: str,
    email: Optional[str],
    agents_enabled: Optional[list[str]] = None,
) -> str:
    """Build the YAML body written into ``~/.bughound/config.yaml``."""
    header = (
        "# Configuration BugHound — générée par `bughound setup`\n"
        "# Les secrets (token, mot de passe) restent dans ~/.bughound/.env\n"
        "\n"
    )
    enabled = list(agents_enabled or ["sherlekhomes"])
    agents_block_lines = ["agents:", "  enabled:"]
    for name in enabled:
        agents_block_lines.append(f"    - {name}")
    agents_block = "\n".join(agents_block_lines) + "\n\n"
    if mode == "browser":
        jira = (
            "jira:\n"
            "  mode: browser\n"
            f"  base_url: {base_url}\n"
            "  browser_profile_dir: ~/.bughound/chrome-profile\n"
            "  browser_headless_after_login: false\n"
            "  write_allowed_projects: []\n"
        )
    else:
        email_value = email or "<votre-email>"
        jira = (
            "jira:\n"
            "  mode: api\n"
            f"  base_url: {base_url}\n"
            f"  email: {email_value}\n"
            "  api_token: null  # défini via JIRA_API_TOKEN dans ~/.bughound/.env\n"
            "  write_allowed_projects: []\n"
        )
    rest = (
        "\n"
        "llm:\n"
        "  # Le LLM est routé via votre client MCP (Claude Code, Copilot, Cursor).\n"
        "  # Les paramètres ci-dessous ne sont utilisés qu'en mode CLI direct.\n"
        "  mode: copilot\n"
        "  provider: null\n"
        "  model: null\n"
        "  api_key: null\n"
        "\n"
        "video:\n"
        "  tesseract_cmd: null\n"
        "  ocr_sample_interval_s: 1.0\n"
        "  scene_change_threshold: 0.35\n"
        "\n"
        "logs:\n"
        "  window_before_s: 10\n"
        "  window_after_s: 5\n"
        "  timestamp_formats:\n"
        "    - \"%m-%d %H:%M:%S.%f\"\n"
        "    - \"%Y-%m-%d %H:%M:%S.%f\"\n"
        "\n"
        "projects:\n"
        "  search_roots:\n"
        "    - ~/AndroidStudioProjects\n"
        "  match_strategy: components-then-labels\n"
        "  fuzzy_threshold: 0.72\n"
        "  interactive_fallback: true\n"
        "\n"
        "artifactory:\n"
        "  # Optionnel : si vos pièces jointes Jira sont sur un Artifactory privé,\n"
        "  # ajoutez ici une entrée par hôte. Les credentials vont dans .env.\n"
        "  hosts: []\n"
        "\n"
        "output:\n"
        "  workdir: ~/.bughound/reports\n"
        "  emit_json: true\n"
    )
    return header + agents_block + jira + rest


def _set_walipr_token_in_env(
    env_path: Path, env_var: str, token: str
) -> None:
    """Insert or update ``env_var=token`` in ``~/.bughound/.env``.

    Idempotent: matches the existing line whether commented (``# VAR=``)
    or not, replaces its value, and preserves every other line. If the
    file does not exist yet, creates it with the standard browser-mode
    template, then injects the token line. Best-effort ``chmod 600`` is
    re-applied so secrets stay user-only.
    """
    if not env_path.exists():
        env_path.parent.mkdir(parents=True, exist_ok=True)
        env_path.write_text(
            _render_user_env_template(mode="browser"), encoding="utf-8"
        )
        try:
            env_path.chmod(0o600)
        except OSError:
            pass

    pattern = re.compile(rf"^\s*#?\s*{re.escape(env_var)}\s*=.*$")
    new_line = f"{env_var}={token}"

    lines = env_path.read_text(encoding="utf-8").splitlines()
    replaced = False
    out: list[str] = []
    for line in lines:
        if not replaced and pattern.match(line):
            out.append(new_line)
            replaced = True
        else:
            out.append(line)

    if not replaced:
        if out and out[-1] != "":
            out.append("")
        out.append(
            "# WaliPR — ajouté par `bughound setup --with-walipr`"
        )
        out.append(new_line)

    env_path.write_text("\n".join(out) + "\n", encoding="utf-8")
    try:
        env_path.chmod(0o600)
    except OSError:
        pass


def _render_user_env_template(*, mode: str) -> str:
    """Build a commented ``.env`` template the user fills in locally."""
    common = (
        "# BugHound — secrets locaux (ne JAMAIS committer)\n"
        "# Décommentez et renseignez les variables dont vous avez besoin.\n"
        "\n"
    )
    jira_block = (
        "# --- Jira -----------------------------------------------------------\n"
    )
    if mode == "api":
        jira_block += (
            "# Token API Atlassian Cloud (id.atlassian.com → Manage account →\n"
            "# Security → Create and manage API tokens).\n"
            "# JIRA_API_TOKEN=\n"
        )
    else:
        jira_block += (
            "# Mode browser : pas de token. Le premier lancement ouvre\n"
            "# Chromium pour le SSO ; la session est ensuite réutilisée.\n"
        )
    artifactory_block = (
        "\n"
        "# --- Artifactory (optionnel) ---------------------------------------\n"
        "# Si vos pièces jointes Jira pointent sur un Artifactory privé :\n"
        "# ARTIFACTORY_USER=\n"
        "# ARTIFACTORY_TOKEN=\n"
    )
    walipr_block = (
        "\n"
        "# --- WaliPR — review de MR/PR distantes (optionnel) ---------------\n"
        "# Tokens utilisés par `bughound review-mr <url>` et le tool MCP\n"
        "# `review_merge_request`. Décommentez UNIQUEMENT la ligne de la\n"
        "# forge que vous utilisez et collez le PAT après le `=`\n"
        "# (pas d'espace, pas de guillemets).\n"
        "#\n"
        "# GitLab — User Settings → Access Tokens\n"
        "#   scopes : `read_repository` (review) + `api` (post-comment)\n"
        "# WALIPR_GITLAB_TOKEN=\n"
        "#\n"
        "# GitHub — Settings → Developer settings → Personal access tokens\n"
        "#   scopes : `repo` (privé) ou `public_repo` (post : `repo`)\n"
        "# WALIPR_GITHUB_TOKEN=\n"
        "#\n"
        "# Bitbucket — Personal settings → App passwords (Cloud) ou\n"
        "#             HTTP access tokens (Server)\n"
        "#   scopes : `pullrequest:read` (review), `pullrequest:write` (post)\n"
        "# WALIPR_BITBUCKET_TOKEN=\n"
    )
    llm_block = (
        "\n"
        "# --- LLM (optionnel, mode CLI direct uniquement) -------------------\n"
        "# Inutile si vous utilisez BugHound via Claude Code / Copilot / Cursor.\n"
        "# LLM_API_KEY=\n"
    )
    return common + jira_block + artifactory_block + walipr_block + llm_block


def _prompt_walipr_tokens(env_path: Path) -> int:
    """Walk the user through configuring one PAT per forge.

    Prompts ``yes/no`` per forge listed in ``_WALIPR_FORGE_LABELS``. For
    each ``yes``, asks for the PAT with ``hide_input=True`` so the token
    never echoes to the terminal nor lands in shell history. Empty
    answers are skipped (the corresponding line stays commented in
    ``.env``). Returns the number of tokens actually written so the
    summary can report it.
    """
    console.print()
    console.print("[bold]Configuration des tokens WaliPR[/bold]")
    console.print(
        "[dim]Saisie masquée. Le token est écrit directement dans "
        f"{env_path} sans transiter par l'historique shell.[/dim]"
    )
    console.print()

    written = 0
    for label, env_var, scope_hint in _WALIPR_FORGE_LABELS.values():
        if not typer.confirm(
            f"Configurer {label} ?", default=False
        ):
            continue
        console.print(f"  [dim]{scope_hint}[/dim]")
        token = typer.prompt(
            f"  Token {label}",
            hide_input=True,
            default="",
            show_default=False,
        ).strip()
        if not token:
            console.print(
                f"  [yellow]Token vide — {env_var} reste en l'état.[/yellow]"
            )
            continue
        _set_walipr_token_in_env(env_path, env_var, token)
        console.print(
            f"  [green]✓ {env_var} écrit dans {env_path}[/green]"
        )
        written += 1

    return written


def _print_setup_summary(
    *,
    config_path: Path,
    env_path: Path,
    mode: str,
    base_url: str,
    is_new_env: bool,
    agents_enabled: Optional[list[str]] = None,
    walipr_tokens_added: int = 0,
) -> None:
    """Friendly recap so the user knows exactly what was written."""
    console.print()
    console.print("[green]✓ Configuration enregistrée.[/green]")
    console.print(f"  config : [cyan]{config_path}[/cyan]")
    console.print(
        f"  env    : [cyan]{env_path}[/cyan] "
        f"({'créé' if is_new_env else 'préservé'})"
    )
    console.print(f"  mode   : [yellow]{mode}[/yellow]")
    console.print(f"  jira   : [yellow]{base_url}[/yellow]")
    if agents_enabled:
        console.print(
            f"  agents : [yellow]{', '.join(agents_enabled)}[/yellow]"
        )
    if walipr_tokens_added > 0:
        console.print(
            f"  walipr : [yellow]{walipr_tokens_added} "
            f"token(s) configuré(s)[/yellow]"
        )
    console.print()
    console.print("[bold]Étapes suivantes[/bold]")
    if mode == "api":
        console.print(
            f"  1. Ouvrez [cyan]{env_path}[/cyan] et renseignez "
            "[bold]JIRA_API_TOKEN[/bold]."
        )
    else:
        console.print(
            "  1. Premier lancement : Chromium s'ouvre pour le SSO, "
            "la session est ensuite réutilisée."
        )
    console.print(
        "  2. Lancez votre première enquête : "
        "[bold]bughound analyze MON-TICKET-42[/bold]"
    )


@app.command()
def setup(
    jira_url: Optional[str] = typer.Option(
        None,
        "--jira-url",
        envvar="JIRA_URL",
        help="URL de base de votre Jira (https://jira.maboite.com).",
    ),
    jira_mode: Optional[str] = typer.Option(
        None,
        "--jira-mode",
        envvar="JIRA_MODE",
        help="Mode Jira : 'browser' (Server/DC + SSO) ou 'api' (Cloud).",
    ),
    jira_email: Optional[str] = typer.Option(
        None,
        "--jira-email",
        envvar="JIRA_EMAIL",
        help="Email Atlassian (uniquement pour le mode api).",
    ),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help=(
            "N'invite jamais l'utilisateur. Utilisé par install.sh quand "
            "JIRA_URL / JIRA_MODE sont déjà fournis via env."
        ),
    ),
    agents_arg: Optional[str] = typer.Option(
        None,
        "--agents",
        envvar="BUGHOUND_AGENTS",
        help=(
            "Liste d'agents MCP à activer, séparés par des virgules "
            "(ex. 'sherlekhomes,walipr'). Par défaut : tous les agents "
            "disponibles. En --non-interactive, valeur prise telle quelle."
        ),
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Écrase ~/.bughound/config.yaml sans demander confirmation.",
    ),
    with_walipr: bool = typer.Option(
        False,
        "--with-walipr/--no-with-walipr",
        envvar="BUGHOUND_WITH_WALIPR",
        help=(
            "Après la configuration Jira, propose de saisir un PAT par "
            "forge (saisie masquée, écriture sécurisée dans "
            "~/.bughound/.env). Ignoré en --non-interactive."
        ),
    ),
) -> None:
    """Crée ``~/.bughound/config.yaml`` et ``~/.bughound/.env`` interactivement.

    Pour automatiser (install.sh, CI), passez ``--non-interactive`` avec
    ``JIRA_URL`` et ``JIRA_MODE`` (et ``JIRA_EMAIL`` si mode=api) en env.
    """
    home = _SETUP_HOME
    home.mkdir(parents=True, exist_ok=True)
    config_path = home / "config.yaml"
    env_path = home / ".env"

    # Mode ----------------------------------------------------------------
    if jira_mode is None:
        if non_interactive:
            jira_mode = "browser"
        else:
            jira_mode = typer.prompt(
                "Type de Jira [browser=Server/DC SSO, api=Cloud]",
                default="browser",
            ).strip().lower()
    jira_mode = jira_mode.strip().lower()
    if jira_mode not in {"browser", "api"}:
        raise typer.BadParameter(
            f"--jira-mode doit valoir 'browser' ou 'api' (reçu : {jira_mode!r})."
        )

    # URL -----------------------------------------------------------------
    if jira_url is None or not jira_url.strip():
        if non_interactive:
            raise typer.BadParameter(
                "--jira-url (ou env JIRA_URL) est requis en --non-interactive."
            )
        jira_url = typer.prompt("URL de base Jira (https://...)").strip()
    jira_url = jira_url.strip().rstrip("/")
    if not (jira_url.startswith("http://") or jira_url.startswith("https://")):
        raise typer.BadParameter(
            f"jira_url doit commencer par http(s):// (reçu : {jira_url!r})."
        )

    # Email (api uniquement) ----------------------------------------------
    if jira_mode == "api":
        if not jira_email or not jira_email.strip():
            if non_interactive:
                console.print(
                    "[yellow]Mode api sans email : laissez "
                    "<votre-email> dans le YAML, à compléter à la main.[/yellow]"
                )
                jira_email = None
            else:
                jira_email = typer.prompt(
                    "Email Atlassian", default=""
                ).strip() or None
        else:
            jira_email = jira_email.strip()
    else:
        jira_email = None

    # Agents --------------------------------------------------------------
    # On découvre dynamiquement les agents enregistrés dans le registry
    # (Palier 1+). En interactif et avec ≥ 2 agents, on demande à
    # l'utilisateur de cocher ceux à activer ; sinon on prend tout.
    from . import agents as _agents_module
    available = _agents_module.list_agents()
    if not available:  # garde-fou : ne devrait jamais arriver
        available = ["sherlekhomes"]

    selected_agents: list[str]
    if agents_arg is not None and agents_arg.strip():
        # Parse explicite '--agents a,b,c' : on filtre / valide.
        wanted = [a.strip() for a in agents_arg.split(",") if a.strip()]
        unknown = [a for a in wanted if a not in available]
        if unknown:
            raise typer.BadParameter(
                f"Agents inconnus : {', '.join(unknown)}. "
                f"Disponibles : {', '.join(available)}."
            )
        selected_agents = wanted
    elif non_interactive or len(available) <= 1:
        # Cas par défaut (install.sh, mono-agent, CI) : tout activer.
        selected_agents = list(available)
    else:
        # Mode interactif avec choix multiple : un yes/no par agent.
        console.print()
        console.print("[bold]Agents MCP disponibles[/bold]")
        for name in available:
            desc = _AGENT_DESCRIPTIONS.get(name, "")
            console.print(f"  • [cyan]{name}[/cyan]  [dim]{desc}[/dim]")
        console.print()
        selected_agents = []
        for name in available:
            if typer.confirm(f"Activer l'agent '{name}' ?", default=True):
                selected_agents.append(name)
        if not selected_agents:
            console.print(
                "[yellow]Aucun agent sélectionné — réactivation forcée "
                "de 'sherlekhomes' (défaut).[/yellow]"
            )
            selected_agents = ["sherlekhomes"]

    # config.yaml ---------------------------------------------------------
    yaml_body = _render_user_config_yaml(
        mode=jira_mode, base_url=jira_url, email=jira_email,
        agents_enabled=selected_agents,
    )
    if config_path.exists() and not force:
        if non_interactive:
            console.print(
                f"[yellow]{config_path} existe déjà — non écrasé "
                "(--force pour forcer).[/yellow]"
            )
        else:
            if not typer.confirm(
                f"{config_path} existe déjà. L'écraser ?",
                default=False,
            ):
                console.print("[dim]Configuration conservée en l'état.[/dim]")
                raise typer.Exit(code=0)
            config_path.write_text(yaml_body, encoding="utf-8")
    else:
        config_path.write_text(yaml_body, encoding="utf-8")

    # .env (jamais écrasé : il peut contenir des secrets) -----------------
    is_new_env = not env_path.exists()
    if is_new_env:
        env_path.write_text(
            _render_user_env_template(mode=jira_mode), encoding="utf-8"
        )
        try:
            env_path.chmod(0o600)
        except OSError:
            # Best-effort: Windows / restricted filesystems silently skip.
            pass

    # Prompt WaliPR (opt-in, interactif uniquement). Jamais déclenché en
    # --non-interactive pour préserver install.sh + CI.
    walipr_tokens_added = 0
    if with_walipr and not non_interactive:
        walipr_tokens_added = _prompt_walipr_tokens(env_path)

    _print_setup_summary(
        config_path=config_path,
        env_path=env_path,
        mode=jira_mode,
        base_url=jira_url,
        is_new_env=is_new_env,
        agents_enabled=selected_agents,
        walipr_tokens_added=walipr_tokens_added,
    )


# ---------------------------------------------------------------------------
# mcp-install
# ---------------------------------------------------------------------------

# Catalogue des clients MCP supportés. Pour chaque client :
#   - path     : fichier de config JSON dans le HOME utilisateur
#   - container: chemin (clé(s) JSON imbriquées) où sont stockés les serveurs
#                (ex. ["mcpServers"] ou ["servers"])
#   - extra    : champs additionnels à ajouter à l'entrée serveur (ex. "type":
#                "stdio" pour VS Code/Copilot)
_MCP_CLIENTS: dict[str, dict] = {
    "claude": {
        "label": "Claude Code",
        "path": Path.home() / ".claude.json",
        "container": ["mcpServers"],
        "extra": {},
    },
    "vscode-copilot": {
        "label": "VS Code / Copilot Chat",
        "path": Path.home() / ".config" / "Code" / "User" / "mcp.json",
        "container": ["servers"],
        "extra": {"type": "stdio"},
    },
    "cursor": {
        "label": "Cursor",
        "path": Path.home() / ".cursor" / "mcp.json",
        "container": ["mcpServers"],
        "extra": {},
    },
}


def _resolve_bughound_command() -> str:
    """Return the absolute path to the running bughound binary.

    MCP clients launch servers with a minimal PATH; using a relative
    command name like "bughound" frequently fails. We resolve it once
    here so the written config always works.
    """
    abs_path = shutil.which("bughound")
    if abs_path:
        return abs_path
    # Fallback: inside a pipx venv the entry point lives next to the
    # current Python interpreter.
    cand = Path(os.sys.executable).parent / "bughound"
    if cand.exists():
        return str(cand)
    return "bughound"


def _load_json(path: Path) -> dict:
    if not path.exists():
        return {}
    raw = path.read_text(encoding="utf-8")
    if not raw.strip():
        return {}
    try:
        # VS Code's mcp.json may contain // comments — JSON5 isn't worth
        # a dependency, but a naive strip works for our own writes.
        # We only need to parse files we wrote ourselves; if the user
        # has comments we keep them by erroring out and asking.
        return json.loads(raw)
    except json.JSONDecodeError:
        # The file is JSONC (with comments). Try to strip common
        # comment styles before giving up.
        cleaned_lines = []
        for line in raw.splitlines():
            stripped = line.lstrip()
            if stripped.startswith("//"):
                continue
            cleaned_lines.append(line)
        cleaned = "\n".join(cleaned_lines)
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            raise typer.BadParameter(
                f"{path} contient du JSON invalide ou trop complexe à "
                f"parser ({e}). Éditez-le à la main, ou supprimez-le."
            ) from e


def _set_nested(obj: dict, keys: list[str], value: dict) -> None:
    cur = obj
    for k in keys[:-1]:
        nxt = cur.get(k)
        if not isinstance(nxt, dict):
            nxt = {}
            cur[k] = nxt
        cur = nxt
    cur[keys[-1]] = value


def _get_nested(obj: dict, keys: list[str]) -> Optional[dict]:
    cur = obj
    for k in keys:
        if not isinstance(cur, dict) or k not in cur:
            return None
        cur = cur[k]
    return cur if isinstance(cur, dict) else None


def _build_server_entry(command: str, extra: dict, *, agent: str = "sherlekhomes") -> dict:
    """Build an MCP server entry for one agent.

    SherleKhomes garde des ``args=["mcp-serve"]`` historiques (zéro
    régression pour les utilisateurs qui n'auraient jamais relancé
    ``mcp-install``). Les autres agents reçoivent ``["mcp-serve",
    "--agent", "<nom>"]`` pour forcer le dispatch via le registry.
    """
    if agent == "sherlekhomes":
        args = ["mcp-serve"]
    else:
        args = ["mcp-serve", "--agent", agent]
    entry = {"command": command, "args": args}
    entry.update(extra)
    return entry


# Anciens noms de la clé MCP que l'on souhaite migrer automatiquement
# vers le nouveau nommage au prochain ``mcp-install`` (évite les
# doublons "bughound" + "sherlekhomes" côté client).
_LEGACY_SERVER_NAMES = ("bughound",)


def _read_enabled_agents_from_user_config() -> list[str]:
    """Lit ``~/.bughound/config.yaml`` et renvoie ``agents.enabled``.

    Tolère le YAML manquant ou la clé ``agents`` absente : dans ces deux
    cas on retombe sur ``["sherlekhomes"]`` (rétro-compat avec les
    installs antérieurs au multi-agents). Une erreur de lecture YAML
    est silencieuse — l'utilisateur peut toujours forcer la liste via
    ``mcp-install --agents …``.
    """
    user_config = Path("~/.bughound/config.yaml").expanduser()
    if not user_config.exists():
        return ["sherlekhomes"]
    try:
        with user_config.open("r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
    except (OSError, yaml.YAMLError):
        return ["sherlekhomes"]
    block = data.get("agents") if isinstance(data, dict) else None
    enabled = block.get("enabled") if isinstance(block, dict) else None
    if not isinstance(enabled, list) or not enabled:
        return ["sherlekhomes"]
    return [str(name).strip() for name in enabled if str(name).strip()]


def _install_one_client(
    client_key: str,
    *,
    command: str,
    agent: str,
    overwrite: Optional[bool],
    print_only: bool,
) -> str:
    """Install MCP for a single (client, agent) pair. Returns a status string.

    La clé du serveur écrite dans la config MCP du client est égale au
    nom de l'agent (``sherlekhomes``, ``walipr``, …) : un agent par
    entrée, pas de fusion. La migration de l'ancienne clé ``bughound``
    n'est tentée que pour l'agent ``sherlekhomes`` (héritier direct).
    """
    spec = _MCP_CLIENTS[client_key]
    path: Path = spec["path"]
    container: list[str] = list(spec["container"])
    extra: dict = spec["extra"]
    server_name = agent

    new_entry = _build_server_entry(command, extra, agent=agent)

    if print_only:
        snippet = {container[0]: {server_name: new_entry}}
        console.print(
            f"\n[bold]{spec['label']}[/bold] · agent [cyan]{agent}[/cyan] → "
            f"[cyan]{path}[/cyan]"
        )
        console.print(json.dumps(snippet, indent=2))
        return "printed"

    data = _load_json(path)
    existing_servers = _get_nested(data, container) or {}
    if server_name in existing_servers and existing_servers[server_name] != new_entry:
        if overwrite is None:
            if not typer.confirm(
                f"Le serveur '{server_name}' existe déjà dans {path}. "
                "Le remplacer ?",
                default=False,
            ):
                return f"skipped ({path})"
        elif not overwrite:
            return f"skipped ({path})"

    # Migration : on retire les anciens noms ("bughound", …) uniquement
    # quand on est en train d'écrire l'agent qui en hérite (sherlekhomes).
    # Sinon on laisse l'entrée legacy en place — l'install d'un autre
    # agent (walipr) ne doit pas casser SherleKhomes côté client.
    merged = dict(existing_servers)
    if agent == "sherlekhomes":
        for legacy in _LEGACY_SERVER_NAMES:
            if legacy != server_name and legacy in merged:
                merged.pop(legacy, None)
    merged[server_name] = new_entry

    # Build a fresh container if needed (preserves siblings).
    _set_nested(data, container, merged)

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    return f"written ({path})"


@app.command("mcp-install")
def mcp_install(
    client: str = typer.Option(
        "all",
        "--client",
        "-c",
        help=(
            "Client MCP cible : 'claude', 'vscode-copilot', 'cursor', ou "
            "'all' (défaut : tous les clients détectés)."
        ),
    ),
    agents_arg: Optional[str] = typer.Option(
        None,
        "--agents",
        envvar="BUGHOUND_AGENTS",
        help=(
            "Liste d'agents MCP à enregistrer (séparés par des virgules). "
            "Par défaut : lecture de ~/.bughound/config.yaml (clé "
            "agents.enabled), avec fallback ['sherlekhomes']."
        ),
    ),
    server_name: Optional[str] = typer.Option(
        None,
        "--name",
        hidden=True,
        help=(
            "DÉPRÉCIÉ — utilisé uniquement pour rétro-compatibilité avec "
            "les anciennes invocations 'mcp-install --name X'. Préférez "
            "--agents."
        ),
    ),
    print_only: bool = typer.Option(
        False,
        "--print-only",
        help="Affiche la config qui serait écrite, sans toucher aux fichiers.",
    ),
    overwrite: bool = typer.Option(
        False,
        "--overwrite",
        help=(
            "Écrase une entrée du même nom existante sans demander. "
            "Utile pour les ré-installations idempotentes."
        ),
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Mode non-interactif : ne demande aucune confirmation.",
    ),
) -> None:
    """Enregistre BugHound comme serveur MCP dans Claude Code / VS Code / Cursor.

    Itère sur les agents activés (``agents.enabled`` du config.yaml ou
    ``--agents`` en override) et écrit une entrée par agent dans la
    config MCP de chaque client. Merge prudent : préserve toutes les
    autres entrées MCP de l'utilisateur, et demande confirmation avant
    d'écraser une entrée du même nom (sauf avec ``--overwrite`` ou
    ``--yes``). Migre automatiquement l'ancienne clé ``bughound`` vers
    ``sherlekhomes`` quand cet agent est installé.
    """
    if client == "all":
        targets = list(_MCP_CLIENTS.keys())
    elif client in _MCP_CLIENTS:
        targets = [client]
    else:
        raise typer.BadParameter(
            f"Client inconnu : {client!r}. "
            f"Valeurs valides : {', '.join(_MCP_CLIENTS)}, all."
        )

    # Résolution de la liste d'agents à installer.
    # Priorité : --agents > --name (legacy) > config.yaml > fallback.
    from . import agents as _agents_module
    available = _agents_module.list_agents()
    if not available:
        available = ["sherlekhomes"]

    if agents_arg is not None and agents_arg.strip():
        wanted = [a.strip() for a in agents_arg.split(",") if a.strip()]
    elif server_name is not None and server_name.strip():
        # Rétro-compat : on accepte ``--name X`` mais on prévient.
        wanted = [server_name.strip()]
        console.print(
            "[yellow]⚠ --name est déprécié, utilisez --agents.[/yellow]"
        )
    else:
        wanted = _read_enabled_agents_from_user_config()

    unknown = [a for a in wanted if a not in available]
    if unknown:
        raise typer.BadParameter(
            f"Agents inconnus : {', '.join(unknown)}. "
            f"Disponibles : {', '.join(available)}."
        )

    command = _resolve_bughound_command()
    console.print(
        f"[*] Commande MCP : [cyan]{command} mcp-serve[/cyan] · "
        f"agents : [cyan]{', '.join(wanted)}[/cyan]"
    )

    overwrite_flag: Optional[bool] = True if overwrite else (False if yes else None)

    for key in targets:
        for agent in wanted:
            try:
                status = _install_one_client(
                    key,
                    command=command,
                    agent=agent,
                    overwrite=overwrite_flag,
                    print_only=print_only,
                )
            except typer.BadParameter as exc:
                console.print(
                    f"[red]✗ {_MCP_CLIENTS[key]['label']} · {agent} : "
                    f"{exc}[/red]"
                )
                continue
            console.print(
                f"[green]✓[/green] {_MCP_CLIENTS[key]['label']} · "
                f"[cyan]{agent}[/cyan] : {status}"
            )

    if not print_only:
        console.print()
        console.print(
            "[dim]Rechargez votre client (Reload Window dans VS Code, "
            "ou redémarrage de Claude Code) pour prendre en compte la "
            "nouvelle config.[/dim]"
        )


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------


@app.command()
def version() -> None:
    """Print the BugHound version."""
    console.print(f"BugHound v{__version__}")


def main() -> None:
    app()


if __name__ == "__main__":  # pragma: no cover
    main()
