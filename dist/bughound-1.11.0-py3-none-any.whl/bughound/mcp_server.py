"""Shim de rétro-compat — le serveur MCP de SherleKhomes a déménagé.

Le code historique vit désormais dans
:mod:`bughound.agents.sherlekhomes.mcp_server`. Ce module ré-exporte
les symboles publics pour ne pas casser :

- les tests qui font ``from bughound.mcp_server import ...`` ;
- le CLI ``mcp-serve`` qui fait ``from .mcp_server import run_stdio`` ;
- toute intégration externe qui aurait importé ce module directement.

Il déclenche un :class:`DeprecationWarning` à l'import pour signaler
le déménagement, sans bloquer les usages existants.
"""

from __future__ import annotations

import warnings as _warnings

_warnings.warn(
    "bughound.mcp_server est déprécié — utilisez "
    "bughound.agents.sherlekhomes.mcp_server",
    DeprecationWarning,
    stacklevel=2,
)

from .agents.sherlekhomes.mcp_server import (  # noqa: E402, F401
    DEFAULT_CONFIG_PATH,
    analyze_ticket_impl,
    build_server,
    confirm_and_cleanup_impl,
    get_report_impl,
    list_candidate_projects_impl,
    run_stdio,
)

__all__ = [
    "DEFAULT_CONFIG_PATH",
    "analyze_ticket_impl",
    "build_server",
    "confirm_and_cleanup_impl",
    "get_report_impl",
    "list_candidate_projects_impl",
    "run_stdio",
]
