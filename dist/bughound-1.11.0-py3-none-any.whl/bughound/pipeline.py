"""End-to-end BugHound pipeline.

The pipeline stitches the individual modules together. It does *not* build
its own clients — callers inject them. This keeps the pipeline fully
testable with fakes (no Jira, no LLM, no OpenCV required) and lets the CLI
wire concrete implementations behind the same interface.

High-level flow:

1. Fetch ticket from Jira
2. Analyse ticket metadata (type, relevant comments)
3. Resolve local project + read/generate ``docs/doc.md``
4. Download & unpack attachments
5. Video: OCR the on-screen clock every 10 s + detect user actions
6. Build reduced log window [first − 5min ; last + 2min] + LLM diagnosis
7. Propose a concrete fix (before/after snippets)
8. If ``confidence_score > 0.90``, apply the fix; finalise the report
"""

from __future__ import annotations

import logging
import re as _re
from datetime import date as _date
from pathlib import Path
from typing import Callable, Optional

from .analyzers import (
    BestHandoffPayload,
    FixProposer,
    LogDiagnostician,
    MonolithicAnalyzer,
    TicketAnalyzer,
    apply_fix,
    prepare_best_handoff,
)
from .analyzers.clarification import (
    LOGS_MISSING,
    NO_CODE_REFS,
    VIDEO_CLOCK_MISSING,
)
from .attachments import AttachmentBundle, AttachmentKind, AttachmentManager
from .attachments.selection import select_confirmation_pair
from .core.models import (
    AnalysisMode,
    AppliedFix,
    AppliedFixStatus,
    Attachment,
    BugReport,
    CodeReference,
    ConfidenceScores,
    ProposedFix,
    ReproductionMethod,
    ResolvedProject as ResolvedProjectModel,
    Ticket,
    TicketAnalysis,
    TicketType,
    UserAction,
    VideoEvent,
)
from .documentation import ProjectDocumentationGenerator
from .jira_client import JiraClient
from .llm import LLMClient
from .logs import AlignmentError, LogCorrelator, LogcatParser, VideoLogAligner
from .logs.aligner import _parse_hhmm
from .projects import CodebaseInspector, ProjectResolver
from .projects.resolver import ResolvedProject
from .video import VideoAnalyzer
from .video.time_ocr import DisplayTimeSample
from .workspace import TicketWorkspace

log = logging.getLogger(__name__)


# A progress callback: (step_index, total_steps, human_readable_message).
# Emitting progress is purely informational — the pipeline never blocks
# on the callback, and exceptions from it are swallowed so an editor's
# flaky UI can't break the analysis.
ProgressCallback = Callable[[int, int, str], None]

# Number of top-level steps the pipeline announces. Kept as a constant so
# the "[step X/TOTAL]" labels stay consistent even as internal details move.
_TOTAL_STEPS = 8

# Minimum confidence required to auto-apply a fix on disk.
_AUTO_APPLY_THRESHOLD = 0.90

# Stop-words excluded from keyword extraction so common English/French words
# don't pollute the log search.
_KEYWORD_STOP_WORDS = frozenset({
    "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "to", "of", "in", "on", "at", "by",
    "for", "with", "from", "and", "or", "not", "no", "but", "if", "as",
    "that", "this", "these", "those", "it", "its", "they", "them", "we",
    "you", "your", "our", "their", "my", "his", "her", "only", "also",
    "when", "where", "what", "how", "why", "which", "who",
    # French
    "le", "la", "les", "un", "une", "des", "du", "de", "et", "ou", "en",
    "dans", "sur", "par", "pour", "avec", "est", "sont", "ne", "pas",
    "que", "qui", "ce", "se", "il", "elle", "ils", "elles", "au", "aux",
    "mais", "donc", "or", "ni", "car", "plus", "très", "même",
})


def _align_parser_year(target: object, year: int) -> None:
    """Best-effort sync of a :class:`LogcatParser`'s default year.

    ``target`` may be either a :class:`LogcatParser` directly or a
    :class:`LogCorrelator` whose internal parser is exposed as
    ``_parser``. Anything else is ignored. The function is deliberately
    silent on failure: aligning the year is an optimisation, not a
    correctness requirement (ISO-timestamped lines parse fine without
    it; only year-less ``MM-DD`` Android lines benefit from it).
    """
    parser = getattr(target, "_parser", target)
    if parser is None:
        return
    if hasattr(parser, "_default_year"):
        try:
            parser._default_year = int(year)
        except (TypeError, ValueError):  # pragma: no cover - defensive
            pass


# Filename prefixes that identify an Android *bugreport* dump. Bugreports
# bundle a complete logcat snapshot together with system state (dumpsys,
# /proc, services), which makes them strictly more informative than
# stand-alone ``mlog.log`` / ``logcat_*.txt`` exports captured around the
# same moment. When a bugreport is present we therefore prefer it over
# any other log file for window extraction.
_BUGREPORT_FILENAME_PREFIXES: tuple[str, ...] = ("bugreport",)


def _is_bugreport(path: Path) -> bool:
    """Return ``True`` if ``path`` looks like an Android bugreport dump.

    The check is purely filename-based (matches ``bugreport-*`` /
    ``bugreport_*`` / ``bugreport.txt``) so it stays cheap and works
    even on files that haven't been opened yet. It mirrors the prefix
    used by :mod:`bughound.attachments.kinds` to upgrade ``.txt`` files
    to :attr:`AttachmentKind.LOG`.
    """
    name = path.name.lower()
    return any(name.startswith(p) for p in _BUGREPORT_FILENAME_PREFIXES)


def _prioritize_bugreports(paths: list[Path]) -> list[Path]:
    """If any bugreport is in ``paths``, return only the bugreports.

    Bugreports embed a full ``logcat`` snapshot together with system
    state (``dumpsys``, ``/proc``, services, …) for the exact day of
    the bug. Other log files in the same ticket are usually partial
    or out-of-day extracts (e.g. an unrelated ``A12_switching_source``
    captured weeks later), and mixing them dilutes the wall-clock
    range probe and pollutes the log window.

    When no bugreport is present we return the input unchanged so the
    legacy multi-log behaviour is preserved.
    """
    bugreports = [p for p in paths if _is_bugreport(p)]
    if bugreports:
        return bugreports
    return list(paths)


def _group_samples_by_video(
    samples: list[DisplayTimeSample],
) -> dict[Optional[Path], list[DisplayTimeSample]]:
    """Group display-time samples by their ``source_video`` path.

    Order within each group is preserved. A ``None`` key catches samples
    produced by older code paths (or test fakes) that don't stamp the
    source video — they're treated as a single virtual group so behaviour
    stays sensible if no video is set.
    """
    grouped: dict[Optional[Path], list[DisplayTimeSample]] = {}
    for s in samples:
        key = s.source_video
        grouped.setdefault(key, []).append(s)
    return grouped


def _pick_anchor_sample(
    group: list[DisplayTimeSample],
    *,
    reference_date,
    log_lower,
    log_upper,
) -> Optional[DisplayTimeSample]:
    """Pick the most plausible anchor sample within a single video.

    Defends against OCR hallucinations like ``01:09`` showing up as the
    very first parseable reading on a video that actually starts around
    ``11:03``. Strategy:

    1. **Log-range filter (preferred)** — when ``log_lower``/``log_upper``
       are provided, restrict candidates to samples whose ``HH:MM`` falls
       inside the widened log range.
    2. **Majority vote on hours when spread > 1 h** — if the kept samples
       cover more than 60 min of wall-clock, the recording almost
       certainly contains OCR hallucinations: cluster samples by hour
       and pick the cluster with the most samples. Ties go to the
       cluster with the earliest sample (a real on-screen clock keeps
       advancing, so the first reading of the dominant cluster anchors
       the window).
    3. **Earliest sample within the (filtered) candidates** — default
       behaviour preserving :meth:`VideoLogAligner.display_time_anchor`
       semantics when there's no spread to disambiguate.
    """
    from collections import Counter

    parseable: list[tuple[DisplayTimeSample, object]] = []
    for s in group:
        wc = _parse_hhmm(s.wallclock_hhmm, reference_date)
        if wc is not None:
            parseable.append((s, wc))

    if not parseable:
        return None

    # 1. Filter by log range when available.
    if log_lower is not None and log_upper is not None:
        in_range = [
            (s, wc) for (s, wc) in parseable
            if log_lower <= wc <= log_upper
        ]
        if not in_range:
            # All samples sit outside the logs: no plausible anchor here.
            return None
        candidates = in_range
    else:
        candidates = list(parseable)

    # 2. Majority vote on hours when the spread exceeds 1 h: that means
    # at least one of the readings is an OCR hallucination, and a real
    # on-screen clock can't drift by more than a few minutes during a
    # short recording. We trust the most frequent hour and pick its
    # earliest sample (chronologically in the video) as the anchor.
    if len(candidates) >= 2:
        wallclocks = [wc for (_s, wc) in candidates]
        spread = (max(wallclocks) - min(wallclocks)).total_seconds()
        if spread > 60 * 60:
            # Cluster by hour-of-day so multiple readings of the same
            # genuine hour (e.g. 11:03 + 11:04 + 11:05) reinforce each
            # other against an isolated OCR hallucination.
            counts = Counter(wc.hour for (_s, wc) in candidates)
            top_hour, top_count = counts.most_common(1)[0]
            tied = [h for (h, c) in counts.items() if c == top_count]
            if len(tied) == 1:
                # Clear majority: trust it.
                cluster_members = [
                    (s, wc) for (s, wc) in candidates
                    if wc.hour == top_hour
                ]
                cluster_members.sort(key=lambda x: x[0].frame_time_s)
                return cluster_members[0][0]
            # Tie (typically 1 + 1 in a two-sample group). Heuristic:
            # OCR hallucinations cluster on the *first* frames of a
            # recording (camera focusing, status-bar still drawing).
            # Prefer the latest sample whose hour belongs to a tied
            # cluster — it's the most likely genuine reading.
            latest = max(candidates, key=lambda x: x[0].frame_time_s)
            return latest[0]

    # 3. Default: earliest sample (matches legacy behaviour for
    # well-behaved recordings where every reading is consistent).
    candidates.sort(key=lambda x: x[0].frame_time_s)
    return candidates[0][0]


def _resolve_window_from_samples(
    *,
    samples: list[DisplayTimeSample],
    aligner: VideoLogAligner,
    reference_date,
    log_range: Optional[tuple],
) -> tuple[Optional[object], Optional[object], list[Path], dict]:
    """Compute the (first_wc, last_wc) wall-clock window from clock samples.

    The function builds **one anchor per source video** (instead of using
    the first sample as a global anchor and projecting every other sample
    through it — which would be wrong as soon as two videos were filmed
    at different wall-clock times).

    For each video the anchor sample is selected by
    :func:`_pick_anchor_sample` so that OCR hallucinations
    (e.g. ``01:09`` glimpsed in a frame whose real clock reads ``11:03``)
    don't shift the window by hours.

    When ``log_range`` is provided ``(min_log_ts, max_log_ts)`` the function
    additionally drops any per-video wall-clock that falls fully outside
    the logs' coverage, with a 30-min tolerance on each side. The list of
    discarded video paths is returned so the pipeline can surface a note.

    Returns ``(first_wc, last_wc, dropped_videos, debug)`` where
    ``debug`` is a dict ``{video_path: (first_wc, last_wc)}`` for each
    retained video, useful for progress messages and tests.
    """
    from datetime import timedelta

    grouped = _group_samples_by_video(samples)
    per_video_wallclocks: list = []
    retained_debug: dict = {}
    dropped_videos: list[Path] = []

    log_lower = None
    log_upper = None
    if log_range is not None:
        log_min, log_max = log_range
        # Tolerance: 30 min on each side. Keeps the filter from rejecting
        # videos that are *just* outside the logs' window because of
        # rotation boundaries.
        log_lower = log_min - timedelta(minutes=30)
        log_upper = log_max + timedelta(minutes=30)

    for video_path, group in grouped.items():
        anchor_sample = _pick_anchor_sample(
            group,
            reference_date=reference_date,
            log_lower=log_lower,
            log_upper=log_upper,
        )
        if anchor_sample is None:
            # No plausible sample (typically: every reading sits outside
            # the logs' window). Drop the whole video.
            if video_path is not None:
                dropped_videos.append(video_path)
            continue

        sub_anchor = aligner.display_time_anchor(
            [anchor_sample], reference_date=reference_date
        )
        if sub_anchor is None:
            continue
        first_wc = sub_anchor.wallclock
        last_wc = first_wc
        # Project the *remaining* samples through the chosen anchor and
        # extend the window — but only those that are temporally after
        # the anchor's frame in the recording.
        for s in group:
            if s is anchor_sample:
                continue
            wc = VideoLogAligner.to_wallclock(sub_anchor, s.frame_time_s)
            if wc < first_wc:
                first_wc = wc
            if wc > last_wc:
                last_wc = wc

        # Filter: skip videos whose wall-clock range falls fully outside
        # the available logs (with tolerance). When samples sit on both
        # sides of the boundary we still keep them — the correlator will
        # clip the actual window.
        if log_lower is not None and log_upper is not None:
            if last_wc < log_lower or first_wc > log_upper:
                if video_path is not None:
                    dropped_videos.append(video_path)
                continue

        per_video_wallclocks.append(first_wc)
        per_video_wallclocks.append(last_wc)
        if video_path is not None:
            retained_debug[video_path] = (first_wc, last_wc)

    if not per_video_wallclocks:
        return None, None, dropped_videos, retained_debug
    return (
        min(per_video_wallclocks),
        max(per_video_wallclocks),
        dropped_videos,
        retained_debug,
    )


def _extract_ticket_keywords(ticket: "Ticket") -> list[str]:
    """Extract meaningful keywords from a ticket's title and description.

    Returns a deduplicated list of lowercase tokens (>3 chars, not stop-words
    and not purely numeric) suitable for passing to
    ``VideoLogAligner.keyword_anchor``.
    """
    parts: list[str] = []
    if ticket.title:
        parts.append(ticket.title)
    if ticket.description:
        parts.append(ticket.description)
    text = " ".join(parts)
    tokens = _re.findall(r"[A-Za-z][A-Za-z0-9_]{2,}", text)
    seen: set[str] = set()
    keywords: list[str] = []
    for tok in tokens:
        low = tok.lower()
        if low in _KEYWORD_STOP_WORDS:
            continue
        if low not in seen:
            seen.add(low)
            keywords.append(tok)
    return keywords


class BugHoundPipeline:
    """Run the full ticket → report pipeline."""

    def __init__(
        self,
        *,
        jira: JiraClient,
        llm: LLMClient,
        workdir: Path,
        attachment_manager: Optional[AttachmentManager] = None,
        ticket_analyzer: Optional[TicketAnalyzer] = None,
        video_analyzer: Optional[VideoAnalyzer] = None,
        aligner: Optional[VideoLogAligner] = None,
        correlator: Optional[LogCorrelator] = None,
        logcat_parser: Optional[LogcatParser] = None,
        project_resolver: Optional[ProjectResolver] = None,
        project_override: Optional[ResolvedProject] = None,
        doc_generator: Optional[ProjectDocumentationGenerator] = None,
        log_diagnostician: Optional[LogDiagnostician] = None,
        fix_proposer: Optional[FixProposer] = None,
        monolithic_analyzer: Optional[MonolithicAnalyzer] = None,
        use_monolithic: bool = False,
        mode: Optional[str] = None,
    ) -> None:
        self._jira = jira
        self._llm = llm
        self._workdir = workdir
        self._attachments = attachment_manager or AttachmentManager(jira)
        self._ticket_analyzer = ticket_analyzer or TicketAnalyzer(llm)
        # Video analyzer is optional: if the caller didn't supply one, we
        # skip video analysis (handy when Tesseract/OpenCV aren't available).
        self._video = video_analyzer
        self._aligner = aligner or VideoLogAligner()
        self._correlator = correlator or LogCorrelator()
        self._logcat_parser = logcat_parser or LogcatParser()
        self._project_resolver = project_resolver
        self._project_override = project_override
        self._doc_generator = doc_generator or ProjectDocumentationGenerator(llm)
        self._diagnostician = log_diagnostician or LogDiagnostician(llm)
        self._fix_proposer = fix_proposer or FixProposer(llm)
        # The ``BugHoundPipeline`` constructor still defaults to
        # ``legacy`` so existing programmatic call-sites (and a large
        # body of unit tests) keep working unchanged. The user-facing
        # entry points — the CLI ``analyze`` command and the MCP tool
        # ``analyze_ticket`` — default to ``best`` instead, which is
        # what guards the external chat LLM's context window in
        # production.
        #
        # ``best`` mode short-circuits *all* LLM calls inside BugHound:
        # ingestion runs deterministically and a ready-to-execute
        # prompt is handed off to the external LLM inside its own
        # single context.
        if mode is None:
            self._mode = "monolithic" if use_monolithic else "legacy"
        else:
            if mode not in {"legacy", "monolithic", "best"}:
                raise ValueError(
                    f"unknown analysis mode {mode!r}; expected "
                    "'legacy', 'monolithic' or 'best'"
                )
            if use_monolithic and mode != "monolithic":
                raise ValueError(
                    "use_monolithic=True is incompatible with "
                    f"mode={mode!r}"
                )
            self._mode = mode
        self._use_monolithic = self._mode == "monolithic"
        self._monolithic = monolithic_analyzer or (
            MonolithicAnalyzer(llm) if self._use_monolithic else None
        )
        # Populated by ``run()`` so callers (CLI, MCP tool) can reach the
        # per-ticket workspace that hosts downloads/extracted/video frames.
        self.last_workspace: Optional[TicketWorkspace] = None

    # ---- public API -------------------------------------------------------

    def run(
        self,
        ticket_key: str,
        *,
        progress: Optional[ProgressCallback] = None,
    ) -> "BugReport | BestHandoffPayload":
        """Run the pipeline and return a :class:`BugReport`.

        In ``best`` mode the pipeline stops after the deterministic
        ingestion phase (steps 1-6) and returns a
        :class:`BestHandoffPayload` instead of a :class:`BugReport` —
        no LLM call is made inside BugHound. The caller (CLI or MCP
        tool) is responsible for surfacing the ready-to-execute prompt
        carried by the payload to its single-context external LLM.
        """
        emit = self._make_emitter(progress)

        workspace = TicketWorkspace.for_ticket(self._workdir, ticket_key)
        self.last_workspace = workspace

        # ---- step 1: fetch the ticket -------------------------------------
        emit(1, f"Récupération du ticket {ticket_key} depuis Jira…")
        ticket = self._jira.get_ticket(ticket_key)
        emit(
            1,
            f"Ticket {ticket.key} — « {ticket.title[:80]} » "
            f"({len(ticket.attachments)} pièce(s) jointe(s), "
            f"{len(ticket.comments)} commentaire(s))",
        )

        # ---- step 2: analyze ticket metadata ------------------------------
        if self._mode == "best":
            # ``best`` mode never calls any LLM inside BugHound — the
            # ticket metadata is forwarded as-is to the external LLM
            # via the handoff prompt.
            emit(
                2,
                "Analyse du ticket différée (mode best : aucun appel "
                "LLM côté BugHound, handoff au chat externe).",
            )
            analysis = TicketAnalysis(
                ticket_key=ticket.key,
                ticket_type=TicketType.UNKNOWN,
                type_confidence=0.0,
                summary="",
                relevant_comments=[],
            )
        elif self._use_monolithic:
            # Defer ticket typing + comment relevance to the monolithic
            # analyzer. We still announce the step so the UI keeps a stable
            # 8-step counter, but no LLM call happens here.
            emit(
                2,
                "Analyse du ticket différée (mode monolithique : un seul "
                "appel LLM en fin de pipeline).",
            )
            analysis = TicketAnalysis(
                ticket_key=ticket.key,
                ticket_type=TicketType.UNKNOWN,
                type_confidence=0.0,
                summary="",
                relevant_comments=[],
            )
        else:
            emit(2, "Analyse du ticket (type + commentaires pertinents)…")
            analysis = self._ticket_analyzer.analyze(ticket)
            emit(
                2,
                f"Type du ticket : {analysis.ticket_type} — "
                f"{len(analysis.relevant_comments)} commentaire(s) "
                f"pertinent(s) retenu(s).",
            )

        report = BugReport(
            ticket=ticket,
            analysis=analysis,
            analysis_mode=(
                AnalysisMode.BEST
                if self._mode == "best"
                else AnalysisMode.MONOLITHIC
                if self._use_monolithic
                else AnalysisMode.LEGACY
            ),
        )

        # ---- step 3: resolve the local project + read/generate doc.md ----
        emit(3, "Résolution du dossier de code local + lecture/génération de docs/doc.md…")
        resolved = self._resolve_project(ticket)
        project_doc_md: Optional[str] = None
        if resolved is not None:
            report.project = ResolvedProjectModel(
                ticket_key=resolved.ticket_key,
                root=resolved.root,
                name=resolved.name,
                matched_on=resolved.matched_on,
                score=resolved.score,
            )
            if self._mode == "best":
                # ``best`` mode hands off to the external LLM, so we
                # never call the doc generator here. The external LLM
                # will read the project itself when it executes the
                # workflow inside its own context.
                emit(
                    3,
                    f"Projet résolu : {resolved.name} ({resolved.root}) "
                    f"— génération doc.md ignorée (mode best).",
                )
            else:
                try:
                    doc_path = self._doc_generator.generate_or_read(resolved)
                    report.doc_md_path = doc_path
                    try:
                        project_doc_md = doc_path.read_text(encoding="utf-8")
                    except OSError:
                        project_doc_md = None
                    # Detect the doc-generator fallback so the user sees it in
                    # the final report instead of a silent "empty doc".
                    if (
                        project_doc_md
                        and "Le modèle n'a pas produit de JSON structuré"
                        in project_doc_md
                    ):
                        report.notes.append(
                            "Project doc is a fallback stub: the LLM did not "
                            "return valid JSON. Check LLM configuration or "
                            "delete docs/doc.md to retry."
                        )
                        emit(
                            3,
                            f"Projet résolu : {resolved.name} — doc.md écrit "
                            f"en fallback (LLM vide, voir notes).",
                        )
                    else:
                        emit(
                            3,
                            f"Projet résolu : {resolved.name} ({resolved.root}) — "
                            f"doc : {doc_path.relative_to(resolved.root)}.",
                        )
                except Exception as exc:  # pragma: no cover - defensive
                    report.notes.append(f"doc.md generation failed: {exc}")
                    emit(3, f"doc.md non généré ({exc}).")
        else:
            emit(3, "Aucun projet local n'a pu être résolu — doc.md et cross-ref ignorés.")

        # ---- step 4: download + unpack attachments -----------------------
        emit(
            4,
            f"Téléchargement de {len(ticket.attachments)} pièce(s) jointe(s) "
            f"dans {workspace.root}…",
        )
        workspace.ensure_dirs()
        bundle = self._attachments.collect(
            ticket,
            self._workdir,
            downloads_dir=workspace.downloads,
            extracted_dir=workspace.extracted,
        )
        other = (
            len(bundle.files)
            - len(bundle.videos)
            - len(bundle.logs)
            - len(bundle.archives)
        )
        emit(
            4,
            f"Pièces jointes prêtes : {len(bundle.videos)} vidéo(s), "
            f"{len(bundle.logs)} log(s), {len(bundle.archives)} archive(s), "
            f"{other} autre(s).",
        )
        if bundle.skipped_attachments:
            names = ", ".join(a.filename for a in bundle.skipped_attachments[:5])
            suffix = "…" if len(bundle.skipped_attachments) > 5 else ""
            report.notes.append(
                f"{len(bundle.skipped_attachments)} pièce(s) jointe(s) plus "
                f"ancienne(s) ignorée(s) (lot le plus récent conservé) : "
                f"{names}{suffix}"
            )
        if bundle.skipped_archives:
            names = ", ".join(p.name for p in bundle.skipped_archives[:5])
            suffix = "…" if len(bundle.skipped_archives) > 5 else ""
            report.notes.append(
                f"{len(bundle.skipped_archives)} archive(s) protégée(s) "
                f"par mot de passe ignorée(s) : {names}{suffix}"
            )
        if bundle.harvested_urls:
            preview = ", ".join(bundle.harvested_urls[:3])
            suffix = "…" if len(bundle.harvested_urls) > 3 else ""
            report.notes.append(
                f"{len(bundle.harvested_urls)} fichier(s) récupéré(s) depuis "
                f"des URL(s) dans la description du ticket (aucune pièce jointe Jira) : "
                f"{preview}{suffix}"
            )
            emit(
                4,
                f"Pas de pièce jointe Jira — téléchargement via URL depuis "
                f"la description : {len(bundle.harvested_urls)} "
                f"fichier(s).",
            )

        # ---- step 5: video analysis (display-time OCR + user actions) ----
        display_samples: list[DisplayTimeSample] = []
        user_actions: list[UserAction] = []
        video_events: list[VideoEvent] = []   # kept for backward compat / reporter
        if self._video is not None and bundle.videos:
            emit(
                5,
                f"Extraction frames + OCR horloge (toutes les 10s) sur "
                f"{len(bundle.videos)} vidéo(s)…",
            )
            for video_file in bundle.videos:
                # Display-time OCR (new flow). Tolerate analyzers that
                # don't implement the method yet (older fakes in tests).
                detect_dt = getattr(self._video, "detect_display_times", None)
                if callable(detect_dt):
                    try:
                        samples = detect_dt(
                            video_file.path, frames_dir=workspace.frames
                        )
                    except Exception as exc:  # pragma: no cover - defensive
                        report.notes.append(
                            f"Display-time detection failed for {video_file.path.name}: {exc}"
                        )
                        samples = []
                    display_samples.extend(samples)

                # User actions (scene-change based).
                detect_ua = getattr(self._video, "detect_user_actions", None)
                if callable(detect_ua):
                    try:
                        actions = detect_ua(video_file.path)
                    except Exception as exc:  # pragma: no cover - defensive
                        report.notes.append(
                            f"User-action detection failed for {video_file.path.name}: {exc}"
                        )
                        actions = []
                    user_actions.extend(actions)

                # Legacy events (crash_dialog, scene_change, fatal_exception…).
                # Kept so existing callers / reporters that rely on
                # ``video_events`` still see crash dialogs even when the new
                # display-time flow yields nothing.
                analyze_video = getattr(self._video, "analyze_video", None)
                if callable(analyze_video):
                    try:
                        legacy_events = analyze_video(video_file.path)
                    except Exception as exc:  # pragma: no cover - defensive
                        report.notes.append(
                            f"Video analysis failed for {video_file.path.name}: {exc}"
                        )
                        legacy_events = []
                    video_events.extend(legacy_events)

            # Surface each clock reading as a video event too, so the
            # reporter can display them consistently alongside actions.
            for s in display_samples:
                video_events.append(
                    VideoEvent(
                        timestamp_s=s.frame_time_s,
                        confidence=0.9,
                        kind="display_time",
                        evidence=s.text[:160],
                        frame_path=s.frame_path,
                        detected_time=s.wallclock_hhmm,
                    )
                )
            if display_samples:
                emit(
                    5,
                    f"{len(display_samples)} lecture(s) d'horloge, "
                    f"{len(user_actions)} action(s) utilisateur détectée(s).",
                )
            else:
                emit(5, f"{len(user_actions)} action(s) utilisateur — aucune horloge lisible.")

            bug_kinds = {"crash_dialog", "fatal_exception", "anr", "ocr_error"}
            if any(ev.kind in bug_kinds for ev in video_events):
                top = max(
                    (ev for ev in video_events if ev.kind in bug_kinds),
                    key=lambda ev: ev.confidence,
                )
                emit(
                    5,
                    f"Bug détecté dans la vidéo : {top.kind} "
                    f"à t={top.timestamp_s:.1f}s (conf {top.confidence:.2f}).",
                )
        elif bundle.videos and self._video is None:
            report.notes.append(
                "Found video attachments but no video analyzer is configured; "
                "skipping video analysis."
            )
            emit(5, "Vidéos trouvées mais l'analyseur vidéo n'est pas configuré.")
        else:
            emit(5, "Aucune vidéo à analyser.")

        report.video_events = video_events
        report.user_actions = user_actions

        # ---- step 6: build reduced log window + LLM diagnosis ------------
        diagnosis = None
        log_paths = [f.path for f in bundle.of_kind(AttachmentKind.LOG)]
        # If a bugreport is among the attachments, rely on it exclusively.
        # Bugreports embed a full logcat snapshot for the exact day of the
        # bug, while sibling logs (``mlog.log``, ``A12_switching_source``,
        # …) are often partial or captured on a different day, which
        # dilutes the wall-clock probe and empties the window.
        prioritized = _prioritize_bugreports(log_paths)
        if prioritized != log_paths:
            dropped = [p.name for p in log_paths if p not in prioritized]
            emit(
                6,
                f"Bugreport(s) détecté(s) : "
                f"{', '.join(p.name for p in prioritized)} — "
                f"priorité, {len(dropped)} autre(s) log(s) ignoré(s) "
                f"({', '.join(dropped[:3])}{'…' if len(dropped) > 3 else ''}).",
            )
            log_paths = prioritized
        if log_paths and display_samples:
            # Probe the wall-clock range covered by the available logs so
            # we can drop any video whose clock falls fully outside it.
            # When several videos are present, this prevents a recording
            # made *after* the logs end (or before they start) from
            # stretching the requested window into a region with no data.
            log_range = self._correlator.probe_log_range(log_paths)

            # Reference date used to turn a ``HH:MM`` OCR reading into a
            # full ``datetime``. We strongly prefer the **logs' own date**
            # (when probing succeeded) because:
            #   - logs and the on-screen clock are recorded *together*,
            #   - the ticket's ``created`` date can lag the bug by days
            #     or months, which would put the wall-clock window in a
            #     totally different day than the logs (→ 0 line extracted).
            # We fall back to the ticket creation date, then to today's
            # date, as the legacy behaviour for tests and edge cases.
            if log_range is not None:
                ticket_ref_date = log_range[0].date()
                # Also align the LogcatParser's default year with the logs
                # themselves: yearless ``MM-DD HH:MM:SS.mmm`` lines would
                # otherwise be stamped with ``datetime.now().year``, which
                # can land them in a different year than the wall-clock
                # window we're about to build.
                _align_parser_year(self._correlator, log_range[0].year)
                _align_parser_year(self._logcat_parser, log_range[0].year)
            elif ticket.created is not None:
                ticket_ref_date = ticket.created.date()
            else:
                ticket_ref_date = _date.today()

            first_sample_wc, last_sample_wc, dropped, retained = (
                _resolve_window_from_samples(
                    samples=list(display_samples),
                    aligner=self._aligner,
                    reference_date=ticket_ref_date,
                    log_range=log_range,
                )
            )
            for v in dropped:
                report.notes.append(
                    f"Vidéo écartée — son horloge ({v.name}) tombe en "
                    f"dehors de la plage couverte par les logs disponibles."
                )
            if first_sample_wc is None:
                # No per-video anchor produced a usable window. Fall back
                # to the legacy global-anchor projection so we still emit
                # *something* (older test fakes don't stamp source_video,
                # and ``_resolve_window_from_samples`` would then return
                # ``None`` only when even ``display_time_anchor`` fails).
                fallback = self._aligner.display_time_anchor(
                    display_samples, reference_date=ticket_ref_date
                )
                if fallback is not None:
                    first_sample_wc = fallback.wallclock
                    last_sample_wc = first_sample_wc
                    for s in display_samples[1:]:
                        wc = VideoLogAligner.to_wallclock(
                            fallback, s.frame_time_s
                        )
                        if wc > last_sample_wc:
                            last_sample_wc = wc

            if first_sample_wc is not None:
                if len(retained) > 1:
                    parts = ", ".join(
                        f"{p.name}={fw.strftime('%H:%M')}→{lw.strftime('%H:%M')}"
                        for p, (fw, lw) in retained.items()
                    )
                    emit(6, f"Vidéos retenues pour la fenêtre logs : {parts}.")

                emit(
                    6,
                    f"Fenêtre logs [{first_sample_wc.strftime('%H:%M')}−5min ; "
                    f"{last_sample_wc.strftime('%H:%M')}+2min]…",
                )
                try:
                    window, wide_window = self._correlator.build_log_window_pair(
                        log_files=log_paths,
                        start_wallclock=first_sample_wc,
                        end_wallclock=last_sample_wc,
                        out_dir=workspace.logs_window,
                    )

                    # Fallback HH:MM-only (date-agnostic, awk-style):
                    # when the wall-clock window is empty — typically
                    # because ``reference_date`` doesn't match the
                    # actual recording day of the logs (multi-day
                    # archives, ticket created long after the bug,
                    # year-less logcat misdated to ``now().year``…)
                    # — we re-extract using *time-of-day only*. This
                    # is what an awk filter on column $2 would do.
                    if window.line_count == 0:
                        emit(
                            6,
                            "Fenêtre wall-clock vide — repli sur "
                            "filtre heure-seule (HH:MM, awk-style)…",
                        )
                        window = self._correlator.build_log_window_by_hour(
                            log_files=log_paths,
                            start_time=first_sample_wc.time(),
                            end_time=last_sample_wc.time(),
                            out_dir=workspace.logs_window,
                            file_name="window.log",
                            reference_date=ticket_ref_date,
                        )
                        wide_window = None
                        if window.line_count > 0:
                            report.notes.append(
                                f"Fenêtre wall-clock vide → repli "
                                f"heure-seule (awk-style) : "
                                f"{window.line_count} ligne(s) extraite(s)."
                            )

                    # Final fallback: when both the wall-clock and the
                    # HH:MM-only window are empty, hand the whole log
                    # file(s) to the LLM rather than nothing.  Matches
                    # the user contract: "si après génération du fichier
                    # de logs celui-ci est vide on envoie tout le
                    # fichier pour analyse."
                    if window.line_count == 0:
                        emit(
                            6,
                            "Fenêtre HH:MM toujours vide — envoi du "
                            "fichier de logs complet à l'analyse.",
                        )
                        window = self._correlator.build_full_log_window(
                            log_files=log_paths,
                            out_dir=workspace.logs_window,
                            file_name="window.log",
                            reference_date=ticket_ref_date,
                        )
                        wide_window = None
                        if window.line_count > 0:
                            report.notes.append(
                                f"Fenêtre vide après filtres horaires → "
                                f"repli sur le(s) fichier(s) complet(s) : "
                                f"{window.line_count} ligne(s)."
                            )

                    report.log_window = window
                    if wide_window is not None:
                        report.notes.append(
                            f"Fenêtre étroite pauvre ({window.line_count} "
                            f"ligne(s)) — fenêtre large écrite en plus dans "
                            f"{wide_window.window_path.name} "
                            f"({wide_window.line_count} ligne(s))."
                        )
                    window_text = window.window_path.read_text(
                        encoding="utf-8", errors="replace"
                    )
                    if self._mode == "best":
                        emit(
                            6,
                            f"{window.line_count} ligne(s) extraites — "
                            f"diagnostic LLM ignoré (mode best, handoff externe).",
                        )
                    elif self._use_monolithic:
                        emit(
                            6,
                            f"{window.line_count} ligne(s) extraites — "
                            f"diagnostic LLM différé (mode monolithique).",
                        )
                    else:
                        emit(
                            6,
                            f"{window.line_count} ligne(s) extraites → "
                            f"diagnostic par LLM…",
                        )
                        diagnosis = self._diagnostician.diagnose(
                            ticket_title=ticket.title,
                            ticket_description=ticket.description,
                            log_window_text=window_text,
                            project_doc_markdown=project_doc_md,
                            project_name=resolved.name if resolved else None,
                        )
                        self._apply_diagnosis_to_report(report, diagnosis)
                        if diagnosis.root_cause:
                            emit(6, f"Cause racine identifiée : « {diagnosis.root_cause[:80]}… »")
                        else:
                            emit(6, "Diagnostic LLM vide — on continue sans cause racine.")
                except Exception as exc:  # pragma: no cover - defensive
                    report.notes.append(f"Log window build failed: {exc}")
                    emit(6, f"Échec construction fenêtre logs ({exc}).")
            else:
                # Fallback: no display-time samples OR malformed; try legacy
                # auto-anchor against log markers if we have any video event.
                self._legacy_correlate(bundle, video_events, report)
                emit(6, "Pas d'ancre d'horloge vidéo — fallback sur auto-anchor.")
        elif log_paths and not display_samples:
            # No clock readings: still try the legacy correlator so the
            # report isn't empty.
            emit(6, "Corrélation logs (legacy) — pas d'horloge vidéo.")
            self._legacy_correlate(bundle, video_events, report)
            emit(
                6,
                f"Corrélation logs legacy : "
                f"{len(report.log_excerpts)} extrait(s) produit(s).",
            )
        else:
            emit(6, "Aucun log à corréler.")
            report.notes.append(
                "Aucun log téléchargé — le diagnostic LLM ne sera pas effectué. "
                "Vérifiez que le lien Artifactory dans le ticket est accessible "
                "et que les identifiants sont configurés."
            )

        # If the fancy window path didn't run (no display-time anchor) but
        # we still collected some log content via the legacy fallback (or
        # raw logs), hand it to the diagnostician so the report carries a
        # root cause + reproduction steps anyway.
        # IMPORTANT: we only diagnose when actual log content exists — never
        # fall back to ticket description / comments alone.
        if (
            diagnosis is None
            and log_paths
            and not self._use_monolithic
            and self._mode != "best"
        ):
            legacy_text = self._gather_legacy_log_text(report, log_paths)
            if legacy_text:
                try:
                    diagnosis = self._diagnostician.diagnose(
                        ticket_title=ticket.title,
                        ticket_description=ticket.description,
                        log_window_text=legacy_text,
                        project_doc_markdown=project_doc_md,
                        project_name=resolved.name if resolved else None,
                    )
                    self._apply_diagnosis_to_report(report, diagnosis)
                except Exception as exc:  # pragma: no cover - defensive
                    report.notes.append(f"Log diagnosis failed: {exc}")
                    diagnosis = None

        # ---- step 6b: confirmation pass on an older log+video pair --------
        #
        # When Pass 1 was anchored on an isolated log (no matching video),
        # we try to find a log+video pair *elsewhere* in the bundle — even
        # if it is older. That pair runs through the full video-OCR +
        # log-window + LLM diagnosis flow and its output is stored in the
        # ``*_confirmation`` fields on the report, so the reporter can
        # present it as a cross-check next to the primary diagnosis.
        if self._mode != "best":
            try:
                self._run_confirmation_pass(
                    ticket=ticket,
                    bundle=bundle,
                    workspace=workspace,
                    report=report,
                    project_doc_md=project_doc_md,
                    resolved=resolved,
                    primary_log_paths=log_paths,
                    emit=emit,
                )
            except Exception as exc:  # pragma: no cover - defensive
                report.notes.append(f"Confirmation pass failed: {exc}")

        # ---- ``best`` mode handoff ---------------------------------------
        #
        # Stop here, before any LLM call (no cross-ref, no fix proposer,
        # no monolithic analyzer, no Pass 2 reasoning). Hand the
        # deterministic artefacts off as a ready-to-execute prompt so
        # the external LLM (Copilot Chat) can run the debug workflow
        # inside its own single context. Never blocks: missing pieces
        # are surfaced as ``[MANQUANT]`` markers in the prompt itself.
        if self._mode == "best":
            anchor_summary = self._format_video_anchor_summary(display_samples)
            # Pass the raw on-disk log files so the handoff can fall
            # back to the full log when the curated ``log_window`` is
            # missing or empty (typical when video clock OCR fails:
            # the window can't be cut precisely, but the bundled log
            # is still usable evidence).
            raw_log_paths = [f.path for f in bundle.of_kind(AttachmentKind.LOG)]
            payload = prepare_best_handoff(
                ticket=ticket,
                log_window=report.log_window,
                anchor_summary=anchor_summary,
                project_root_hint=Path.cwd(),
                resolved_project=resolved,
                ticket_workspace=workspace,
                raw_log_paths=raw_log_paths,
            )
            emit(
                7,
                "Mode best : artefacts prêts, prompt généré pour Copilot.",
            )
            emit(8, f"Handoff : {payload.analysis_dir}.")
            return payload

        # ---- step 7: find impacted code + propose a fix ------------------
        emit(7, "Cross-référence code + proposition de correctif…")
        code_refs = self._cross_reference_code(resolved, report, bundle)
        report.code_references = code_refs

        proposed: Optional[ProposedFix] = None
        if self._use_monolithic:
            proposed = self._run_monolithic_analysis(
                ticket=ticket,
                report=report,
                resolved=resolved,
                project_doc_md=project_doc_md,
                code_refs=code_refs,
                display_samples=display_samples,
                log_paths=log_paths,
                emit=emit,
            )
        elif diagnosis is not None and resolved is not None:
            try:
                proposed = self._fix_proposer.propose(
                    diagnosis=diagnosis,
                    code_refs=code_refs,
                    project_doc_markdown=project_doc_md,
                    project_root=resolved.root,
                )
            except Exception as exc:  # pragma: no cover - defensive
                report.notes.append(f"Fix proposer failed: {exc}")
                proposed = None
        report.proposed_fix = proposed
        if proposed is not None:
            emit(
                7,
                f"Correctif proposé sur {proposed.file_path.name} "
                f"(score {proposed.confidence_score:.2f}).",
            )
        else:
            emit(7, "Aucun correctif automatique proposé.")

        # ---- step 8: apply the fix (if confidence > threshold) -----------
        applied: Optional[AppliedFix] = None
        if proposed is not None and proposed.confidence_score > _AUTO_APPLY_THRESHOLD:
            project_root = resolved.root if resolved is not None else None
            try:
                applied = apply_fix(proposed, project_root=project_root)
            except Exception as exc:  # pragma: no cover - defensive
                applied = AppliedFix(
                    file_path=proposed.file_path,
                    applied=False,
                    reason=f"apply_fix raised: {exc}",
                )
        elif proposed is not None:
            applied = AppliedFix(
                file_path=proposed.file_path,
                applied=False,
                reason=(
                    f"confidence {proposed.confidence_score:.2f} below "
                    f"{_AUTO_APPLY_THRESHOLD:.2f} threshold"
                ),
            )
        report.applied_fix = applied

        if applied is not None and applied.applied:
            emit(8, f"Patch appliqué sur {applied.file_path}.")
        elif applied is not None:
            emit(8, f"Patch non appliqué ({applied.reason}).")
        else:
            emit(8, "Rapport prêt (aucun patch à appliquer).")

        # Final pass: derive the display-friendly ``applied_fix_status``
        # and emit a divergence note when the silent Pass 2 cross-check
        # disagrees with the primary diagnosis. Confidence scores are now
        # produced by the LLM alone (no deterministic post-adjusters), so
        # there is nothing else to compute here.
        report.applied_fix_status = _derive_fix_status(
            report.proposed_fix, report.applied_fix
        )
        self._maybe_emit_pass2_divergence_note(report)

        return report

    # ---- action-oriented report helpers ------------------------------------

    @staticmethod
    def _apply_diagnosis_to_report(report: BugReport, diagnosis) -> None:
        """Copy a legacy :class:`Diagnosis` onto the :class:`BugReport`.

        Centralised so both call-sites (display-time anchored window and
        legacy fallback) hydrate the same set of fields and stay in sync
        when new fields are added. ``diagnosis`` may carry the new
        ``root_cause_en``/``reproduction_method``/``regression_zones``/
        ``confidence_scores`` fields produced by the extended schema, or
        only the legacy three when the LLM still answers the old shape.
        """
        report.root_cause = diagnosis.root_cause or None
        report.reproduction_steps = list(diagnosis.reproduction_steps)
        # New action-oriented fields. Pulled defensively because tests and
        # older diagnostician backends construct ``Diagnosis`` with the
        # legacy 3-arg constructor where these attributes default to None.
        report.root_cause_en = getattr(diagnosis, "root_cause_en", None)
        rep_method = getattr(diagnosis, "reproduction_method", None)
        if rep_method is not None:
            report.reproduction_method = rep_method
        report.regression_zones = list(
            getattr(diagnosis, "regression_zones", []) or []
        )
        scores = getattr(diagnosis, "confidence_scores", None)
        if scores is not None:
            report.confidence_scores = scores
        # Phase 7: verbatim log evidence + OK/KO timeline. Defaults to empty
        # lists when the diagnostician backend doesn't surface them so the
        # report stays renderable without a proof block.
        report.root_cause_evidence_logs = list(
            getattr(diagnosis, "root_cause_evidence_logs", []) or []
        )
        report.root_cause_timeline = list(
            getattr(diagnosis, "root_cause_timeline", []) or []
        )

    def _maybe_emit_pass2_divergence_note(self, report: BugReport) -> None:
        """Append a discreet warning when Pass 2 disagrees with Pass 1.

        Pass 2 still runs (option B from the action-report refactor) and is
        kept in memory + JSON for traceability, but it no longer surfaces a
        full ``Confirmation`` block in the markdown. When its diagnosis
        substantially diverges from the primary one we add a one-line note
        in :attr:`BugReport.notes` so the reader knows to inspect the JSON
        before committing the fix.
        """
        primary = (report.root_cause or "").strip().lower()
        secondary = (report.root_cause_confirmation or "").strip().lower()
        if not primary or not secondary:
            return
        coherent = (
            primary == secondary
            or primary in secondary
            or secondary in primary
        )
        if coherent:
            return
        report.notes.append(
            "⚠ Le diagnostic Pass 2 (cross-check sur un autre fichier de "
            "logs) diverge de l'analyse principale. Voir le JSON "
            "(`root_cause_confirmation`) pour le détail."
        )

    # ---- progress helpers --------------------------------------------------

    @staticmethod
    def _make_emitter(
        progress: Optional[ProgressCallback],
    ) -> Callable[[int, str], None]:
        def emit(step: int, message: str) -> None:
            log.info("[step %d/%d] %s", step, _TOTAL_STEPS, message)
            if progress is None:
                return
            try:
                progress(step, _TOTAL_STEPS, message)
            except Exception:  # pragma: no cover - never fail on UI glitches
                log.debug("progress callback raised; ignoring", exc_info=True)

        return emit

    # ---- internals --------------------------------------------------------

    def _resolve_project(self, ticket: Ticket) -> Optional[ResolvedProject]:
        if self._project_override is not None:
            return ResolvedProject(
                ticket_key=ticket.key,
                root=self._project_override.root,
                name=self._project_override.name,
                matched_on=self._project_override.matched_on,
                score=self._project_override.score,
            )
        if self._project_resolver is None:
            return None
        return self._project_resolver.resolve(ticket)

    def _cross_reference_code(
        self,
        resolved: Optional[ResolvedProject],
        report: BugReport,
        bundle: AttachmentBundle,
    ) -> list[CodeReference]:
        if resolved is None:
            return []

        inspector = CodebaseInspector(resolved.root)
        haystack: list[str] = []
        # Prefer the consolidated log window, then the curated excerpts,
        # then raw logs — richest evidence first.
        if report.log_window is not None:
            try:
                haystack.append(
                    report.log_window.window_path.read_text(
                        encoding="utf-8", errors="replace"
                    )
                )
            except OSError:
                pass
        if not haystack and report.log_excerpts:
            for ex in report.log_excerpts:
                haystack.extend(ex.lines)
        if not haystack and bundle.logs:
            for log_file in bundle.logs:
                try:
                    haystack.append(
                        log_file.path.read_text(encoding="utf-8", errors="replace")
                    )
                except OSError:
                    continue

        if not haystack:
            return []
        return inspector.cross_reference_logs("\n".join(haystack))

    def _gather_legacy_log_text(
        self,
        report: BugReport,
        log_paths: list[Path],
    ) -> str:
        """Assemble log text for the diagnostician when no log_window exists.

        Prefers curated excerpts (from ``_legacy_correlate``) over raw logs,
        since they're already narrowed down to what the aligner thinks is
        the bug window.
        """
        if report.log_excerpts:
            parts: list[str] = []
            for ex in report.log_excerpts:
                parts.append(f"--- {ex.source_file.name} ---")
                parts.extend(ex.lines)
            return "\n".join(parts)

        blobs: list[str] = []
        for p in log_paths:
            try:
                blobs.append(p.read_text(encoding="utf-8", errors="replace"))
            except OSError:
                continue
        return "\n".join(blobs)

    def _legacy_correlate(
        self,
        bundle: AttachmentBundle,
        video_events: list[VideoEvent],
        report: BugReport,
    ) -> None:
        """Fallback anchor via log markers + narrow excerpt per log file.

        Anchor priority when no on-screen clock is available:
        1. ``filename_anchor`` — wall-clock embedded in the log filename
           (e.g. ``PussADB_20260408_145916...``). Deterministic and
           immune to crash markers from previous boot sessions, so it
           sits **above** ``auto_anchor``.
        2. ``auto_anchor``    — crash/ANR/behavioral markers in the log
        3. ``keyword_anchor`` — first log line matching ticket keywords
        4. ``log_range_anchor`` — first log timestamp (last resort)
        """
        log_paths = [f.path for f in bundle.of_kind(AttachmentKind.LOG)]
        if not log_paths:
            return

        # Same bugreport priority as in pass 1: the dump for the bug's day
        # carries the crash/ANR markers we want auto_anchor to find.
        log_paths = _prioritize_bugreports(log_paths)

        all_lines = []
        for p in log_paths:
            all_lines.extend(self._logcat_parser.parse_file(p))

        # 1. Try filename_anchor first: it bypasses crash markers from
        #    previous boot sessions which can otherwise mislead auto_anchor.
        anchor = self._aligner.filename_anchor(log_paths=log_paths)
        if anchor is not None:
            report.notes.append(
                f"Ancre : filename ({anchor.source[:80]}) "
                f"— horodatage extrait du nom du fichier de log."
            )

        if anchor is None and video_events:
            try:
                anchor = self._aligner.auto_anchor(
                    log_lines=all_lines, video_events=video_events,
                )
            except AlignmentError as exc:
                log.info(
                    "auto_anchor failed (%s); trying keyword_anchor.", exc
                )
                keywords = _extract_ticket_keywords(report.ticket)
                anchor = self._aligner.keyword_anchor(
                    log_lines=iter(all_lines), keywords=keywords
                )
                if anchor is not None:
                    report.notes.append(
                        f"Ancre : keyword ({anchor.source[:80]}) "
                        f"— marqueur de crash non trouvé, mots-clés du ticket utilisés."
                    )
                else:
                    anchor = self._aligner.log_range_anchor(log_lines=iter(all_lines))
                    if anchor is None:
                        report.notes.append(
                            f"Could not align video and logs: {exc} "
                            "(keyword + log_range fallbacks also failed — log has no parseable timestamps)"
                        )
                        return
                    report.notes.append(
                        f"Ancre : log_range (premier timestamp utilisé ; marqueur de crash non trouvé). "
                        f"Erreur d'origine : {exc}"
                    )

        if anchor is None:
            # No video at all — try keyword anchor first, then log_range.
            keywords = _extract_ticket_keywords(report.ticket)
            anchor = self._aligner.keyword_anchor(
                log_lines=iter(all_lines), keywords=keywords
            )
            if anchor is not None:
                report.notes.append(
                    f"Ancre : keyword ({anchor.source[:80]}) "
                    f"— pas de vidéo, mots-clés du ticket utilisés pour cibler les logs."
                )
            else:
                anchor = self._aligner.log_range_anchor(log_lines=iter(all_lines))
                if anchor is None:
                    report.notes.append(
                        "Aucun ancrage possible : aucune vidéo et aucun timestamp parseable dans les logs."
                    )
                    return
                report.notes.append("Ancre : log_range (aucune vidéo ; premier timestamp du log utilisé).")

        if video_events:
            strongest = max(video_events, key=lambda e: e.confidence)
            for path in log_paths:
                try:
                    excerpt = self._correlator.excerpt_for_event(
                        event=strongest, anchor=anchor, log_file=path,
                    )
                except Exception as exc:  # pragma: no cover - defensive
                    report.notes.append(f"Échec corrélation {path.name}: {exc}")
                    continue
                report.log_excerpts.append(excerpt)

            # ALSO build a real ``report.log_window`` so downstream
            # consumers that look at ``log_window`` (typically the
            # ``best`` mode handoff) see the same evidence as
            # ``log_excerpts``. Window = [event − 5 min ; event + 2 min].
            try:
                event_wc = VideoLogAligner.to_wallclock(
                    anchor, strongest.timestamp_s,
                )
                window = self._correlator.build_log_window(
                    log_files=log_paths,
                    start_wallclock=event_wc,
                    end_wallclock=event_wc,
                    out_dir=log_paths[0].parent / "window",
                    # User contract: window = [bug − 5 min ; bug + 2 min].
                    pad_before_s=300.0,
                    pad_after_s=120.0,
                )
                if window.line_count > 0 and report.log_window is None:
                    report.log_window = window
            except Exception as exc:  # pragma: no cover - defensive
                report.notes.append(
                    f"Échec construction fenêtre log (legacy event path): {exc}"
                )
        else:
            # No video events: build a full log window around the entire log span.
            from datetime import timedelta as _td
            start_wc = anchor.wallclock
            end_wc = anchor.wallclock
            # Scan all lines to find the last timestamp.
            for line in all_lines:
                if line.timestamp is not None and line.timestamp > end_wc:
                    end_wc = line.timestamp
            try:
                window = self._correlator.build_log_window(
                    log_files=log_paths,
                    start_wallclock=start_wc,
                    end_wallclock=end_wc,
                    out_dir=report.ticket.key  # type: ignore[arg-type]
                    if False
                    else (log_paths[0].parent / "window"),
                    # User contract: window = [bug − 5 min ; bug + 2 min].
                    pad_before_s=300.0,
                    pad_after_s=120.0,
                )
                report.log_window = window
            except Exception as exc:  # pragma: no cover - defensive
                report.notes.append(f"Échec construction fenêtre log (no-video path): {exc}")

    # ---- monolithic analysis ---------------------------------------------

    def _run_monolithic_analysis(
        self,
        *,
        ticket: Ticket,
        report: BugReport,
        resolved: Optional[ResolvedProject],
        project_doc_md: Optional[str],
        code_refs: list[CodeReference],
        display_samples: list[DisplayTimeSample],
        log_paths: list[Path],
        emit: Callable[[int, str], None],
    ) -> Optional[ProposedFix]:
        """Drive the single-conversation analyzer and map its result.

        This consolidates the LLM blocks of legacy steps 2 / 6 / 6b / 7b
        into a single :class:`MonolithicAnalyzer` call. The deterministic
        signals already gathered by the pipeline (log window, display
        samples, code references, …) are forwarded as the opening user
        turn.
        """
        if self._monolithic is None:
            return None

        # Read the primary + confirmation log windows back from disk.
        primary_text = self._read_log_window_text(report.log_window)
        confirmation_text = self._read_log_window_text(
            report.log_window_confirmation
        )

        video_anchor_summary = self._format_video_anchor_summary(
            display_samples
        )

        # Compute missing-signal flags from deterministic facts. The
        # analyzer uses these to decide between asking a clarification or
        # proceeding with a clearly-labelled degraded analysis.
        missing_signals: list[str] = []
        if not primary_text:
            missing_signals.append(LOGS_MISSING)
        if not display_samples:
            missing_signals.append(VIDEO_CLOCK_MISSING)
        if not code_refs:
            missing_signals.append(NO_CODE_REFS)

        emit(7, "Analyse monolithique : appel LLM unique en cours…")
        try:
            result = self._monolithic.analyze(
                ticket=ticket,
                project_doc_md=project_doc_md,
                project_name=resolved.name if resolved else None,
                log_window_text=primary_text,
                log_window_confirmation_text=confirmation_text,
                video_anchor_summary=video_anchor_summary,
                code_refs=code_refs,
                project_root=resolved.root if resolved else None,
                missing_signals=missing_signals,
            )
        except Exception as exc:  # pragma: no cover - defensive
            report.notes.append(f"Monolithic analysis failed: {exc}")
            emit(7, f"Analyse monolithique échouée ({exc}).")
            return None

        # Surface clarifications asked by the LLM so the reporter can list
        # them in the final markdown via a dedicated section.
        if result.clarifications_asked:
            report.clarifications_asked = list(result.clarifications_asked)

        if not result.completed:
            report.notes.append(
                "Analyse monolithique abandonnée avant la conclusion (LLM "
                "n'a pas produit de verdict final). Le rapport peut être "
                "incomplet."
            )
            emit(7, "Analyse monolithique : aucun verdict final.")
            return None

        # Map the structured result back onto the BugReport.
        report.analysis = TicketAnalysis(
            ticket_key=ticket.key,
            ticket_type=result.ticket_type,
            type_confidence=result.type_confidence,
            summary=result.summary,
            relevant_comments=result.relevant_comments,
        )
        report.root_cause = result.root_cause
        report.root_cause_en = result.root_cause_en
        report.reproduction_steps = list(result.reproduction_steps)
        report.reproduction_method = result.reproduction_method
        report.regression_zones = list(result.regression_zones)
        report.confidence_scores = result.confidence_scores
        report.root_cause_evidence_logs = list(
            result.root_cause_evidence_logs
        )
        report.root_cause_timeline = list(result.root_cause_timeline)

        return result.proposed_fix

    @staticmethod
    def _read_log_window_text(window: object) -> Optional[str]:
        """Best-effort read of a ``LogWindow.window_path``.

        Returns ``None`` when the window is missing or unreadable so the
        caller can flag the corresponding missing signal.
        """
        if window is None:
            return None
        path = getattr(window, "window_path", None)
        if path is None:
            return None
        try:
            text = Path(path).read_text(encoding="utf-8", errors="replace")
        except OSError:
            return None
        return text or None

    @staticmethod
    def _format_video_anchor_summary(
        display_samples: list[DisplayTimeSample],
    ) -> Optional[str]:
        """Render a short French summary of the on-screen clock readings."""
        if not display_samples:
            return None
        first = display_samples[0]
        last = display_samples[-1]
        first_clock = first.wallclock_hhmm or "?"
        last_clock = last.wallclock_hhmm or "?"
        return (
            f"{len(display_samples)} lecture(s) d'horloge vidéo — "
            f"première à t={first.frame_time_s:.1f}s ({first_clock}), "
            f"dernière à t={last.frame_time_s:.1f}s ({last_clock})."
        )

    # ---- confirmation pass ------------------------------------------------

    def _run_confirmation_pass(
        self,
        *,
        ticket: Ticket,
        bundle: AttachmentBundle,
        workspace: TicketWorkspace,
        report: BugReport,
        project_doc_md: Optional[str],
        resolved: Optional[ResolvedProject],
        primary_log_paths: list[Path],
        emit: Callable[[int, str], None],
    ) -> None:
        """Pass 2 — cross-check the primary diagnosis with an older log+video pair.

        Builds a flat list of ``Attachment`` from ``bundle.files`` (top-level
        and archive-extracted entries alike), excludes the pass-1 log, and
        asks :func:`select_confirmation_pair` for the newest remaining
        ``(log, video)`` pair that respects the ≤ 2 h gap rule. When a pair
        is found, runs the same video-OCR + log-window + LLM-diagnosis
        flow and writes the outputs to the ``*_confirmation`` fields of
        the report. A no-op when no pair exists or no video analyzer is
        configured.
        """
        if self._video is None:
            return

        # Flattened list of ``Attachment`` objects (one per file, including
        # files pulled out of archives). ``ClassifiedFile.source_attachment``
        # already carries the per-file mtime when it came from an archive.
        attachments: list[Attachment] = [
            f.source_attachment for f in bundle.files
        ]
        # Exclude the pass-1 log so confirmation always offers a *different*
        # anchor. We identify it by local path, which is stable across the
        # synthetic attachment wrappers created for archive members.
        primary_paths = {str(p) for p in primary_log_paths}
        exclude: list[Attachment] = [
            f.source_attachment
            for f in bundle.files
            if f.source_attachment.local_path is not None
            and str(f.source_attachment.local_path) in primary_paths
        ]

        pair = select_confirmation_pair(attachments, exclude=exclude)
        if not pair.kept:
            return

        # Extract the concrete log + video files from the bundle using the
        # selected attachments' filenames (the synthetic attachments share
        # the ``local_path`` of the underlying file).
        kept_paths = {
            a.local_path for a in pair.kept if a.local_path is not None
        }
        conf_log_files = [
            f for f in bundle.logs if f.path in kept_paths
        ]
        conf_video_files = [
            f for f in bundle.videos if f.path in kept_paths
        ]
        if not conf_log_files or not conf_video_files:
            return

        conf_log = conf_log_files[0]
        conf_video = conf_video_files[0]

        anchor_day = pair.latest_day.isoformat() if pair.latest_day else "?"

        # ---- video OCR + user actions on the confirmation pair -----------
        display_samples: list[DisplayTimeSample] = []
        user_actions: list[UserAction] = []
        video_events: list[VideoEvent] = []

        detect_dt = getattr(self._video, "detect_display_times", None)
        if callable(detect_dt):
            try:
                display_samples = list(
                    detect_dt(conf_video.path, frames_dir=workspace.frames)
                )
            except Exception as exc:  # pragma: no cover - defensive
                report.notes.append(
                    f"Confirmation: display-time detection failed "
                    f"({conf_video.path.name}): {exc}"
                )

        detect_ua = getattr(self._video, "detect_user_actions", None)
        if callable(detect_ua):
            try:
                user_actions = list(detect_ua(conf_video.path))
            except Exception as exc:  # pragma: no cover - defensive
                report.notes.append(
                    f"Confirmation: user-action detection failed "
                    f"({conf_video.path.name}): {exc}"
                )

        analyze_video = getattr(self._video, "analyze_video", None)
        if callable(analyze_video):
            try:
                video_events = list(analyze_video(conf_video.path))
            except Exception as exc:  # pragma: no cover - defensive
                report.notes.append(
                    f"Confirmation: video analysis failed "
                    f"({conf_video.path.name}): {exc}"
                )

        for s in display_samples:
            video_events.append(
                VideoEvent(
                    timestamp_s=s.frame_time_s,
                    confidence=0.9,
                    kind="display_time",
                    evidence=s.text[:160],
                    frame_path=s.frame_path,
                    detected_time=s.wallclock_hhmm,
                )
            )

        report.video_events_confirmation = video_events
        report.user_actions_confirmation = user_actions

        # ---- build a log window on the confirmation log ------------------
        if not display_samples:
            return

        # Probe the confirmation log's wall-clock range so we can use its
        # *date* as the OCR reference (logs and the on-screen clock share
        # the same recording day, which is rarely the ticket's creation
        # day). Falls back to ticket.created / today otherwise.
        conf_log_range = self._correlator.probe_log_range([conf_log.path])
        if conf_log_range is not None:
            ticket_ref_date = conf_log_range[0].date()
            _align_parser_year(self._correlator, conf_log_range[0].year)
            _align_parser_year(self._logcat_parser, conf_log_range[0].year)
        elif ticket.created is not None:
            ticket_ref_date = ticket.created.date()
        else:
            ticket_ref_date = _date.today()
        # Single-video pass, but we still go through the per-video helper
        # so the wall-clock window is built from real per-video anchors
        # (consistent with the main pass).
        first_sample_wc, last_sample_wc, _dropped, _retained = (
            _resolve_window_from_samples(
                samples=list(display_samples),
                aligner=self._aligner,
                reference_date=ticket_ref_date,
                log_range=conf_log_range,
            )
        )
        if first_sample_wc is None:
            return

        # Use a dedicated sub-directory to avoid overwriting the Pass-1 window.
        conf_out = workspace.logs_window / "confirmation"
        try:
            window, wide_window = self._correlator.build_log_window_pair(
                log_files=[conf_log.path],
                start_wallclock=first_sample_wc,
                end_wallclock=last_sample_wc,
                out_dir=conf_out,
            )

            # Same HH:MM-only fallback as the main pass (see comment
            # there): when the wall-clock window is empty, repeat with
            # awk-style time-of-day filtering.
            if window.line_count == 0:
                window = self._correlator.build_log_window_by_hour(
                    log_files=[conf_log.path],
                    start_time=first_sample_wc.time(),
                    end_time=last_sample_wc.time(),
                    out_dir=conf_out,
                    file_name="window.log",
                    reference_date=ticket_ref_date,
                )

            # Final fallback (Pass 2): also use the full file if both
            # filtered windows are empty. Pass 2 is silent for the
            # user but the LLM should still get something to chew on
            # for cross-checking.
            if window.line_count == 0:
                window = self._correlator.build_full_log_window(
                    log_files=[conf_log.path],
                    out_dir=conf_out,
                    file_name="window.log",
                    reference_date=ticket_ref_date,
                )
                wide_window = None
                if window.line_count > 0:
                    report.notes.append(
                        f"Confirmation: fenêtre wall-clock vide → repli "
                        f"heure-seule (awk-style) : "
                        f"{window.line_count} ligne(s) extraite(s)."
                    )

            report.log_window_confirmation = window
            if wide_window is not None:
                report.notes.append(
                    f"Confirmation: fenêtre étroite pauvre "
                    f"({window.line_count} ligne(s)) — fenêtre large écrite "
                    f"dans {wide_window.window_path.name}."
                )
            window_text = window.window_path.read_text(
                encoding="utf-8", errors="replace"
            )
        except Exception as exc:  # pragma: no cover - defensive
            report.notes.append(f"Confirmation: construction fenêtre échouée ({exc}).")
            return

        # ---- LLM diagnosis on the confirmation window --------------------
        report.confirmation_source = (
            f"{conf_log.path.name} + {conf_video.path.name} ({anchor_day})"
        )

        if self._use_monolithic:
            return

        try:
            diagnosis = self._diagnostician.diagnose(
                ticket_title=ticket.title,
                ticket_description=ticket.description,
                log_window_text=window_text,
                project_doc_markdown=project_doc_md,
                project_name=resolved.name if resolved else None,
            )
        except Exception as exc:  # pragma: no cover - defensive
            report.notes.append(f"Confirmation: diagnostic LLM échoué ({exc}).")
            return

        report.root_cause_confirmation = diagnosis.root_cause or None
        report.reproduction_steps_confirmation = diagnosis.reproduction_steps

        log.info(
            "Confirmation pass: log=%s video=%s day=%s root_cause=%r",
            conf_log.path.name,
            conf_video.path.name,
            anchor_day,
            (diagnosis.root_cause or "")[:80],
        )


# ---------------------------------------------------------------------------
# Action-oriented report finalisers
# ---------------------------------------------------------------------------
#
# Phase 7 made the LLM the sole source of truth for confidence scores, the
# root-cause narrative and the regression-zones list. Only one deterministic
# helper survives: ``_derive_fix_status`` translates the ``AppliedFix``
# record (or its absence) into a display-friendly enum so the reporter can
# pick the right icon without re-parsing free-text reasons.


def _derive_fix_status(
    proposed: Optional[ProposedFix],
    applied: Optional[AppliedFix],
) -> AppliedFixStatus:
    """Translate ``applied_fix`` (or its absence) into a display enum.

    Rules:
    - No proposed fix at all → ``NOT_AVAILABLE``.
    - Patch was actually written to disk → ``APPLIED``.
    - ``apply_fix`` raised (reason mentions ``raised``/``exception``) →
      ``FAILED``.
    - Below confidence threshold (reason mentions ``below``) →
      ``BELOW_THRESHOLD``.
    - Otherwise (a patch was produced but not auto-applied for any other
      reason) → ``PROPOSED``.
    """
    if proposed is None:
        return AppliedFixStatus.NOT_AVAILABLE
    if applied is None:
        return AppliedFixStatus.PROPOSED
    if applied.applied:
        return AppliedFixStatus.APPLIED
    reason = (applied.reason or "").lower()
    if "raised" in reason or "exception" in reason:
        return AppliedFixStatus.FAILED
    if "below" in reason:
        return AppliedFixStatus.BELOW_THRESHOLD
    return AppliedFixStatus.PROPOSED
