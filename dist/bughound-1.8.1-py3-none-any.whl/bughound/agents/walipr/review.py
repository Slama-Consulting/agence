"""Revue LLM d'un diff parsé pour WaliPR.

Pipeline :

1. :func:`render_diff_for_prompt` — sérialise les :class:`FileDiff`
   (issus de :mod:`.diff`) en un bloc texte compact que le LLM peut
   reviewer ligne à ligne. Les binaires sont skippés.
2. :func:`build_prompt` — assemble le ``user`` prompt (standards +
   diff sérialisé + consigne de sortie JSON).
3. :func:`review_diff` — appelle :meth:`LLMClient.complete_json` puis
   normalise la réponse en :class:`ReviewResult` (parsing tolérant).

Le LLM est passé par injection (réutilisation directe du factory
:func:`bughound.llm.build_llm_client` côté MCP — pas de couplage ici).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Iterable, Literal, Optional

from ...llm import LLMClient
from .diff import FileDiff
from .standards import StandardsBundle, build_standards_bundle


Severity = Literal["info", "minor", "major", "blocker"]
_VALID_SEVERITIES: tuple[Severity, ...] = ("info", "minor", "major", "blocker")
_VALID_CATEGORIES: tuple[str, ...] = (
    "style",
    "null-safety",
    "concurrency",
    "architecture",
    "testing",
    "security",
    "compatibility",
    "other",
)


@dataclass(frozen=True)
class SuggestedPatch:
    """Correctif structuré proposé par le LLM pour un finding (P5.1).

    Le LLM peut fournir l'un des deux formats (les deux sont tolérés
    et coexistent dans le schéma JSON) :

    - ``unified_diff`` : un mini-diff unifié au format git
      (``--- a/<path>\\n+++ b/<path>\\n@@ ... @@``) limité au
      fichier concerné. Avantage : standard, applicable via
      ``git apply``.
    - ``block_replacement`` : remplacement de bloc texte
      ``(file, line_start, line_end, replacement)`` (1-based, inclusif).
      Plus simple à générer pour un LLM modeste.

    Au moins l'un des deux doit être présent pour qu'un patch soit
    considéré « applicable » (cf. :func:`is_applicable`). La conversion
    block_replacement → unified_diff se fait dans
    :mod:`bughound.agents.walipr.patches`.
    """

    unified_diff: Optional[str] = None
    file: Optional[str] = None
    line_start: Optional[int] = None
    line_end: Optional[int] = None
    replacement: Optional[str] = None

    def is_applicable(self) -> bool:
        if self.unified_diff and self.unified_diff.strip():
            return True
        return (
            isinstance(self.file, str)
            and bool(self.file.strip())
            and isinstance(self.line_start, int)
            and isinstance(self.line_end, int)
            and self.line_start >= 1
            and self.line_end >= self.line_start
            and isinstance(self.replacement, str)
        )


@dataclass(frozen=True)
class ReviewFinding:
    """Constat de revue (un point précis dans un fichier modifié)."""

    file: str
    line: Optional[int]
    severity: Severity
    category: str
    message: str
    suggestion: Optional[str] = None
    suggested_patch: Optional[SuggestedPatch] = None  # P5.1


@dataclass(frozen=True)
class ReviewResult:
    """Résultat agrégé d'une revue de diff."""

    summary: str
    findings: tuple[ReviewFinding, ...] = field(default_factory=tuple)
    score: Optional[float] = None  # [0, 1] — qualité globale du diff
    languages: tuple[str, ...] = ()  # langages détectés / appliqués (P4.5)
    cache_status: Optional[Literal["hit", "miss", "disabled"]] = None  # P6.2


# ---------------------------------------------------------------------------
# Prompt construction
# ---------------------------------------------------------------------------

WALIPR_SYSTEM = (
    "Tu es WaliPR, un reviewer de code méticuleux et bilingue (FR/EN). "
    "Tu reçois un diff Git unifié et un ou plusieurs jeux de standards "
    "de code (par langage). Tu produis UNIQUEMENT un objet JSON "
    "conforme au schéma fourni. Tes constats doivent : (1) citer un "
    "fichier et une ligne du `+` côté nouveau quand pertinent ; (2) "
    "être actionnables (pas de généralités) ; (3) classer chaque "
    "finding dans une catégorie et une sévérité du schéma ; (4) "
    "appliquer les standards pertinents au langage de chaque fichier "
    "(le diff peut toucher plusieurs langages). N'invente jamais de "
    "fichiers ni de lignes absents du diff. Réponds en français pour "
    "`message` et `suggestion`. "
    "PATCH OPTIONNEL — Quand tu peux proposer un correctif concret "
    "et trivial (typiquement pour les sévérités `info` et `minor`), "
    "ajoute un champ `suggested_patch` au finding au format soit "
    "`{\"unified_diff\": \"<mini diff git>\"}` soit "
    "`{\"file\": \"<path>\", \"line_start\": <int>, "
    "\"line_end\": <int>, \"replacement\": \"<texte>\"}`. "
    "N'inclus JAMAIS de patch sur du code que tu n'es pas certain "
    "de comprendre — il vaut mieux omettre `suggested_patch` que "
    "proposer un patch incorrect."
)

WALIPR_SCHEMA_HINT = json.dumps(
    {
        "summary": "string (1-3 phrases en français, vue d'ensemble)",
        "score": "number in [0, 1] (qualité globale du diff)",
        "findings": [
            {
                "file": "string (chemin tel qu'il apparaît dans le diff)",
                "line": "integer | null (ligne dans la version nouvelle)",
                "severity": "info | minor | major | blocker",
                "category": " | ".join(_VALID_CATEGORIES),
                "message": "string (constat en français)",
                "suggestion": "string | null (correction proposée)",
                "suggested_patch": (
                    "object | null — soit "
                    "{unified_diff: string}, soit "
                    "{file: string, line_start: int, line_end: int, "
                    "replacement: string}. À fournir uniquement pour "
                    "les correctifs triviaux et certains."
                ),
            }
        ],
    },
    indent=2,
    ensure_ascii=False,
)


def _render_hunk_lines(lines: Iterable[str], new_start: int) -> list[str]:
    """Annoter chaque ligne ajoutée/contexte du hunk avec son numéro côté +.

    Les lignes ``-`` et ``\\ No newline at end of file`` ne consomment
    pas de numéro côté nouveau. On préfixe chaque ligne par
    ``"<num or '   '> <prefix><payload>"`` pour que le LLM puisse
    citer une ligne précise.
    """
    out: list[str] = []
    cur = new_start
    for raw in lines:
        if not raw:
            out.append("    ")
            continue
        prefix = raw[0]
        if prefix == "+":
            out.append(f"{cur:>4} {raw}")
            cur += 1
        elif prefix == " ":
            out.append(f"{cur:>4} {raw}")
            cur += 1
        elif prefix == "-":
            out.append(f"   - {raw}")
        else:
            # ``\ No newline at end of file``, ou bruit divers : on
            # passe sans incrémenter.
            out.append(f"     {raw}")
    return out


def render_diff_for_prompt(file_diffs: list[FileDiff], *, max_chars: int = 60_000) -> str:
    """Sérialise les :class:`FileDiff` en texte annoté pour le prompt.

    Filtre les binaires. Tronque à ``max_chars`` (queue avec marqueur)
    pour ne pas faire exploser le contexte LLM.
    """
    blocks: list[str] = []
    for f in file_diffs:
        if f.is_binary:
            blocks.append(f"### {f.path} (binary, skipped)")
            continue
        if not f.hunks:
            # Rename/mode-only diff : utile à mentionner mais rien à reviewer.
            tag = "renamed" if f.is_renamed else "metadata-only"
            label = f.path
            if f.old_path and f.old_path != f.path:
                label = f"{f.old_path} -> {f.path}"
            blocks.append(f"### {label} ({tag}, no content change)")
            continue
        header = f"### {f.path}"
        if f.is_new:
            header += " (new file)"
        elif f.is_deleted:
            header += " (deleted)"
        elif f.is_renamed and f.old_path:
            header = f"### {f.old_path} -> {f.path} (renamed)"
        body: list[str] = [header]
        for h in f.hunks:
            body.append(h.header)
            body.extend(_render_hunk_lines(h.lines, h.new_start))
        blocks.append("\n".join(body))

    rendered = "\n\n".join(blocks)
    if len(rendered) > max_chars:
        rendered = (
            rendered[:max_chars]
            + f"\n\n[... diff truncated to {max_chars} chars by WaliPR ...]"
        )
    return rendered


def build_prompt(file_diffs: list[FileDiff], *, standards: Optional[str] = None) -> str:
    """Assemble le ``user`` prompt complet (standards + diff).

    ``standards`` peut concaténer plusieurs jeux par langage : chaque
    jeu est attendu avec son propre en-tête ``## Standards <Langage>``
    déjà inclus (cf. :func:`bughound.agents.walipr.standards.load_standards_for_languages`).
    Si ``standards`` est vide ou ``None``, on émet à la place une note
    explicite « Aucun standard projet spécifique » pour que le LLM
    sache qu'il doit s'appuyer sur ses bonnes pratiques générales.
    """
    parts: list[str] = []
    if standards and standards.strip():
        parts.append("## Standards de référence\n")
        parts.append(standards.strip())
        parts.append("")
    else:
        parts.append("## Standards de référence\n")
        parts.append(
            "Aucun standard projet spécifique pour ces fichiers. "
            "Applique tes bonnes pratiques générales (style, lisibilité, "
            "robustesse, sécurité) en fonction du langage détecté."
        )
        parts.append("")
    parts.append("## Diff à reviewer\n")
    parts.append(render_diff_for_prompt(file_diffs) or "(diff vide)")
    parts.append("")
    parts.append(
        "## Consigne\n"
        "Produis UN seul objet JSON conforme au schema_hint. "
        "Si le diff ne contient aucun problème, renvoie `findings: []` et "
        "explique-le brièvement dans `summary`."
    )
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Parsing tolérant de la réponse LLM
# ---------------------------------------------------------------------------


def _coerce_severity(value: Any) -> Severity:
    if isinstance(value, str):
        v = value.strip().lower()
        if v in _VALID_SEVERITIES:
            return v  # type: ignore[return-value]
    return "info"


def _coerce_category(value: Any) -> str:
    if isinstance(value, str):
        v = value.strip().lower()
        if v in _VALID_CATEGORIES:
            return v
    return "other"


def _coerce_line(value: Any) -> Optional[int]:
    if value is None:
        return None
    if isinstance(value, bool):
        return None  # True/False n'est pas un numéro de ligne
    if isinstance(value, int):
        return value if value > 0 else None
    if isinstance(value, str):
        try:
            n = int(value.strip())
        except ValueError:
            return None
        return n if n > 0 else None
    return None


def _coerce_score(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    if f < 0.0:
        return 0.0
    if f > 1.0:
        return 1.0
    return f


def _coerce_findings(raw: Any) -> tuple[ReviewFinding, ...]:
    # Import paresseux pour éviter une boucle review.py ↔ patches.py
    # (patches.py importe SuggestedPatch depuis review.py).
    from .patches import coerce_suggested_patch

    if not isinstance(raw, list):
        return ()
    out: list[ReviewFinding] = []
    for entry in raw:
        if not isinstance(entry, dict):
            continue
        file = entry.get("file")
        message = entry.get("message")
        if not isinstance(file, str) or not file.strip():
            continue
        if not isinstance(message, str) or not message.strip():
            continue
        suggestion = entry.get("suggestion")
        if not isinstance(suggestion, str) or not suggestion.strip():
            suggestion = None
        # P5.4 — patch optionnel, tolérance complète au format.
        suggested_patch = coerce_suggested_patch(entry.get("suggested_patch"))
        out.append(
            ReviewFinding(
                file=file.strip(),
                line=_coerce_line(entry.get("line")),
                severity=_coerce_severity(entry.get("severity")),
                category=_coerce_category(entry.get("category")),
                message=message.strip(),
                suggestion=suggestion.strip() if suggestion else None,
                suggested_patch=suggested_patch,
            )
        )
    return tuple(out)


def _parse_review_payload(payload: Optional[dict[str, Any]], raw_text: str) -> ReviewResult:
    if not isinstance(payload, dict):
        # Fallback : pas de JSON utilisable → on garde le texte brut comme summary.
        summary = raw_text.strip() or "(le LLM n'a renvoyé aucun JSON exploitable)"
        if len(summary) > 800:
            summary = summary[:800] + "…"
        return ReviewResult(summary=summary, findings=(), score=None)
    summary = payload.get("summary")
    if not isinstance(summary, str) or not summary.strip():
        summary = "(résumé manquant)"
    return ReviewResult(
        summary=summary.strip(),
        findings=_coerce_findings(payload.get("findings")),
        score=_coerce_score(payload.get("score")),
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def review_diff(
    file_diffs: list[FileDiff],
    llm: LLMClient,
    *,
    standards: Optional[str] = None,
    languages: Optional[Iterable[str]] = None,
    cache_enabled: bool = False,
    repo_root: Optional[Any] = None,
    model_name: Optional[str] = None,
    diff_text: Optional[str] = None,
    cache_ttl_seconds: Optional[int] = None,
) -> ReviewResult:
    """Demande au LLM de reviewer ``file_diffs``.

    Résolution des standards (priorité décroissante) :

    1. Si ``standards`` (str) est fourni : utilisé tel quel
       (rétro-compat avec le mode Kotlin-only des Paliers 1-3).
       ``languages`` est alors ignoré côté chargement (mais propagé
       dans le résultat à titre informatif).
    2. Sinon si ``languages`` est fourni : on charge les jeux
       correspondants via :func:`build_standards_bundle(...,
       languages_override=...)`.
    3. Sinon : détection auto des langages depuis les extensions
       du diff.

    Si tous les fichiers sont binaires ou sans hunks, court-circuite
    le LLM et renvoie un résultat vide trivial.

    Cache (P6) — **opt-in** via ``cache_enabled=True`` :

    - ``repo_root`` : racine du repo où est stocké ``.walipr-cache/``.
    - ``model_name`` : nom du modèle LLM (entre dans la clé).
    - ``diff_text`` : diff brut (si fourni, entre dans la clé tel quel ;
      sinon on sérialise via :func:`render_diff_for_prompt`).
    - ``cache_ttl_seconds`` : TTL personnalisé, défaut
      :data:`bughound.agents.walipr.cache.DEFAULT_TTL_SECONDS` (7 jours).

    Si ``cache_enabled=False`` (défaut), le cache n'est jamais touché
    et ``cache_status`` reste ``None`` (rétro-compat totale).
    """
    reviewable = [f for f in file_diffs if not f.is_binary and f.hunks]
    if not reviewable:
        # Pour la cohérence du résultat, on calcule quand même les
        # langages "déclarés" (override) ou détectés (auto) ; pas
        # d'appel LLM.
        if standards is not None:
            langs: tuple[str, ...] = tuple(languages or ())
        else:
            bundle = build_standards_bundle(file_diffs, languages_override=languages)
            langs = bundle.languages
        return ReviewResult(
            summary="Aucun changement de code à reviewer (diff vide, "
            "binaires uniquement, ou renames sans contenu).",
            findings=(),
            score=None,
            languages=langs,
        )

    if standards is not None:
        effective_standards = standards
        effective_languages: tuple[str, ...] = tuple(languages or ())
    else:
        bundle: StandardsBundle = build_standards_bundle(
            file_diffs, languages_override=languages
        )
        effective_standards = bundle.text
        effective_languages = bundle.languages

    # P6 — check cache AVANT l'appel LLM. Import paresseux pour éviter
    # tout couplage si le cache n'est pas activé.
    cache_key: Optional[str] = None
    if cache_enabled and repo_root is not None:
        from . import cache as _cache  # import local

        diff_for_key = diff_text if diff_text is not None else render_diff_for_prompt(
            file_diffs
        )
        cache_key = _cache.compute_key(
            diff_text=diff_for_key,
            standards_text=effective_standards or "",
            languages=effective_languages,
            model_name=model_name or "",
        )
        ttl = (
            cache_ttl_seconds
            if cache_ttl_seconds is not None
            else _cache.DEFAULT_TTL_SECONDS
        )
        entry = _cache.load_entry(repo_root, cache_key, ttl_seconds=ttl)
        if entry is not None:
            cached = entry.result
            return ReviewResult(
                summary=cached.summary,
                findings=cached.findings,
                score=cached.score,
                languages=cached.languages or effective_languages,
                cache_status="hit",
            )

    user_prompt = build_prompt(file_diffs, standards=effective_standards)
    response = llm.complete_json(
        system=WALIPR_SYSTEM,
        user=user_prompt,
        schema_hint=WALIPR_SCHEMA_HINT,
    )
    payload = response.parsed
    if payload is None:
        # Le backend n'a pas réussi à parser : on tente un parsing
        # tolérant nous-mêmes pour récupérer ce qui peut l'être.
        payload = LLMClient._try_parse_json(response.raw_text)
    parsed = _parse_review_payload(payload, response.raw_text)
    final_status: Optional[str] = None
    if cache_enabled and repo_root is not None and cache_key is not None:
        from . import cache as _cache

        result_to_store = ReviewResult(
            summary=parsed.summary,
            findings=parsed.findings,
            score=parsed.score,
            languages=effective_languages,
        )
        try:
            _cache.store_entry(repo_root, cache_key, result_to_store)
        except OSError:
            # On n'échoue pas la revue si le cache ne peut pas écrire.
            pass
        final_status = "miss"
    return ReviewResult(
        summary=parsed.summary,
        findings=parsed.findings,
        score=parsed.score,
        languages=effective_languages,
        cache_status=final_status,  # type: ignore[arg-type]
    )
