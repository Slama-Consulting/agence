"""Interface commune des clients de forges (P7.3 + P8).

Définit :

- :class:`MergeRequestData` : structure immuable produite par
  :meth:`ForgeClient.fetch_mr`. Elle contient le diff unifié prêt à
  être passé à :func:`bughound.agents.walipr.diff.parse_unified_diff`,
  plus les métadonnées nécessaires au cache (``source_sha``) et au
  rendu (``title``, ``web_url``, etc.). Depuis P8, expose aussi
  ``base_sha``/``start_sha`` pour les commentaires inline GitLab.
- :class:`ForgeClient` : ABC à 3 méthodes (``fetch_mr``,
  ``post_comment``, ``post_inline_comment``). Les implémentations
  vivent dans :mod:`.gitlab`, :mod:`.github`, :mod:`.bitbucket`.
- :class:`PostCommentResult` : retour minimal de ``post_comment`` /
  ``post_inline_comment`` (id + URL), facilement sérialisable en
  JSON pour la sortie MCP.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from .url import ForgeRef


@dataclass(frozen=True)
class MergeRequestData:
    """Snapshot immuable d'une MR/PR distante.

    Attributes:
        ref: Référence canonique (forge, host, project, iid).
        title: Titre de la MR/PR.
        description: Corps de description (markdown brut).
        source_branch: Branche source (la "feature branch").
        target_branch: Branche de destination (souvent ``main``/
            ``master``/``develop``).
        source_sha: SHA HEAD de la branche source (composante de la
            clé de cache P7.7 — invalide le cache dès qu'un push
            ajoute un commit).
        web_url: URL web canonique de la MR/PR.
        diff_unified: Diff au format unified (compatible
            :func:`parse_unified_diff`). Concatène tous les fichiers.
    """

    ref: ForgeRef
    title: str
    description: str
    source_branch: str
    target_branch: str
    source_sha: str
    web_url: str
    diff_unified: str
    # P8 — diff_refs nécessaires aux commentaires inline GitLab.
    # Champ optionnel (défaut "") pour préserver la compat ascendante
    # avec GitHub et Bitbucket qui n'en ont pas besoin (ils utilisent
    # ``source_sha`` directement comme ``commit_id``).
    base_sha: str = ""
    start_sha: str = ""

    @property
    def diff_size_lines(self) -> int:
        """Nombre de lignes ``+``/``-`` (hors marqueurs ``---``/``+++``).

        Sert à appliquer le seuil ``--max-diff-lines`` (P7.7) en
        soft-fail avant d'envoyer un diff trop lourd au LLM.
        """
        if not self.diff_unified:
            return 0
        count = 0
        for line in self.diff_unified.splitlines():
            if not line:
                continue
            if line.startswith("+++") or line.startswith("---"):
                continue
            if line[0] in ("+", "-"):
                count += 1
        return count


@dataclass(frozen=True)
class PostCommentResult:
    """Résultat minimal d'un post de commentaire (P7.4-P7.6)."""

    id: str
    url: str


class ForgeClient(ABC):
    """Interface commune aux clients GitLab/GitHub/Bitbucket.

    Les implémentations sont **stateless** côté logique métier (les
    seuls états admis sont la conf HTTP : token, base URL, transport
    optionnel pour les tests).
    """

    @abstractmethod
    def fetch_mr(self, ref: ForgeRef) -> MergeRequestData:
        """Récupère la MR/PR référencée et retourne ses métadonnées + diff.

        Doit lever :class:`bughound.agents.walipr.forges.errors.ForgeAPIError`
        (ou sous-classe) en cas d'erreur réseau/HTTP.
        """

    @abstractmethod
    def post_comment(
        self, ref: ForgeRef, body: str,
    ) -> PostCommentResult:
        """Poste un commentaire général sur la MR/PR (pas un inline).

        Doit lever :class:`ForgeAPIError` en cas d'échec.
        """

    def post_inline_comment(
        self,
        ref: ForgeRef,
        mr_data: "MergeRequestData",
        file: str,
        line: int,
        body: str,
    ) -> PostCommentResult:
        """Poste un commentaire **inline** sur une ligne du diff (P8).

        Args:
            ref: Référence canonique de la MR/PR.
            mr_data: Données complètes (nécessaires pour ``base_sha``
                et ``source_sha`` côté GitLab/GitHub).
            file: Chemin du fichier tel qu'il apparaît dans le diff
                (côté nouveau).
            line: Numéro de ligne dans la version nouvelle (1-based).
            body: Texte markdown du commentaire.

        Implémentation par défaut : lève :class:`NotImplementedError`.
        Volontairement **non abstraite** pour préserver la compat
        ascendante avec les sous-classes/fakes P1-P7 qui n'ont pas
        besoin de poster en inline. Les vrais clients (GitLab,
        GitHub, Bitbucket) l'overrident.

        Doit lever :class:`ForgeAPIError` en cas d'échec API distant.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support inline comments"
        )


__all__ = [
    "ForgeClient",
    "MergeRequestData",
    "PostCommentResult",
]
