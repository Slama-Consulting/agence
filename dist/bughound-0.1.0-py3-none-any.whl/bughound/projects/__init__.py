"""Project resolution and local codebase inspection for BugHound."""

from .inspector import CodebaseInspector
from .resolver import ProjectResolver, ResolvedProject

__all__ = ["CodebaseInspector", "ProjectResolver", "ResolvedProject"]
