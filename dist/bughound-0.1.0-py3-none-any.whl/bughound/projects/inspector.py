"""Index a local Android/Kotlin/Java project and resolve FQNs to files.

The inspector walks a project root once, builds an index
``class_fqn -> (file_path, line)`` and exposes two lookups:

* :meth:`CodebaseInspector.find_class` — exact FQN match.
* :meth:`CodebaseInspector.cross_reference_logs` — scan a blob of log
  text for known FQNs (typical stack trace pattern
  ``at com.acme.foo.MyActivity.onCreate(MyActivity.kt:42)``) and return
  a de-duplicated list of :class:`CodeReference`.

Design choices:

* No external parser. A single pass of regular expressions on the source
  is enough to extract the ``package`` + top-level class/object/interface
  declarations for Kotlin and Java, which is what stack traces reference.
* XML layouts and ``*.gradle.kts`` scripts are indexed by basename only
  so we can still surface "the file exists" for log lines that name them
  (e.g. "inflating R.layout.fragment_main").
* Directories ``build/``, ``.gradle/``, ``node_modules/``, ``.idea/``,
  ``.git/`` are pruned for speed and sanity.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

from ..core.models import CodeReference


log = logging.getLogger(__name__)


# Directories we never descend into. Android build output is huge and
# contains generated copies of user sources, which would pollute the index.
_IGNORED_DIRS = frozenset({
    "build", ".gradle", ".idea", ".git", "node_modules",
    ".kotlin", ".cxx", "out", "captures",
})

_SOURCE_EXTS = frozenset({".kt", ".java"})
_AUX_EXTS = frozenset({".xml", ".gradle.kts", ".kts"})

# Kotlin/Java ``package com.foo.bar`` — trailing semicolon is optional (Kotlin).
_PACKAGE_RE = re.compile(
    r"^\s*package\s+([A-Za-z_][\w.]*)\s*;?\s*$", re.MULTILINE
)

# Top-level declarations we care about. We intentionally keep this loose:
# ``(data|sealed|open|abstract|final|public|internal|private|enum|class|
#   object|interface)`` in any order, followed by the simple name.
_DECL_RE = re.compile(
    r"^\s*"
    r"(?:(?:public|private|internal|protected|open|final|abstract|sealed|"
    r"data|enum|annotation|companion|inner|static)\s+)*"
    r"(?:class|object|interface)\s+"
    r"([A-Za-z_]\w*)",
    re.MULTILINE,
)

# Stack-trace style: ``at com.acme.Foo.method(Foo.kt:42)`` or plain
# ``com.acme.Foo$Inner`` mentions in a log line.
_FQN_IN_LOG_RE = re.compile(r"\b([a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+\.[A-Z][\w$]*)\b")


@dataclass(frozen=True)
class _IndexEntry:
    file_path: Path
    line: int


class CodebaseInspector:
    """Lightweight, in-memory index of a project's top-level classes."""

    def __init__(self, root: Path) -> None:
        self._root = Path(root).expanduser().resolve()
        self._by_fqn: dict[str, _IndexEntry] = {}
        self._by_basename: dict[str, Path] = {}
        self._indexed = False

    # -- public API --------------------------------------------------------

    @property
    def root(self) -> Path:
        return self._root

    @property
    def class_count(self) -> int:
        self._ensure_indexed()
        return len(self._by_fqn)

    def find_class(self, fqn: str) -> Optional[CodeReference]:
        """Return a :class:`CodeReference` for *fqn*, or ``None``.

        Inner-class FQNs (``com.foo.Outer$Inner``) fall back to their
        enclosing class so we still surface *a* file.
        """
        self._ensure_indexed()
        fqn = fqn.strip()
        if not fqn:
            return None

        entry = self._by_fqn.get(fqn)
        if entry is None and "$" in fqn:
            entry = self._by_fqn.get(fqn.split("$", 1)[0])
        if entry is None:
            return None

        return CodeReference(
            class_fqn=fqn,
            file_path=entry.file_path,
            line=entry.line,
            snippet=self._snippet(entry.file_path, entry.line),
        )

    def cross_reference_logs(self, text: str) -> list[CodeReference]:
        """Scan *text* for any known FQN and return de-duplicated refs."""
        if not text:
            return []
        self._ensure_indexed()

        seen: dict[str, CodeReference] = {}
        for match in _FQN_IN_LOG_RE.finditer(text):
            fqn = match.group(1)
            if fqn in seen:
                continue
            ref = self.find_class(fqn)
            if ref is not None:
                seen[fqn] = ref
        return list(seen.values())

    # -- indexing ----------------------------------------------------------

    def _ensure_indexed(self) -> None:
        if self._indexed:
            return
        self._indexed = True
        if not self._root.exists():
            log.warning("Codebase root does not exist: %s", self._root)
            return
        log.debug("Indexing codebase at %s…", self._root)
        for path in self._walk():
            suffix = path.suffix.lower()
            if suffix in _SOURCE_EXTS:
                self._index_source(path)
            elif suffix in _AUX_EXTS:
                self._by_basename.setdefault(path.name, path)
        log.debug(
            "Index ready: %d class(es), %d aux file(s) under %s",
            len(self._by_fqn), len(self._by_basename), self._root,
        )

    def _walk(self) -> Iterable[Path]:
        stack: list[Path] = [self._root]
        while stack:
            current = stack.pop()
            try:
                children = list(current.iterdir())
            except OSError:
                continue
            for child in children:
                if child.is_dir():
                    if child.name in _IGNORED_DIRS or child.name.startswith("."):
                        continue
                    stack.append(child)
                elif child.is_file():
                    yield child

    def _index_source(self, path: Path) -> None:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return

        pkg_match = _PACKAGE_RE.search(text)
        package = pkg_match.group(1) if pkg_match else ""

        for match in _DECL_RE.finditer(text):
            simple = match.group(1)
            fqn = f"{package}.{simple}" if package else simple
            # Use the position of the simple name (group 1) rather than the
            # whole match, because ``^\s*`` may swallow a preceding newline
            # and throw the line count off by one.
            line = text.count("\n", 0, match.start(1)) + 1
            # First declaration wins — later ones would be nested classes
            # that share the same file anyway.
            self._by_fqn.setdefault(fqn, _IndexEntry(path, line))

    # -- helpers -----------------------------------------------------------

    @staticmethod
    def _snippet(path: Path, line: int, context: int = 2) -> str:
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return ""
        start = max(0, line - 1 - context)
        end = min(len(lines), line + context)
        return "\n".join(lines[start:end])
