"""Resolve a Jira ticket to a local Android Studio project.

Matching strategy (in order):

1. Exact (case-insensitive) match of a Jira *component* name against a
   directory name under one of the configured ``search_roots``.
2. Exact match of a Jira *label* against a directory name.
3. Fuzzy match (``difflib.SequenceMatcher``) above a configured threshold
   against components then labels.

Successful resolutions are cached in ``~/.bughound/projects-cache.json``
keyed by ticket key so that re-runs for the same ticket are instantaneous
and stable. The cache is a best-effort optimisation: if it is missing,
corrupt, or points at a directory that no longer exists, we silently
re-resolve.

This module is deliberately side-effect-free apart from reading/writing
that single JSON cache file. It never talks to Jira or to the LLM.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Iterable, Optional

from ..core.models import Ticket


log = logging.getLogger(__name__)


DEFAULT_CACHE_PATH = Path("~/.bughound/projects-cache.json").expanduser()


@dataclass(frozen=True)
class ResolvedProject:
    """A Jira ticket mapped to a local project directory."""

    ticket_key: str
    root: Path
    name: str
    matched_on: str        # "component", "label", "fuzzy-component", "fuzzy-label", "manual", "cache"
    score: float           # 1.0 for exact matches, [0, 1] for fuzzy, 1.0 for cache hits


class ProjectResolver:
    """Match a ticket to a local project directory under ``search_roots``."""

    def __init__(
        self,
        *,
        search_roots: Iterable[Path],
        fuzzy_threshold: float = 0.72,
        cache_path: Optional[Path] = None,
    ) -> None:
        self._roots = [Path(r).expanduser() for r in search_roots]
        self._threshold = float(fuzzy_threshold)
        self._cache_path = Path(cache_path).expanduser() if cache_path else DEFAULT_CACHE_PATH

    # -- public API --------------------------------------------------------

    def resolve(self, ticket: Ticket) -> Optional[ResolvedProject]:
        cached = self._lookup_cache(ticket.key)
        if cached is not None:
            return cached

        candidates = self._list_candidates()
        if not candidates:
            return None

        resolved = (
            self._match_exact(ticket, candidates, "component", ticket.components)
            or self._match_exact(ticket, candidates, "label", ticket.labels)
            or self._match_fuzzy(ticket, candidates, "fuzzy-component", ticket.components)
            or self._match_fuzzy(ticket, candidates, "fuzzy-label", ticket.labels)
        )
        if resolved is not None:
            self._save_cache(resolved)
        return resolved

    def record_manual(self, ticket: Ticket, root: Path) -> ResolvedProject:
        root = Path(root).expanduser().resolve()
        resolved = ResolvedProject(
            ticket_key=ticket.key,
            root=root,
            name=root.name,
            matched_on="manual",
            score=1.0,
        )
        self._save_cache(resolved)
        return resolved

    # -- matching ----------------------------------------------------------

    def _list_candidates(self) -> list[Path]:
        dirs: list[Path] = []
        for root in self._roots:
            if not root.exists():
                continue
            for child in root.iterdir():
                if child.is_dir() and not child.name.startswith("."):
                    dirs.append(child)
        return dirs

    def _match_exact(
        self,
        ticket: Ticket,
        candidates: list[Path],
        matched_on: str,
        needles: list[str],
    ) -> Optional[ResolvedProject]:
        for needle in needles:
            if not needle:
                continue
            key = needle.strip().lower()
            for c in candidates:
                if c.name.lower() == key:
                    return ResolvedProject(
                        ticket_key=ticket.key,
                        root=c.resolve(),
                        name=c.name,
                        matched_on=matched_on,
                        score=1.0,
                    )
        return None

    def _match_fuzzy(
        self,
        ticket: Ticket,
        candidates: list[Path],
        matched_on: str,
        needles: list[str],
    ) -> Optional[ResolvedProject]:
        best: Optional[tuple[float, Path]] = None
        for needle in needles:
            if not needle:
                continue
            key = needle.strip().lower()
            for c in candidates:
                score = SequenceMatcher(None, key, c.name.lower()).ratio()
                if score >= self._threshold and (best is None or score > best[0]):
                    best = (score, c)
        if best is None:
            return None
        score, path = best
        return ResolvedProject(
            ticket_key=ticket.key,
            root=path.resolve(),
            name=path.name,
            matched_on=matched_on,
            score=round(score, 3),
        )

    # -- cache -------------------------------------------------------------

    def _lookup_cache(self, ticket_key: str) -> Optional[ResolvedProject]:
        data = self._load_cache()
        entry = data.get(ticket_key)
        if not entry:
            return None
        try:
            root = Path(entry["root"])
        except (KeyError, TypeError):
            return None
        if not root.exists():
            return None
        return ResolvedProject(
            ticket_key=ticket_key,
            root=root,
            name=entry.get("name", root.name),
            matched_on="cache",
            score=1.0,
        )

    def _save_cache(self, resolved: ResolvedProject) -> None:
        data = self._load_cache()
        data[resolved.ticket_key] = {
            "root": str(resolved.root),
            "name": resolved.name,
            "matched_on": resolved.matched_on,
            "score": resolved.score,
        }
        try:
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
            self._cache_path.write_text(
                json.dumps(data, indent=2, sort_keys=True), encoding="utf-8"
            )
        except OSError as exc:  # pragma: no cover
            log.warning("Could not write project cache %s: %s", self._cache_path, exc)

    def _load_cache(self) -> dict[str, dict]:
        if not self._cache_path.exists():
            return {}
        try:
            return json.loads(self._cache_path.read_text(encoding="utf-8")) or {}
        except (OSError, json.JSONDecodeError):
            return {}
