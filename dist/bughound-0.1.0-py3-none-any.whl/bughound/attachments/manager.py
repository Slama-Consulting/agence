"""Attachment orchestration: download, extract archives, classify.

Sits between the Jira client and the rest of the pipeline. Given a ticket,
it produces a :class:`AttachmentBundle` that groups every relevant file
(videos, logs, archives, ...) by kind — ready to be fed to the video and
log analyzers.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional

from ..core.models import Attachment, Ticket
from ..jira_client import JiraClient
from ..utils.fs import ensure_dir, safe_filename
from .archive import ArchiveExtractor, PasswordRequiredError, UnsafeArchiveError
from .handlers import HandlerRegistry, default_registry
from .kinds import IMAGE_EXTENSIONS, AttachmentKind, classify_file
from .multipart import detect_multipart, reassemble
from .passwords import PasswordProvider
from .selection import SelectionResult, select_log_first
from .url_fallback import (
    harvest_all_urls,
    materialise_url_attachments,
)

log = logging.getLogger(__name__)


@dataclass
class ClassifiedFile:
    """A concrete file on disk with its detected kind and origin."""

    path: Path
    kind: AttachmentKind
    # The ticket-level attachment it came from (or was extracted from).
    source_attachment: Attachment
    # Path inside the archive, if it was extracted. ``None`` for top-level
    # files downloaded directly from Jira.
    archive_member: Optional[str] = None


@dataclass
class AttachmentBundle:
    """All files collected for a ticket, grouped by kind for convenience."""

    ticket_key: str
    root_dir: Path
    files: list[ClassifiedFile] = field(default_factory=list)
    # Attachments dropped by the selection step (older uploads). Exposed
    # so the pipeline can surface them in the report/progress messages.
    skipped_attachments: list[Attachment] = field(default_factory=list)
    # Archives whose password was required but not provided.
    skipped_archives: list[Path] = field(default_factory=list)
    # URLs harvested from the ticket's text fields when it had no native
    # Jira attachments. Exposed so the pipeline can log where the files
    # came from.
    harvested_urls: list[str] = field(default_factory=list)

    def of_kind(self, kind: AttachmentKind) -> list[ClassifiedFile]:
        # LOG and TEXT are treated as equivalent for the pipeline: a `.txt`
        # with no clear logcat signature can still contain the log content
        # we care about (e.g. ``A12_switching_source.txt``). Asking for one
        # transparently returns both.
        if kind is AttachmentKind.LOG or kind is AttachmentKind.TEXT:
            return [
                f for f in self.files
                if f.kind is AttachmentKind.LOG or f.kind is AttachmentKind.TEXT
            ]
        return [f for f in self.files if f.kind is kind]

    @property
    def videos(self) -> list[ClassifiedFile]:
        return self.of_kind(AttachmentKind.VIDEO)

    @property
    def logs(self) -> list[ClassifiedFile]:
        # LOG ∪ TEXT: see ``of_kind``.
        return self.of_kind(AttachmentKind.LOG)

    @property
    def archives(self) -> list[ClassifiedFile]:
        return self.of_kind(AttachmentKind.ARCHIVE)

    @property
    def images(self) -> list[ClassifiedFile]:
        return self.of_kind(AttachmentKind.IMAGE)


class AttachmentManager:
    """Download ticket attachments, unpack archives, classify every file.

    The manager is intentionally passive about *which* files are interesting
    to the rest of the pipeline: it returns everything it finds and lets
    downstream modules filter by :class:`AttachmentKind`.
    """

    def __init__(
        self,
        jira: JiraClient,
        *,
        extractor: Optional[ArchiveExtractor] = None,
        password_provider: Optional[PasswordProvider] = None,
        max_archive_depth: int = 5,
        url_handlers: Optional[HandlerRegistry] = None,
    ) -> None:
        self._jira = jira
        # If an explicit extractor is provided we respect it; otherwise we
        # build a default one wired to the caller's password provider (if any)
        # so that encrypted archives can be unlocked on the fly.
        self._extractor = extractor or ArchiveExtractor(
            password_provider=password_provider
        )
        self._max_archive_depth = max_archive_depth
        # Registry of host-specific URL handlers (Artifactory, …). The
        # default registry is shared across calls; callers can inject a
        # custom one for tests or extra integrations.
        self._url_handlers = url_handlers or default_registry
        # Optional explicit extraction root — set per-call by ``collect()``.
        self._extracted_root: Optional[Path] = None

    def collect(
        self,
        ticket: Ticket,
        workdir: Path,
        *,
        filter_attachments: Optional[Iterable[str]] = None,
        downloads_dir: Optional[Path] = None,
        extracted_dir: Optional[Path] = None,
        only_latest_batch: bool = True,
    ) -> AttachmentBundle:
        """Download all attachments of ``ticket`` into ``workdir``.

        Args:
            ticket: The ticket whose attachments should be fetched.
            workdir: Root directory for this ticket's artifacts. A subdir
                ``<ticket-key>/`` is created inside it when ``downloads_dir``
                is not explicitly provided.
            filter_attachments: If provided, only attachments whose id or
                filename is in this set are downloaded.
            downloads_dir: Explicit directory for raw downloads. When set,
                overrides the default ``workdir/<ticket-key>/downloads``.
                Used by the per-ticket workspace layout.
            extracted_dir: Explicit directory for archive extractions. When
                set, overrides the default ``workdir/<ticket-key>/extracted``.

        Returns:
            An :class:`AttachmentBundle` listing every concrete file on disk.
        """
        if downloads_dir is not None:
            root = ensure_dir(Path(downloads_dir).parent)
            downloads_dir = ensure_dir(Path(downloads_dir))
        else:
            root = ensure_dir(workdir / safe_filename(ticket.key))
            downloads_dir = ensure_dir(root / "downloads")
        self._extracted_root = (
            ensure_dir(Path(extracted_dir)) if extracted_dir is not None else None
        )
        bundle = AttachmentBundle(ticket_key=ticket.key, root_dir=root)

        wanted = set(filter_attachments) if filter_attachments is not None else None

        # Step 1 — log-first selection.
        #
        # We want the *most recent log* and, if available, a video whose
        # upload time sits within 2 hours of that log on the same calendar
        # day (see ``select_log_first``). Images are never useful for log
        # analysis and can skew date-based selection, so they are filtered
        # out by extension before any comparison.
        #
        # When the Jira-side selection cannot produce both a log and a
        # matching video, ``needs_artifactory`` is set — we still download
        # what Jira gave us, but we *also* run the URL fallback and then
        # re-select over the combined set so an Artifactory log/video can
        # replace a missing piece.
        eligible: list[Attachment] = [
            a for a in ticket.attachments
            if (wanted is None or a.id in wanted or a.filename in wanted)
            and Path(a.filename).suffix.lower() not in IMAGE_EXTENSIONS
        ]
        selection: SelectionResult = select_log_first(eligible)
        if only_latest_batch:
            # Honour the selection: only the kept subset is downloaded from
            # Jira. Skipped attachments are recorded so the pipeline can
            # surface them in progress messages / report notes.
            bundle.skipped_attachments = list(selection.skipped)
            jira_targets = selection.kept
        else:
            # Backward compat: caller wants everything, so download all
            # eligible Jira attachments regardless of selection.
            jira_targets = eligible

        # Step 2 — download the retained Jira attachments.
        downloaded: list[tuple[Attachment, Path]] = []
        for attachment in jira_targets:
            try:
                local_path = self._jira.download_attachment(attachment, downloads_dir)
            except Exception as exc:
                log.warning(
                    "Failed to download attachment %s (%s): %s",
                    attachment.id,
                    attachment.filename,
                    exc,
                )
                continue
            downloaded.append((attachment, local_path))

        # Step 2b — URL fallback.
        #
        # Always look for download links inside the ticket's description
        # + comments (Artifactory, etc.). Testers often attach a small
        # file AND paste an Artifactory link for the full log bundle, or
        # paste the link without attaching anything. When the Jira-side
        # selection told us something was missing
        # (``needs_artifactory=True``), this step is the only way to
        # obtain it.
        fetched_pairs, harvested_urls = self._run_url_fallback(
            ticket, downloads_dir,
        )
        downloaded.extend(fetched_pairs)
        bundle.harvested_urls = harvested_urls

        # Step 2c — re-select over the combined set if the Jira-only
        # selection was incomplete. We merge the original Jira-eligible
        # list with the Artifactory-fetched synthetic attachments and run
        # ``select_log_first`` again; if it finds a better log/video pair
        # we update ``downloaded`` to reflect that.
        if only_latest_batch and selection.needs_artifactory and fetched_pairs:
            combined: list[Attachment] = list(eligible) + [a for a, _ in fetched_pairs]
            reselection = select_log_first(combined)
            # Build a fast lookup from attachment id -> local path for
            # things we already have on disk.
            paths_by_id = {a.id: p for a, p in downloaded}
            # Recompute downloaded so we only keep files matching the
            # re-selection. Artifactory-only files already sit on disk
            # (they were fetched above); Jira files we retained are
            # still present from step 2.
            new_downloaded: list[tuple[Attachment, Path]] = []
            kept_ids = {a.id for a in reselection.kept}
            for attachment in reselection.kept:
                local = paths_by_id.get(attachment.id)
                if local is not None:
                    new_downloaded.append((attachment, local))
                    continue
                # Jira attachment newly promoted by the re-selection and
                # not yet downloaded — pull it now.
                try:
                    local_path = self._jira.download_attachment(
                        attachment, downloads_dir,
                    )
                except Exception as exc:
                    log.warning(
                        "Failed to download promoted attachment %s (%s): %s",
                        attachment.id, attachment.filename, exc,
                    )
                    continue
                new_downloaded.append((attachment, local_path))
            # Anything in ``downloaded`` that the re-selection discarded
            # stays on disk (for forensics) but is moved to
            # ``skipped_attachments`` so the pipeline doesn't ingest it.
            dropped = [
                a for a, _ in downloaded if a.id not in kept_ids
            ]
            if dropped:
                bundle.skipped_attachments = list(bundle.skipped_attachments) + dropped
            downloaded = new_downloaded

        # Step 3 — detect multi-part archive families across the downloads
        # and reassemble them before handing files off to ingestion.
        families, claimed = detect_multipart([p for _, p in downloaded])
        downloads_by_path = {p: a for a, p in downloaded}

        for family in families:
            try:
                assembled = reassemble(family, downloads_dir)
            except Exception as exc:  # pragma: no cover - defensive
                log.warning(
                    "Failed to reassemble multi-part archive %s: %s",
                    family.stem, exc,
                )
                continue
            # Attribute the assembled archive to its first part's source
            # attachment — that's the one the user uploaded "first".
            source_attachment = downloads_by_path[family.parts[0]]
            self._ingest_file(
                assembled,
                source_attachment=source_attachment,
                bundle=bundle,
                root=root,
                depth=0,
                archive_member=(
                    f"reassembled from {len(family.parts)} part(s) "
                    f"[{family.scheme.value}]"
                ),
            )

        # Step 4 — ingest every remaining stand-alone file.
        for attachment, local_path in downloaded:
            if local_path in claimed:
                continue
            self._ingest_file(
                local_path,
                source_attachment=attachment,
                bundle=bundle,
                root=root,
                depth=0,
            )

        return bundle

    # ---- internals --------------------------------------------------------

    def _run_url_fallback(
        self,
        ticket: Ticket,
        downloads_dir: Path,
    ) -> tuple[list[tuple[Attachment, Path]], list[str]]:
        """Resolve URLs in the ticket text into concrete files on disk.

        Tries registered :class:`URLHandler` instances first (Artifactory,
        …) so folder-style links are walked recursively; then falls back
        to a simple extension-whitelist download for anything not claimed
        by a handler.
        """
        all_urls = harvest_all_urls(ticket)
        if not all_urls:
            return [], []

        fetched: list[tuple[Attachment, Path]] = []
        harvested_urls: list[str] = []
        unclaimed: list[str] = []

        auth = None
        try:
            auth = self._jira.http_auth()
        except Exception as exc:  # pragma: no cover - defensive
            log.debug("Jira client refused to share auth: %s", exc)

        for index, url in enumerate(all_urls):
            handler = self._url_handlers.resolve(url)
            if handler is None:
                unclaimed.append(url)
                continue
            log.info(
                "URL fallback: %s -> handler %r", url, handler.name,
            )
            try:
                files = handler.fetch(url, downloads_dir, auth=auth)
            except Exception as exc:
                log.warning(
                    "Handler %r failed on %s: %s",
                    handler.name, url, exc,
                )
                continue
            if not files:
                log.info("Handler %r returned no files for %s", handler.name, url)
                continue
            harvested_urls.append(url)
            for offset, fetched_file in enumerate(files):
                synthetic = Attachment(
                    id=f"{handler.name}-{index}-{offset}",
                    filename=fetched_file.relative_name,
                    url=fetched_file.source_url,
                    created=datetime.now(),
                    local_path=fetched_file.path,
                )
                fetched.append((synthetic, fetched_file.path))

        if unclaimed:
            # For URLs nothing claimed, reuse the simple extension-based
            # fallback so a bare ``https://srv/logs.zip`` still works.
            candidates = []
            # Re-run the candidate harvesting only on unclaimed URLs to
            # keep logic in one place.
            from .url_fallback import _filename_from_url  # local import
            for url in unclaimed:
                filename = _filename_from_url(url)
                if filename is None:
                    continue
                candidates.append((url, filename))
            if candidates:
                log.info(
                    "URL fallback: downloading %d simple link(s) for %s",
                    len(candidates), ticket.key,
                )
                simple = materialise_url_attachments(candidates, downloads_dir)
                fetched.extend(simple)
                harvested_urls.extend(att.url for att, _ in simple)

        return fetched, harvested_urls

    def _ingest_file(
        self,
        path: Path,
        *,
        source_attachment: Attachment,
        bundle: AttachmentBundle,
        root: Path,
        depth: int,
        archive_member: Optional[str] = None,
    ) -> None:
        kind = classify_file(path)

        # Images (screenshots, diagrams) are never useful for log analysis.
        # Skip them silently whether they come from Jira directly or from
        # inside an extracted archive.
        if kind is AttachmentKind.IMAGE:
            log.debug("Skipping image file: %s", path)
            return

        # Record the file (even archives — useful for traceability).
        bundle.files.append(
            ClassifiedFile(
                path=path,
                kind=kind,
                source_attachment=source_attachment,
                archive_member=archive_member,
            )
        )

        if kind is not AttachmentKind.ARCHIVE:
            return

        if depth >= self._max_archive_depth:
            log.warning(
                "Archive nesting depth %d exceeded for %s; not extracting.",
                self._max_archive_depth,
                path,
            )
            return

        extract_base = (
            getattr(self, "_extracted_root", None) or (root / "extracted")
        )
        extract_dir = ensure_dir(
            extract_base / f"{safe_filename(path.stem)}_{depth}"
        )
        try:
            extracted = self._extractor.extract(path, extract_dir)
        except UnsafeArchiveError as exc:
            log.error("Refusing to extract unsafe archive %s: %s", path, exc)
            return
        except PasswordRequiredError as exc:
            # No (or wrong) password supplied — record the archive so the
            # pipeline can surface it in the report instead of silently
            # dropping the user's data.
            log.warning("Skipping password-protected archive %s: %s", path, exc)
            bundle.skipped_archives.append(path)
            return
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("Failed to extract archive %s: %s", path, exc)
            return

        for extracted_path in extracted:
            # Give the extracted file its own Attachment with ``created``
            # taken from the filesystem mtime. Archive members often keep
            # their original capture time inside the archive (e.g. a
            # ``mlog.log`` recorded on 02-24 sitting inside a RAR uploaded
            # weeks later), and the selector needs that real date to pair
            # a log with the matching video. The parent archive attachment
            # stays in ``bundle.files`` untouched so traceability (and the
            # report) still point to the original upload.
            child_attachment = _attachment_from_extracted(
                extracted_path,
                parent=source_attachment,
            )
            self._ingest_file(
                extracted_path,
                source_attachment=child_attachment,
                bundle=bundle,
                root=root,
                depth=depth + 1,
                archive_member=str(extracted_path.relative_to(extract_dir)),
            )


def _attachment_from_extracted(
    path: Path,
    *,
    parent: Attachment,
) -> Attachment:
    """Build a synthetic :class:`Attachment` for a file pulled out of an archive.

    Dating uses the on-disk mtime because that is the most reliable hint
    of when the file was actually captured (archive tools preserve mtimes
    by default). Falls back to the parent's ``created`` if the stat call
    fails for any reason — better an old-but-consistent date than no date
    at all.
    """
    try:
        mtime = datetime.fromtimestamp(path.stat().st_mtime)
    except OSError:
        mtime = parent.created
    return Attachment(
        id=f"{parent.id}::{path.name}",
        filename=path.name,
        mime_type=parent.mime_type,
        url=parent.url,
        created=mtime,
        local_path=path,
    )
