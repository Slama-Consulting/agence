"""Interactive password source for protected archives.

The :class:`PasswordProvider` abstracts *where* a password comes from:
the CLI uses a hidden terminal prompt, the MCP tool uses FastMCP's
``elicit`` flow to ask the chat client, and the tests inject a scripted
provider. The extractor never sees anything else.

Passwords are cached in-memory per workspace run so a user asked for
``dump.zip``'s password doesn't get re-prompted for every entry inside
it. Nothing is ever persisted to disk.
"""

from __future__ import annotations

import getpass
import logging
from pathlib import Path
from typing import Callable, Optional, Protocol

log = logging.getLogger(__name__)


class PasswordProvider(Protocol):
    """Callable returning the password for ``archive`` or ``None`` to skip."""

    def __call__(self, archive: Path) -> Optional[str]:  # pragma: no cover - protocol
        ...


class CachingPasswordProvider:
    """Wraps another provider and caches answers per archive path.

    Also de-duplicates when the same archive is retried with the same
    password (we only ask once per path).
    """

    def __init__(self, inner: PasswordProvider) -> None:
        self._inner = inner
        self._cache: dict[Path, Optional[str]] = {}

    def __call__(self, archive: Path) -> Optional[str]:
        if archive in self._cache:
            return self._cache[archive]
        pw = self._inner(archive)
        self._cache[archive] = pw
        return pw


class TerminalPasswordProvider:
    """Prompt for a password on the terminal using :func:`getpass`.

    Returns ``None`` if no TTY is attached — the extractor will then
    mark the archive as skipped rather than blocking forever.
    """

    def __call__(self, archive: Path) -> Optional[str]:
        import sys
        if not sys.stdin.isatty():
            log.warning(
                "Archive %s is password-protected but no TTY is available; skipping.",
                archive.name,
            )
            return None
        try:
            pw = getpass.getpass(
                f"Mot de passe pour {archive.name} (laisser vide pour ignorer) : "
            )
        except (KeyboardInterrupt, EOFError):
            return None
        return pw or None


class StaticPasswordProvider:
    """Return a pre-known password. Used when one is passed via CLI/MCP."""

    def __init__(self, password: Optional[str]) -> None:
        self._password = password

    def __call__(self, archive: Path) -> Optional[str]:
        return self._password


def callable_provider(fn: Callable[[Path], Optional[str]]) -> PasswordProvider:
    """Wrap a plain callable so typing recognises it as a provider."""
    return fn  # type: ignore[return-value]


__all__ = [
    "PasswordProvider",
    "CachingPasswordProvider",
    "TerminalPasswordProvider",
    "StaticPasswordProvider",
    "callable_provider",
]
