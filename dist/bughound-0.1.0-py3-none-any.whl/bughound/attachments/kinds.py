"""File classification: figure out if a file is a log, video, archive, ..."""

from __future__ import annotations

import re
from enum import Enum
from pathlib import Path
from typing import Optional


class AttachmentKind(str, Enum):
    """What a file is, as far as BugHound's pipeline cares."""

    VIDEO = "video"
    LOG = "log"
    ARCHIVE = "archive"
    IMAGE = "image"
    TEXT = "text"
    OTHER = "other"


# Extensions that are classified as images — exported so other modules can
# filter them out without importing the full extension map.
IMAGE_EXTENSIONS: frozenset[str] = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp",
})

# Extension → kind. Extensions are checked lower-cased with the leading dot.
_EXT_MAP: dict[str, AttachmentKind] = {
    # Videos
    ".mp4": AttachmentKind.VIDEO,
    ".mov": AttachmentKind.VIDEO,
    ".mkv": AttachmentKind.VIDEO,
    ".webm": AttachmentKind.VIDEO,
    ".avi": AttachmentKind.VIDEO,
    ".m4v": AttachmentKind.VIDEO,
    # Archives
    ".zip": AttachmentKind.ARCHIVE,
    ".tar": AttachmentKind.ARCHIVE,
    ".tgz": AttachmentKind.ARCHIVE,
    ".gz": AttachmentKind.ARCHIVE,     # treated as archive even for plain .gz
    ".bz2": AttachmentKind.ARCHIVE,
    ".xz": AttachmentKind.ARCHIVE,
    ".7z": AttachmentKind.ARCHIVE,
    ".rar": AttachmentKind.ARCHIVE,
    # Logs
    ".log": AttachmentKind.LOG,
    ".logcat": AttachmentKind.LOG,
    ".txt": AttachmentKind.TEXT,       # upgraded to LOG by sniffing if needed
    # Images
    ".png": AttachmentKind.IMAGE,
    ".jpg": AttachmentKind.IMAGE,
    ".jpeg": AttachmentKind.IMAGE,
    ".gif": AttachmentKind.IMAGE,
    ".webp": AttachmentKind.IMAGE,
}

# Magic bytes used to confirm or override extension-based guesses.
_MAGIC_SIGNATURES: list[tuple[bytes, AttachmentKind]] = [
    # ZIP (also APK/JAR/DOCX but those are fine to treat as archives here)
    (b"PK\x03\x04", AttachmentKind.ARCHIVE),
    (b"PK\x05\x06", AttachmentKind.ARCHIVE),
    # gzip
    (b"\x1f\x8b", AttachmentKind.ARCHIVE),
    # 7z
    (b"7z\xbc\xaf\x27\x1c", AttachmentKind.ARCHIVE),
    # RAR 1.5 – 4.x
    (b"Rar!\x1a\x07\x00", AttachmentKind.ARCHIVE),
    # RAR 5+
    (b"Rar!\x1a\x07\x01\x00", AttachmentKind.ARCHIVE),
    # MP4 (ftyp box appears at offset 4, not 0 — handled in classify_file)
    # PNG
    (b"\x89PNG\r\n\x1a\n", AttachmentKind.IMAGE),
    # JPEG
    (b"\xff\xd8\xff", AttachmentKind.IMAGE),
    # GIF
    (b"GIF87a", AttachmentKind.IMAGE),
    (b"GIF89a", AttachmentKind.IMAGE),
]


# Filename prefixes (lower-cased) that identify a log file regardless of
# content. Bugreport dumps and plain logcat exports both start with these
# well-known prefixes, but their first 4 KB often contains only metadata so
# content-sniffing alone would miss them.
_LOG_FILENAME_PREFIXES: tuple[str, ...] = (
    "bugreport",
    "logcat",
)


# Heuristic patterns that suggest a text file is actually a logcat dump.
_LOGCAT_HINTS = (
    # Classic logcat threadtime/time headers.
    " D/", " I/", " W/", " E/", " V/",
    "beginning of crash",
    "AndroidRuntime",
    "FATAL EXCEPTION",
    "ANR in ",
)

# Regex fallback for logcat formats where the level is a standalone letter
# surrounded by whitespace (e.g. automotive dumps with
# `YYYY-MM-DD HH:MM:SS.mmm  PID-TID  Tag  Process  LEVEL  Message`).
# We require a timestamp-like prefix + PID-TID + a standalone V/D/I/W/E/F
# surrounded by spaces to avoid matching prose.
_SPACE_LEVEL_LOG_RE = re.compile(
    r"^\s*"
    r"(?:\d{4}-\d{2}-\d{2}[ T]|\d{2}-\d{2}\s+)"
    r"\d{2}:\d{2}:\d{2}\.\d{3,6}\s+"
    r"\d+-\d+\s+\S.*?\s+[VDIWEF]\s+\S",
    re.MULTILINE,
)


def classify_file(path: Path, *, sample_bytes: int = 65536) -> AttachmentKind:
    """Return the :class:`AttachmentKind` for ``path``.

    Uses extension first, then validates / overrides via magic bytes and
    content sniffing. Files that don't exist or can't be read fall back to
    :attr:`AttachmentKind.OTHER`.

    ``sample_bytes`` defaults to 64 KiB rather than 4 KiB because Renault
    bugreport/automotive dumps frequently prefix their payload with a
    large metadata header (system properties, build fingerprint, …) that
    blows past the first 4 KiB before any logcat line is reached. The
    bigger window keeps ``_looks_like_logcat`` effective on those files
    without becoming visibly slower in practice — we only ever read from
    the file, never the full contents.
    """
    if not path.exists() or not path.is_file():
        return AttachmentKind.OTHER

    ext_kind = _EXT_MAP.get(path.suffix.lower())

    try:
        with path.open("rb") as fh:
            head = fh.read(sample_bytes)
    except OSError:
        return ext_kind or AttachmentKind.OTHER

    # Magic bytes win over extension when they disagree.
    magic_kind = _match_magic(head)
    if magic_kind is not None:
        return magic_kind

    # MP4/MOV: "ftypXXXX" at offset 4
    if len(head) >= 12 and head[4:8] == b"ftyp":
        return AttachmentKind.VIDEO

    if ext_kind is not None:
        # Upgrade .txt → LOG when the content looks like logcat.
        if ext_kind in (AttachmentKind.TEXT, AttachmentKind.LOG):
            # Fast-path: well-known log filename prefixes (e.g. bugreport-*,
            # logcat_*). These files often have a large metadata header before
            # the actual logcat section, so the 4 KB content-sniff alone is
            # not reliable for them.
            stem_lower = path.name.lower()
            if any(stem_lower.startswith(p) for p in _LOG_FILENAME_PREFIXES):
                return AttachmentKind.LOG
            if _looks_like_logcat(head):
                return AttachmentKind.LOG
        return ext_kind

    # No extension match, no magic match: last-ditch text sniff.
    if _looks_like_text(head):
        stem_lower = path.name.lower()
        if any(stem_lower.startswith(p) for p in _LOG_FILENAME_PREFIXES):
            return AttachmentKind.LOG
        if _looks_like_logcat(head):
            return AttachmentKind.LOG
        return AttachmentKind.TEXT

    return AttachmentKind.OTHER


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _match_magic(head: bytes) -> Optional[AttachmentKind]:
    for signature, kind in _MAGIC_SIGNATURES:
        if head.startswith(signature):
            return kind
    return None


def _looks_like_logcat(head: bytes) -> bool:
    try:
        snippet = head.decode("utf-8", errors="replace")
    except Exception:
        return False
    if any(hint in snippet for hint in _LOGCAT_HINTS):
        return True
    # Real-world dumps often use `YYYY-MM-DD ... PID-TID ... Tag ... LEVEL msg`
    # where the level is a bare letter between spaces. Require >= 2 matching
    # lines so ordinary prose doesn't get flagged as logcat.
    return len(_SPACE_LEVEL_LOG_RE.findall(snippet)) >= 2


def _looks_like_text(head: bytes) -> bool:
    if not head:
        return False
    # Heuristic: mostly printable ASCII / UTF-8, few control bytes.
    # NUL bytes are a strong signal that it's binary.
    if b"\x00" in head:
        return False
    try:
        head.decode("utf-8")
        return True
    except UnicodeDecodeError:
        return False
