"""Safe archive extraction.

Supports ZIP (optionally password-protected), tar (.tar / .tar.gz / .tgz
/ .tar.bz2 / .tar.xz), RAR (single- and multi-volume, via ``rarfile``),
and 7z (via ``py7zr``) out of the box. Every entry path is validated
against the destination root so a crafted archive cannot escape via
``../`` traversal (zip-slip / tar-slip).

Format detection is performed by **magic bytes first**, with an
extension-based fallback for edge cases (e.g. multi-volume RAR where
the first volume lacks a readable header). Each container is routed
to its own native extractor: a real RAR goes through ``rarfile``, a
real ZIP goes through ``zipfile``, etc. — no silent promotion between
formats.

Password handling: when a ZIP/RAR/7z archive requires a password,
the extractor asks the configured :class:`PasswordProvider` — which
may prompt the user on the terminal, via an MCP elicitation, or
return a pre-known password from config. Returning ``None`` (e.g. no
TTY attached) marks the archive as skipped rather than blocking.
"""

from __future__ import annotations

import logging
import tarfile
import zipfile
from pathlib import Path
from typing import Optional

from .passwords import PasswordProvider

log = logging.getLogger(__name__)


class UnsafeArchiveError(RuntimeError):
    """Raised when an archive entry would escape the destination root."""


class PasswordRequiredError(RuntimeError):
    """Raised when an archive needs a password and none was supplied."""


class ArchiveExtractor:
    """Extract ZIP, tar, RAR and 7z archives into a controlled directory."""

    def __init__(
        self,
        password_provider: Optional[PasswordProvider] = None,
    ) -> None:
        self._password_provider = password_provider

    def extract(self, archive_path: Path, dest_dir: Path) -> list[Path]:
        """Extract ``archive_path`` into ``dest_dir`` and return the file list.

        ``dest_dir`` is created if missing. Returns the flat list of extracted
        regular files (directories are created but not listed).

        Dispatch order: magic bytes first (so a file named ``foo.rar`` that
        is really a ZIP still gets handled via ZIP, and vice-versa), then
        extension-based fallbacks for multi-volume RAR / weird ZIP headers.
        """
        dest_dir.mkdir(parents=True, exist_ok=True)

        # Peek the first 8 bytes so we can dispatch by actual format.
        try:
            with archive_path.open("rb") as fh:
                head = fh.read(8)
        except OSError:
            head = b""

        # RAR v1.5–4 and v5+ magic.
        if head.startswith(b"Rar!\x1a\x07"):
            return self._extract_rar(archive_path, dest_dir)
        # 7z magic.
        if head.startswith(b"7z\xbc\xaf\x27\x1c"):
            return self._extract_7z(archive_path, dest_dir)
        # ZIP magic (regular + empty EOCD).
        if head.startswith(b"PK\x03\x04") or head.startswith(b"PK\x05\x06"):
            return self._extract_zip(archive_path, dest_dir)
        # tar (various flavours, detected via header inspection).
        if tarfile.is_tarfile(archive_path):
            return self._extract_tar(archive_path, dest_dir)

        # Magic didn't match — fall back to extension-based guesses.
        name = archive_path.name.lower()
        if name.endswith(".rar") or ".part1.rar" in name:
            return self._extract_rar(archive_path, dest_dir)
        if name.endswith(".7z"):
            return self._extract_7z(archive_path, dest_dir)
        if zipfile.is_zipfile(archive_path):
            return self._extract_zip(archive_path, dest_dir)

        raise ValueError(f"Unsupported archive format: {archive_path}")

    # ---- zip --------------------------------------------------------------

    def _extract_zip(self, archive: Path, dest: Path) -> list[Path]:
        extracted: list[Path] = []
        dest_resolved = dest.resolve()

        with zipfile.ZipFile(archive) as zf:
            needs_pw = any(
                (info.flag_bits & 0x1) for info in zf.infolist() if not info.is_dir()
            )
            password_bytes: Optional[bytes] = None
            if needs_pw:
                pw = self._ask_password(archive)
                if not pw:
                    raise PasswordRequiredError(
                        f"{archive.name} is password-protected and no password was provided."
                    )
                password_bytes = pw.encode("utf-8")

            for info in zf.infolist():
                target = self._safe_join(dest_resolved, info.filename)
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info, pwd=password_bytes) as src, target.open("wb") as dst:
                    while True:
                        chunk = src.read(64 * 1024)
                        if not chunk:
                            break
                        dst.write(chunk)
                extracted.append(target)

        return extracted

    # ---- tar --------------------------------------------------------------

    def _extract_tar(self, archive: Path, dest: Path) -> list[Path]:
        extracted: list[Path] = []
        dest_resolved = dest.resolve()

        with tarfile.open(archive) as tf:
            members = tf.getmembers()
            for member in members:
                # Refuse device nodes, symlinks, hardlinks: unnecessary and
                # a common exfiltration vector.
                if not (member.isreg() or member.isdir()):
                    log.warning(
                        "Skipping non-regular tar entry %r (type=%s)",
                        member.name,
                        member.type,
                    )
                    continue

                target = self._safe_join(dest_resolved, member.name)
                if member.isdir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue

                target.parent.mkdir(parents=True, exist_ok=True)
                src = tf.extractfile(member)
                if src is None:
                    continue
                with src, target.open("wb") as dst:
                    while True:
                        chunk = src.read(64 * 1024)
                        if not chunk:
                            break
                        dst.write(chunk)
                extracted.append(target)

        return extracted

    # ---- rar --------------------------------------------------------------

    def _extract_rar(self, archive: Path, dest: Path) -> list[Path]:
        try:
            import rarfile  # type: ignore
        except ImportError as exc:  # pragma: no cover - env-dependent
            raise RuntimeError(
                "RAR archives require the 'rarfile' package and an unrar/bsdtar "
                "binary on PATH."
            ) from exc

        dest_resolved = dest.resolve()
        extracted: list[Path] = []
        with rarfile.RarFile(archive) as rf:
            password: Optional[str] = None
            if rf.needs_password():
                password = self._ask_password(archive)
                if not password:
                    raise PasswordRequiredError(
                        f"{archive.name} is password-protected and no password was provided."
                    )
                rf.setpassword(password)
            for info in rf.infolist():
                target = self._safe_join(dest_resolved, info.filename)
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with rf.open(info, pwd=password) as src, target.open("wb") as dst:
                    while True:
                        chunk = src.read(64 * 1024)
                        if not chunk:
                            break
                        dst.write(chunk)
                extracted.append(target)
        return extracted

    # ---- 7z ---------------------------------------------------------------

    def _extract_7z(self, archive: Path, dest: Path) -> list[Path]:
        try:
            import py7zr  # type: ignore
        except ImportError as exc:  # pragma: no cover - env-dependent
            raise RuntimeError(
                "7z archives require the 'py7zr' package."
            ) from exc

        dest_resolved = dest.resolve()
        password: Optional[str] = None
        try:
            # First pass: peek without password to see if one is required.
            with py7zr.SevenZipFile(archive, mode="r") as zf:
                zf.getnames()
                needs_pw = zf.needs_password() if hasattr(zf, "needs_password") else False
        except py7zr.exceptions.PasswordRequired:
            needs_pw = True
        except Exception:
            needs_pw = False

        if needs_pw:
            password = self._ask_password(archive)
            if not password:
                raise PasswordRequiredError(
                    f"{archive.name} is password-protected and no password was provided."
                )

        extracted: list[Path] = []
        with py7zr.SevenZipFile(archive, mode="r", password=password) as zf:
            # py7zr extracts into the destination; we then validate each
            # resulting path stays under ``dest_resolved``.
            zf.extractall(path=dest)
            for name in zf.getnames():
                candidate = (dest / name).resolve()
                try:
                    candidate.relative_to(dest_resolved)
                except ValueError as exc:
                    raise UnsafeArchiveError(
                        f"7z entry {name!r} escapes destination {dest_resolved}"
                    ) from exc
                if candidate.is_file():
                    extracted.append(candidate)
        return extracted

    # ---- shared -----------------------------------------------------------

    def _ask_password(self, archive: Path) -> Optional[str]:
        if self._password_provider is None:
            return None
        try:
            return self._password_provider(archive)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("Password provider raised for %s: %s", archive.name, exc)
            return None

    @staticmethod
    def _safe_join(root: Path, member_name: str) -> Path:
        # Reject absolute paths outright.
        candidate = (root / member_name).resolve()
        try:
            candidate.relative_to(root)
        except ValueError as exc:
            raise UnsafeArchiveError(
                f"Archive entry {member_name!r} escapes destination {root}"
            ) from exc
        return candidate
