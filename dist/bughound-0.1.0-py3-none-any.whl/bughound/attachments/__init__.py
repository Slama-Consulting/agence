from .kinds import AttachmentKind, classify_file
from .archive import ArchiveExtractor, PasswordRequiredError, UnsafeArchiveError
from .manager import AttachmentBundle, AttachmentManager, ClassifiedFile
from .multipart import MultipartArchive, MultipartScheme, detect_multipart, reassemble
from .passwords import (
    CachingPasswordProvider,
    PasswordProvider,
    StaticPasswordProvider,
    TerminalPasswordProvider,
)
from .selection import (
    SelectionResult,
    pick_latest_batch,
    select_confirmation_pair,
    select_log_first,
)

__all__ = [
    "AttachmentKind",
    "classify_file",
    "ArchiveExtractor",
    "PasswordRequiredError",
    "UnsafeArchiveError",
    "AttachmentBundle",
    "AttachmentManager",
    "ClassifiedFile",
    "MultipartArchive",
    "MultipartScheme",
    "detect_multipart",
    "reassemble",
    "PasswordProvider",
    "CachingPasswordProvider",
    "StaticPasswordProvider",
    "TerminalPasswordProvider",
    "SelectionResult",
    "pick_latest_batch",
    "select_confirmation_pair",
    "select_log_first",
]
