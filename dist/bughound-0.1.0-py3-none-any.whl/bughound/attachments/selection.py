"""Pick the right subset of attachments for analysis.

Two strategies coexist:

* :func:`pick_latest_batch` — legacy behaviour. Keeps the most recent
  calendar day of uploads. Used by older call-sites and tests; kept here
  for backward compatibility.

* :func:`select_log_first` — log-centric selection (the one the pipeline
  now uses). Find the most recent **log** attachment, then add the video
  whose upload time sits within 2 hours of that log on the same calendar
  day. If one or both pieces are missing, surface ``needs_artifactory``
  so the manager can try the Artifactory fallback before giving up.

Attachments without a ``created`` timestamp are treated conservatively
(kept rather than silently dropped) so HTML-scraped tickets still work.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable, Optional

from ..core.models import Attachment

log = logging.getLogger(__name__)


def _naive(dt: Optional[datetime]) -> Optional[datetime]:
    """Strip ``tzinfo`` so naïve and aware datetimes can be compared.

    Some attachment sources (Jira REST API) return timezone-aware
    timestamps, while others (URL fallback, Artifactory directory
    listings, local filesystem fallbacks) return naïve ones. Mixing
    them in ``sorted()`` or ``min()`` raises ``TypeError`` on Python's
    strict ordering rules. Forcing every comparison through this
    helper keeps the selection logic simple: we only care about the
    *relative* order of uploads inside a single bundle, not their
    absolute timezone.
    """
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt
    return dt.replace(tzinfo=None)


# Extensions used at the selection stage. We intentionally rely on the
# filename only (not magic bytes) because the files are not downloaded
# yet when this runs.
_VIDEO_EXTS: frozenset[str] = frozenset({
    ".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v",
})
_LOG_EXTS: frozenset[str] = frozenset({
    ".log", ".txt", ".logcat",
})
# Archive extensions — kept unconditionally by ``select_log_first`` because
# a zip/rar/7z bundle usually contains the real log or video inside.
# Filtering these out at selection time would silently throw away the most
# common shape of attachment for Android bugreports.
_ARCHIVE_EXTS: frozenset[str] = frozenset({
    ".zip", ".tar", ".tgz", ".gz", ".bz2", ".xz", ".7z", ".rar",
})
# Maximum gap allowed between the chosen log and a candidate video.
_VIDEO_LOG_MAX_GAP = timedelta(hours=2)


@dataclass(frozen=True)
class SelectionResult:
    """Outcome of an attachment-selection pass.

    ``kept`` are the attachments chosen for download; ``skipped`` are
    the ones explicitly dropped. ``latest_day`` is the calendar day
    that anchored the decision (``None`` if no dates were available).

    ``needs_artifactory`` is set by :func:`select_log_first` when the
    Jira-only selection did not yield both a usable log and a matching
    video; the caller is expected to try the URL fallback before
    falling back to log-only analysis.
    """

    kept: list[Attachment]
    skipped: list[Attachment]
    latest_day: date | None
    needs_artifactory: bool = False


def pick_latest_batch(attachments: Iterable[Attachment]) -> SelectionResult:
    """Return only the attachments uploaded on the most recent calendar day.

    Legacy selector preserved for backward compatibility. New call-sites
    should use :func:`select_log_first`.

    Rules:
    - Attachments with no ``created`` timestamp are always kept (can't be
      reliably ranked).
    - Among the dated ones, find the most recent calendar day and keep
      every attachment uploaded on that day.
    - Everything older is marked as ``skipped``.
    """
    items = list(attachments)
    dated = [a for a in items if a.created is not None]
    undated = [a for a in items if a.created is None]

    if not dated:
        return SelectionResult(kept=list(items), skipped=[], latest_day=None)

    latest_day = max(a.created.date() for a in dated)  # type: ignore[union-attr]
    kept_dated = [a for a in dated if a.created.date() == latest_day]  # type: ignore[union-attr]
    skipped = [a for a in dated if a.created.date() != latest_day]  # type: ignore[union-attr]

    if skipped:
        log.info(
            "Attachment selection: keeping %d file(s) from %s, "
            "skipping %d older file(s).",
            len(kept_dated) + len(undated),
            latest_day.isoformat(),
            len(skipped),
        )

    # Undated files keep their original relative order but come after the
    # dated ones, so the pipeline sees the "most trustworthy" set first.
    return SelectionResult(
        kept=kept_dated + undated,
        skipped=skipped,
        latest_day=latest_day,
    )


def _ext(att: Attachment) -> str:
    return Path(att.filename).suffix.lower()


def _is_log(att: Attachment) -> bool:
    return _ext(att) in _LOG_EXTS


def _is_video(att: Attachment) -> bool:
    return _ext(att) in _VIDEO_EXTS


def _is_archive(att: Attachment) -> bool:
    return _ext(att) in _ARCHIVE_EXTS


def select_log_first(
    attachments: Iterable[Attachment],
) -> SelectionResult:
    """Pick the newest log + a video whose date matches that log.

    Strategy:

    1. Partition attachments into log-candidates (``.log``, ``.txt``,
       ``.logcat``), video-candidates (``.mp4``, ``.mov``, …) and
       archive-candidates (``.zip``, ``.tar``, ``.rar``, ``.7z``, …).
       Everything else (images, pdf, …) is ignored at this stage.
    2. Pick the **most recent** log by ``created``. Undated logs are kept
       only when no dated log exists.
    3. Find videos uploaded on the same calendar day *and* within
       :data:`_VIDEO_LOG_MAX_GAP` of the **anchor time**. The anchor is
       the chosen log's ``created`` when one exists, otherwise the most
       recent dated archive (Android tickets often ship the log
       *inside* a ``.zip`` and a sibling video — without this fallback
       the video would be silently dropped). If multiple videos
       qualify, keep the one closest in time to the anchor. If one
       single video exists but fails this check, it is **not** kept.
    4. Archives are **always kept**: they usually contain the real log
       and/or video inside, and the manager walks them after download.
    5. ``needs_artifactory`` is ``True`` when no log was retained, or
       when no matching video was retained (so the Artifactory fallback
       can look for the missing piece).
    """
    items = list(attachments)

    logs = [a for a in items if _is_log(a)]
    videos = [a for a in items if _is_video(a)]
    archives = [a for a in items if _is_archive(a)]

    # ---- pick the newest log -------------------------------------------
    dated_logs = [a for a in logs if a.created is not None]
    undated_logs = [a for a in logs if a.created is None]
    chosen_log: Attachment | None = None
    if dated_logs:
        # Stable sort: most recent first, ties broken by insertion order.
        # ``_naive`` is required because ``a.created`` mixes tz-aware
        # (Jira REST) and tz-naïve (URL fallback / Artifactory) datetimes
        # in the same bundle, which would otherwise raise TypeError.
        dated_logs_sorted = sorted(
            dated_logs,
            key=lambda a: _naive(a.created),  # type: ignore[return-value]
            reverse=True,
        )
        chosen_log = dated_logs_sorted[0]
    elif undated_logs:
        # Undated logs are a safety net only — keep them all so the caller
        # can still analyse something. A single chosen log can't be picked
        # without dates, so we keep them collectively.
        chosen_log = None  # handled below (we keep all undated logs)

    # ---- pick a matching video -----------------------------------------
    # Anchor for video pairing: prefer the chosen log's timestamp; if no
    # direct log was retained (typical Android case where the log lives
    # *inside* a .zip), fall back to the most recent dated archive. This
    # keeps the same "same calendar day + ≤ 2 h gap" rule but stops
    # silently dropping the video when the log is bundled in an archive.
    chosen_video: Attachment | None = None
    ref_time: Optional[datetime] = None
    if chosen_log is not None and chosen_log.created is not None:
        ref_time = _naive(chosen_log.created)
    else:
        dated_archives = [a for a in archives if a.created is not None]
        if dated_archives:
            newest_archive = max(
                dated_archives,
                key=lambda a: _naive(a.created),  # type: ignore[return-value]
            )
            ref_time = _naive(newest_archive.created)

    if ref_time is not None:
        ref_day = ref_time.date()
        eligible_videos = [
            v for v in videos
            if v.created is not None
            and v.created.date() == ref_day
            and abs(_naive(v.created) - ref_time) <= _VIDEO_LOG_MAX_GAP  # type: ignore[operator]
        ]
        if eligible_videos:
            chosen_video = min(
                eligible_videos,
                key=lambda v: abs(_naive(v.created) - ref_time),  # type: ignore[operator]
            )

    # ---- assemble kept + skipped ---------------------------------------
    kept: list[Attachment] = []
    if chosen_log is not None:
        kept.append(chosen_log)
    else:
        # No dated log → keep all undated logs so something can be analysed.
        kept.extend(undated_logs)

    if chosen_video is not None:
        kept.append(chosen_video)

    # Archives are kept unconditionally: they almost always contain the
    # actual log/video inside, and ``AttachmentManager`` will recurse into
    # them (up to ``max_archive_depth``) to surface what's useful.
    kept.extend(archives)

    kept_ids = {id(a) for a in kept}
    skipped = [a for a in items if id(a) not in kept_ids]

    latest_day = (
        chosen_log.created.date()
        if chosen_log is not None and chosen_log.created is not None
        else None
    )

    # We need Artifactory when we are missing a log (no log at all) OR
    # we are missing a matching video. The caller decides what to do.
    needs_artifactory = (
        chosen_log is None and not undated_logs
    ) or (chosen_video is None)

    if skipped:
        log.info(
            "Attachment selection (log-first): keeping %d file(s), "
            "skipping %d other(s); needs_artifactory=%s, anchor_day=%s.",
            len(kept),
            len(skipped),
            needs_artifactory,
            latest_day.isoformat() if latest_day else "none",
        )

    return SelectionResult(
        kept=kept,
        skipped=skipped,
        latest_day=latest_day,
        needs_artifactory=needs_artifactory,
    )


def select_confirmation_pair(
    attachments: Iterable[Attachment],
    *,
    exclude: Iterable[Attachment] = (),
) -> SelectionResult:
    """Pick the best log+video pair for a confirmation pass.

    Walks all logs newest-first (by ``created``) and returns the first one
    that has a matching video on the same calendar day within
    :data:`_VIDEO_LOG_MAX_GAP`. Logs listed in ``exclude`` (typically the
    pass-1 anchor) are skipped so pass 2 always offers a different view.

    Returns a :class:`SelectionResult` with ``kept=[log, video]`` on
    success, or an empty ``kept`` list when no valid pair exists.
    ``needs_artifactory`` is always ``False`` here — confirmation is a
    best-effort cross-check, not a mandatory step.
    """
    items = list(attachments)
    excluded_ids = {id(a) for a in exclude}

    logs = [
        a for a in items
        if _is_log(a) and a.created is not None and id(a) not in excluded_ids
    ]
    videos = [a for a in items if _is_video(a) and a.created is not None]

    # Newest logs first; ties broken by insertion order (stable sort).
    # ``_naive`` shields the comparison from tz-aware/tz-naïve mixes
    # (Jira REST returns aware datetimes; URL/Artifactory fallbacks return
    # naïve ones — see :func:`_naive` docstring).
    logs_sorted = sorted(
        logs,
        key=lambda a: _naive(a.created),  # type: ignore[return-value]
        reverse=True,
    )

    for candidate_log in logs_sorted:
        ref_time = _naive(candidate_log.created)  # type: ignore[union-attr]
        assert ref_time is not None
        ref_day = ref_time.date()
        eligible = [
            v for v in videos
            if v.created.date() == ref_day  # type: ignore[union-attr]
            and abs(_naive(v.created) - ref_time) <= _VIDEO_LOG_MAX_GAP  # type: ignore[operator]
        ]
        if not eligible:
            continue
        chosen_video = min(
            eligible,
            key=lambda v: abs(_naive(v.created) - ref_time),  # type: ignore[operator]
        )
        kept = [candidate_log, chosen_video]
        kept_ids = {id(a) for a in kept}
        skipped = [a for a in items if id(a) not in kept_ids]
        log.info(
            "Attachment selection (confirmation): log=%s video=%s day=%s",
            candidate_log.filename,
            chosen_video.filename,
            ref_day.isoformat(),
        )
        return SelectionResult(
            kept=kept,
            skipped=skipped,
            latest_day=ref_day,
            needs_artifactory=False,
        )

    return SelectionResult(
        kept=[],
        skipped=list(items),
        latest_day=None,
        needs_artifactory=False,
    )


__all__ = [
    "SelectionResult",
    "pick_latest_batch",
    "select_log_first",
    "select_confirmation_pair",
]
