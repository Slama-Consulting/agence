"""URL handler for JFrog Artifactory repositories.

Artifactory exposes two URL families:

  * **UI tree**  – ``https://<host>/ui/repos/tree/General/<repo>/<path>``.
    What users paste in a ticket. HTML landing page, not downloadable.
  * **REST**     – ``https://<host>/api/storage/<repo>/<path>`` (list) and
    ``https://<host>/artifactory/<repo>/<path>`` (raw download).

This handler converts a UI URL (or a bare ``/artifactory/<repo>/<path>``
URL) into a REST listing, walks the tree, and downloads every file whose
extension is in our attachment whitelist.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any, Optional
from urllib.parse import unquote, urlparse, urlunparse

import requests

from ...utils.fs import ensure_dir, safe_filename
from .base import FetchedFile, URLHandler
from .credentials import CredentialProvider

log = logging.getLogger(__name__)


# Extensions we accept. Kept in sync with the simple URL fallback so the
# pipeline sees a consistent set of files no matter how they arrived.
# Images are intentionally excluded: screenshots in Artifactory are never
# useful for log analysis and bloat the download.
_ACCEPTED_EXTENSIONS: frozenset[str] = frozenset({
    ".zip", ".7z", ".rar", ".tar", ".gz", ".tgz", ".bz2", ".tbz2",
    ".mp4", ".mov", ".mkv", ".avi", ".webm",
    ".log", ".txt", ".logcat",
})


# ``/ui/repos/tree/General/<repo>/<path>`` or
# ``/ui/repos/tree/General/<repo>/<path>?…``.
_UI_TREE_RE = re.compile(
    r"^/ui/repos/tree/[^/]+/(?P<repo>[^/]+)/(?P<path>.*)$"
)

# Raw download paths look like ``/artifactory/<repo>/<path>`` or just
# ``/<repo>/<path>`` depending on the deployment (``/artifactory`` context
# root vs. root-mounted).
_ARTIFACTORY_PREFIX_RE = re.compile(r"^/artifactory/(?P<rest>.+)$")


class ArtifactoryHandler(URLHandler):
    """Walk an Artifactory folder recursively and pull every file in it."""

    name = "artifactory"

    def __init__(
        self,
        *,
        credentials_provider: Optional[CredentialProvider] = None,
        timeout: float = 30.0,
        max_files: int = 200,
        max_depth: int = 6,
    ) -> None:
        self._creds = credentials_provider
        self._timeout = timeout
        self._max_files = max_files
        self._max_depth = max_depth

    # ---- URLHandler ------------------------------------------------------

    def can_handle(self, url: str) -> bool:
        try:
            parsed = urlparse(url)
        except ValueError:
            return False
        if parsed.scheme not in {"http", "https"}:
            return False
        return "artifactory" in (parsed.netloc or "").lower()

    def fetch(
        self,
        url: str,
        dest_dir: Path,
        *,
        auth: Optional[tuple[str, str]] = None,
    ) -> list[FetchedFile]:
        ensure_dir(dest_dir)

        parsed = urlparse(url)
        host = parsed.netloc
        if self._creds is not None:
            resolved = self._creds.lookup(host)
            if resolved is not None:
                auth = resolved.as_basic_auth()

        api_base, repo, path = self._to_api_storage(url)
        if api_base is None:
            log.warning("Artifactory: cannot derive REST URL from %s", url)
            return []

        log.info(
            "Artifactory: walking %s/%s (max_files=%d, max_depth=%d)",
            repo, path, self._max_files, self._max_depth,
        )

        session = requests.Session()
        if auth is not None:
            session.auth = auth
        # Track the host so the credential refresh in ``_list`` can look
        # up fresh credentials once per fetch if Artifactory returns 401/403.
        session._bughound_host = host  # type: ignore[attr-defined]
        session._bughound_refreshed = False  # type: ignore[attr-defined]

        collected: list[FetchedFile] = []
        try:
            self._walk(
                session,
                api_base=api_base,
                repo=repo,
                path=path,
                dest_dir=dest_dir,
                depth=0,
                collected=collected,
            )
        finally:
            session.close()

        log.info("Artifactory: fetched %d file(s) from %s", len(collected), url)
        return collected

    # ---- internals -------------------------------------------------------

    @classmethod
    def _to_api_storage(
        cls, url: str,
    ) -> tuple[Optional[str], Optional[str], Optional[str]]:
        """Return ``(api_base, repo, path)`` for an Artifactory URL.

        ``api_base`` is the host + scheme (without trailing slash);
        ``repo`` is the top-level repository name and ``path`` is the
        sub-path within that repo (possibly empty). Returns ``(None,…)``
        if the URL is not understood.
        """
        try:
            parsed = urlparse(url)
        except ValueError:
            return None, None, None
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            return None, None, None

        api_base = urlunparse((parsed.scheme, parsed.netloc, "", "", "", ""))
        path = unquote(parsed.path or "/")

        # Case 1: UI URL.
        m = _UI_TREE_RE.match(path)
        if m:
            return api_base, m.group("repo"), m.group("path").strip("/")

        # Case 2: ``/artifactory/<repo>/<rest>``.
        m = _ARTIFACTORY_PREFIX_RE.match(path)
        if m:
            parts = m.group("rest").split("/", 1)
            repo = parts[0]
            rest = parts[1] if len(parts) > 1 else ""
            return api_base, repo, rest

        # Case 3: root-mounted ``/<repo>/<rest>``.
        stripped = path.strip("/")
        if stripped:
            parts = stripped.split("/", 1)
            repo = parts[0]
            rest = parts[1] if len(parts) > 1 else ""
            return api_base, repo, rest

        return None, None, None

    def _walk(
        self,
        session: requests.Session,
        *,
        api_base: str,
        repo: str,
        path: str,
        dest_dir: Path,
        depth: int,
        collected: list[FetchedFile],
    ) -> None:
        if depth > self._max_depth:
            log.warning(
                "Artifactory: max depth %d reached at %s/%s",
                self._max_depth, repo, path,
            )
            return
        if len(collected) >= self._max_files:
            return

        listing = self._list(session, api_base, repo, path)
        if listing is None:
            return

        children = listing.get("children") or []
        if not children:
            # Maybe the URL pointed directly at a file — try a download.
            uri = listing.get("downloadUri")
            if uri and _accepted_suffix(uri):
                self._download_file(session, uri, dest_dir, collected)
            return

        for child in children:
            if len(collected) >= self._max_files:
                log.warning(
                    "Artifactory: stopped after %d files (max_files cap)",
                    self._max_files,
                )
                return
            child_uri = str(child.get("uri") or "").lstrip("/")
            if not child_uri:
                continue
            sub_path = f"{path}/{child_uri}".strip("/")
            if child.get("folder"):
                self._walk(
                    session,
                    api_base=api_base,
                    repo=repo,
                    path=sub_path,
                    dest_dir=dest_dir,
                    depth=depth + 1,
                    collected=collected,
                )
                continue
            if not _accepted_suffix(child_uri):
                log.debug("Artifactory: skipping non-whitelisted %s", child_uri)
                continue
            # Fetch file metadata so we get the canonical downloadUri.
            file_info = self._list(session, api_base, repo, sub_path)
            download_uri = (file_info or {}).get("downloadUri")
            if not download_uri:
                # Fall back to the conventional download URL.
                download_uri = (
                    f"{api_base}/artifactory/{repo}/{sub_path}"
                )
            self._download_file(session, download_uri, dest_dir, collected)

    def _list(
        self,
        session: requests.Session,
        api_base: str,
        repo: str,
        path: str,
    ) -> Optional[dict[str, Any]]:
        suffix = f"/{path}" if path else ""
        url = f"{api_base}/artifactory/api/storage/{repo}{suffix}"
        try:
            resp = session.get(
                url,
                headers={"Accept": "application/json"},
                timeout=self._timeout,
            )
        except requests.RequestException as exc:
            log.warning("Artifactory: list failed for %s (%s)", url, exc)
            return None
        if resp.status_code == 404:
            log.warning("Artifactory: not found %s", url)
            return None
        # 401/403: credentials are missing, expired, or scoped to another
        # repo. Try once to refresh from the credential provider (e.g.
        # re-read ``~/.gradle/gradle.properties``) and re-issue the request.
        if resp.status_code in (401, 403) and self._creds is not None:
            already_refreshed = bool(
                getattr(session, "_bughound_refreshed", False)
            )
            host = getattr(session, "_bughound_host", None)
            if not already_refreshed and host:
                session._bughound_refreshed = True  # type: ignore[attr-defined]
                # ``CredentialProvider.lookup`` re-reads disk-backed
                # providers (dotenv / gradle.properties) on every call, so
                # a second invocation picks up creds that were updated
                # in-between — no dedicated ``force_refresh`` kwarg needed.
                refreshed = self._creds.lookup(host)
                if refreshed is not None:
                    session.auth = refreshed.as_basic_auth()
                    log.info(
                        "Artifactory: HTTP %d on %s, retrying with refreshed "
                        "credentials for %s",
                        resp.status_code, url, host,
                    )
                    try:
                        resp = session.get(
                            url,
                            headers={"Accept": "application/json"},
                            timeout=self._timeout,
                        )
                    except requests.RequestException as exc:
                        log.warning(
                            "Artifactory: retry list failed for %s (%s)",
                            url, exc,
                        )
                        return None
        if not resp.ok:
            log.warning(
                "Artifactory: list returned HTTP %d for %s",
                resp.status_code, url,
            )
            return None
        try:
            return resp.json()
        except ValueError:
            log.warning("Artifactory: non-JSON response at %s", url)
            return None

    def _download_file(
        self,
        session: requests.Session,
        download_url: str,
        dest_dir: Path,
        collected: list[FetchedFile],
    ) -> None:
        name = _safe_name_from_url(download_url)
        if name is None:
            return
        # Avoid clobbering when two folders contain a file with the same
        # name by disambiguating with a numeric suffix.
        target = dest_dir / name
        counter = 1
        while target.exists():
            stem = Path(name).stem
            suffix = Path(name).suffix
            target = dest_dir / f"{stem}_{counter}{suffix}"
            counter += 1

        try:
            with session.get(
                download_url, stream=True, timeout=self._timeout,
            ) as resp:
                resp.raise_for_status()
                with target.open("wb") as fh:
                    for chunk in resp.iter_content(chunk_size=64 * 1024):
                        if chunk:
                            fh.write(chunk)
        except requests.RequestException as exc:
            log.warning(
                "Artifactory: download failed for %s (%s)", download_url, exc,
            )
            if target.exists():
                try:
                    target.unlink()
                except OSError:
                    pass
            return

        collected.append(
            FetchedFile(
                path=target,
                source_url=download_url,
                relative_name=target.name,
            )
        )


def _accepted_suffix(url_or_name: str) -> bool:
    name = url_or_name.rsplit("/", 1)[-1]
    suffix = Path(name).suffix.lower()
    return suffix in _ACCEPTED_EXTENSIONS


def _safe_name_from_url(url: str) -> Optional[str]:
    try:
        parsed = urlparse(url)
    except ValueError:
        return None
    name = unquote(Path(parsed.path).name).strip()
    if not name:
        return None
    if not _accepted_suffix(name):
        return None
    return safe_filename(name)


__all__ = ["ArtifactoryHandler"]
