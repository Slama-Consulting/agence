"""Factory for building a :class:`HandlerRegistry` with default handlers."""

from __future__ import annotations

from typing import Iterable

from .artifactory import ArtifactoryHandler
from .credentials import ConfiguredHostEntry, build_default_provider
from .registry import HandlerRegistry


def build_default_registry(
    *,
    artifactory_entries: Iterable[ConfiguredHostEntry] = (),
) -> HandlerRegistry:
    """Build a :class:`HandlerRegistry` pre-loaded with the default handlers.

    The Artifactory handler is wired with a credential chain that covers:
    env vars → ``~/.bughound/.env`` → explicit config entries → gradle.properties.

    Args:
        artifactory_entries: Host entries from the ``artifactory.hosts`` YAML
            block. Each entry can target a specific host or a glob pattern.
    """
    provider = build_default_provider(config_entries=artifactory_entries)
    registry = HandlerRegistry()
    registry.register(ArtifactoryHandler(credentials_provider=provider))
    return registry


__all__ = ["build_default_registry"]
