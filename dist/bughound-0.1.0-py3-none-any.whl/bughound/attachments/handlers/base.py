"""Abstract base for URL handlers used by the attachment fallback path."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass(frozen=True)
class FetchedFile:
    """One concrete file downloaded by a handler.

    ``source_url`` is the *leaf* URL we actually fetched (not necessarily
    the URL we were given — handlers walking a tree return one entry per
    file). ``relative_name`` is a human-readable label used later as the
    synthetic :class:`Attachment` filename.
    """

    path: Path
    source_url: str
    relative_name: str


class URLHandler(ABC):
    """A host-specific strategy for turning a URL into files on disk.

    Handlers are expected to be stateless: they receive everything they
    need (auth, destination dir) from the caller. The registry picks the
    first handler whose :meth:`can_handle` returns ``True`` for a URL.
    """

    #: Short identifier used in logs and synthetic attachment IDs.
    name: str = "generic"

    @abstractmethod
    def can_handle(self, url: str) -> bool:
        """Return ``True`` if this handler knows how to fetch ``url``."""

    @abstractmethod
    def fetch(
        self,
        url: str,
        dest_dir: Path,
        *,
        auth: Optional[tuple[str, str]] = None,
    ) -> list[FetchedFile]:
        """Download every file reachable from ``url`` into ``dest_dir``.

        Implementations should:
          * create ``dest_dir`` if missing,
          * skip files whose extension is not worth ingesting,
          * raise (or return an empty list) on failure — the caller logs
            and moves on to the next URL.
        """


__all__ = ["FetchedFile", "URLHandler"]
