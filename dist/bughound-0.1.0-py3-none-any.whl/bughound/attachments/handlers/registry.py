"""Registry that picks the right :class:`URLHandler` for a given URL."""

from __future__ import annotations

import logging
from typing import Iterable, Optional

from .base import URLHandler

log = logging.getLogger(__name__)


class HandlerRegistry:
    """Ordered collection of handlers.

    First-match-wins: handlers are queried in registration order, so the
    most specific ones (Artifactory, Nexus…) should be registered before
    any generic catch-all.
    """

    def __init__(self, handlers: Optional[Iterable[URLHandler]] = None) -> None:
        self._handlers: list[URLHandler] = list(handlers or [])

    def register(self, handler: URLHandler) -> None:
        """Append ``handler`` to the registry."""
        self._handlers.append(handler)
        log.debug("Registered URL handler %r", handler.name)

    def resolve(self, url: str) -> Optional[URLHandler]:
        """Return the first handler that claims ``url``, or ``None``."""
        for handler in self._handlers:
            try:
                if handler.can_handle(url):
                    return handler
            except Exception as exc:  # pragma: no cover - defensive
                log.warning(
                    "Handler %r raised while checking %s: %s",
                    handler.name, url, exc,
                )
        return None

    def __iter__(self):
        return iter(self._handlers)

    def __len__(self) -> int:
        return len(self._handlers)


# Lazy import to avoid a circular dependency at module import time.
def _build_default_registry() -> HandlerRegistry:
    from .artifactory import ArtifactoryHandler
    from .credentials import build_default_provider
    provider = build_default_provider()
    return HandlerRegistry([ArtifactoryHandler(credentials_provider=provider)])


#: Shared registry used by :class:`AttachmentManager`. Tests and advanced
#: callers can build their own instance instead of mutating this one.
default_registry: HandlerRegistry = _build_default_registry()


__all__ = ["HandlerRegistry", "default_registry"]
