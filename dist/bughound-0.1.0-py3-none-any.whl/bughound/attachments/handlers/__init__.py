"""Pluggable URL handlers for fetching attachments from file servers.

When a Jira ticket has no native attachments but points at an external
file host (Artifactory, Nexus, SharePoint, a web drop folder…), BugHound
delegates the fetch to a host-specific handler. Handlers know how to:

  * recognize their own URLs via :meth:`URLHandler.can_handle`,
  * list / download files via :meth:`URLHandler.fetch`,

and are registered in :data:`default_registry` at import time so the
pipeline picks them up without explicit wiring.
"""

from .artifactory import ArtifactoryHandler
from .base import FetchedFile, URLHandler
from .credentials import ConfiguredHostEntry
from .factory import build_default_registry
from .registry import HandlerRegistry, default_registry

__all__ = [
    "ArtifactoryHandler",
    "ConfiguredHostEntry",
    "FetchedFile",
    "HandlerRegistry",
    "URLHandler",
    "build_default_registry",
    "default_registry",
]
