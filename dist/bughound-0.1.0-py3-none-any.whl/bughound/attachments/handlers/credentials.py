"""Credential resolution for URL handlers (Artifactory, …).

Looks for host-specific Basic-auth ``(user, token)`` pairs across several
sources in a well-defined order. Each source is independent so missing or
malformed files are skipped without aborting the chain.

Resolution order (first hit wins):
    1. Process environment: ``ARTIFACTORY_USER`` + ``ARTIFACTORY_TOKEN``
       (plus legacy aliases ``ARTIFACTORY_DT_USERNAME`` /
       ``ARTIFACTORY_DT_PASSWORD``).
    2. A dotenv file at ``~/.bughound/.env`` loaded with the same keys.
    3. Explicit entries passed from the YAML config (``artifactory.hosts``),
       which can target a specific hostname.
    4. ``~/.gradle/gradle.properties`` as a best-effort fallback
       (recognises Renault's ``ARTIFACTORY_DT_*`` / ``ARTIFACTORY_ALLIANCE_*``
       conventions).

``ArtifactoryCredentials`` instances are returned with both the raw tuple
and the host they were matched against, so callers can audit-log which
source supplied the secret without printing the secret itself.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class ArtifactoryCredentials:
    """Resolved username / token pair with provenance metadata."""

    user: str
    token: str
    source: str           # "env", "dotenv", "config", "gradle", …
    host_pattern: str     # "*" for global, or a hostname pattern

    def as_basic_auth(self) -> tuple[str, str]:
        return (self.user, self.token)


def _host_matches(pattern: str, host: str) -> bool:
    """Return ``True`` when ``host`` satisfies ``pattern``.

    ``*`` matches anything. A literal hostname matches exactly. A pattern
    starting with ``*.`` matches any subdomain of the given root.
    """
    if pattern == "*":
        return True
    if pattern == host:
        return True
    if pattern.startswith("*."):
        return host.endswith(pattern[1:])
    return False


class CredentialProvider:
    """Abstract provider returning credentials for a given host (or ``None``)."""

    source: str = "generic"

    def lookup(self, host: str) -> Optional[ArtifactoryCredentials]:
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Individual providers
# ---------------------------------------------------------------------------


_ENV_USER_KEYS = ("ARTIFACTORY_USER", "ARTIFACTORY_DT_USERNAME")
_ENV_TOKEN_KEYS = ("ARTIFACTORY_TOKEN", "ARTIFACTORY_DT_PASSWORD")


def _first_set(mapping: dict[str, str], keys: Iterable[str]) -> Optional[str]:
    for key in keys:
        value = mapping.get(key)
        if value:
            return value
    return None


class EnvProvider(CredentialProvider):
    """Read credentials from an environment-like mapping."""

    source = "env"

    def __init__(self, env: Optional[dict[str, str]] = None) -> None:
        self._env = dict(env) if env is not None else dict(os.environ)

    def lookup(self, host: str) -> Optional[ArtifactoryCredentials]:
        user = _first_set(self._env, _ENV_USER_KEYS)
        token = _first_set(self._env, _ENV_TOKEN_KEYS)
        if user and token:
            return ArtifactoryCredentials(
                user=user, token=token, source=self.source, host_pattern="*",
            )
        return None


class DotenvProvider(CredentialProvider):
    """Read credentials from a simple ``KEY=VALUE`` dotenv file.

    We parse ourselves — no hard dependency on ``python-dotenv`` — because
    the file only needs very limited shell-like syntax.
    """

    source = "dotenv"

    def __init__(self, path: Path) -> None:
        self._path = path

    def lookup(self, host: str) -> Optional[ArtifactoryCredentials]:
        if not self._path.is_file():
            return None
        try:
            parsed = _parse_env_file(self._path)
        except OSError as exc:
            log.debug("Could not read %s: %s", self._path, exc)
            return None
        user = _first_set(parsed, _ENV_USER_KEYS)
        token = _first_set(parsed, _ENV_TOKEN_KEYS)
        if user and token:
            return ArtifactoryCredentials(
                user=user, token=token, source=self.source, host_pattern="*",
            )
        return None


@dataclass(frozen=True)
class ConfiguredHostEntry:
    """One entry from the YAML ``artifactory.hosts`` list."""

    host: str            # hostname or glob pattern
    user: str
    token: str


class ConfigProvider(CredentialProvider):
    """Credentials declared explicitly in ``config.yaml``."""

    source = "config"

    def __init__(self, entries: Iterable[ConfiguredHostEntry]) -> None:
        self._entries = list(entries)

    def lookup(self, host: str) -> Optional[ArtifactoryCredentials]:
        for entry in self._entries:
            if _host_matches(entry.host, host):
                return ArtifactoryCredentials(
                    user=entry.user,
                    token=entry.token,
                    source=self.source,
                    host_pattern=entry.host,
                )
        return None


# Mapping from ``gradle.properties`` prefix to the host pattern it unlocks.
# Only well-known Renault prefixes are recognised to avoid leaking random
# Gradle secrets to unrelated hosts.
_GRADLE_PREFIX_HOSTS: tuple[tuple[str, str], ...] = (
    ("ARTIFACTORY_DT_", "artifactory.dt.renault.com"),
    ("ARTIFACTORY_ALLIANCE_", "*.renault.com"),
)


class GradlePropertiesProvider(CredentialProvider):
    """Fallback reader for ``~/.gradle/gradle.properties``.

    Recognises paired keys such as ``ARTIFACTORY_DT_USERNAME`` +
    ``ARTIFACTORY_DT_PASSWORD`` and maps them to the corresponding host
    pattern from :data:`_GRADLE_PREFIX_HOSTS`.
    """

    source = "gradle"

    def __init__(self, path: Path) -> None:
        self._path = path

    def lookup(self, host: str) -> Optional[ArtifactoryCredentials]:
        if not self._path.is_file():
            return None
        try:
            parsed = _parse_env_file(self._path)
        except OSError as exc:
            log.debug("Could not read %s: %s", self._path, exc)
            return None
        for prefix, pattern in _GRADLE_PREFIX_HOSTS:
            if not _host_matches(pattern, host):
                continue
            user = (
                parsed.get(f"{prefix}USERNAME")
                or parsed.get(f"{prefix}USER")
                or parsed.get(f"{prefix}IPN")
            )
            token = (
                parsed.get(f"{prefix}PASSWORD")
                or parsed.get(f"{prefix}TOKEN")
                or parsed.get(f"{prefix}APIKEY")
            )
            if user and token:
                return ArtifactoryCredentials(
                    user=user, token=token,
                    source=self.source, host_pattern=pattern,
                )
        return None


# ---------------------------------------------------------------------------
# Chain
# ---------------------------------------------------------------------------


class ChainCredentialProvider(CredentialProvider):
    """Ask each configured provider in order; return the first hit."""

    source = "chain"

    def __init__(self, providers: Iterable[CredentialProvider]) -> None:
        self._providers: list[CredentialProvider] = list(providers)

    def lookup(self, host: str) -> Optional[ArtifactoryCredentials]:
        for provider in self._providers:
            try:
                found = provider.lookup(host)
            except Exception as exc:  # pragma: no cover - defensive
                log.warning(
                    "Credential provider %s raised for host %s: %s",
                    provider.source, host, exc,
                )
                continue
            if found is not None:
                log.info(
                    "Artifactory credentials for %s resolved from %s "
                    "(host pattern %r).",
                    host, found.source, found.host_pattern,
                )
                return found
        log.info("No Artifactory credentials available for host %s", host)
        return None


def build_default_provider(
    *,
    env: Optional[dict[str, str]] = None,
    dotenv_path: Optional[Path] = None,
    gradle_properties_path: Optional[Path] = None,
    config_entries: Optional[Iterable[ConfiguredHostEntry]] = None,
) -> ChainCredentialProvider:
    """Assemble the default env → dotenv → config → gradle chain."""
    dotenv = dotenv_path or Path.home() / ".bughound" / ".env"
    gradle = gradle_properties_path or Path.home() / ".gradle" / "gradle.properties"
    return ChainCredentialProvider([
        EnvProvider(env=env),
        DotenvProvider(dotenv),
        ConfigProvider(config_entries or []),
        GradlePropertiesProvider(gradle),
    ])


# ---------------------------------------------------------------------------
# Shared parsing helper
# ---------------------------------------------------------------------------


# Matches ``KEY=VALUE`` lines. Supports optional whitespace around ``=`` so
# both dotenv and gradle.properties are parsed with the same routine.
_ENV_LINE_RE = re.compile(
    r"""
    ^\s*
    (?:export\s+)?             # ``export`` prefix tolerated for dotenvs
    (?P<key>[A-Za-z_][A-Za-z0-9_.]*)
    \s*=\s*
    (?P<value>.*?)
    \s*$
    """,
    re.VERBOSE,
)


def _parse_env_file(path: Path) -> dict[str, str]:
    """Return a ``dict`` of key/value pairs from a dotenv-like file.

    * Ignores comment lines (``#``) and blank lines.
    * Strips a single pair of surrounding quotes on the value.
    """
    out: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith("!"):
            continue
        match = _ENV_LINE_RE.match(line)
        if match is None:
            continue
        value = match.group("value")
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        out[match.group("key")] = value
    return out


__all__ = [
    "ArtifactoryCredentials",
    "ChainCredentialProvider",
    "ConfigProvider",
    "ConfiguredHostEntry",
    "CredentialProvider",
    "DotenvProvider",
    "EnvProvider",
    "GradlePropertiesProvider",
    "build_default_provider",
]
