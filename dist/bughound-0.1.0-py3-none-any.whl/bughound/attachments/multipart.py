"""Detect and reassemble multi-part archive families.

Users often upload large dumps split across several files. BugHound
recognises four common schemes and reassembles them before extraction:

- ``foo.zip.001 / foo.zip.002 / foo.zip.003`` — byte-level split ZIP.
  Reassembled by concatenation; the result is a normal ``.zip``.
- ``foo.z01 / foo.z02 / foo.zip`` — WinZip / 7-Zip spanned ZIP.
  Concatenation: ``z01 + z02 + ... + zip``.
- ``foo.part1.rar / foo.part2.rar`` — RAR multi-volume. Kept as-is;
  unrar reads every volume from disk when given the first one.
- ``foo.7z.001 / foo.7z.002`` — 7-Zip split archives. Reassembled by
  concatenation, same as split ZIP.

Each scheme yields a :class:`MultipartArchive` that names the logical
archive and lists its parts in the right order. Incomplete families
(a ``.002`` without a ``.001``) are dropped with a warning — partial
archives can't be extracted reliably.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Iterable

log = logging.getLogger(__name__)


class MultipartScheme(str, Enum):
    """Which naming convention a multi-part family uses."""

    SPLIT_ZIP = "split_zip"       # foo.zip.001, foo.zip.002 …
    SPANNED_ZIP = "spanned_zip"   # foo.z01, foo.z02, foo.zip
    SPLIT_7Z = "split_7z"         # foo.7z.001, foo.7z.002 …
    MULTI_RAR = "multi_rar"       # foo.part1.rar, foo.part2.rar …


@dataclass(frozen=True)
class MultipartArchive:
    """A logical archive made of several on-disk parts.

    ``parts`` is the ordered list of files (first volume first).
    ``reassembled_name`` is the filename the joined archive should take
    (``foo.zip`` for split/spanned ZIP, ``foo.7z`` for 7z, unused for
    RAR which reads volumes directly).
    """

    scheme: MultipartScheme
    stem: str
    parts: list[Path]
    reassembled_name: str


# ---------------------------------------------------------------------------
# Pattern matchers
# ---------------------------------------------------------------------------

# foo.zip.001, foo.zip.042
_SPLIT_ZIP = re.compile(r"^(?P<stem>.+?)\.zip\.(?P<num>\d{3,})$", re.IGNORECASE)
# foo.7z.001
_SPLIT_7Z = re.compile(r"^(?P<stem>.+?)\.7z\.(?P<num>\d{3,})$", re.IGNORECASE)
# foo.z01, foo.z02
_SPANNED_MIDDLE = re.compile(r"^(?P<stem>.+?)\.z(?P<num>\d{2,})$", re.IGNORECASE)
# foo.zip (last piece of a spanned family)
_SPANNED_LAST = re.compile(r"^(?P<stem>.+?)\.zip$", re.IGNORECASE)
# foo.part1.rar, foo.part02.rar
_MULTI_RAR = re.compile(r"^(?P<stem>.+?)\.part(?P<num>\d+)\.rar$", re.IGNORECASE)


def detect_multipart(files: Iterable[Path]) -> tuple[list[MultipartArchive], set[Path]]:
    """Group ``files`` into multi-part families.

    Returns ``(families, claimed_paths)`` where ``claimed_paths`` is the
    set of files that belong to at least one detected family — the caller
    can skip those when processing the remaining single-file attachments.
    """
    file_list = [p for p in files]
    by_name = {p.name: p for p in file_list}
    families: list[MultipartArchive] = []
    claimed: set[Path] = set()

    # --- split ZIP / split 7z : group by stem + extension
    for pattern, scheme, final_ext in (
        (_SPLIT_ZIP, MultipartScheme.SPLIT_ZIP, "zip"),
        (_SPLIT_7Z, MultipartScheme.SPLIT_7Z, "7z"),
    ):
        grouped: dict[str, list[tuple[int, Path]]] = {}
        for path in file_list:
            if path in claimed:
                continue
            m = pattern.match(path.name)
            if not m:
                continue
            grouped.setdefault(m["stem"], []).append((int(m["num"]), path))
        for stem, items in grouped.items():
            items.sort(key=lambda it: it[0])
            nums = [n for n, _ in items]
            if nums[0] != 1:
                log.warning(
                    "Multipart %s family %r missing first volume (have %s); skipping.",
                    scheme.value, stem, nums,
                )
                continue
            if any(b - a != 1 for a, b in zip(nums, nums[1:])):
                log.warning(
                    "Multipart %s family %r has gaps in %s; skipping.",
                    scheme.value, stem, nums,
                )
                continue
            parts = [p for _, p in items]
            claimed.update(parts)
            families.append(
                MultipartArchive(
                    scheme=scheme,
                    stem=stem,
                    parts=parts,
                    reassembled_name=f"{stem}.{final_ext}",
                )
            )

    # --- spanned ZIP : .z01..z(N) + .zip  (the final .zip is mandatory)
    spanned_groups: dict[str, list[tuple[int, Path]]] = {}
    for path in file_list:
        if path in claimed:
            continue
        m = _SPANNED_MIDDLE.match(path.name)
        if not m:
            continue
        spanned_groups.setdefault(m["stem"], []).append((int(m["num"]), path))
    for stem, items in spanned_groups.items():
        last_name = f"{stem}.zip"
        last_path = by_name.get(last_name)
        if last_path is None or last_path in claimed:
            log.warning(
                "Spanned ZIP family %r is missing its final '.zip' volume; skipping.",
                stem,
            )
            continue
        items.sort(key=lambda it: it[0])
        nums = [n for n, _ in items]
        if nums[0] != 1 or any(b - a != 1 for a, b in zip(nums, nums[1:])):
            log.warning(
                "Spanned ZIP family %r has gaps in %s; skipping.",
                stem, nums,
            )
            continue
        parts = [p for _, p in items] + [last_path]
        claimed.update(parts)
        families.append(
            MultipartArchive(
                scheme=MultipartScheme.SPANNED_ZIP,
                stem=stem,
                parts=parts,
                reassembled_name=f"{stem}.zip",
            )
        )

    # --- multi-volume RAR : part1.rar, part2.rar, … (unrar reads them from disk)
    rar_groups: dict[str, list[tuple[int, Path]]] = {}
    for path in file_list:
        if path in claimed:
            continue
        m = _MULTI_RAR.match(path.name)
        if not m:
            continue
        rar_groups.setdefault(m["stem"], []).append((int(m["num"]), path))
    for stem, items in rar_groups.items():
        items.sort(key=lambda it: it[0])
        nums = [n for n, _ in items]
        if nums[0] != 1 or any(b - a != 1 for a, b in zip(nums, nums[1:])):
            log.warning(
                "Multi-part RAR family %r has gaps in %s; skipping.",
                stem, nums,
            )
            continue
        parts = [p for _, p in items]
        claimed.update(parts)
        families.append(
            MultipartArchive(
                scheme=MultipartScheme.MULTI_RAR,
                stem=stem,
                parts=parts,
                reassembled_name=parts[0].name,  # unrar uses the first volume
            )
        )

    return families, claimed


# ---------------------------------------------------------------------------
# Reassembly
# ---------------------------------------------------------------------------


def reassemble(family: MultipartArchive, dest_dir: Path) -> Path:
    """Join the parts of ``family`` into a single file under ``dest_dir``.

    For split ZIP / spanned ZIP / split 7z we concatenate bytes — that's
    exactly what those formats expect. For RAR we just point at the
    first volume; unrar reads the rest itself.
    """
    dest_dir.mkdir(parents=True, exist_ok=True)

    if family.scheme is MultipartScheme.MULTI_RAR:
        # unrar reads every .partN.rar from the same directory as the
        # first volume, so we simply return the first volume's path.
        return family.parts[0]

    out_path = dest_dir / family.reassembled_name
    with out_path.open("wb") as dst:
        for part in family.parts:
            with part.open("rb") as src:
                while True:
                    chunk = src.read(1024 * 1024)
                    if not chunk:
                        break
                    dst.write(chunk)
    log.info(
        "Reassembled %s family %r (%d part(s)) into %s",
        family.scheme.value, family.stem, len(family.parts), out_path,
    )
    return out_path


__all__ = [
    "MultipartScheme",
    "MultipartArchive",
    "detect_multipart",
    "reassemble",
]
