"""Fallback: harvest download URLs from a ticket's text fields.

When a Jira ticket has no attachments (the reporter dropped files on a file
server and only pasted a link), we scan the description + every comment body
for URLs that look like file downloads and fetch them with plain HTTP. The
downloaded files are then handed back to :class:`AttachmentManager` as if
they had been real Jira attachments, which means they go through the usual
classification + archive-extraction path without duplicating code.

The intent is pragmatic, not bullet-proof: we only accept ``http(s)://`` URLs
pointing at a file-looking path (extension in a whitelist or the URL ends
with a filename-ish segment). Share-page URLs (Google Drive viewer, Jira
confluence links, …) are skipped because they need auth or HTML parsing.
"""

from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Iterable, Optional
from urllib.parse import unquote, urlparse

import requests

from ..core.models import Attachment, Ticket
from ..utils.fs import ensure_dir, safe_filename

log = logging.getLogger(__name__)


# Extensions we consider worth downloading blindly from a raw link. Kept in
# sync with :mod:`bughound.attachments.kinds`' top-level mapping so the
# fallback can't fetch something we wouldn't know what to do with.
_ACCEPTED_EXTENSIONS: frozenset[str] = frozenset({
    # archives
    ".zip", ".7z", ".rar", ".tar", ".gz", ".tgz", ".bz2", ".tbz2",
    # videos
    ".mp4", ".mov", ".mkv", ".avi", ".webm",
    # logs / text
    ".log", ".txt", ".logcat",
    # images intentionally excluded: they are never useful for analysis
})


# Match bare URLs. We stop at common trailing punctuation that is almost
# never part of the URL itself (``.``, ``,``, ``)`` in prose, ``]`` in
# markdown, ``|`` in Jira wiki tables…).
_URL_RE = re.compile(
    r"""
    (?P<url>
        https?://               # scheme
        [^\s<>"'\[\]|]+         # body (no quotes/brackets/whitespace)
    )
    """,
    re.VERBOSE,
)


# Markdown: ``[label](url)`` — we just want the URL part.
_MD_LINK_RE = re.compile(r"\[[^\]]*\]\((?P<url>https?://[^\s)]+)\)")

# Jira wiki: ``[label|url]`` or ``[url]``.
_JIRA_LINK_RE = re.compile(r"\[(?:[^\]\|]*\|)?(?P<url>https?://[^\]\s]+)\]")


def extract_urls(text: str) -> list[str]:
    """Return every URL found in ``text`` in document order, de-duplicated."""
    if not text:
        return []

    seen: set[str] = set()
    out: list[str] = []

    for pattern in (_MD_LINK_RE, _JIRA_LINK_RE, _URL_RE):
        for match in pattern.finditer(text):
            url = match.group("url")
            # Trim trailing punctuation that almost always isn't part of the URL.
            url = url.rstrip(".,;:!?)")
            if url in seen:
                continue
            seen.add(url)
            out.append(url)

    return out


def _filename_from_url(url: str) -> Optional[str]:
    """Return a file name from a URL if its path ends with an accepted extension.

    URLs pointing at a viewer page or an HTML landing page are rejected.
    """
    try:
        parsed = urlparse(url)
    except ValueError:
        return None
    if parsed.scheme not in {"http", "https"}:
        return None

    name = unquote(Path(parsed.path).name).strip()
    if not name:
        return None
    suffix = Path(name).suffix.lower()
    if suffix not in _ACCEPTED_EXTENSIONS:
        return None
    return safe_filename(name)


def harvest_all_urls(ticket: Ticket) -> list[str]:
    """Return every URL found in the ticket's description.

    De-duplicated in document order. Unlike
    :func:`harvest_download_candidates`, this does *not* filter by file
    extension, so callers can offer the URL to host-specific handlers
    (Artifactory, …) before giving up.
    """
    urls: list[str] = []
    if ticket.description:
        urls = extract_urls(ticket.description)
    
    # De-duplicate while preserving order
    seen: set[str] = set()
    out: list[str] = []
    for url in urls:
        if url not in seen:
            seen.add(url)
            out.append(url)
    return out


def harvest_download_candidates(ticket: Ticket) -> list[tuple[str, str]]:
    """Scan the ticket's description for URLs that look like file downloads.

    Returns a list of ``(url, suggested_filename)`` pairs, de-duplicated
    in document order.
    """
    candidates: list[tuple[str, str]] = []
    for url in harvest_all_urls(ticket):
        filename = _filename_from_url(url)
        if filename is None:
            continue
        candidates.append((url, filename))
    return candidates


def download_url(
    url: str,
    dest_dir: Path,
    filename: str,
    *,
    session: Optional[requests.Session] = None,
    timeout: float = 30.0,
    chunk_size: int = 64 * 1024,
) -> Path:
    """Download ``url`` into ``dest_dir/filename`` using plain HTTP.

    Raises ``requests.HTTPError`` / ``requests.RequestException`` on failure
    so callers can log and move on.
    """
    ensure_dir(dest_dir)
    target = dest_dir / filename
    sess = session or requests
    with sess.get(url, stream=True, timeout=timeout) as resp:
        resp.raise_for_status()
        with target.open("wb") as fh:
            for chunk in resp.iter_content(chunk_size=chunk_size):
                if chunk:
                    fh.write(chunk)
    return target


def materialise_url_attachments(
    candidates: Iterable[tuple[str, str]],
    dest_dir: Path,
    *,
    session: Optional[requests.Session] = None,
    id_prefix: str = "url",
) -> list[tuple[Attachment, Path]]:
    """Download each candidate and build a synthetic :class:`Attachment` for it.

    Failures are logged and skipped; the returned list only contains the URLs
    that were actually fetched.
    """
    out: list[tuple[Attachment, Path]] = []
    for index, (url, filename) in enumerate(candidates):
        try:
            local_path = download_url(
                url, dest_dir, filename, session=session,
            )
        except Exception as exc:
            log.warning("URL fallback: failed to download %s (%s)", url, exc)
            continue
        attachment = Attachment(
            id=f"{id_prefix}-{index}",
            filename=filename,
            url=url,
            created=datetime.now(),
            local_path=local_path,
        )
        out.append((attachment, local_path))
    return out


__all__ = [
    "extract_urls",
    "harvest_all_urls",
    "harvest_download_candidates",
    "download_url",
    "materialise_url_attachments",
]
