"""Configuration loading for BugHound.

Loads a YAML config file, overlays environment variables (``JIRA_API_TOKEN``,
``LLM_API_KEY``) and returns a validated :class:`BugHoundConfig` object.

Environment variables win over the YAML — this lets users commit a template
``config.yaml`` without secrets.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Config schema
# ---------------------------------------------------------------------------


class JiraConfig(BaseModel):
    mode: str = "api"                          # "api", "scrape", or "browser"
    base_url: str
    email: Optional[str] = None
    api_token: Optional[str] = None
    # Browser-backed client (mode="browser") settings.
    browser_profile_dir: Optional[Path] = None
    browser_headless_after_login: bool = True
    # Project keys that may receive writes when --yes is passed. Empty
    # disables writes entirely, which is the default.
    write_allowed_projects: list[str] = Field(default_factory=list)


class LLMConfig(BaseModel):
    mode: str = "copilot"                      # "api" or "copilot"
    provider: Optional[str] = None             # "anthropic" or "openai"
    model: Optional[str] = None
    api_key: Optional[str] = None


class VideoConfig(BaseModel):
    tesseract_cmd: Optional[str] = None
    ocr_sample_interval_s: float = 1.0
    scene_change_threshold: float = 0.35


class LogsConfig(BaseModel):
    window_before_s: float = 10.0
    window_after_s: float = 5.0
    # Known timestamp formats (for reference; the parser owns the logic).
    timestamp_formats: list[str] = Field(default_factory=list)


class OutputConfig(BaseModel):
    workdir: Path = Path("~/.bughound/reports").expanduser()
    emit_json: bool = True


class ProjectsConfig(BaseModel):
    search_roots: list[Path] = Field(
        default_factory=lambda: [Path("~/AndroidStudioProjects").expanduser()]
    )
    match_strategy: str = "components-then-labels"  # reserved for future use
    fuzzy_threshold: float = 0.72
    interactive_fallback: bool = True


class ArtifactoryHostEntry(BaseModel):
    host: str    # e.g. "artifactory.dt.renault.com" or "*.renault.com"
    user: str
    token: str


class ArtifactoryConfig(BaseModel):
    hosts: list[ArtifactoryHostEntry] = Field(default_factory=list)


class BugHoundConfig(BaseModel):
    """Top-level configuration."""

    jira: JiraConfig
    llm: LLMConfig
    video: VideoConfig = Field(default_factory=VideoConfig)
    logs: LogsConfig = Field(default_factory=LogsConfig)
    output: OutputConfig = Field(default_factory=OutputConfig)
    projects: ProjectsConfig = Field(default_factory=ProjectsConfig)
    artifactory: ArtifactoryConfig = Field(default_factory=ArtifactoryConfig)


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------


def load_config(
    path: Path,
    *,
    env: Optional[dict[str, str]] = None,
) -> BugHoundConfig:
    """Load and validate a configuration file.

    Args:
        path: path to ``config.yaml``.
        env:  optional environment mapping. Defaults to ``os.environ``.

    Overlay order (last wins): YAML file < env vars.
    """
    env = dict(env) if env is not None else dict(os.environ)

    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}

    # Env overrides for secrets. We don't let the YAML win if the env is set,
    # so a user who rotates a token only edits .env.
    if "JIRA_API_TOKEN" in env and env["JIRA_API_TOKEN"]:
        data.setdefault("jira", {})["api_token"] = env["JIRA_API_TOKEN"]
    if "LLM_API_KEY" in env and env["LLM_API_KEY"]:
        data.setdefault("llm", {})["api_key"] = env["LLM_API_KEY"]

    return BugHoundConfig(**data)
