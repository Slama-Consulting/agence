"""Factory that builds the right LLM client from config."""

from __future__ import annotations

from typing import Optional

from .base import LLMClient
from .copilot import CopilotClient


def build_llm_client(
    *,
    mode: str,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
) -> LLMClient:
    """Instantiate the LLM client matching the requested mode.

    Args:
        mode:     "api" for a real provider call, "copilot" for interactive mode.
        provider: "anthropic" or "openai" when ``mode == 'api'``.
        model:    model identifier for the chosen provider.
        api_key:  provider API key.

    Returns:
        An :class:`LLMClient` instance.
    """
    mode_norm = mode.lower().strip()

    if mode_norm == "copilot":
        return CopilotClient()

    if mode_norm == "api":
        if not provider:
            raise ValueError("llm.provider is required when llm.mode == 'api'")
        if not model:
            raise ValueError("llm.model is required when llm.mode == 'api'")
        if not api_key:
            raise ValueError(
                "An API key is required when llm.mode == 'api'. "
                "Set LLM_API_KEY or llm.api_key in your config."
            )

        provider_norm = provider.lower().strip()
        if provider_norm == "anthropic":
            # Local import: keep optional deps out of the import graph for users
            # who never leave copilot mode.
            from .anthropic_client import AnthropicClient

            return AnthropicClient(api_key=api_key, model=model)

        if provider_norm == "openai":
            from .openai_client import OpenAIClient

            return OpenAIClient(api_key=api_key, model=model)

        raise ValueError(f"Unknown LLM provider: {provider!r}")

    raise ValueError(f"Unknown LLM mode: {mode!r} (expected 'api' or 'copilot')")
