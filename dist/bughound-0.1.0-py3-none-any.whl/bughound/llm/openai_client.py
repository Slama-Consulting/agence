"""OpenAI-backed LLM client."""

from __future__ import annotations

from typing import Optional

from .base import ChatMessage, LLMClient, LLMResponse


class OpenAIClient(LLMClient):
    """Thin wrapper around the official ``openai`` SDK (>=1.0)."""

    def __init__(self, *, api_key: str, model: str, max_tokens: int = 2048) -> None:
        try:
            from openai import OpenAI
        except ImportError as exc:  # pragma: no cover - env-dependent
            raise RuntimeError(
                "The `openai` package is required for LLM mode 'api' with "
                "provider 'openai'. Install it via `pip install openai`."
            ) from exc

        self._client = OpenAI(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    def complete_json(
        self,
        *,
        system: str,
        user: str,
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        full_user = user
        if schema_hint:
            full_user = (
                f"{user}\n\n"
                f"Respond ONLY with a JSON object matching this schema:\n{schema_hint}"
            )

        response = self._client.chat.completions.create(
            model=self._model,
            max_tokens=self._max_tokens,
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": full_user},
            ],
        )
        raw = response.choices[0].message.content or ""

        return LLMResponse(
            raw_text=raw,
            parsed=self._try_parse_json(raw),
            meta={
                "mode": "api",
                "provider": "openai",
                "model": self._model,
                "finish_reason": response.choices[0].finish_reason,
            },
        )

    def complete_conversation(
        self,
        *,
        system: str,
        messages: list[ChatMessage],
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        if not messages:
            raise ValueError("complete_conversation requires at least one message")
        if messages[-1].role != "user":
            raise ValueError(
                "complete_conversation requires the last message to come from the user"
            )

        api_messages: list[dict[str, str]] = [
            {"role": "system", "content": system}
        ]
        for idx, msg in enumerate(messages):
            content = msg.content
            if schema_hint and idx == len(messages) - 1:
                content = (
                    f"{content}\n\n"
                    f"Respond ONLY with a JSON object matching this schema:\n"
                    f"{schema_hint}"
                )
            api_messages.append({"role": msg.role, "content": content})

        response = self._client.chat.completions.create(
            model=self._model,
            max_tokens=self._max_tokens,
            response_format={"type": "json_object"},
            messages=api_messages,
        )
        raw = response.choices[0].message.content or ""

        return LLMResponse(
            raw_text=raw,
            parsed=self._try_parse_json(raw),
            meta={
                "mode": "api",
                "provider": "openai",
                "model": self._model,
                "finish_reason": response.choices[0].finish_reason,
                "turns": len(messages),
            },
        )
