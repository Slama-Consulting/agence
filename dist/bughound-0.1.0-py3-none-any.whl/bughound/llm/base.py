"""LLM client abstraction.

BugHound supports two execution modes:

1. ``api``     - fully autonomous. An API-backed client (Anthropic, OpenAI, ...)
                 answers prompts and the pipeline runs end-to-end.
2. ``copilot`` - no API key available. The client instead records the prompts
                 and hands them to the user to run through Copilot / Claude /
                 ChatGPT, then accepts the answer back.

Every client implements the same :meth:`LLMClient.complete_json` contract so
analyzers do not need to know which backend is in use.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Literal, Optional


@dataclass
class LLMResponse:
    """A structured response from an LLM call."""

    raw_text: str
    parsed: Optional[dict[str, Any]] = None
    # Free-form metadata (model name, token usage, prompt id in copilot mode...)
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class ChatMessage:
    """A single turn in a multi-turn conversation with an LLM.

    Only ``user`` and ``assistant`` roles are supported; the system prompt is
    passed out-of-band via :meth:`LLMClient.complete_conversation`.
    """

    role: Literal["user", "assistant"]
    content: str


class LLMClient(ABC):
    """Common interface for every LLM backend."""

    @abstractmethod
    def complete_json(
        self,
        *,
        system: str,
        user: str,
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        """Run a completion that is expected to return a JSON object.

        Implementations must:
          - pass ``system`` as the system / role instruction,
          - pass ``user`` as the user message,
          - if ``schema_hint`` is given, append it to the prompt so the model
            knows the expected JSON shape,
          - attempt to parse the answer as JSON and populate
            :attr:`LLMResponse.parsed`; if parsing fails, leave it as ``None``
            and keep the raw text so the caller can recover.
        """

    def complete_conversation(
        self,
        *,
        system: str,
        messages: list[ChatMessage],
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        """Run a multi-turn completion that is expected to return a JSON object.

        The default implementation serialises the full conversation history
        into a single ``user`` payload and delegates to :meth:`complete_json`,
        so every existing backend keeps working without changes. Backends that
        natively support multi-turn chat (Anthropic, OpenAI, ...) override this
        method to take advantage of the native API.

        Caller contract:
          - ``messages`` must contain at least one entry and end with a
            ``user`` turn (the latest question to the model),
          - the ``system`` instruction is passed separately, as in
            :meth:`complete_json`,
          - ``schema_hint``, when provided, is appended to the latest user
            turn (or to the serialised transcript, for the default impl).
        """
        if not messages:
            raise ValueError("complete_conversation requires at least one message")
        if messages[-1].role != "user":
            raise ValueError(
                "complete_conversation requires the last message to come from the user"
            )

        serialised = self._serialise_conversation(messages)
        return self.complete_json(
            system=system,
            user=serialised,
            schema_hint=schema_hint,
        )

    # ---- helpers shared by subclasses ------------------------------------

    @staticmethod
    def _serialise_conversation(messages: list[ChatMessage]) -> str:
        """Fallback serialisation for backends without native multi-turn.

        Produces a readable transcript the model can reason over even when
        passed as a single prompt. Used by the default implementation of
        :meth:`complete_conversation`.
        """
        lines: list[str] = []
        for msg in messages:
            tag = "USER" if msg.role == "user" else "ASSISTANT"
            lines.append(f"--- {tag} ---")
            lines.append(msg.content.rstrip())
        return "\n".join(lines)

    # ---- helpers shared by subclasses ------------------------------------

    @staticmethod
    def _try_parse_json(text: str) -> Optional[dict[str, Any]]:
        """Best-effort extraction of a JSON object from model output.

        Models often wrap JSON in prose or fences, so we look for the first
        balanced ``{...}`` block before giving up.
        """
        if not text:
            return None
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass

        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end == -1 or end <= start:
            return None
        candidate = text[start : end + 1]
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            return None
