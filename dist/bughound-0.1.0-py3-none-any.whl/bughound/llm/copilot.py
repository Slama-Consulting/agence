"""Copilot-assist LLM client.

Used when the user has no LLM API key. BugHound prints the prompts to stdout
(or a log file) and waits for the user to paste back the answer from Copilot,
Claude, ChatGPT, etc.

This keeps the pipeline fully usable offline while still letting an external
model do the reasoning.
"""

from __future__ import annotations

import sys
from typing import Optional, TextIO

from .base import ChatMessage, LLMClient, LLMResponse


class CopilotClient(LLMClient):
    """Interactive LLM client that delegates reasoning to a human + external LLM."""

    def __init__(
        self,
        *,
        prompt_out: TextIO = sys.stdout,
        answer_in: TextIO = sys.stdin,
    ) -> None:
        # Kept as attributes so tests can inject file-like objects.
        self._out = prompt_out
        self._in = answer_in
        self._prompt_counter = 0

    def complete_json(
        self,
        *,
        system: str,
        user: str,
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        self._prompt_counter += 1
        prompt_id = f"P{self._prompt_counter:03d}"

        banner = f"\n{'=' * 72}\n[BugHound] Copilot prompt {prompt_id}\n{'=' * 72}\n"
        full_user = user
        if schema_hint:
            full_user = (
                f"{user}\n\n"
                f"Respond ONLY with a JSON object matching this schema:\n{schema_hint}"
            )

        self._out.write(banner)
        self._out.write("--- SYSTEM ---\n")
        self._out.write(system.rstrip() + "\n")
        self._out.write("--- USER ---\n")
        self._out.write(full_user.rstrip() + "\n")
        self._out.write(
            "\n[BugHound] Paste the model answer below. "
            "End input with a line containing only `===END===`.\n"
        )
        self._out.flush()

        answer = self._read_until_sentinel("===END===")
        parsed = self._try_parse_json(answer)
        return LLMResponse(
            raw_text=answer,
            parsed=parsed,
            meta={"mode": "copilot", "prompt_id": prompt_id},
        )

    def complete_conversation(
        self,
        *,
        system: str,
        messages: list[ChatMessage],
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        if not messages:
            raise ValueError("complete_conversation requires at least one message")
        if messages[-1].role != "user":
            raise ValueError(
                "complete_conversation requires the last message to come from the user"
            )

        self._prompt_counter += 1
        prompt_id = f"P{self._prompt_counter:03d}"

        banner = (
            f"\n{'=' * 72}\n"
            f"[BugHound] Copilot prompt {prompt_id} "
            f"(conversation, {len(messages)} tour(s))\n"
            f"{'=' * 72}\n"
        )
        self._out.write(banner)
        self._out.write("--- SYSTEM ---\n")
        self._out.write(system.rstrip() + "\n")

        for idx, msg in enumerate(messages):
            tag = "USER" if msg.role == "user" else "ASSISTANT"
            content = msg.content
            if schema_hint and idx == len(messages) - 1 and msg.role == "user":
                content = (
                    f"{content}\n\n"
                    f"Respond ONLY with a JSON object matching this schema:\n"
                    f"{schema_hint}"
                )
            self._out.write(f"--- {tag} ---\n")
            self._out.write(content.rstrip() + "\n")

        self._out.write(
            "\n[BugHound] Paste the model answer below. "
            "End input with a line containing only `===END===`.\n"
        )
        self._out.flush()

        answer = self._read_until_sentinel("===END===")
        parsed = self._try_parse_json(answer)
        return LLMResponse(
            raw_text=answer,
            parsed=parsed,
            meta={
                "mode": "copilot",
                "prompt_id": prompt_id,
                "turns": len(messages),
            },
        )

    def _read_until_sentinel(self, sentinel: str) -> str:
        lines: list[str] = []
        for line in self._in:
            if line.rstrip("\n") == sentinel:
                break
            lines.append(line)
        return "".join(lines).strip()
