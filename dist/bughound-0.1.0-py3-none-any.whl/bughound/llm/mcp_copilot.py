"""MCP-aware copilot LLM client.

The regular :class:`~bughound.llm.copilot.CopilotClient` prints prompts to
stdout and reads answers from stdin. That works from a terminal but is
*broken* when the pipeline runs behind an MCP stdio transport: stdin and
stdout are already claimed by the JSON-RPC framing, so every printed line
corrupts the channel and every ``input()`` call blocks forever.

``MCPCopilotClient`` solves this by exposing the same contract as
:class:`CopilotClient` but routing the prompt to the chat UI (via
``ctx.info``) and reading the answer via an elicitation callback. The
caller is responsible for wiring those two callbacks — typically from
the FastMCP tool handler where the request ``Context`` is available.
"""

from __future__ import annotations

from typing import Callable, Optional

from .base import ChatMessage, LLMClient, LLMResponse


#: Signature for the "push text to the chat" side. Expected to be a
#: blocking function (we run the LLM call from a worker thread).
InfoCallback = Callable[[str], None]

#: Signature for the "ask the user for the model answer" side. Must
#: return the answer as a string, or ``None`` if the user cancelled /
#: gave an empty response.
ElicitCallback = Callable[[str], Optional[str]]


class MCPCopilotClient(LLMClient):
    """Copilot client whose prompts and answers flow through MCP callbacks."""

    def __init__(
        self,
        *,
        info: InfoCallback,
        elicit: ElicitCallback,
    ) -> None:
        self._info = info
        self._elicit = elicit
        self._prompt_counter = 0

    def complete_json(
        self,
        *,
        system: str,
        user: str,
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        self._prompt_counter += 1
        prompt_id = f"P{self._prompt_counter:03d}"

        full_user = user
        if schema_hint:
            full_user = (
                f"{user}\n\n"
                f"Respond ONLY with a JSON object matching this schema:\n"
                f"{schema_hint}"
            )

        # Surface the full prompt in the chat so the user can copy it
        # into Copilot / ChatGPT / Claude and paste the answer back.
        pretty = (
            f"[BugHound] Prompt copilot {prompt_id} — copie-le dans ton LLM "
            f"de choix, puis colle la réponse JSON dans la fenêtre de "
            f"saisie.\n\n"
            f"--- SYSTEM ---\n{system.rstrip()}\n\n"
            f"--- USER ---\n{full_user.rstrip()}"
        )
        try:
            self._info(pretty)
        except Exception:  # pragma: no cover - UI glitches mustn't break the run
            pass

        question = (
            f"Réponse du modèle pour le prompt {prompt_id} (JSON brut) ?"
        )
        answer = self._elicit(question)
        if answer is None:
            answer = ""

        parsed = self._try_parse_json(answer)
        return LLMResponse(
            raw_text=answer,
            parsed=parsed,
            meta={"mode": "mcp-copilot", "prompt_id": prompt_id},
        )

    def complete_conversation(
        self,
        *,
        system: str,
        messages: list[ChatMessage],
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        if not messages:
            raise ValueError("complete_conversation requires at least one message")
        if messages[-1].role != "user":
            raise ValueError(
                "complete_conversation requires the last message to come from the user"
            )

        self._prompt_counter += 1
        prompt_id = f"P{self._prompt_counter:03d}"

        transcript_lines: list[str] = []
        for idx, msg in enumerate(messages):
            tag = "USER" if msg.role == "user" else "ASSISTANT"
            content = msg.content
            if schema_hint and idx == len(messages) - 1 and msg.role == "user":
                content = (
                    f"{content}\n\n"
                    f"Respond ONLY with a JSON object matching this schema:\n"
                    f"{schema_hint}"
                )
            transcript_lines.append(f"--- {tag} ---\n{content.rstrip()}")
        transcript = "\n\n".join(transcript_lines)

        pretty = (
            f"[BugHound] Prompt copilot {prompt_id} — conversation "
            f"({len(messages)} tour(s)). Copie-la dans ton LLM de choix, puis "
            f"colle la réponse JSON dans la fenêtre de saisie.\n\n"
            f"--- SYSTEM ---\n{system.rstrip()}\n\n"
            f"{transcript}"
        )
        try:
            self._info(pretty)
        except Exception:  # pragma: no cover - UI glitches mustn't break the run
            pass

        question = (
            f"Réponse du modèle pour le prompt {prompt_id} (JSON brut) ?"
        )
        answer = self._elicit(question)
        if answer is None:
            answer = ""

        parsed = self._try_parse_json(answer)
        return LLMResponse(
            raw_text=answer,
            parsed=parsed,
            meta={
                "mode": "mcp-copilot",
                "prompt_id": prompt_id,
                "turns": len(messages),
            },
        )
