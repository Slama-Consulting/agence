"""Anthropic-backed LLM client (Claude)."""

from __future__ import annotations

from typing import Optional

from .base import ChatMessage, LLMClient, LLMResponse


class AnthropicClient(LLMClient):
    """Thin wrapper around the official ``anthropic`` SDK.

    The SDK is imported lazily so users who stick to the copilot mode do not
    need to install it.
    """

    def __init__(self, *, api_key: str, model: str, max_tokens: int = 2048) -> None:
        try:
            import anthropic  # local import: keeps it optional
        except ImportError as exc:  # pragma: no cover - env-dependent
            raise RuntimeError(
                "The `anthropic` package is required for LLM mode 'api' with "
                "provider 'anthropic'. Install it via `pip install anthropic`."
            ) from exc

        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model
        self._max_tokens = max_tokens

    def complete_json(
        self,
        *,
        system: str,
        user: str,
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        full_user = user
        if schema_hint:
            full_user = (
                f"{user}\n\n"
                f"Respond ONLY with a JSON object matching this schema:\n{schema_hint}"
            )

        message = self._client.messages.create(
            model=self._model,
            max_tokens=self._max_tokens,
            system=system,
            messages=[{"role": "user", "content": full_user}],
        )

        # Anthropic SDK returns a list of content blocks; concatenate text blocks.
        parts: list[str] = []
        for block in message.content:
            text = getattr(block, "text", None)
            if text:
                parts.append(text)
        raw = "".join(parts)

        return LLMResponse(
            raw_text=raw,
            parsed=self._try_parse_json(raw),
            meta={
                "mode": "api",
                "provider": "anthropic",
                "model": self._model,
                "stop_reason": getattr(message, "stop_reason", None),
            },
        )

    def complete_conversation(
        self,
        *,
        system: str,
        messages: list[ChatMessage],
        schema_hint: Optional[str] = None,
    ) -> LLMResponse:
        if not messages:
            raise ValueError("complete_conversation requires at least one message")
        if messages[-1].role != "user":
            raise ValueError(
                "complete_conversation requires the last message to come from the user"
            )

        # Append the schema hint to the final user turn so the model sees it
        # last, mirroring the behaviour of :meth:`complete_json`.
        api_messages: list[dict[str, str]] = []
        for idx, msg in enumerate(messages):
            content = msg.content
            if schema_hint and idx == len(messages) - 1:
                content = (
                    f"{content}\n\n"
                    f"Respond ONLY with a JSON object matching this schema:\n"
                    f"{schema_hint}"
                )
            api_messages.append({"role": msg.role, "content": content})

        message = self._client.messages.create(
            model=self._model,
            max_tokens=self._max_tokens,
            system=system,
            messages=api_messages,
        )

        parts: list[str] = []
        for block in message.content:
            text = getattr(block, "text", None)
            if text:
                parts.append(text)
        raw = "".join(parts)

        return LLMResponse(
            raw_text=raw,
            parsed=self._try_parse_json(raw),
            meta={
                "mode": "api",
                "provider": "anthropic",
                "model": self._model,
                "stop_reason": getattr(message, "stop_reason", None),
                "turns": len(api_messages),
            },
        )
