"""Prompt templates for :mod:`bughound.documentation`.

Kept isolated so we can snapshot-test wording and evolve the schema
without touching the generator logic.
"""

from __future__ import annotations

from .scanner import ProjectStructure


PROJECT_DOC_SYSTEM = (
    "You are a senior software architect writing a comprehensive, stable "
    "documentation entry for a project so that any future AI (or human) "
    "investigating a bug can understand the codebase and know exactly "
    "which files to read first. Write in French. Be precise, structured, "
    "and cite real file paths / class FQNs from the provided scan."
)


# The schema is a hint for the model; we still consume the returned JSON
# leniently and render a Markdown document from it.
PROJECT_DOC_SCHEMA = """{
  "title": "Short title in French, e.g. 'MyApp — Documentation Technique'",
  "overview": "2-4 sentences describing what the project does, its users, its platform",
  "stack": "Languages, frameworks, architecture pattern, target API/runtime",
  "architecture_ascii": "ASCII or mermaid diagram of the architecture (can be multiline)",
  "modules": [
    {
      "name": "human-readable module name",
      "path": "relative path within the project",
      "responsibility": "what this module does in 1-2 sentences",
      "key_classes": ["com.acme.Foo", "com.acme.Bar"]
    }
  ],
  "external_integrations": [
    {
      "name": "external system / API / service",
      "kind": "aidl | rest | sdk | contentprovider | broadcast | other",
      "entry_point_file": "relative path of the file binding to it",
      "notes": "what flows through it"
    }
  ],
  "decision_tree_internal": [
    {
      "bug_type": "short label, e.g. 'Crash at startup', 'Playback state incorrect'",
      "files_to_read": [
        "relative/path/one.kt",
        "relative/path/two.kt"
      ],
      "hints": "heuristics a human/AI should check first"
    }
  ],
  "decision_tree_cross_project": [
    {
      "symptom": "observable symptom in the UI or logs",
      "primary_project": "this project or a named sibling project",
      "key_files": ["relative path or FQN"],
      "rationale": "why that project is the prime suspect"
    }
  ]
}"""


def render_project_doc_prompt(structure: ProjectStructure) -> str:
    """Build the user prompt for documentation generation."""
    return (
        "Produce a JSON document describing the following project. "
        "Fill every field; if information is missing infer reasonable "
        "defaults from the file names and classes below. Every path "
        "you cite must be relative to the project root.\n\n"
        "=== PROJECT SCAN ===\n"
        f"{structure.to_prompt_block()}\n"
        "=== END PROJECT SCAN ===\n"
    )


# ---------------------------------------------------------------------------
# Markdown rendering
# ---------------------------------------------------------------------------

def render_markdown_from_json(parsed: dict) -> str:
    """Convert the model's JSON answer into the final doc.md body."""
    if not isinstance(parsed, dict):
        parsed = {}

    title = str(parsed.get("title") or "Project — Documentation Technique").strip()
    overview = str(parsed.get("overview") or "").strip()
    stack = str(parsed.get("stack") or "").strip()
    arch = str(parsed.get("architecture_ascii") or "").strip()

    lines: list[str] = [f"# {title}", ""]

    lines.append("## 0. Index")
    lines.append("")
    lines.append("| Section | Contenu |")
    lines.append("|---------|---------|")
    lines.append("| 1. Vue d'ensemble | Rôle du projet et stack technique |")
    lines.append("| 2. Architecture | Diagramme + découpage modulaire |")
    lines.append("| 3. Intégrations externes | APIs, services et points d'entrée |")
    lines.append("| 4. Decision Tree Interne | Fichiers à lire par type de bug |")
    lines.append("| 5. Decision Tree Cross-Projet | Où investiguer en premier |")
    lines.append("")

    lines.append("## 1. Vue d'ensemble")
    lines.append("")
    if overview:
        lines.append(overview)
    else:
        lines.append("_Non renseigné._")
    lines.append("")
    if stack:
        lines.append("**Stack technique** : " + stack)
        lines.append("")

    lines.append("## 2. Architecture")
    lines.append("")
    if arch:
        lines.append("```")
        lines.append(arch)
        lines.append("```")
        lines.append("")
    modules = parsed.get("modules") or []
    if isinstance(modules, list) and modules:
        lines.append("### Modules")
        lines.append("")
        lines.append("| Module | Chemin | Responsabilité | Classes clés |")
        lines.append("|--------|--------|----------------|--------------|")
        for m in modules:
            if not isinstance(m, dict):
                continue
            name = str(m.get("name") or "").strip() or "—"
            path = str(m.get("path") or "").strip() or "—"
            resp = str(m.get("responsibility") or "").strip().replace("|", "/")
            classes = m.get("key_classes") or []
            if isinstance(classes, list):
                classes_str = ", ".join(str(c) for c in classes[:8])
            else:
                classes_str = str(classes)
            lines.append(f"| {name} | `{path}` | {resp} | {classes_str} |")
        lines.append("")

    lines.append("## 3. Intégrations externes")
    lines.append("")
    integrations = parsed.get("external_integrations") or []
    if isinstance(integrations, list) and integrations:
        for ext in integrations:
            if not isinstance(ext, dict):
                continue
            name = str(ext.get("name") or "").strip() or "—"
            kind = str(ext.get("kind") or "").strip() or "—"
            entry = str(ext.get("entry_point_file") or "").strip()
            notes = str(ext.get("notes") or "").strip()
            lines.append(f"### {name} ({kind})")
            lines.append("")
            if entry:
                lines.append(f"- Point d'entrée : `{entry}`")
            if notes:
                lines.append(f"- Notes : {notes}")
            lines.append("")
    else:
        lines.append("_Aucune intégration externe identifiée._")
        lines.append("")

    lines.append("## 4. Decision Tree Interne — Fichiers par type de bug")
    lines.append("")
    tree_internal = parsed.get("decision_tree_internal") or []
    if isinstance(tree_internal, list) and tree_internal:
        for entry in tree_internal:
            if not isinstance(entry, dict):
                continue
            bug = str(entry.get("bug_type") or "").strip() or "—"
            files = entry.get("files_to_read") or []
            hints = str(entry.get("hints") or "").strip()
            lines.append(f"### {bug}")
            lines.append("")
            if isinstance(files, list):
                for i, f in enumerate(files, 1):
                    lines.append(f"{i}. `{f}`")
            if hints:
                lines.append("")
                lines.append(f"> {hints}")
            lines.append("")
    else:
        lines.append("_Arbre de décision non renseigné._")
        lines.append("")

    lines.append("## 5. Decision Tree Cross-Projet")
    lines.append("")
    tree_cross = parsed.get("decision_tree_cross_project") or []
    if isinstance(tree_cross, list) and tree_cross:
        lines.append("| Symptôme | Projet prioritaire | Fichiers clés | Raison |")
        lines.append("|----------|--------------------|---------------|--------|")
        for entry in tree_cross:
            if not isinstance(entry, dict):
                continue
            sym = str(entry.get("symptom") or "").strip().replace("|", "/") or "—"
            proj = str(entry.get("primary_project") or "").strip() or "—"
            files = entry.get("key_files") or []
            if isinstance(files, list):
                files_str = ", ".join(f"`{f}`" for f in files[:5])
            else:
                files_str = str(files)
            why = str(entry.get("rationale") or "").strip().replace("|", "/")
            lines.append(f"| {sym} | {proj} | {files_str} | {why} |")
        lines.append("")
    else:
        lines.append("_Aucun arbre de décision cross-projet renseigné._")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


__all__ = [
    "PROJECT_DOC_SCHEMA",
    "PROJECT_DOC_SYSTEM",
    "render_markdown_from_json",
    "render_project_doc_prompt",
]
