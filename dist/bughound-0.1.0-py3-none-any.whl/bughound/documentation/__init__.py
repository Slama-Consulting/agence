"""Project documentation generation for BugHound.

This module is responsible for reading or producing ``docs/doc.md`` at
the root of a resolved project. The generated document is a stable map
of the codebase — overview, modules, external links, and decision trees
by bug type — that later pipeline steps (log diagnostician, fix
proposer) and any future AI can rely on to navigate the project.
"""

from .generator import ProjectDocumentationGenerator
from .scanner import ProjectStructure, scan_project

__all__ = [
    "ProjectDocumentationGenerator",
    "ProjectStructure",
    "scan_project",
]
