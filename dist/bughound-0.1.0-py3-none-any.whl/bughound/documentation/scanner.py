"""Structural scan of a project root.

Produces a compact :class:`ProjectStructure` that we can inline in a
prompt. We deliberately cap each section so even a huge monorepo fits
in a single LLM call: top-level tree, Gradle modules, Android manifest
file list, class FQNs grouped by top-level package, plus any README /
existing docs fragments.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional

from ..projects.inspector import CodebaseInspector


# Files whose mere presence tells the LLM which stack the project uses.
_STACK_HINT_FILES = (
    "build.gradle.kts",
    "build.gradle",
    "settings.gradle.kts",
    "settings.gradle",
    "AndroidManifest.xml",
    "pyproject.toml",
    "requirements.txt",
    "package.json",
    "Cargo.toml",
    "go.mod",
    "pom.xml",
)

# Directories we never descend into when building the tree summary.
_IGNORED_DIRS = frozenset({
    "build", ".gradle", ".idea", ".git", "node_modules",
    ".kotlin", ".cxx", "out", "captures", "__pycache__",
    ".venv", "venv", ".tox", "target", "dist",
})

# Max number of classes we send per package, max entries total, tree depth.
_MAX_CLASSES_PER_PACKAGE = 40
_MAX_TOTAL_CLASSES = 600
_MAX_TREE_DEPTH = 3
_MAX_TREE_ENTRIES_PER_DIR = 30
_README_MAX_CHARS = 4000


@dataclass
class ProjectStructure:
    """Flat, prompt-friendly view of a project."""

    root: Path
    name: str
    stack_hints: list[str] = field(default_factory=list)
    tree: str = ""
    gradle_modules: list[str] = field(default_factory=list)
    manifest_packages: list[str] = field(default_factory=list)
    packages: dict[str, list[str]] = field(default_factory=dict)  # pkg -> [classes]
    class_count: int = 0
    readme_excerpt: Optional[str] = None

    def to_prompt_block(self) -> str:
        """Render the structure as a single text block suitable for an LLM prompt."""
        parts: list[str] = []
        parts.append(f"Project name: {self.name}")
        parts.append(f"Project root: {self.root}")
        if self.stack_hints:
            parts.append("Stack hint files found:")
            for hint in self.stack_hints:
                parts.append(f"  - {hint}")
        if self.gradle_modules:
            parts.append("Gradle modules detected:")
            for m in self.gradle_modules:
                parts.append(f"  - {m}")
        if self.manifest_packages:
            parts.append("AndroidManifest package(s):")
            for p in self.manifest_packages:
                parts.append(f"  - {p}")
        if self.tree:
            parts.append("Top-level tree (truncated):")
            parts.append(self.tree)
        if self.packages:
            parts.append(f"Classes indexed ({self.class_count} total), "
                         "grouped by top-level package:")
            for pkg, classes in self.packages.items():
                parts.append(f"  [{pkg}]")
                for c in classes:
                    parts.append(f"    - {c}")
        if self.readme_excerpt:
            parts.append("README excerpt:")
            parts.append(self.readme_excerpt)
        return "\n".join(parts)


def scan_project(root: Path) -> ProjectStructure:
    """Scan ``root`` and return a :class:`ProjectStructure`."""
    root = Path(root).expanduser().resolve()
    structure = ProjectStructure(root=root, name=root.name)

    structure.stack_hints = _collect_stack_hints(root)
    structure.tree = _render_tree(root)
    structure.gradle_modules = _collect_gradle_modules(root)
    structure.manifest_packages = _collect_manifest_packages(root)
    structure.readme_excerpt = _read_readme(root)

    inspector = CodebaseInspector(root)
    # Trigger indexing so we can read the (private) FQN map.
    _ = inspector.class_count
    structure.packages, structure.class_count = _group_fqns(inspector)
    return structure


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _collect_stack_hints(root: Path) -> list[str]:
    found: list[str] = []
    for rel in _STACK_HINT_FILES:
        # Look at the root and one level deep so modules-based Gradle
        # projects still surface their root-level build files.
        for candidate in (root / rel, *list(root.glob(f"*/{rel}"))):
            if candidate.exists() and candidate.is_file():
                try:
                    found.append(str(candidate.relative_to(root)))
                except ValueError:
                    found.append(str(candidate))
    # De-duplicate while preserving order.
    seen: set[str] = set()
    unique: list[str] = []
    for item in found:
        if item not in seen:
            seen.add(item)
            unique.append(item)
    return unique


def _render_tree(root: Path) -> str:
    lines: list[str] = [root.name + "/"]
    _render_tree_level(root, prefix="", lines=lines, depth=0)
    # Keep the output finite even on huge repos.
    if len(lines) > 400:
        lines = lines[:400] + ["  …"]
    return "\n".join(lines)


def _render_tree_level(
    directory: Path, *, prefix: str, lines: list[str], depth: int,
) -> None:
    if depth >= _MAX_TREE_DEPTH:
        return
    try:
        entries = sorted(
            (p for p in directory.iterdir()
             if p.name not in _IGNORED_DIRS and not p.name.startswith(".")),
            key=lambda p: (not p.is_dir(), p.name.lower()),
        )
    except OSError:
        return
    if len(entries) > _MAX_TREE_ENTRIES_PER_DIR:
        entries = entries[:_MAX_TREE_ENTRIES_PER_DIR]
    for entry in entries:
        marker = "/" if entry.is_dir() else ""
        lines.append(f"{prefix}- {entry.name}{marker}")
        if entry.is_dir():
            _render_tree_level(
                entry, prefix=prefix + "  ", lines=lines, depth=depth + 1,
            )


def _collect_gradle_modules(root: Path) -> list[str]:
    settings = None
    for name in ("settings.gradle.kts", "settings.gradle"):
        candidate = root / name
        if candidate.exists():
            settings = candidate
            break
    if settings is None:
        return []
    try:
        text = settings.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return []
    modules: list[str] = []
    for raw in text.splitlines():
        stripped = raw.strip()
        if stripped.startswith("include"):
            # Capture every "...":' bits.
            inside = stripped[len("include"):].strip()
            inside = inside.lstrip("(").rstrip(")").strip()
            for chunk in inside.split(","):
                mod = chunk.strip().strip('"').strip("'")
                if mod:
                    modules.append(mod)
    return modules


def _collect_manifest_packages(root: Path) -> list[str]:
    packages: list[str] = []
    for manifest in root.rglob("AndroidManifest.xml"):
        # Skip build outputs.
        if any(part in _IGNORED_DIRS for part in manifest.parts):
            continue
        try:
            text = manifest.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        # Cheap regex-free parse: look for package="com.foo.bar".
        marker = 'package="'
        idx = text.find(marker)
        if idx == -1:
            continue
        end = text.find('"', idx + len(marker))
        if end == -1:
            continue
        pkg = text[idx + len(marker): end]
        if pkg and pkg not in packages:
            packages.append(pkg)
        if len(packages) >= 10:
            break
    return packages


def _read_readme(root: Path) -> Optional[str]:
    for name in ("README.md", "README.rst", "README.txt", "README"):
        candidate = root / name
        if candidate.exists() and candidate.is_file():
            try:
                text = candidate.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            text = text.strip()
            if not text:
                continue
            if len(text) > _README_MAX_CHARS:
                text = text[:_README_MAX_CHARS] + "\n… (truncated)"
            return text
    return None


def _group_fqns(inspector: CodebaseInspector) -> tuple[dict[str, list[str]], int]:
    """Group every indexed FQN by its top-level package (first two segments)."""
    by_fqn: dict[str, object] = getattr(inspector, "_by_fqn", {})
    groups: dict[str, list[str]] = {}
    total = 0
    for fqn in sorted(by_fqn.keys()):
        total += 1
        parts = fqn.split(".")
        if len(parts) >= 3:
            key = ".".join(parts[:3])
        elif len(parts) >= 2:
            key = ".".join(parts[:2])
        else:
            key = parts[0]
        groups.setdefault(key, []).append(fqn)

    # Cap per package and overall.
    capped: dict[str, list[str]] = {}
    running = 0
    for pkg, classes in groups.items():
        if running >= _MAX_TOTAL_CLASSES:
            break
        room = _MAX_TOTAL_CLASSES - running
        take = classes[: min(_MAX_CLASSES_PER_PACKAGE, room)]
        if len(classes) > len(take):
            take = take + [f"… (+{len(classes) - len(take)} more)"]
        capped[pkg] = take
        running += len(take)
    return capped, total


__all__ = ["ProjectStructure", "scan_project"]
