"""Read or generate ``docs/doc.md`` for a resolved project."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from ..llm import LLMClient
from ..projects.resolver import ResolvedProject
from . import prompts
from .scanner import scan_project

log = logging.getLogger(__name__)


DOC_RELATIVE_PATH = Path("docs") / "doc.md"


class ProjectDocumentationGenerator:
    """Get-or-create the stable project documentation file.

    Strategy:
      1. If ``<project_root>/docs/doc.md`` exists, return its path (no LLM call).
      2. Otherwise, scan the project, ask the LLM for a structured
         description, render Markdown and write it at that path. Then
         return the path.

    Once generated, the file is never refreshed automatically: developers
    own it and are expected to keep it in sync with their code. To
    regenerate, delete the file.
    """

    def __init__(self, llm: LLMClient) -> None:
        self._llm = llm

    def generate_or_read(self, resolved: ResolvedProject) -> Path:
        """Return the path to ``doc.md``, generating it if it does not exist.

        The caller (pipeline step 3) assumes that, whenever ``resolved`` is
        not ``None``, a file exists on disk after this call. To honour
        that contract even when ``scan_project`` or the LLM raises
        unexpectedly (network errors, OOM, permission issues, …), the
        body is wrapped in a try/except that falls back to a minimal
        stub rather than propagating the error. The stub tells the user
        exactly what happened so they can regenerate by deleting the
        file.
        """
        doc_path = Path(resolved.root) / DOC_RELATIVE_PATH
        if doc_path.exists() and doc_path.is_file():
            log.info("Project doc already present at %s", doc_path)
            return doc_path

        log.info("Generating project doc for %s at %s", resolved.name, doc_path)
        markdown: str
        try:
            structure = scan_project(Path(resolved.root))
            user_prompt = prompts.render_project_doc_prompt(structure)
            response = self._llm.complete_json(
                system=prompts.PROJECT_DOC_SYSTEM,
                user=user_prompt,
                schema_hint=prompts.PROJECT_DOC_SCHEMA,
            )
            parsed = response.parsed or {}
            if not parsed:
                raw_len = len(response.raw_text or "")
                log.warning(
                    "Project doc generation: LLM returned no valid JSON for %s "
                    "(raw_text length=%d, preview=%r). Writing fallback file.",
                    resolved.name,
                    raw_len,
                    (response.raw_text or "")[:200],
                )
                markdown = _fallback_markdown(resolved, response.raw_text)
            else:
                markdown = prompts.render_markdown_from_json(parsed)
        except Exception as exc:  # pragma: no cover - defensive
            log.exception(
                "Project doc generation crashed for %s — writing minimal stub",
                resolved.name,
            )
            markdown = _minimal_stub(resolved, exc)

        try:
            doc_path.parent.mkdir(parents=True, exist_ok=True)
            doc_path.write_text(markdown, encoding="utf-8")
        except OSError:
            log.exception("Failed to write doc.md at %s", doc_path)
            raise
        return doc_path

    @staticmethod
    def read_doc(resolved: ResolvedProject) -> Optional[str]:
        """Read the current content of ``doc.md`` or return ``None``."""
        doc_path = Path(resolved.root) / DOC_RELATIVE_PATH
        if not doc_path.exists():
            return None
        try:
            return doc_path.read_text(encoding="utf-8")
        except OSError:
            return None


def _fallback_markdown(resolved: ResolvedProject, raw_text: str) -> str:
    body = raw_text.strip() or "_Aucune documentation générée._"
    return (
        f"# {resolved.name} — Documentation Technique\n\n"
        "> Document généré automatiquement par BugHound. Le modèle n'a pas "
        "produit de JSON structuré ; le texte brut est conservé ci-dessous.\n\n"
        f"{body}\n"
    )


def _minimal_stub(resolved: ResolvedProject, exc: BaseException) -> str:
    """Last-resort stub when scan_project or the LLM raised before producing markdown.

    The stub tells the user which project was matched and which error
    prevented the full generation, so they can delete the file and retry
    once the underlying issue is fixed.
    """
    matched_on = getattr(resolved, "matched_on", "?")
    score = getattr(resolved, "score", "?")
    ticket_key = getattr(resolved, "ticket_key", "?")
    return (
        f"# {resolved.name} — Documentation Technique (stub minimal)\n\n"
        f"> Document écrit par BugHound en fallback suite à une erreur "
        f"interne : `{exc.__class__.__name__}: {exc}`.\n"
        f"> Régénérez ce fichier en le supprimant puis relancez l'analyse.\n\n"
        f"- Ticket ancré : `{ticket_key}`\n"
        f"- Racine projet : `{resolved.root}`\n"
        f"- Match : `{matched_on}` (score {score})\n"
    )


__all__ = ["DOC_RELATIVE_PATH", "ProjectDocumentationGenerator"]
