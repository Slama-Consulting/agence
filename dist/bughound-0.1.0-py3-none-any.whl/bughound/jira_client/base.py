"""Common interface for Jira backends (API vs scrape vs browser)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from ..core.models import Attachment, Ticket


# ---------------------------------------------------------------------------
# Write-side results
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class WriteResult:
    """Outcome of a write operation (``add_comment`` / ``create_issue``).

    In dry-run mode no HTTP request is sent; ``dry_run`` is True and the
    resulting IDs / URLs are ``None``. The caller is expected to check
    :attr:`dry_run` before treating the operation as committed.
    """

    dry_run: bool
    target: str              # e.g. "CCSEXT-235266" or "CCSEXT"
    action: str              # "comment" | "create"
    payload: dict            # the body we would have sent
    key: Optional[str] = None
    url: Optional[str] = None


class WriteNotSupportedError(RuntimeError):
    """Raised when a backend cannot perform the requested write."""


class WriteRefusedError(RuntimeError):
    """Raised when a write is blocked by the safety allow-list."""


# ---------------------------------------------------------------------------
# Base client
# ---------------------------------------------------------------------------


class JiraClient(ABC):
    """Abstract Jira client.

    Implementations fetch a :class:`Ticket` by key and download attachments.
    Analyzers and the pipeline only ever talk to this interface.

    Write operations (``add_comment``, ``create_issue``) are optional and
    default to raising :class:`WriteNotSupportedError`. Backends that can
    write (like the browser-backed client) override them.
    """

    @abstractmethod
    def get_ticket(self, key: str) -> Ticket:
        """Fetch a ticket with its metadata, comments and attachment list."""

    @abstractmethod
    def download_attachment(self, attachment: Attachment, dest_dir: Path) -> Path:
        """Download ``attachment`` into ``dest_dir`` and return the local path.

        Implementations must:
          - create ``dest_dir`` if missing,
          - preserve the original filename (sanitized),
          - set :attr:`Attachment.local_path` on the input object.
        """

    # ---- optional HTTP credential sharing --------------------------------

    def http_auth(self) -> Optional[tuple[str, str]]:
        """Return Basic-auth credentials compatible with ``requests.auth``.

        Used by attachment URL handlers (Artifactory, …) that live on the
        same corporate SSO as Jira and can reuse the same token. Default
        backends return ``None`` so handlers fall back to anonymous HTTP.
        """
        return None

    # ---- optional write operations ---------------------------------------

    def add_comment(
        self,
        key: str,
        body: str,
        *,
        dry_run: bool = True,
    ) -> WriteResult:
        """Add a comment to ``key``. Default backends refuse writes."""
        raise WriteNotSupportedError(
            f"{type(self).__name__} does not support add_comment"
        )

    def create_issue(
        self,
        *,
        project: str,
        title: str,
        body: str,
        issue_type: str = "Bug",
        dry_run: bool = True,
    ) -> WriteResult:
        """Create an issue in ``project``. Default backends refuse writes."""
        raise WriteNotSupportedError(
            f"{type(self).__name__} does not support create_issue"
        )
