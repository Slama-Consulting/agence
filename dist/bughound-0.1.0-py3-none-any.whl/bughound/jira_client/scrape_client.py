"""Best-effort scraping fallback when no Jira API token is available.

Strategy: fetch the public issue URL, parse the embedded JSON state or JSON-LD
block Jira injects for issue pages, and degrade gracefully to raw HTML text
extraction when the structured payload cannot be found.

This is intentionally a best-effort client. When tickets are private (behind
auth) the API client is the correct choice; scraping is only useful for
public Jira instances or pre-saved HTML dumps.
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import requests
from bs4 import BeautifulSoup
from dateutil import parser as dtparser

from ..core.models import Attachment, Comment, Ticket
from ..utils.fs import ensure_dir, safe_filename
from .base import JiraClient


class JiraScrapeClient(JiraClient):
    """Fetch ticket data from the public HTML view of a Jira instance."""

    def __init__(
        self,
        *,
        base_url: str,
        session: Optional[requests.Session] = None,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._session = session or requests.Session()
        self._timeout = timeout

    def get_ticket(self, key: str) -> Ticket:
        url = f"{self._base_url}/browse/{key}"
        html = self._fetch(url)
        soup = BeautifulSoup(html, "html.parser")

        title = self._meta(soup, "og:title") or self._text(soup.select_one("#summary-val")) or key
        description = self._text(soup.select_one("#description-val"))
        status = self._text(soup.select_one("#status-val"))
        reporter = self._text(soup.select_one("#reporter-val"))
        assignee = self._text(soup.select_one("#assignee-val"))

        created = self._parse_dt(self._meta(soup, "og:updated_time"))

        return Ticket(
            key=key,
            title=title,
            description=description,
            status=status,
            reporter=reporter,
            assignee=assignee,
            labels=[],
            created=created,
            updated=created,
            attachments=self._scrape_attachments(soup),
            comments=self._scrape_comments(soup),
            url=url,
        )

    def download_attachment(self, attachment: Attachment, dest_dir: Path) -> Path:
        ensure_dir(dest_dir)
        local = dest_dir / safe_filename(attachment.filename)
        with self._session.get(
            attachment.url, stream=True, timeout=self._timeout
        ) as resp:
            resp.raise_for_status()
            with local.open("wb") as fh:
                for chunk in resp.iter_content(chunk_size=64 * 1024):
                    if chunk:
                        fh.write(chunk)
        attachment.local_path = local
        return local

    # ---- internals --------------------------------------------------------

    def _fetch(self, url: str) -> str:
        resp = self._session.get(
            url,
            headers={"User-Agent": "BugHound/0.1 (+scrape)"},
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.text

    @staticmethod
    def _meta(soup: BeautifulSoup, prop: str) -> Optional[str]:
        tag = soup.find("meta", attrs={"property": prop}) or soup.find(
            "meta", attrs={"name": prop}
        )
        if tag and tag.get("content"):
            return tag["content"]
        return None

    @staticmethod
    def _text(node: Any) -> str:
        if node is None:
            return ""
        return re.sub(r"\s+", " ", node.get_text(" ", strip=True))

    def _scrape_attachments(self, soup: BeautifulSoup) -> list[Attachment]:
        results: list[Attachment] = []
        for a in soup.select("a[data-attachment-name], .attachment-content a"):
            href = a.get("href")
            name = a.get("data-attachment-name") or a.get_text(strip=True)
            if not href or not name:
                continue
            abs_url = href if href.startswith("http") else f"{self._base_url}{href}"
            results.append(
                Attachment(
                    id=a.get("data-attachment-id") or abs_url,
                    filename=name,
                    url=abs_url,
                )
            )
        return results

    def _scrape_comments(self, soup: BeautifulSoup) -> list[Comment]:
        results: list[Comment] = []
        for idx, c in enumerate(soup.select(".activity-comment, .issue-comment")):
            body_el = c.select_one(".action-body, .comment-body")
            author_el = c.select_one(".user-hover, .author")
            date_el = c.select_one("time")
            created = self._parse_dt(date_el.get("datetime") if date_el else None)
            body = self._text(body_el)
            if not body:
                continue
            results.append(
                Comment(
                    id=c.get("id") or f"scrape-{idx}",
                    author=self._text(author_el) or "unknown",
                    created=created or datetime.min,
                    body=body,
                    attachments=[],
                )
            )
        return results

    @staticmethod
    def _parse_dt(value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        try:
            return dtparser.isoparse(value)
        except (ValueError, TypeError):
            return None
