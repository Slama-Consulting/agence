"""Jira Cloud REST API client.

Uses Basic Auth with email + API token (the standard for Jira Cloud).
Only the endpoints we actually need are implemented; no SDK required so the
dependency footprint stays small and predictable.
"""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Any, Optional

import requests
from dateutil import parser as dtparser

from ..core.models import Attachment, Comment, Ticket
from ..utils.fs import ensure_dir, safe_filename
from .base import JiraClient


class JiraApiClient(JiraClient):
    """Jira Cloud REST v3 client."""

    def __init__(
        self,
        *,
        base_url: str,
        email: str,
        api_token: str,
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._auth = (email, api_token)
        self._timeout = timeout

    # ---- public API -------------------------------------------------------

    def get_ticket(self, key: str) -> Ticket:
        data = self._get(
            f"/rest/api/3/issue/{key}",
            params={"fields": "*all", "expand": "renderedFields"},
        )
        fields = data.get("fields", {})

        ticket_attachments = [
            self._parse_attachment(a) for a in fields.get("attachment", []) or []
        ]
        comments = self._parse_comments(fields.get("comment", {}) or {})

        return Ticket(
            key=data["key"],
            title=fields.get("summary") or "",
            description=self._extract_text(fields.get("description")),
            status=(fields.get("status") or {}).get("name"),
            reporter=self._user_display(fields.get("reporter")),
            assignee=self._user_display(fields.get("assignee")),
            labels=list(fields.get("labels") or []),
            components=[
                c.get("name", "") for c in (fields.get("components") or []) if c.get("name")
            ],
            issue_type_name=(fields.get("issuetype") or {}).get("name", "") or "",
            created=self._parse_dt(fields.get("created")),
            updated=self._parse_dt(fields.get("updated")),
            attachments=ticket_attachments,
            comments=comments,
            url=f"{self._base_url}/browse/{data['key']}",
        )

    def http_auth(self) -> Optional[tuple[str, str]]:
        """Expose the Jira Basic-auth tuple for reuse by attachment handlers.

        Corporate deployments typically front Artifactory / Nexus / file
        shares with the same SSO as Jira, so the same token can be reused
        to walk a folder tree and download files without re-prompting.
        """
        return self._auth

    def download_attachment(self, attachment: Attachment, dest_dir: Path) -> Path:
        ensure_dir(dest_dir)
        local = dest_dir / safe_filename(attachment.filename)

        # Jira attachment URLs require the same auth as the API.
        with requests.get(
            attachment.url,
            auth=self._auth,
            stream=True,
            timeout=self._timeout,
        ) as resp:
            resp.raise_for_status()
            with local.open("wb") as fh:
                for chunk in resp.iter_content(chunk_size=64 * 1024):
                    if chunk:
                        fh.write(chunk)

        attachment.local_path = local
        return local

    # ---- internals --------------------------------------------------------

    def _get(self, path: str, *, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        resp = requests.get(
            url,
            auth=self._auth,
            params=params,
            headers={"Accept": "application/json"},
            timeout=self._timeout,
        )
        resp.raise_for_status()
        return resp.json()

    def _parse_comments(self, comment_block: dict[str, Any]) -> list[Comment]:
        result: list[Comment] = []
        for c in comment_block.get("comments", []) or []:
            result.append(
                Comment(
                    id=str(c.get("id")),
                    author=self._user_display(c.get("author")) or "unknown",
                    created=self._parse_dt(c.get("created")) or datetime.min,
                    body=self._extract_text(c.get("body")),
                    # Jira Cloud does not expose per-comment attachments in the
                    # comment payload; they live under fields.attachment and
                    # may be referenced inline. We keep the list empty here
                    # and rely on ticket-level attachments.
                    attachments=[],
                )
            )
        return result

    @classmethod
    def _parse_attachment(cls, a: dict[str, Any]) -> Attachment:
        return Attachment(
            id=str(a.get("id")),
            filename=a.get("filename") or f"attachment_{a.get('id')}",
            mime_type=a.get("mimeType"),
            size_bytes=a.get("size"),
            url=a.get("content") or "",
            created=cls._parse_dt(a.get("created")),
        )

    @staticmethod
    def _user_display(user: Optional[dict[str, Any]]) -> Optional[str]:
        if not user:
            return None
        return user.get("displayName") or user.get("emailAddress") or user.get("accountId")

    @staticmethod
    def _parse_dt(value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        try:
            return dtparser.isoparse(value)
        except (ValueError, TypeError):
            return None

    @classmethod
    def _extract_text(cls, value: Any) -> str:
        """Extract plain text from Jira Cloud description/comment bodies.

        Jira Cloud stores rich text as Atlassian Document Format (ADF), a
        nested JSON tree. We walk it and concatenate text nodes. Plain strings
        (legacy / server) are returned as-is.
        """
        if value is None:
            return ""
        if isinstance(value, str):
            return value
        if isinstance(value, dict):
            return cls._walk_adf(value).strip()
        return str(value)

    @classmethod
    def _walk_adf(cls, node: Any) -> str:
        if isinstance(node, dict):
            if node.get("type") == "text":
                return node.get("text", "")
            parts = [cls._walk_adf(c) for c in node.get("content", []) or []]
            joined = "".join(parts)
            # Preserve paragraph / heading breaks for readability.
            if node.get("type") in {"paragraph", "heading", "listItem"}:
                joined += "\n"
            return joined
        if isinstance(node, list):
            return "".join(cls._walk_adf(n) for n in node)
        return ""
