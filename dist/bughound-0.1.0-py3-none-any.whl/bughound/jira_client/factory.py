"""Pick the right Jira client based on configuration."""

from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

from .api_client import JiraApiClient
from .base import JiraClient
from .browser_client import (
    BrowserProfile,
    JiraBrowserClient,
    build_playwright_session_factory,
)
from .scrape_client import JiraScrapeClient


def build_jira_client(
    *,
    mode: str,
    base_url: str,
    email: Optional[str] = None,
    api_token: Optional[str] = None,
    browser_profile_dir: Optional[Path] = None,
    browser_headless_after_login: bool = True,
    write_allowed_projects: Iterable[str] = (),
) -> JiraClient:
    """Instantiate a Jira client from config.

    Args:
        mode:      "api", "scrape", or "browser".
        base_url:  Jira instance base URL.
        email:     Jira account email (required for mode="api").
        api_token: Jira API token (required for mode="api").
        browser_profile_dir: where to persist the Chromium profile
            (required for mode="browser").
        browser_headless_after_login: run headless once a cached session
            exists.
        write_allowed_projects: project keys that may receive writes in
            non-dry-run mode (browser backend only).
    """
    mode_norm = mode.lower().strip()

    if mode_norm == "api":
        if not email or not api_token:
            raise ValueError(
                "jira.mode == 'api' requires both an email and an API token. "
                "Set JIRA_API_TOKEN and jira.email in your config."
            )
        return JiraApiClient(base_url=base_url, email=email, api_token=api_token)

    if mode_norm == "scrape":
        return JiraScrapeClient(base_url=base_url)

    if mode_norm == "browser":
        # Resolve ~ coming from YAML (Pydantic keeps it literal).
        profile_dir = (
            Path(browser_profile_dir).expanduser()
            if browser_profile_dir is not None
            else Path("~/.bughound/chrome-profile").expanduser()
        )
        profile = BrowserProfile(
            profile_dir=profile_dir,
            headless_after_first_login=browser_headless_after_login,
        )
        factory = build_playwright_session_factory(
            base_url=base_url, profile=profile,
        )
        return JiraBrowserClient(
            base_url=base_url,
            session_factory=factory,
            write_allowed_projects=write_allowed_projects,
        )

    raise ValueError(
        f"Unknown Jira mode: {mode!r} (expected 'api', 'scrape', or 'browser')"
    )
