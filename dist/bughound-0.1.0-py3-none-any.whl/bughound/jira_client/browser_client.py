"""Browser-backed Jira client: uses your existing browser session via Playwright.

The motivation: enterprise Jira Data Center instances sit behind SSO / SAML /
MFA that make plain API-token auth impossible or awkward. But a user who is
already logged in via Chrome has a perfectly valid session cookie. This
backend reuses that session by:

  1. Driving a persistent Chromium profile stored under a local directory
     (``~/.bughound/chrome-profile`` by default). On first run the user logs
     into Jira interactively; subsequent runs start headless.
  2. Extracting cookies from the Playwright context and injecting them into
     a plain ``requests.Session`` for fast, non-JS calls to the Jira REST API.

Reads go through the REST API (Jira Server / Data Center v2) because it's far
faster and more robust than scraping.

Writes (``add_comment``, ``create_issue``) default to **dry-run** and are
additionally gated by an optional project allow-list. A caller must pass
``dry_run=False`` *and* the target project must be in the allow-list before
any POST hits the wire.

This module lazy-imports Playwright so that simply importing BugHound does
not require it. Tests inject a ``session_factory`` (a callable that returns
a ready ``requests.Session``) to bypass Playwright entirely.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Optional

import requests
from dateutil import parser as dtparser

from ..core.models import Attachment, Comment, Ticket
from ..utils.fs import ensure_dir, safe_filename
from .base import JiraClient, WriteRefusedError, WriteResult


log = logging.getLogger(__name__)


SessionFactory = Callable[[], requests.Session]


# ---------------------------------------------------------------------------
# Playwright-backed session factory
# ---------------------------------------------------------------------------


@dataclass
class BrowserProfile:
    """Where and how Playwright should persist the Chromium profile."""

    profile_dir: Path = Path("~/.bughound/chrome-profile").expanduser()
    # Jira URL used to verify that the session is authenticated.
    login_probe_url: Optional[str] = None
    # Seconds the interactive login window stays open waiting for the user
    # to complete SSO before we give up. SSO with MFA can take a while.
    login_timeout_s: float = 600.0
    # Once login has succeeded at least once, run headless next time.
    headless_after_first_login: bool = True
    # Extra Chromium args (useful for corporate environments with custom CAs).
    chromium_args: list[str] = field(default_factory=list)


def build_playwright_session_factory(
    *,
    base_url: str,
    profile: BrowserProfile,
) -> SessionFactory:
    """Return a factory that opens Chromium with a persistent profile and
    returns a ``requests.Session`` primed with the Jira cookies."""

    def factory() -> requests.Session:
        # Import lazily so 'import bughound' doesn't require Playwright.
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:  # pragma: no cover - env-specific
            raise RuntimeError(
                "Playwright is required for jira.mode == 'browser'. "
                "Install with: pip install playwright && playwright install chromium"
            ) from exc

        ensure_dir(profile.profile_dir)
        probe_url = profile.login_probe_url or f"{base_url.rstrip('/')}/rest/api/2/myself"
        headless = profile.headless_after_first_login and _profile_has_cookies(
            profile.profile_dir
        )

        log.info(
            "Starting Chromium (headless=%s, profile=%s)…",
            headless, profile.profile_dir,
        )
        cookies: list[dict[str, Any]] = []
        with sync_playwright() as p:
            context = p.chromium.launch_persistent_context(
                user_data_dir=str(profile.profile_dir),
                headless=headless,
                args=list(profile.chromium_args),
            )
            try:
                log.info("Probing Jira authentication at %s…", probe_url)
                if not _context_is_authenticated(context, probe_url):
                    log.warning("Not authenticated yet (cached cookies missing/stale).")
                    if headless:
                        # Cached cookies turned out to be stale. Re-open with
                        # a visible window so the user can log in again.
                        context.close()
                        return _interactive_login(
                            p, profile=profile, probe_url=probe_url
                        )
                    # Non-headless: open the Jira landing page (NOT the JSON
                    # probe) so the user lands somewhere they can interact
                    # with, and wait until a silent API probe says OK.
                    page = context.new_page()
                    page.goto(base_url, wait_until="domcontentloaded")
                    _wait_for_authentication(
                        context, probe_url, profile.login_timeout_s
                    )
                cookies = context.cookies()
                log.info("Authenticated — extracted %d cookie(s).", len(cookies))
            finally:
                context.close()

        session = requests.Session()
        for c in cookies:
            session.cookies.set(
                c["name"], c["value"],
                domain=c.get("domain"),
                path=c.get("path", "/"),
            )
        session.headers.update(
            {"User-Agent": "BugHound/0.1 (+browser)", "Accept": "application/json"}
        )
        log.info("Jira session ready (cookies primed into requests).")
        return session

    return factory


def _interactive_login(
    p: Any,
    *,
    profile: BrowserProfile,
    probe_url: str,
) -> requests.Session:
    """Fallback path used when cached cookies turned out to be stale."""
    # Derive the Jira landing URL from the probe URL.
    base_url = probe_url.split("/rest/api/")[0]
    context = p.chromium.launch_persistent_context(
        user_data_dir=str(profile.profile_dir),
        headless=False,
        args=list(profile.chromium_args),
    )
    try:
        page = context.new_page()
        page.goto(base_url, wait_until="domcontentloaded")
        _wait_for_authentication(context, probe_url, profile.login_timeout_s)
        cookies = context.cookies()
    finally:
        context.close()

    session = requests.Session()
    for c in cookies:
        session.cookies.set(
            c["name"], c["value"],
            domain=c.get("domain"),
            path=c.get("path", "/"),
        )
    return session


def _context_is_authenticated(context: Any, probe_url: str) -> bool:
    """Hit the Jira API directly from Playwright's context — this uses the
    same cookies as the browser but doesn't navigate, so it never disturbs
    the user who may be typing credentials on the login page."""
    try:
        resp = context.request.get(
            probe_url,
            headers={"Accept": "application/json"},
            timeout=10_000,  # 10s, in milliseconds
        )
    except Exception:
        return False
    if not resp.ok:
        return False
    try:
        body = resp.json()
    except Exception:
        return False
    return isinstance(body, dict) and (
        "displayName" in body or "name" in body or "emailAddress" in body
    )


def _wait_for_authentication(
    context: Any, probe_url: str, timeout_s: float
) -> None:
    """Poll the Jira REST API from Playwright's context until it responds
    with an authenticated JSON payload. Never reloads the visible page —
    the user can type credentials undisturbed."""
    deadline = time.monotonic() + timeout_s
    log.warning(
        "A browser window is open — complete the Jira login (SSO + MFA if "
        "needed). BugHound polls silently every 2s and continues "
        "automatically once authentication succeeds. Timeout: %.0fs.",
        timeout_s,
    )
    while time.monotonic() < deadline:
        if _context_is_authenticated(context, probe_url):
            return
        time.sleep(2.0)
    raise RuntimeError(
        "Timed out waiting for interactive Jira authentication."
    )


def _profile_has_cookies(profile_dir: Path) -> bool:
    """Rough heuristic: if the profile directory contains a Cookies DB,
    assume we've logged in at least once."""
    return (profile_dir / "Default" / "Cookies").exists() or (
        profile_dir / "Cookies"
    ).exists()


# ---------------------------------------------------------------------------
# The client itself
# ---------------------------------------------------------------------------


class JiraBrowserClient(JiraClient):
    """Jira Server / Data Center client that borrows the user's browser session."""

    def __init__(
        self,
        *,
        base_url: str,
        session_factory: SessionFactory,
        write_allowed_projects: Iterable[str] = (),
        timeout: float = 30.0,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._factory = session_factory
        self._timeout = timeout
        self._allowed = {p.upper() for p in write_allowed_projects}
        self._session: Optional[requests.Session] = None

    # ---- session management ---------------------------------------------

    def _get_session(self) -> requests.Session:
        if self._session is None:
            self._session = self._factory()
        return self._session

    # ---- reads ----------------------------------------------------------

    def get_ticket(self, key: str) -> Ticket:
        data = self._api_get(
            f"/rest/api/2/issue/{key}",
            params={"fields": "*all"},
        )
        fields = data.get("fields", {}) or {}

        attachments = [
            self._parse_attachment(a) for a in fields.get("attachment", []) or []
        ]
        comments = self._parse_comments(fields.get("comment", {}) or {})

        return Ticket(
            key=data["key"],
            title=fields.get("summary") or "",
            description=self._coerce_text(fields.get("description")),
            status=(fields.get("status") or {}).get("name"),
            reporter=self._user_display(fields.get("reporter")),
            assignee=self._user_display(fields.get("assignee")),
            labels=list(fields.get("labels") or []),
            components=[
                c.get("name", "") for c in (fields.get("components") or []) if c.get("name")
            ],
            issue_type_name=(fields.get("issuetype") or {}).get("name", "") or "",
            created=self._parse_dt(fields.get("created")),
            updated=self._parse_dt(fields.get("updated")),
            attachments=attachments,
            comments=comments,
            url=f"{self._base_url}/browse/{data['key']}",
        )

    def download_attachment(self, attachment: Attachment, dest_dir: Path) -> Path:
        ensure_dir(dest_dir)
        local = dest_dir / safe_filename(attachment.filename)
        session = self._get_session()

        size_hint = (
            f" ({attachment.size_bytes / 1_000_000:.1f} MB)"
            if attachment.size_bytes else ""
        )
        log.info("  downloading %s%s", attachment.filename, size_hint)
        with session.get(
            attachment.url, stream=True, timeout=self._timeout
        ) as resp:
            resp.raise_for_status()
            with local.open("wb") as fh:
                for chunk in resp.iter_content(chunk_size=64 * 1024):
                    if chunk:
                        fh.write(chunk)

        attachment.local_path = local
        return local

    # ---- writes ---------------------------------------------------------

    def add_comment(
        self,
        key: str,
        body: str,
        *,
        dry_run: bool = True,
    ) -> WriteResult:
        payload = {"body": body}
        if dry_run:
            return WriteResult(
                dry_run=True, target=key, action="comment", payload=payload,
            )
        self._check_write_allowed(key.split("-", 1)[0])
        data = self._api_post(f"/rest/api/2/issue/{key}/comment", payload)
        return WriteResult(
            dry_run=False,
            target=key,
            action="comment",
            payload=payload,
            key=str(data.get("id")) if data else None,
            url=f"{self._base_url}/browse/{key}",
        )

    def create_issue(
        self,
        *,
        project: str,
        title: str,
        body: str,
        issue_type: str = "Bug",
        dry_run: bool = True,
    ) -> WriteResult:
        payload = {
            "fields": {
                "project": {"key": project},
                "summary": title,
                "description": body,
                "issuetype": {"name": issue_type},
            }
        }
        if dry_run:
            return WriteResult(
                dry_run=True, target=project, action="create", payload=payload,
            )
        self._check_write_allowed(project)
        data = self._api_post("/rest/api/2/issue", payload)
        new_key = (data or {}).get("key")
        return WriteResult(
            dry_run=False,
            target=project,
            action="create",
            payload=payload,
            key=new_key,
            url=f"{self._base_url}/browse/{new_key}" if new_key else None,
        )

    # ---- internals ------------------------------------------------------

    def _check_write_allowed(self, project: str) -> None:
        if not self._allowed:
            raise WriteRefusedError(
                "Write operations are disabled: add the project key to "
                "`jira.write_allowed_projects` in your config.yaml to opt in."
            )
        if project.upper() not in self._allowed:
            raise WriteRefusedError(
                f"Project {project!r} is not in write_allowed_projects "
                f"{sorted(self._allowed)}."
            )

    def _api_get(self, path: str, *, params: Optional[dict[str, Any]] = None) -> dict[str, Any]:
        session = self._get_session()
        log.debug("GET %s%s", self._base_url, path)
        resp = session.get(
            f"{self._base_url}{path}",
            params=params,
            timeout=self._timeout,
            headers={"Accept": "application/json"},
        )
        resp.raise_for_status()
        return resp.json()

    def _api_post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        session = self._get_session()
        resp = session.post(
            f"{self._base_url}{path}",
            json=payload,
            timeout=self._timeout,
            headers={"Accept": "application/json", "Content-Type": "application/json"},
        )
        resp.raise_for_status()
        if resp.status_code == 204 or not resp.content:
            return {}
        return resp.json()

    # ---- parsing helpers (shared-ish with the API client) ---------------

    def _parse_comments(self, comment_block: dict[str, Any]) -> list[Comment]:
        result: list[Comment] = []
        for c in comment_block.get("comments", []) or []:
            result.append(
                Comment(
                    id=str(c.get("id")),
                    author=self._user_display(c.get("author")) or "unknown",
                    created=self._parse_dt(c.get("created")) or datetime.min,
                    body=self._coerce_text(c.get("body")),
                    attachments=[],
                )
            )
        return result

    def _parse_attachment(self, a: dict[str, Any]) -> Attachment:
        return Attachment(
            id=str(a.get("id")),
            filename=a.get("filename") or f"attachment_{a.get('id')}",
            mime_type=a.get("mimeType"),
            size_bytes=a.get("size"),
            url=a.get("content") or "",
            created=self._parse_dt(a.get("created")),
        )

    @staticmethod
    def _user_display(user: Optional[dict[str, Any]]) -> Optional[str]:
        if not user:
            return None
        return user.get("displayName") or user.get("name") or user.get("emailAddress")

    @staticmethod
    def _parse_dt(value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        try:
            return dtparser.isoparse(value)
        except (ValueError, TypeError):
            return None

    @staticmethod
    def _coerce_text(value: Any) -> str:
        # Jira Server / DC returns plain strings (wiki markup). Cloud returns
        # ADF dicts — we don't expect those here but handle gracefully.
        if value is None:
            return ""
        if isinstance(value, str):
            return value
        return str(value)
