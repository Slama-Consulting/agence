"""Filesystem helpers used across the project."""

from __future__ import annotations

import re
from pathlib import Path

_UNSAFE = re.compile(r"[^A-Za-z0-9._-]+")


def safe_filename(name: str, *, fallback: str = "file") -> str:
    """Return a filesystem-safe version of ``name``.

    Keeps alphanumerics, dot, underscore and dash; collapses everything else
    into a single underscore. Falls back to ``fallback`` if the result is empty.
    """
    cleaned = _UNSAFE.sub("_", name).strip("._")
    return cleaned or fallback


def ensure_dir(path: Path) -> Path:
    """Create ``path`` (and parents) if missing, return it."""
    path.mkdir(parents=True, exist_ok=True)
    return path
