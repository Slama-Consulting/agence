"""BugHound - trace bugs from Jira tickets to logs and videos."""

__version__ = "0.1.0"
