"""Shared data models used across the BugHound pipeline."""

from __future__ import annotations

from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Literal, Optional

from pydantic import BaseModel, Field, model_validator


class TicketType(str, Enum):
    """High-level intent of a Jira ticket."""

    DEV = "dev"            # new feature / development work
    FIX = "fix"            # bug fix
    REFACTOR = "refactor"
    DOC = "doc"
    TASK = "task"          # generic task / chore
    QUESTION = "question"
    OTHER = "other"
    UNKNOWN = "unknown"


class Attachment(BaseModel):
    """A file attached to a ticket or a comment."""

    id: str
    filename: str
    mime_type: Optional[str] = None
    size_bytes: Optional[int] = None
    url: str
    # Creation/upload time reported by Jira, used to keep only the most
    # recent batch of attachments when a ticket accumulates old dumps.
    created: Optional[datetime] = None
    # Populated after download
    local_path: Optional[Path] = None


class Comment(BaseModel):
    """A comment on a Jira ticket."""

    id: str
    author: str
    created: datetime
    body: str
    attachments: list[Attachment] = Field(default_factory=list)


class Ticket(BaseModel):
    """A Jira ticket with its full context."""

    key: str                       # e.g. PROJ-123
    title: str
    description: str
    status: Optional[str] = None
    reporter: Optional[str] = None
    assignee: Optional[str] = None
    labels: list[str] = Field(default_factory=list)
    components: list[str] = Field(default_factory=list)
    issue_type_name: str = ""
    created: Optional[datetime] = None
    updated: Optional[datetime] = None
    attachments: list[Attachment] = Field(default_factory=list)
    comments: list[Comment] = Field(default_factory=list)
    url: Optional[str] = None


class CommentRelevance(BaseModel):
    """LLM-assessed relevance of a single comment to the reported bug."""

    comment_id: str
    is_relevant: bool
    confidence: float = Field(ge=0.0, le=1.0)
    reason: str


class TicketAnalysis(BaseModel):
    """Output of the ticket analyzer."""

    ticket_key: str
    ticket_type: TicketType
    type_confidence: float = Field(ge=0.0, le=1.0)
    summary: str                   # short human-readable summary of the need
    relevant_comments: list[CommentRelevance] = Field(default_factory=list)


class VideoEvent(BaseModel):
    """A candidate "bug moment" detected in a video."""

    timestamp_s: float             # seconds from the start of the video
    wallclock: Optional[datetime] = None  # absolute time if recoverable (e.g. OCR)
    confidence: float = Field(ge=0.0, le=1.0)
    kind: str                      # e.g. "crash_dialog", "anr", "scene_change", "ocr_error"
    evidence: str                  # short description / OCR snippet / detector name
    frame_path: Optional[Path] = None
    # HH:MM or HH:MM:SS read off the on-screen clock by Tesseract. When
    # present, this is what anchors log windows to wall-clock time.
    detected_time: Optional[str] = None


class UserAction(BaseModel):
    """A detected user interaction (tap, navigation…) in the video.

    Produced by scene-change detection over frames sampled every N seconds.
    Used by the reporter to reconstruct reproduction steps alongside the
    LLM-authored narrative.
    """

    timestamp_s: float
    kind: str                      # e.g. "user_action", "freeze"
    evidence: str
    frame_path: Optional[Path] = None


class LogExcerpt(BaseModel):
    """A slice of log lines correlated with a video event."""

    source_file: Path
    anchor_time: datetime
    window_before: timedelta
    window_after: timedelta
    lines: list[str]


class LogWindow(BaseModel):
    """A consolidated log window built from the on-screen clock anchor.

    The pipeline extracts every line timestamped within
    ``[first_seen − pad_before ; last_seen + pad_after]`` across all log
    files, concatenates them chronologically and writes the result to
    ``window_path``. This is what the diagnostician LLM reads instead of
    raw 1-GB logcat dumps.
    """

    source_files: list[Path] = Field(default_factory=list)
    window_path: Path
    start_time: datetime
    end_time: datetime
    line_count: int = 0


class ResolvedProject(BaseModel):
    """A Jira ticket mapped to a local project directory (pydantic mirror
    of :class:`bughound.projects.resolver.ResolvedProject`, kept here to
    avoid a circular dependency when serialising reports)."""

    ticket_key: str
    root: Path
    name: str
    matched_on: str
    score: float = Field(ge=0.0, le=1.0)


class CodeReference(BaseModel):
    """A pointer into the local codebase that is relevant to a bug.

    Built by :class:`bughound.projects.inspector.CodebaseInspector` from
    a fully-qualified class name seen in a stack trace or a log line.
    """

    class_fqn: str                 # e.g. "com.acme.foo.MyActivity"
    file_path: Path                # absolute path on disk
    line: Optional[int] = None     # 1-based line number of the class/ID
    snippet: str = ""              # a few surrounding lines for context


class ProposedFix(BaseModel):
    """A concrete patch proposal for a single file."""

    file_path: Path                # absolute path of the file to edit
    start_line: int = 0            # 1-based start of the block (informational)
    end_line: int = 0              # 1-based end of the block (informational)
    before_snippet: str            # exact string to find in the file
    after_snippet: str             # replacement string
    description: str               # what the change does
    reason: str                    # why it fixes the root cause
    confidence_score: float = Field(ge=0.0, le=1.0)


class AppliedFix(BaseModel):
    """Record of whether a :class:`ProposedFix` was actually written."""

    file_path: Path
    applied: bool
    reason: Optional[str] = None   # populated when ``applied`` is False


class AppliedFixStatus(str, Enum):
    """Display-friendly status for the ``🛠️ Fix`` section of the report.

    Mirrors :class:`AppliedFix` but distinguishes the *reason* a patch
    wasn't applied, so the renderer can pick a clear icon (✔/📝/⚠/✖)
    without re-parsing :attr:`AppliedFix.reason` strings.
    """

    APPLIED = "applied"                  # patch was written to disk
    PROPOSED = "proposed"                # patch produced but not auto-applied
    BELOW_THRESHOLD = "below_threshold"  # confidence < auto-apply threshold
    FAILED = "failed"                    # apply_fix raised an exception
    NOT_AVAILABLE = "not_available"      # no proposed_fix at all


class ReproductionMethod(BaseModel):
    """Structured reproduction recipe for the ``🔁 Méthode de reproduction``.

    Replaces the flat ``BugReport.reproduction_steps: list[str]`` with a
    richer description (preconditions, timing, prior states) so the
    reporter can flag intermittent bugs explicitly. The legacy
    ``reproduction_steps`` field is kept and mirrored from :attr:`steps`
    for backward compatibility (existing JSON consumers).
    """

    is_systematic: bool = True
    preconditions: list[str] = Field(default_factory=list)
    steps: list[str] = Field(default_factory=list)
    timing_notes: Optional[str] = None
    states: Optional[str] = None  # e.g. "lecteur en pause"


class TimelineStep(BaseModel):
    """A single step in the OK/KO timeline narrated by the LLM.

    The LLM tells the bug as a sequence of steps: ones that ran normally
    (``"ok"``) followed by ones that derailed (``"ko"``). Each step has a
    short French description and an optional explanation.
    """

    status: Literal["ok", "ko"]
    description: str  # FR, short sentence
    explanation: Optional[str] = None  # FR, optional detail


class ConfidenceScores(BaseModel):
    """LLM-authored confidence scores for the ``📊`` section.

    Each score lives in ``[0.0, 1.0]``. The LLM is the sole source of
    truth: it justifies its scores from the quality of the logs, the
    coherence with relevant ticket comments, its confidence in the fix
    code and the isolation of the patched file in the code references.
    No deterministic post-processing is applied beyond the
    auto-correction of ``in_module + outside_module`` so the split
    always sums to 1.0.
    """

    root_cause: float = Field(ge=0.0, le=1.0, default=0.0)
    regression: float = Field(ge=0.0, le=1.0, default=0.0)
    fix: float = Field(ge=0.0, le=1.0, default=0.0)
    in_module: float = Field(ge=0.0, le=1.0, default=0.0)
    outside_module: float = Field(ge=0.0, le=1.0, default=0.0)

    @model_validator(mode="after")
    def _check_module_split(self) -> "ConfidenceScores":
        """Force ``outside_module = 1 - in_module`` when the LLM drifts.

        The LLM can produce inconsistent splits like ``in=0.7`` /
        ``out=0.4`` (sum = 1.1). Rather than rejecting the whole
        response, we trust ``in_module`` and recompute ``outside_module``
        clamped to ``[0.0, 1.0]``. This keeps the validator robust to
        slightly noisy LLM JSON without losing useful diagnoses.
        """
        if abs(self.in_module + self.outside_module - 1.0) > 1e-9:
            object.__setattr__(
                self,
                "outside_module",
                max(0.0, min(1.0, 1.0 - self.in_module)),
            )
        return self


class AnalysisMode(str, Enum):
    """Which analyzer drove the report.

    ``LEGACY`` is the historical chain of stateless LLM calls (ticket
    analysis, log diagnosis, fix proposer …). ``MONOLITHIC`` is the
    single-conversation analyzer introduced in the migration plan.
    """

    LEGACY = "legacy"
    MONOLITHIC = "monolithic"
    # ``BEST`` is a handoff mode: BugHound stops after the deterministic
    # ingestion phase and produces a ready-to-execute prompt for an
    # external LLM (Copilot Chat). No internal LLM call is made, so
    # reports built in this mode never carry diagnostic fields.
    BEST = "best"


class BugReport(BaseModel):
    """Final BugHound report for a single ticket."""

    ticket: Ticket
    analysis: TicketAnalysis
    video_events: list[VideoEvent] = Field(default_factory=list)
    user_actions: list[UserAction] = Field(default_factory=list)
    log_excerpts: list[LogExcerpt] = Field(default_factory=list)
    log_window: Optional[LogWindow] = None
    notes: list[str] = Field(default_factory=list)
    project: Optional[ResolvedProject] = None
    doc_md_path: Optional[Path] = None
    code_references: list[CodeReference] = Field(default_factory=list)
    root_cause: Optional[str] = None
    # PO-friendly English summary of the root cause. Optional companion to
    # ``root_cause`` (which stays in French for engineers). Populated by the
    # action-oriented refactor; ``None`` keeps legacy reports unchanged.
    root_cause_en: Optional[str] = None
    reproduction_steps: list[str] = Field(default_factory=list)
    # Richer reproduction recipe used by the ``🔁`` report section.
    # ``reproduction_steps`` (above) is kept and alimented in mirror from
    # ``reproduction_method.steps`` for backward compat.
    reproduction_method: Optional[ReproductionMethod] = None
    # Files / packages at risk of regression by ``proposed_fix``. Populated
    # by the LLM and extended deterministically with code-ref siblings.
    regression_zones: list[str] = Field(default_factory=list)
    # Hybrid confidence scores rendered in the ``📊`` section. ``None``
    # when neither LLM nor heuristics produced a score (legacy fallback).
    confidence_scores: Optional[ConfidenceScores] = None
    # Verbatim log lines the LLM cites as proof of the diagnosis (3-4
    # lines extracted from the log window, in chronological order).
    # Rendered under ``🔍 Cause racine du bug`` as a fenced code block.
    root_cause_evidence_logs: list[str] = Field(default_factory=list)
    # Ordered narrative of what worked (``ok``) and what derailed
    # (``ko``). Rendered as a numbered list under the root-cause section.
    root_cause_timeline: list[TimelineStep] = Field(default_factory=list)
    proposed_fix: Optional[ProposedFix] = None
    applied_fix: Optional[AppliedFix] = None
    # Display-friendly enum mirroring ``applied_fix`` for the report.
    applied_fix_status: AppliedFixStatus = AppliedFixStatus.NOT_AVAILABLE
    # Analyser mode + clarifications surfaced when the monolithic analyser
    # runs. ``analysis_mode`` defaults to LEGACY so existing reports keep
    # their previous behaviour and serialised payloads stay readable.
    analysis_mode: AnalysisMode = AnalysisMode.LEGACY
    clarifications_asked: list[str] = Field(default_factory=list)
    # Pass 2 — confirmation analysis built from an older log+video pair when
    # the primary (pass 1) anchor was an isolated log. All fields default to
    # empty so call-sites that never run pass 2 behave exactly as before.
    log_window_confirmation: Optional[LogWindow] = None
    root_cause_confirmation: Optional[str] = None
    reproduction_steps_confirmation: list[str] = Field(default_factory=list)
    video_events_confirmation: list[VideoEvent] = Field(default_factory=list)
    user_actions_confirmation: list[UserAction] = Field(default_factory=list)
    log_excerpts_confirmation: list[LogExcerpt] = Field(default_factory=list)
    # Human-readable label of the source used for pass 2, e.g.
    # "mlog.log + video.MOV (2026-02-24)". None when pass 2 did not run.
    confirmation_source: Optional[str] = None
