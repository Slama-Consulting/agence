"""Detect the clock time displayed on screen in a video.

Android screen recordings almost always expose the system clock in the
status bar (``HH:MM``), sometimes even with seconds. Reading it off the
frames with Tesseract gives us a rock-solid **anchor** to correlate the
video playback with the logcat wall-clock time — far more reliable than
pattern-matching on error strings like "has stopped".

The detector samples one frame every ``sample_interval_s`` seconds,
runs OCR on each, and keeps every ``HH:MM`` (or ``HH:MM:SS``) match it
sees. Frames are optionally dumped to disk so the reporter can embed
them as evidence.

A "valid" clock value must look like ``\\b\\d{1,2}:\\d{2}(?::\\d{2})?\\b``
with the hour in 0..23 and the minute/second in 0..59. Anything else
(timer counters, decimal numbers, log lines) is filtered out.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .frames import FrameSource, OpenCVFrameSource
from .ocr import OcrEngine

log = logging.getLogger(__name__)


# Accept ``HH:MM`` and ``HH:MM:SS`` (with the seconds optional). The word
# boundaries avoid matching things like ``12:345`` or ``abc12:34``.
_TIME_RE = re.compile(r"\b(\d{1,2}):(\d{2})(?::(\d{2}))?\b")

# Fallback: accept a *partial* clock reading ``HH:M`` when the last digit
# is cut off at the frame edge.  The pattern requires the match to be at the
# end of the string (possibly followed by whitespace/noise) so it does not
# fire on arbitrary numbers inside a larger string.
# We only trust this when the single minute digit is 0–5 (valid tens digit).
_PARTIAL_TIME_RE = re.compile(r"\b(\d{1,2}):(\d)[^\d]*$")

# Vertical strip positions (as fractions of frame height) tried in order.
# Each entry is ``(y0_frac, y1_frac, x0_frac)`` where ``x0_frac`` is the
# leftmost column as a fraction of frame width (1.0 = right edge).
#
# Strategy:
#   • Full-width strips cover standard Android phone self-recordings.
#   • Right-side-only strips (x0≥0.50) target car-screen-in-phone-video
#     scenarios where the IVI display fills the right portion of the frame
#     and its status bar is cut at the right edge.
#   • Far-right strips (x0≥0.85) cover cases where the car-screen clock is
#     at the very right edge of the phone frame and partially cut off.
_STATUS_BAR_STRIPS: list[tuple[float, float, float]] = [
    # (y0_frac, y1_frac, x0_frac)
    #
    # Trimmed list to slash multi-crop Tesseract spawns. We keep only the
    # empirically most useful strips:
    #   - the phone's own status bar (full-width, tall variant covers both
    #     short and tall status bars),
    #   - the embedded car-screen status bar (full-width and right-half),
    #   - the tightest IVI-clock-only strips at the far-right edge,
    #   - the lower-IVI strips for phones held below the dashboard line,
    #   - a Renault-Duster strip (clock sits noticeably lower than other
    #     IVIs because the dashboard tilts the screen — verified on
    #     CCSEXT-235266 where the clock is at y_frac≈0.49).
    # The dropped variants were 1 %-tolerance duplicates of these.
    (0.00, 0.10, 0.00),   # phone own status bar — full width, tall
    (0.27, 0.36, 0.00),   # car screen status bar — full width
    (0.27, 0.36, 0.50),   # car screen status bar — right half
    (0.270, 0.305, 0.917),  # IVI clock zone — tightest, most reliable
    (0.40, 0.50, 0.78),     # IVI clock zone (low) — right portion
    (0.42, 0.46, 0.83),     # IVI clock zone (low) — tight on clock
    (0.46, 0.55, 0.78),     # Renault Duster IVI — clock at y≈0.49, x≥0.82
]

# Scale factors applied before OCR.  4× is the workhorse for full-width
# status-bar strips and binarises cleanly even on 720×1280 portrait
# screen-of-screen recordings; the previous 6× variant doubled the
# Tesseract cost without improving precision in our test corpus.
_OCR_UPSCALES: tuple[int, ...] = (4,)


@dataclass(frozen=True)
class DisplayTimeSample:
    """A single frame where the on-screen clock could be read.

    ``wallclock_hhmm`` is a ``HH:MM`` or ``HH:MM:SS`` string (zero-padded
    hour). ``frame_path`` points at the dumped PNG when the detector was
    asked to persist frames.

    ``source_video`` records which video file the sample came from. This
    is required when several videos are analysed in the same pipeline run
    so downstream code can build a *per-video* anchor instead of projecting
    every sample through the first video's anchor (which would be wrong as
    soon as two recordings happened at different wall-clock times).
    """

    frame_time_s: float
    wallclock_hhmm: str
    text: str
    frame_path: Optional[Path] = None
    source_video: Optional[Path] = None


class DisplayTimeDetector:
    """Extract ``HH:MM(:SS)`` clock readings from sampled video frames."""

    def __init__(
        self,
        engine: OcrEngine,
        *,
        sample_interval_s: float = 10.0,
        # Ignore OCR text shorter than this to skip near-empty frames.
        min_text_length: int = 2,
        # Early-exit threshold: stop OCR-ing the rest of the video once we
        # have collected ``early_stop_after`` samples that all agree within
        # ±2 min of each other. The downstream log-window only needs *one*
        # solid wall-clock anchor per video, so spending CPU on every
        # subsequent frame is pure waste. ``None`` disables the optimisation
        # and keeps the legacy behaviour (scan the whole video).
        early_stop_after: Optional[int] = 2,
    ) -> None:
        if sample_interval_s <= 0:
            raise ValueError("sample_interval_s must be > 0")
        self._engine = engine
        self._sample_interval_s = sample_interval_s
        self._min_text_length = min_text_length
        self._early_stop_after = (
            None if early_stop_after is None else max(1, int(early_stop_after))
        )

    # ---- public API -------------------------------------------------------

    def detect_from_source(
        self,
        source: FrameSource,
        *,
        frames_dir: Optional[Path] = None,
        source_video: Optional[Path] = None,
    ) -> list[DisplayTimeSample]:
        """Walk ``source``, OCR each frame, keep the ones with a clock.

        When ``frames_dir`` is provided, each kept frame is written as
        ``frame_<index>.png`` so callers can embed it in the report.

        ``source_video`` is stamped on every produced sample so the pipeline
        can group samples by recording when several videos are analysed in
        sequence.

        After collection, samples are passed through a *consistency filter*
        that drops isolated readings (likely Tesseract hallucinations) when
        at least three samples were captured.

        **Early-exit optimisation**: when ``early_stop_after`` samples agree
        within ±2 min of each other, the loop breaks immediately. The
        downstream log-window pipeline only needs one solid anchor per
        video, so wasting CPU on every subsequent frame is pointless —
        without this guard a 6-min video can spend 6+ min in Tesseract
        even when the very first frame already exposed the clock.
        """
        raw: list[DisplayTimeSample] = []
        for frame in source.iter_frames():
            hhmm, ocr_text = self._detect_clock(frame.image)
            if hhmm is None:
                continue

            frame_path: Optional[Path] = None
            if frames_dir is not None:
                frame_path = _dump_frame(frame.image, frames_dir, frame.index)

            raw.append(
                DisplayTimeSample(
                    frame_time_s=frame.timestamp_s,
                    wallclock_hhmm=hhmm,
                    text=ocr_text,
                    frame_path=frame_path,
                    source_video=source_video,
                )
            )
            # Stop early when we have enough mutually-coherent readings.
            if self._has_enough_coherent_samples(raw):
                break
        return _filter_consistent(raw)

    def _has_enough_coherent_samples(
        self, samples: list[DisplayTimeSample]
    ) -> bool:
        """Return True when ``samples`` already contains a solid anchor.

        We say "solid" when at least ``early_stop_after`` distinct readings
        agree within ±2 min on minutes-of-day. This is the same coherence
        rule used by :func:`_filter_consistent`, applied online so the
        loop can break as soon as the rule is satisfied.
        """
        if self._early_stop_after is None:
            return False
        if len(samples) < self._early_stop_after:
            return False
        minutes: list[int] = []
        for s in samples:
            m = _TIME_RE.match(s.wallclock_hhmm)
            if m is None:
                continue
            minutes.append(int(m.group(1)) * 60 + int(m.group(2)))
        if len(minutes) < self._early_stop_after:
            return False
        # Find the largest cluster of mutually-close readings (±2 min).
        # Greedy: for each value, count how many others are within ±2 min.
        for anchor in minutes:
            close = sum(1 for m in minutes if abs(m - anchor) <= 2)
            if close >= self._early_stop_after:
                return True
        return False

    # ---- internal helpers -------------------------------------------------

    def _detect_clock(self, image: Any) -> tuple[Optional[str], str]:
        """Try to extract an ``HH:MM`` clock from ``image``.

        Strategy (in order):

        1. **Full-frame layout-aware OCR** via ``engine.read_clock_data()``
           (PSM 11 + 6, no whitelist, returns per-word confidence + bbox).
           This is the most reliable path on real video frames where the
           clock can sit anywhere — typically the IVI clock filmed by a
           phone, which our hard-coded status-bar strips don't cover.
           **Spatial filter**: only candidates whose bbox falls in the
           **top-right region** of the frame (``x ≥ W/2`` and
           ``y + h ≤ H * 0.6``) are considered, since on every supported
           IVI the genuine clock sits in that region. The 0.6 threshold
           (rather than 0.5) covers tilted dashboards like the Renault
           Duster where the clock can fall slightly past the midline
           (verified on CCSEXT-235266 where the clock is at y_frac≈0.52).
           Candidates outside the zone are dropped — even when their OCR
           confidence is high, they are almost always digits scraped off
           other UI elements. Among the remaining candidates we pick the
           highest-confidence ``HH:MM(:SS)`` reading.
        2. **Status-bar crop scan** via ``_extract_candidates_from_frame``
           + ``read_clock_text`` (legacy path). Useful for raw Android
           screen recordings where the clock sits in a known strip and
           ``image_to_data`` is unavailable.
        3. **Raw full-frame OCR fallback** for test fakes and non-OpenCV
           environments.

        Returns ``(hhmm_string, ocr_text)`` or ``(None, "")`` on failure.
        """
        # 1. Layout-aware path: only available when the engine implements
        # ``read_clock_data`` *and* we have a real (numpy) frame.
        try:
            import numpy as np  # local import to keep numpy optional
            is_ndarray = isinstance(image, np.ndarray)
        except ImportError:  # pragma: no cover - env-dependent
            is_ndarray = False

        read_clock_data = getattr(self._engine, "read_clock_data", None)
        if callable(read_clock_data) and is_ndarray:
            try:
                items = read_clock_data(image)
            except Exception as exc:  # pragma: no cover - defensive
                log.debug("read_clock_data failed: %s", exc)
                items = []
            # Compute the top-right zone boundaries once per frame.
            try:
                frame_h, frame_w = image.shape[:2]
            except (AttributeError, ValueError):  # pragma: no cover
                frame_h, frame_w = 0, 0
            x_min = frame_w / 2.0
            # Use 0.6 (rather than 0.5) so the spatial filter accepts IVIs
            # whose clock sits slightly below the midline because of a
            # tilted dashboard (e.g. Renault Duster — see CCSEXT-235266).
            y_max = frame_h * 0.6

            best: tuple[Optional[str], int, str] = (None, -1, "")
            for item in items:
                # Backwards compat: legacy engines may still return 2-tuples
                # without bbox. Treat them as "unknown position" and skip
                # the spatial filter so older fakes keep working.
                if len(item) == 3:
                    txt, conf, bbox = item
                else:  # pragma: no cover - legacy fakes
                    txt, conf = item
                    bbox = None
                hhmm = _pick_best_clock(txt)
                if hhmm is None:
                    continue
                # Spatial filter: drop candidates outside the IVI clock
                # zone (top-right quadrant). When we don't have a bbox or
                # frame dimensions we fall back to legacy behaviour
                # (no spatial filter) to keep test fakes working.
                if bbox is not None and frame_w > 0 and frame_h > 0:
                    bx, by, bw, bh = bbox
                    in_top = (by + bh) <= y_max
                    in_right = bx >= x_min
                    if not (in_top and in_right):
                        continue
                if conf > best[1]:
                    best = (hhmm, conf, txt)
            # Only trust the layout path when confidence is decent.
            # Below 50, Tesseract is essentially guessing and we'd rather
            # fall through to the strip-scan or full-frame fallback.
            if best[0] is not None and best[1] >= 50:
                return best[0], best[2].strip()

        # 2. Multi-crop + preprocessing path (real video frames).
        for candidate in _extract_candidates_from_frame(image):
            try:
                text = self._ocr_clock(candidate)
            except Exception as exc:  # pragma: no cover - defensive
                log.debug("Clock OCR failed on candidate crop: %s", exc)
                continue
            if text and len(text.strip()) >= self._min_text_length:
                hhmm = _pick_best_clock(text)
                if hhmm is not None:
                    return hhmm, text.strip()

        # 3. Fallback: full-frame (or fake) OCR.
        try:
            text = self._ocr_clock(image)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("OCR engine failed on frame: %s", exc)
            return None, ""
        if not text or len(text.strip()) < self._min_text_length:
            return None, ""
        hhmm = _pick_best_clock(text)
        return (hhmm, text.strip()) if hhmm is not None else (None, "")

    def _ocr_clock(self, image: Any) -> str:
        """Run OCR with clock-optimised settings when the engine supports it.

        Prefers ``engine.read_clock_text()`` (``--psm 7``, digit whitelist)
        over the generic ``engine.read_text()`` so that Tesseract is less
        likely to hallucinate letters on tiny status-bar strips.
        """
        read_clock = getattr(self._engine, "read_clock_text", None)
        if callable(read_clock):
            return read_clock(image)
        return self._engine.read_text(image)

    def detect(
        self,
        video_path: Path,
        *,
        frames_dir: Optional[Path] = None,
    ) -> list[DisplayTimeSample]:
        """Sample ``video_path`` every ``sample_interval_s`` and detect times."""
        source = OpenCVFrameSource(
            video_path, sample_interval_s=self._sample_interval_s
        )
        return self.detect_from_source(
            source, frames_dir=frames_dir, source_video=video_path
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_candidates_from_frame(image: Any) -> list[Any]:
    """Return preprocessed status-bar crops ready for clock OCR.

    Slices several horizontal strips at positions defined by
    ``_STATUS_BAR_STRIPS``, upscales each by ``_OCR_UPSCALE`` and
    binarises each (both normal and inverted polarity) so Tesseract works on
    clean black-on-white images regardless of the status-bar colour scheme.

    Far-right strips (x0_frac ≥ 0.85) are included specifically to handle
    car-screen recordings where the IVI clock sits at the very right edge of
    the phone frame and its last digit may be partially cut off.  Combined
    with the ``_PARTIAL_TIME_RE`` fallback in ``_pick_best_clock``, this
    lets the detector recover a ``HH:M0`` anchor even when one digit is
    missing.

    Returns an empty list when ``image`` is not a numpy ndarray (e.g. test
    fakes) or when OpenCV / numpy are not installed.
    """
    try:
        import cv2
        import numpy as np
    except ImportError:  # pragma: no cover - env-dependent
        return []

    if not isinstance(image, np.ndarray):
        return []

    h, w = image.shape[:2]
    candidates: list[Any] = []

    for y0_frac, y1_frac, x0_frac in _STATUS_BAR_STRIPS:
        y0 = int(h * y0_frac)
        y1 = max(int(h * y1_frac), y0 + 1)
        x0 = int(w * x0_frac)
        strip = image[y0:y1, x0:]
        if strip.size == 0:
            continue
        gray = cv2.cvtColor(strip, cv2.COLOR_BGR2GRAY) if strip.ndim == 3 else strip.copy()
        # Try every configured upscale factor: small clocks in compressed
        # screen-of-screen recordings need a larger zoom (×6) to binarise
        # cleanly, while crisp Android status bars are usually fine at ×4.
        for scale in _OCR_UPSCALES:
            up = cv2.resize(
                gray,
                (gray.shape[1] * scale, gray.shape[0] * scale),
                interpolation=cv2.INTER_CUBIC,
            )
            _, thresh_norm = cv2.threshold(up, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            _, thresh_inv = cv2.threshold(up, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            candidates.extend([thresh_norm, thresh_inv])

    return candidates


def _pick_best_clock(text: str) -> Optional[str]:
    """Return the most plausible ``HH:MM(:SS)`` string found in ``text``.

    When several matches coexist (e.g. the status bar clock + an elapsed
    timer in the UI), we prefer the one whose hour stays in 0..23 and
    whose minutes/seconds stay in 0..59. If multiple candidates pass,
    we keep the longest (``HH:MM:SS`` > ``HH:MM``) to maximise precision.

    **Partial reading fallback**: when the last digit of the minutes is cut
    at the frame edge, Tesseract may only return ``HH:M`` (one minute digit).
    In that case we accept the match and pad the missing digit with ``0``
    (e.g. ``10:0`` → ``10:00``).  This gives a conservative anchor that is
    at most 9 minutes off — well within the ±5 min log window used downstream.
    """
    best: Optional[str] = None
    for m in _TIME_RE.finditer(text):
        h = int(m.group(1))
        mn = int(m.group(2))
        s_raw = m.group(3)
        s = int(s_raw) if s_raw is not None else None
        if h > 23 or mn > 59 or (s is not None and s > 59):
            continue
        if s is not None:
            candidate = f"{h:02d}:{mn:02d}:{s:02d}"
        else:
            candidate = f"{h:02d}:{mn:02d}"
        # Prefer the longer (more precise) candidate.
        if best is None or len(candidate) > len(best):
            best = candidate

    if best is not None:
        return best

    # Fallback: partial minute digit at end of text (frame-edge cut-off).
    m = _PARTIAL_TIME_RE.search(text)
    if m is not None:
        h = int(m.group(1))
        mn_tens = int(m.group(2))
        if h <= 23 and mn_tens <= 5:  # valid tens digit for minutes (0–5)
            return f"{h:02d}:{mn_tens}0"

    return None


def _filter_consistent(
    samples: list[DisplayTimeSample],
) -> list[DisplayTimeSample]:
    """Drop hallucinated readings that don't agree with their neighbours.

    A genuine on-screen clock is monotonic and changes slowly: between two
    frames captured a few seconds apart the displayed ``HH:MM`` value can
    only stay the same or advance by one minute. Conversely, isolated
    Tesseract hallucinations like ``4:40`` on a frame that actually shows
    only ``22°C`` typically disagree with all other readings.

    Filter logic:

    * fewer than 3 samples → keep them all (we lack the redundancy needed
      to filter safely);
    * otherwise → keep a sample iff at least one *other* sample agrees
      with it within ±2 minutes of total minutes-of-day. We compare on
      the ``HH:MM`` part only; sub-second precision is irrelevant here.

    The order of returned samples is preserved.
    """
    if len(samples) < 3:
        return list(samples)

    def _minutes(s: DisplayTimeSample) -> Optional[int]:
        m = _TIME_RE.match(s.wallclock_hhmm)
        if m is None:
            return None
        h = int(m.group(1))
        mn = int(m.group(2))
        return h * 60 + mn

    minutes = [_minutes(s) for s in samples]
    kept: list[DisplayTimeSample] = []
    for i, s in enumerate(samples):
        mi = minutes[i]
        if mi is None:
            continue
        has_neighbour = False
        for j, mj in enumerate(minutes):
            if i == j or mj is None:
                continue
            if abs(mj - mi) <= 2:
                has_neighbour = True
                break
        if has_neighbour:
            kept.append(s)
    return kept


def _dump_frame(image: object, frames_dir: Path, index: int) -> Optional[Path]:
    """Write ``image`` to ``frames_dir/frame_<index>.png`` using OpenCV.

    Returns ``None`` on any failure so the caller can keep going — the
    clock reading itself is what matters, the PNG is just a nicety.
    """
    try:
        import cv2  # local import: optional dependency
    except ImportError:  # pragma: no cover - env-dependent
        return None
    try:
        frames_dir.mkdir(parents=True, exist_ok=True)
        out = frames_dir / f"frame_{index:03d}.png"
        ok = cv2.imwrite(str(out), image)
        return out if ok else None
    except Exception:  # pragma: no cover - defensive
        return None


__all__ = [
    "DisplayTimeDetector",
    "DisplayTimeSample",
    "_extract_candidates_from_frame",
    "_filter_consistent",
]
