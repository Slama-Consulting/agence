"""Video analyzer: fuses OCR and scene-change evidence into ranked events.

Two public flows live here:

* :meth:`VideoAnalyzer.analyze_video` / :meth:`analyze_source` — the
  legacy flow that fuses OCR error patterns + scene changes into a
  ranked list of :class:`VideoEvent`. Still used by older tests.
* :meth:`detect_display_times` / :meth:`detect_user_actions` — the new
  flow driven by the refactored pipeline: OCR the on-screen clock every
  10 s, and map each scene change into a :class:`UserAction`.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from ..core.models import UserAction, VideoEvent
from .frames import FrameSource, OpenCVFrameSource
from .ocr import OcrDetector, OcrEngine
from .scene import SceneChangeDetector
from .time_ocr import DisplayTimeDetector, DisplayTimeSample

log = logging.getLogger(__name__)


class VideoAnalyzer:
    """Run every detector over a video and return a ranked list of events."""

    def __init__(
        self,
        *,
        ocr_detector: Optional[OcrDetector] = None,
        scene_detector: Optional[SceneChangeDetector] = None,
        display_time_detector: Optional[DisplayTimeDetector] = None,
        # How close two events must be (in seconds) to be treated as the same
        # underlying bug moment and merged.
        merge_window_s: float = 1.5,
    ) -> None:
        self._ocr = ocr_detector
        self._scene = scene_detector
        self._display_time = display_time_detector
        self._merge_window_s = merge_window_s

    # ---- factory helpers --------------------------------------------------

    @classmethod
    def with_defaults(
        cls,
        *,
        ocr_engine: Optional[OcrEngine],
        scene_detector: Optional[SceneChangeDetector] = None,
        display_time_detector: Optional[DisplayTimeDetector] = None,
    ) -> "VideoAnalyzer":
        """Build an analyzer with default detectors.

        ``ocr_engine`` can be ``None`` if the caller doesn't want OCR (e.g.
        Tesseract isn't installed); only scene detection will run in that case.
        When ``ocr_engine`` is provided, a :class:`DisplayTimeDetector` is
        also wired in so the new pipeline can read the on-screen clock.
        """
        ocr = OcrDetector(ocr_engine) if ocr_engine is not None else None
        time_detector = display_time_detector
        if time_detector is None and ocr_engine is not None:
            time_detector = DisplayTimeDetector(ocr_engine)
        return cls(
            ocr_detector=ocr,
            scene_detector=scene_detector or SceneChangeDetector(),
            display_time_detector=time_detector,
        )

    # ---- public API -------------------------------------------------------

    def analyze_source(self, source: FrameSource) -> list[VideoEvent]:
        """Run detectors over an already-built :class:`FrameSource`."""
        events: list[VideoEvent] = []
        if self._ocr is not None:
            try:
                events.extend(self._ocr.detect(source))
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("OCR detector failed: %s", exc)
        if self._scene is not None:
            # NOTE: many FrameSource implementations are generators and can
            # only be iterated once. Callers that want both detectors should
            # use ``analyze_video`` which creates a fresh source per detector.
            try:
                events.extend(self._scene.detect(source))
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("Scene detector failed: %s", exc)

        return self._merge_and_rank(events)

    def detect_display_times(
        self,
        video_path: Path,
        *,
        frames_dir: Optional[Path] = None,
    ) -> list[DisplayTimeSample]:
        """Sample the video every 10 s and OCR the on-screen clock.

        This is the new pipeline's primary way to anchor the video onto
        wall-clock time: the very first and last ``HH:MM`` readings give
        us the ``[first_seen − 5min ; last_seen + 2min]`` log window.
        Returns an empty list when no display-time detector is configured.
        """
        if self._display_time is None:
            return []
        try:
            return self._display_time.detect(video_path, frames_dir=frames_dir)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("Display-time detector failed on %s: %s", video_path, exc)
            return []

    def detect_user_actions(
        self,
        video_path: Path,
        *,
        sample_interval_s: float = 1.0,
    ) -> list[UserAction]:
        """Map each scene change into a ``UserAction`` (tap / navigation / freeze).

        The scene detector already emits ``scene_change`` and ``freeze``
        ``VideoEvent``s; we just repackage them into ``UserAction`` so the
        reporter can reconstruct reproduction steps cleanly. Returns an
        empty list when no scene detector is configured.
        """
        if self._scene is None:
            return []
        source = OpenCVFrameSource(video_path, sample_interval_s=sample_interval_s)
        try:
            events = self._scene.detect(source)
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("Scene detector failed on %s: %s", video_path, exc)
            return []

        actions: list[UserAction] = []
        for ev in events:
            kind = "freeze" if ev.kind == "freeze" else "user_action"
            actions.append(
                UserAction(
                    timestamp_s=ev.timestamp_s,
                    kind=kind,
                    evidence=ev.evidence,
                    frame_path=ev.frame_path,
                )
            )
        return actions

    def analyze_video(
        self,
        video_path: Path,
        *,
        sample_interval_s: float = 1.0,
    ) -> list[VideoEvent]:
        """Analyze a video file on disk, creating fresh frame sources."""
        events: list[VideoEvent] = []
        if self._ocr is not None:
            source = OpenCVFrameSource(video_path, sample_interval_s=sample_interval_s)
            try:
                events.extend(self._ocr.detect(source))
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("OCR detector failed on %s: %s", video_path, exc)
        if self._scene is not None:
            source = OpenCVFrameSource(video_path, sample_interval_s=sample_interval_s)
            try:
                events.extend(self._scene.detect(source))
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("Scene detector failed on %s: %s", video_path, exc)
        return self._merge_and_rank(events)

    # ---- merging / ranking -----------------------------------------------

    def _merge_and_rank(self, events: list[VideoEvent]) -> list[VideoEvent]:
        if not events:
            return []

        # Sort by timestamp, then merge events close in time: if two
        # detectors both fire near the same moment, we boost confidence.
        events_sorted = sorted(events, key=lambda e: e.timestamp_s)
        merged: list[VideoEvent] = []
        for event in events_sorted:
            if merged and abs(event.timestamp_s - merged[-1].timestamp_s) <= self._merge_window_s:
                merged[-1] = _combine(merged[-1], event)
            else:
                merged.append(event)

        # Final ranking: highest confidence first, then earliest timestamp
        # so "strongest + earliest" wins when tied.
        merged.sort(key=lambda e: (-e.confidence, e.timestamp_s))
        return merged


def _combine(a: VideoEvent, b: VideoEvent) -> VideoEvent:
    """Merge two overlapping events into a single, stronger one.

    Confidence is combined as ``1 - (1 - a)(1 - b)`` which is the probability
    of at least one of two independent detectors being right — intuitive and
    stays in [0, 1].
    """
    confidence = 1.0 - (1.0 - a.confidence) * (1.0 - b.confidence)
    if confidence > 1.0:
        confidence = 1.0
    kind = a.kind if a.confidence >= b.confidence else b.kind
    evidence = f"{a.evidence} + {b.evidence}"
    # Anchor on whichever event had the higher confidence.
    anchor = a if a.confidence >= b.confidence else b
    return VideoEvent(
        timestamp_s=anchor.timestamp_s,
        wallclock=anchor.wallclock,
        confidence=confidence,
        kind=kind,
        evidence=evidence,
        frame_path=anchor.frame_path,
    )
