"""Visual scene-change and freeze detection.

Two complementary signals:
  * **Scene change**: abrupt visual transition (crash dialog pops up, screen
    flips to black, new Activity opens). Computed as a histogram distance
    between consecutive sampled frames.
  * **Freeze**: N consecutive frames whose distance to their predecessor is
    near zero — characteristic of an ANR or a frozen UI thread.

The detector relies on a pluggable distance function so tests can inject
deterministic numeric frames instead of real images.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from ..core.models import VideoEvent
from .frames import FrameSource


# Default frame-distance function. Lazily imports OpenCV and falls back to a
# pure-Python one when OpenCV is unavailable (e.g. in tests).
def _default_distance(a: Any, b: Any) -> float:
    try:
        import cv2
        import numpy as np
    except ImportError:  # pragma: no cover - env-dependent
        return _naive_distance(a, b)

    # Work on grayscale histograms; fast and robust to minor noise.
    g1 = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY) if a.ndim == 3 else a
    g2 = cv2.cvtColor(b, cv2.COLOR_BGR2GRAY) if b.ndim == 3 else b
    h1 = cv2.calcHist([g1], [0], None, [32], [0, 256])
    h2 = cv2.calcHist([g2], [0], None, [32], [0, 256])
    cv2.normalize(h1, h1)
    cv2.normalize(h2, h2)
    # Bhattacharyya distance: 0 = identical, 1 = completely different.
    return float(cv2.compareHist(h1, h2, cv2.HISTCMP_BHATTACHARYYA))


def _naive_distance(a: Any, b: Any) -> float:
    """Fallback distance: absolute difference over summable payloads.

    Works when the test passes plain numbers or tuples as frame images.
    """
    try:
        return float(abs(float(a) - float(b)))
    except (TypeError, ValueError):
        return 1.0 if a != b else 0.0


class SceneChangeDetector:
    """Emit video events on abrupt visual changes and prolonged freezes."""

    def __init__(
        self,
        *,
        change_threshold: float = 0.35,
        freeze_distance: float = 0.02,
        freeze_frames: int = 5,
        distance_fn: Optional[Callable[[Any, Any], float]] = None,
    ) -> None:
        """
        Args:
            change_threshold: minimum distance to call a pair a "scene change".
            freeze_distance:  below this distance, two frames are considered
                              identical.
            freeze_frames:    how many consecutive near-identical frames must
                              be observed to emit a freeze event.
            distance_fn:      override the default OpenCV-based distance.
        """
        self._change_threshold = change_threshold
        self._freeze_distance = freeze_distance
        self._freeze_frames = max(2, freeze_frames)
        self._distance = distance_fn or _default_distance

    def detect(self, source: FrameSource) -> list[VideoEvent]:
        events: list[VideoEvent] = []
        prev_image: Any = None
        prev_ts: float = 0.0
        freeze_start_ts: Optional[float] = None
        freeze_count = 0
        freeze_emitted = False

        for frame in source.iter_frames():
            if prev_image is None:
                prev_image = frame.image
                prev_ts = frame.timestamp_s
                continue

            distance = self._distance(prev_image, frame.image)

            if distance >= self._change_threshold:
                events.append(
                    VideoEvent(
                        timestamp_s=frame.timestamp_s,
                        confidence=_scale(distance, self._change_threshold, 1.0),
                        kind="scene_change",
                        evidence=f"histogram distance={distance:.3f}",
                    )
                )
                # A strong change breaks any ongoing freeze streak.
                freeze_start_ts = None
                freeze_count = 0
                freeze_emitted = False
            elif distance <= self._freeze_distance:
                if freeze_start_ts is None:
                    freeze_start_ts = prev_ts
                    freeze_count = 1
                freeze_count += 1
                if freeze_count >= self._freeze_frames and not freeze_emitted:
                    events.append(
                        VideoEvent(
                            timestamp_s=freeze_start_ts,
                            confidence=0.7,
                            kind="freeze",
                            evidence=(
                                f"{freeze_count} near-identical frames "
                                f"(distance<= {self._freeze_distance:.3f})"
                            ),
                        )
                    )
                    freeze_emitted = True
            else:
                freeze_start_ts = None
                freeze_count = 0
                freeze_emitted = False

            prev_image = frame.image
            prev_ts = frame.timestamp_s

        return events


def _scale(value: float, lo: float, hi: float) -> float:
    """Map ``value`` from [lo, hi] to [0.0, 1.0], clamped."""
    if hi <= lo:
        return 1.0
    scaled = (value - lo) / (hi - lo)
    if scaled < 0.0:
        return 0.0
    if scaled > 1.0:
        return 1.0
    return scaled
