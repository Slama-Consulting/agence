"""Frame sampling primitives.

A ``FrameSource`` knows how to walk a video file and yield sampled frames.
Detectors consume this interface so they can be tested with in-memory fakes
without OpenCV being installed.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterator, Protocol


@dataclass(frozen=True)
class Frame:
    """A single sampled video frame.

    ``image`` is intentionally typed as ``Any`` so the project can run without
    numpy at import time; the real backend produces a numpy.ndarray while tests
    can feed arbitrary sentinels (strings, tuples, mocks).
    """

    index: int          # frame index in the sampled stream (0-based)
    timestamp_s: float  # wall-clock position in the video, in seconds
    image: Any          # numpy.ndarray in prod; any object in tests


class FrameSource(Protocol):
    """Protocol every frame sampler implements."""

    def iter_frames(self) -> Iterator[Frame]:  # pragma: no cover - protocol
        ...


class OpenCVFrameSource:
    """Sample frames from a video file using OpenCV.

    Sampling is time-based (one frame every ``sample_interval_s`` seconds)
    rather than frame-based, so detectors don't need to know the video FPS.

    OpenCV is imported lazily: users who never call ``iter_frames`` don't need
    the dependency installed.
    """

    def __init__(self, video_path: Path, *, sample_interval_s: float = 1.0) -> None:
        if sample_interval_s <= 0:
            raise ValueError("sample_interval_s must be > 0")
        self._path = video_path
        self._interval = sample_interval_s

    def iter_frames(self) -> Iterator[Frame]:
        try:
            import cv2  # local import: keep optional
        except ImportError as exc:  # pragma: no cover - env-dependent
            raise RuntimeError(
                "opencv-python is required to read videos. "
                "Install it via `pip install opencv-python`."
            ) from exc

        capture = cv2.VideoCapture(str(self._path))
        if not capture.isOpened():
            raise RuntimeError(f"Could not open video: {self._path}")

        try:
            fps = capture.get(cv2.CAP_PROP_FPS) or 0.0
            if fps <= 0:
                # Fallback: assume 30fps if the container doesn't report FPS.
                fps = 30.0

            frame_step = max(int(round(fps * self._interval)), 1)
            idx = 0
            sampled_index = 0
            while True:
                ok, image = capture.read()
                if not ok:
                    break
                if idx % frame_step == 0:
                    yield Frame(
                        index=sampled_index,
                        timestamp_s=idx / fps,
                        image=image,
                    )
                    sampled_index += 1
                idx += 1
        finally:
            capture.release()
