"""OCR-based bug detection in video frames.

The detector walks a :class:`FrameSource`, runs OCR on every sampled frame,
and emits a :class:`VideoEvent` whenever the extracted text matches a known
error pattern (crash dialog, ANR, stack trace keyword, ...).
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Iterable, Optional, Protocol

from ..core.models import VideoEvent
from .frames import Frame, FrameSource


# ---------------------------------------------------------------------------
# OCR engine abstraction
# ---------------------------------------------------------------------------


class OcrEngine(Protocol):
    """Anything that turns a frame image into text."""

    def read_text(self, image: Any) -> str:  # pragma: no cover - protocol
        ...


class TesseractOcrEngine:
    """Real OCR engine backed by ``pytesseract``.

    ``pytesseract`` is imported lazily so users who only use fakes (or the
    copilot mode) don't need Tesseract installed.
    """

    def __init__(self, *, tesseract_cmd: Optional[Path] = None, lang: str = "eng") -> None:
        try:
            import pytesseract  # local import
        except ImportError as exc:  # pragma: no cover - env-dependent
            raise RuntimeError(
                "pytesseract is required for OCR. "
                "Install it via `pip install pytesseract` and the tesseract binary."
            ) from exc

        if tesseract_cmd is not None:
            pytesseract.pytesseract.tesseract_cmd = str(tesseract_cmd)
        self._pytesseract = pytesseract
        self._lang = lang

    def read_text(self, image: Any) -> str:
        return self._pytesseract.image_to_string(image, lang=self._lang)

    def read_clock_text(self, image: Any) -> str:
        """OCR optimised for reading ``HH:MM`` status-bar clocks.

        Runs Tesseract under two page-segmentation modes and
        concatenates the outputs so the caller's regex can match in any
        of them. The whitelist ``0123456789:`` keeps Tesseract focused
        on clock glyphs, which dramatically reduces hallucinations on
        the small status-bar crops produced by ``_extract_candidates``.

        * ``PSM 7`` (single line) — works on tight crops where only
          ``HH:MM`` is left after preprocessing.
        * ``PSM 11`` (sparse text) — best when the clock is small and
          surrounded by other UI elements on the same row.

        Trimmed from 5 configs to 2 (PSM 6 + the two whitelist-free
        fallbacks dropped). The layout-aware path
        :meth:`read_clock_data` already covers the no-whitelist
        scenarios with better spatial context, so the extra Tesseract
        spawns here were pure overhead.

        Returning a concatenation rather than the "best" candidate keeps
        this method dumb on purpose: the consumer (`_pick_best_clock`)
        already knows how to pick the most plausible ``HH:MM(:SS)``
        match out of noisy text.
        """
        outputs: list[str] = []
        whitelist = "tessedit_char_whitelist=0123456789:"
        configs = (
            f"--psm 7 --oem 3 -c {whitelist}",
            f"--psm 11 --oem 3 -c {whitelist}",
        )
        for config in configs:
            try:
                txt = self._pytesseract.image_to_string(
                    image, lang=self._lang, config=config
                )
            except Exception:  # pragma: no cover - defensive
                continue
            if txt:
                outputs.append(txt)
        return "\n".join(outputs)

    def read_clock_data(
        self, image: Any
    ) -> list[tuple[str, int, Optional[tuple[int, int, int, int]]]]:
        """Run Tesseract on the *full* image and return ``(text, conf, bbox)``.

        Unlike :meth:`read_clock_text`, this path:

        * processes the **whole frame** (not a pre-cropped status-bar strip),
          so it works on screen-of-screen recordings where the clock is at
          arbitrary positions (e.g. car-IVI clock filmed by a phone);
        * uses **PSM 11 + 6** (sparse / block layout) — clocks usually sit
          next to other glyphs (`23°C ・ 09:09`) and PSM 7 splits them off
          incorrectly;
        * keeps the **default Tesseract dictionary** (no whitelist) so
          surrounding context is recognised, which dramatically improves
          word segmentation on the clock token itself;
        * returns each recognised word with its per-word confidence and a
          ``(left, top, width, height)`` bounding box so callers can
          spatially filter candidates (e.g. keep only those in the top-right
          quadrant of the frame, where the IVI clock sits). The bbox is
          ``None`` when Tesseract didn't expose a coordinate for the item.

        The method is best-effort: it returns ``[]`` on any failure rather
        than raising, so the legacy strip-scanning path still runs.
        """
        results: list[tuple[str, int, Optional[tuple[int, int, int, int]]]] = []
        # PSM 11: sparse text — best for an isolated clock on a busy frame.
        # PSM 6: assume a single uniform block of text — picks up clocks
        # embedded in a status bar line (`23°C ・ 09:09`).
        for psm in (11, 6):
            config = f"--psm {psm} --oem 3"
            try:
                data = self._pytesseract.image_to_data(
                    image,
                    lang=self._lang,
                    config=config,
                    output_type=self._pytesseract.Output.DICT,
                )
            except Exception:  # pragma: no cover - defensive (env / corrupt frame)
                continue
            words = data.get("text", [])
            confs = data.get("conf", [])
            lefts = data.get("left", [])
            tops = data.get("top", [])
            widths = data.get("width", [])
            heights = data.get("height", [])
            for i, (txt, conf) in enumerate(zip(words, confs)):
                if not txt or not txt.strip():
                    continue
                try:
                    conf_i = int(conf)
                except (TypeError, ValueError):
                    conf_i = -1
                bbox: Optional[tuple[int, int, int, int]] = None
                try:
                    bbox = (
                        int(lefts[i]),
                        int(tops[i]),
                        int(widths[i]),
                        int(heights[i]),
                    )
                except (IndexError, TypeError, ValueError):
                    bbox = None
                results.append((txt, conf_i, bbox))
            # Also expose recomposed lines so adjacent tokens like
            # ``23°C`` ``-`` ``09:09`` can be matched together when the
            # word-level scan fragments them. The line-level bbox is the
            # union of its word bboxes.
            from collections import defaultdict
            lines: dict[
                tuple[int, int, int],
                list[tuple[int, str, int, Optional[tuple[int, int, int, int]]]],
            ] = defaultdict(list)
            for i, txt in enumerate(words):
                if not txt or not txt.strip():
                    continue
                try:
                    conf_i = int(confs[i])
                except (TypeError, ValueError):
                    conf_i = -1
                try:
                    word_bbox: Optional[tuple[int, int, int, int]] = (
                        int(lefts[i]),
                        int(tops[i]),
                        int(widths[i]),
                        int(heights[i]),
                    )
                except (IndexError, TypeError, ValueError):
                    word_bbox = None
                key = (
                    int(data.get("block_num", [0])[i]),
                    int(data.get("par_num", [0])[i]),
                    int(data.get("line_num", [0])[i]),
                )
                lines[key].append(
                    (int(data.get("left", [0])[i]), txt, conf_i, word_bbox)
                )
            for items in lines.values():
                items.sort()
                joined = " ".join(t for _, t, _, _ in items)
                if not joined.strip():
                    continue
                avg_conf = max(0, sum(c for *_, c, _ in items) // len(items))
                line_bbox: Optional[tuple[int, int, int, int]] = None
                word_bboxes = [b for *_, b in items if b is not None]
                if word_bboxes:
                    xs = [b[0] for b in word_bboxes]
                    ys = [b[1] for b in word_bboxes]
                    rs = [b[0] + b[2] for b in word_bboxes]
                    bs = [b[1] + b[3] for b in word_bboxes]
                    line_bbox = (
                        min(xs),
                        min(ys),
                        max(rs) - min(xs),
                        max(bs) - min(ys),
                    )
                results.append((joined, avg_conf, line_bbox))
        return results


# ---------------------------------------------------------------------------
# Error patterns
# ---------------------------------------------------------------------------


# (pattern, kind, base_confidence) ordered from most specific to most generic.
# Kinds are short tags reused in the report, so keep them stable.
_DEFAULT_ERROR_PATTERNS: list[tuple[re.Pattern[str], str, float]] = [
    # Android "App has stopped" dialog
    (re.compile(r"has\s+stopped", re.IGNORECASE), "crash_dialog", 0.95),
    (re.compile(r"keeps\s+stopping", re.IGNORECASE), "crash_dialog", 0.95),
    (re.compile(r"isn'?t\s+responding", re.IGNORECASE), "anr_dialog", 0.95),
    (re.compile(r"application\s+not\s+responding", re.IGNORECASE), "anr_dialog", 0.95),
    # Stack trace / logcat keywords captured in the UI (devtools, toasts, etc.)
    (re.compile(r"FATAL\s+EXCEPTION", re.IGNORECASE), "fatal_exception", 0.9),
    (re.compile(r"NullPointerException", re.IGNORECASE), "stack_trace", 0.8),
    (re.compile(r"ANR\s+in\s+", re.IGNORECASE), "anr", 0.9),
    # Generic errors / crash words (lower confidence: can be UI copy)
    (re.compile(r"\bcrash(ed)?\b", re.IGNORECASE), "crash_keyword", 0.55),
    (re.compile(r"\bexception\b", re.IGNORECASE), "exception_keyword", 0.5),
    (re.compile(r"\berror\b", re.IGNORECASE), "error_keyword", 0.4),
]


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------


class OcrDetector:
    """Detect bug moments from OCR'ed text in video frames."""

    def __init__(
        self,
        engine: OcrEngine,
        *,
        patterns: Optional[Iterable[tuple[re.Pattern[str], str, float]]] = None,
        # Ignore OCR text shorter than this (Tesseract often returns garbage
        # on solid-color frames otherwise).
        min_text_length: int = 3,
    ) -> None:
        self._engine = engine
        self._patterns = list(patterns) if patterns is not None else list(_DEFAULT_ERROR_PATTERNS)
        self._min_text_length = min_text_length

    def detect(self, source: FrameSource) -> list[VideoEvent]:
        events: list[VideoEvent] = []
        for frame in source.iter_frames():
            text = self._engine.read_text(frame.image)
            if not text or len(text.strip()) < self._min_text_length:
                continue

            match = self._best_match(text)
            if match is None:
                continue

            kind, confidence, snippet = match
            events.append(
                VideoEvent(
                    timestamp_s=frame.timestamp_s,
                    confidence=confidence,
                    kind=kind,
                    evidence=self._format_evidence(kind, snippet),
                )
            )
        return events

    # ---- internals --------------------------------------------------------

    def _best_match(self, text: str) -> Optional[tuple[str, float, str]]:
        """Return the highest-confidence pattern match in ``text``."""
        best: Optional[tuple[str, float, str]] = None
        for pattern, kind, base_confidence in self._patterns:
            m = pattern.search(text)
            if not m:
                continue
            snippet = _extract_context(text, m.start(), m.end())
            if best is None or base_confidence > best[1]:
                best = (kind, base_confidence, snippet)
        return best

    @staticmethod
    def _format_evidence(kind: str, snippet: str) -> str:
        snippet = snippet.replace("\n", " ").strip()
        if len(snippet) > 160:
            snippet = snippet[:160] + "…"
        return f"[{kind}] {snippet}"


def _extract_context(text: str, start: int, end: int, *, window: int = 60) -> str:
    """Return a short slice of ``text`` around the match with some context."""
    left = max(0, start - window)
    right = min(len(text), end + window)
    return text[left:right]
