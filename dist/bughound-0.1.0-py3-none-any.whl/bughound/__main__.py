"""Allow ``python -m bughound`` invocation."""

from .cli import main


if __name__ == "__main__":
    main()
