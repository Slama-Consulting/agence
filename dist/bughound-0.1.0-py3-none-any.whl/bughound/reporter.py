"""Render a :class:`BugReport` as Markdown or JSON.

Markdown is the primary human-facing output; JSON is the machine-readable
sibling so other tools can consume the same data (CI dashboards, Slack bots,
future analytics).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from .core.models import AppliedFixStatus, BugReport
from .workspace import TicketWorkspace


# Display labels and icons for the :class:`AppliedFixStatus` enum used by
# the ``🛠️ Fix`` section. Centralised here so the table stays consistent
# across the reporter and any future UI consumer.
_FIX_STATUS_LABELS: dict[AppliedFixStatus, str] = {
    AppliedFixStatus.APPLIED: "✔ appliqué",
    AppliedFixStatus.PROPOSED: "📝 proposé (non appliqué)",
    AppliedFixStatus.BELOW_THRESHOLD: "⚠ proposé sous le seuil de confiance",
    AppliedFixStatus.FAILED: "✖ échec d'application",
    AppliedFixStatus.NOT_AVAILABLE: "— aucun correctif",
}


# ---------------------------------------------------------------------------
# Markdown
# ---------------------------------------------------------------------------


def render_markdown(report: BugReport) -> str:
    """Render a :class:`BugReport` as a Markdown document."""
    ticket = report.ticket
    analysis = report.analysis

    parts: list[str] = []
    parts.append(f"# Rapport BugHound — {ticket.key}")
    if ticket.url:
        parts.append(f"[{ticket.url}]({ticket.url})")
    parts.append("")
    parts.append(f"**Titre :** {ticket.title}")
    if ticket.status:
        parts.append(f"**Statut :** {ticket.status}")
    if ticket.reporter:
        parts.append(f"**Rapporteur :** {ticket.reporter}")
    if ticket.assignee:
        parts.append(f"**Assigné à :** {ticket.assignee}")
    parts.append("")

    # =====================================================================
    # ACTION-ORIENTED SECTIONS (top of report)
    # =====================================================================
    #
    # The five sections below answer the questions a reviewer needs to
    # decide quickly: where does the bug come from, what is the patch,
    # how confident are we, what may regress, how do we reproduce it.
    # Raw evidence (description, comments, video events, raw logs, code
    # references) is preserved further down under "📎 Annexes" so the
    # signal stays at the top.

    # --- Document de référence ------------------------------------------
    parts.extend(_render_reference_documents(report))

    # --- 🔍 Cause racine du bug -----------------------------------------
    parts.extend(_render_root_cause_section(report))

    # --- 🛠️ Fix ---------------------------------------------------------
    parts.extend(_render_fix_section(report))

    # --- 📊 Scores de confiance -----------------------------------------
    parts.extend(_render_confidence_section(report))

    # --- ⚠️ Zones à risque de régression --------------------------------
    parts.extend(_render_regression_section(report))

    # --- 🔁 Méthode de reproduction -------------------------------------
    parts.extend(_render_reproduction_section(report))

    # =====================================================================
    # 📎 ANNEXES — PREUVES (every existing evidence section, demoted to H3)
    # =====================================================================
    annex_parts: list[str] = []
    annex_parts.extend(_render_annex_description(ticket))
    annex_parts.extend(_render_annex_comments(ticket, analysis))
    annex_parts.extend(_render_annex_log_window(report))
    annex_parts.extend(_render_annex_log_excerpts(report))
    annex_parts.extend(_render_annex_code_references(report))
    annex_parts.extend(_render_annex_notes(report))

    if annex_parts:
        parts.append("## 📎 Annexes — Preuves")
        parts.append("")
        parts.extend(annex_parts)

    return "\n".join(parts).rstrip() + "\n"


# ---------------------------------------------------------------------------
# Action-oriented section renderers
# ---------------------------------------------------------------------------


def _render_reference_documents(report: BugReport) -> list[str]:
    """Trace the evidence sources used to anchor the diagnosis.

    Lists the video that gave us the bug's wall-clock time and the log
    files from which the analysed window was extracted, plus the time
    range of that window. Helps the reader cross-check that the right
    evidence was used.

    Empty when neither a video timestamp nor a log window is available.
    """
    out: list[str] = []
    has_video_anchor = bool(report.video_events) or bool(report.user_actions)
    has_window = report.log_window is not None
    if not has_video_anchor and not has_window:
        return out

    out.append("## 📁 Document de référence")

    # Video anchor — pick the highest-confidence event with a clock reading.
    video_event = next(
        (
            ev
            for ev in sorted(
                report.video_events, key=lambda e: -e.confidence
            )
            if ev.detected_time or ev.wallclock
        ),
        None,
    )
    # Fallback to user_actions when no scoring video event is present
    # (the OCR-only path produces user_actions but no video_events).
    if video_event is None and report.video_events:
        video_event = report.video_events[0]
    if video_event is not None:
        # Try to recover the original video filename from frame_path
        # (frames live under <video_analysis>/<video_stem>/<frame.png>).
        # Phase 7: the video is now a pure clock sensor — we only surface
        # the bug's wall-clock time (or its in-video timestamp as a
        # fallback) and never the event ``kind``/``confidence``, which
        # are implementation details of the OCR/scene detector.
        video_name = _video_source_name(video_event.frame_path)
        clock = (
            video_event.detected_time
            or (
                video_event.wallclock.isoformat(sep=" ", timespec="seconds")
                if video_event.wallclock
                else None
            )
        )
        if clock:
            out.append(
                f"- **Vidéo :** `{video_name}` — heure du bug détectée : "
                f"**{clock}**"
            )
        else:
            out.append(
                f"- **Vidéo :** `{video_name}` — heure du bug à "
                f"{video_event.timestamp_s:.2f}s dans la vidéo"
            )

    if has_window:
        lw = report.log_window
        assert lw is not None
        sources = (
            ", ".join(f"`{p.name}`" for p in lw.source_files)
            if lw.source_files
            else f"`{lw.window_path.name}`"
        )
        start_str = lw.start_time.isoformat(sep=" ", timespec="seconds")
        end_str = lw.end_time.isoformat(sep=" ", timespec="seconds")
        out.append(
            f"- **Logs :** {sources} — fenêtre extraite entre "
            f"**{start_str}** et **{end_str}** "
            f"({lw.line_count} ligne(s))"
        )

    out.append("")
    return out


def _video_source_name(frame_path: Optional[Path]) -> str:
    """Best-effort recovery of the original video filename from a frame path.

    Frames are stored under ``<video_analysis>/<video_stem>/<frame.png>``,
    so the parent directory's name matches the video stem. The real video
    extension is unknown at this point (could be .mp4/.mov/.mkv/…), so we
    return the stem alone — clear enough for a human reader.
    """
    if frame_path is None:
        return "vidéo"
    parent = frame_path.parent
    return parent.name or "vidéo"


def _render_root_cause_section(report: BugReport) -> list[str]:
    """Render the bilingual root-cause section with proof + timeline.

    Four optional blocks:

    1. ``FR (technique)`` — paragraph for developers (class names, line
       numbers, technical jargon allowed).
    2. ``EN (Product Owner)`` — short paragraph (<= 80 words, plain
       words, no jargon) for non-technical readers.
    3. ``Preuve (logs)`` — 3-4 verbatim log lines extracted from the
       window that prove the diagnosis.
    4. ``Timeline du bug`` — ordered narrative of OK/KO steps explaining
       what should have happened versus what actually happened.

    Each block is independent: any subset can be empty (degraded LLM
    backends) and the section adapts.
    """
    out: list[str] = []
    if (
        not report.root_cause
        and not report.root_cause_en
        and not report.root_cause_evidence_logs
        and not report.root_cause_timeline
    ):
        return out

    out.append("## 🔍 Cause racine du bug")
    if report.root_cause:
        out.append("**FR (technique).**")
        out.append(report.root_cause.strip())
        out.append("")
    if report.root_cause_en:
        out.append("**EN (Product Owner).**")
        out.append(report.root_cause_en.strip())
        out.append("")
    if report.root_cause_evidence_logs:
        out.append("**Preuve (logs) :**")
        out.append("```")
        out.extend(report.root_cause_evidence_logs)
        out.append("```")
        out.append("")
    if report.root_cause_timeline:
        out.append("**Timeline du bug :**")
        for i, step in enumerate(report.root_cause_timeline, start=1):
            marker = "✔" if step.status == "ok" else "✖"
            line = f"{i}. {marker} {step.description}"
            if step.explanation:
                line += f" — {step.explanation}"
            out.append(line)
        out.append("")
    return out


def _render_fix_section(report: BugReport) -> list[str]:
    """Render the ``🛠️ Fix`` section using ``applied_fix_status`` for the icon.

    Shows the applied patch when one was written to disk, otherwise the
    proposed patch. Skipped entirely when no fix is available (status
    ``NOT_AVAILABLE``) so the report stays focused on what was found.
    """
    out: list[str] = []
    status = report.applied_fix_status
    pf = report.proposed_fix

    if pf is None or status is AppliedFixStatus.NOT_AVAILABLE:
        return out

    out.append("## 🛠️ Fix")
    out.append(
        f"**Statut :** {_FIX_STATUS_LABELS.get(status, status.value)}"
    )

    out.append(f"**Fichier :** `{pf.file_path}`")
    if pf.start_line or pf.end_line:
        out.append(f"**Lignes :** {pf.start_line}–{pf.end_line}")
    if pf.description:
        out.append(f"**Description :** {pf.description}")
    if pf.reason:
        out.append(f"**Raison :** {pf.reason}")
    out.append("")
    out.append("**Avant :**")
    out.append("```")
    out.append(pf.before_snippet)
    out.append("```")
    out.append("**Après :**")
    out.append("```")
    out.append(pf.after_snippet)
    out.append("```")

    if (
        report.applied_fix is not None
        and not report.applied_fix.applied
        and report.applied_fix.reason
    ):
        out.append("")
        out.append(
            f"_Note d'application :_ {report.applied_fix.reason}"
        )
    out.append("")
    return out


def _render_confidence_section(report: BugReport) -> list[str]:
    """Render the confidence-scores table (cause/regression/fix/in/outside).

    Uses ``report.confidence_scores`` produced directly by the LLM (no
    deterministic post-processing). Skipped entirely when no scores were
    produced (degraded backends).
    """
    out: list[str] = []
    scores = report.confidence_scores
    if scores is None:
        return out

    out.append("## 📊 Scores de confiance")
    out.append("| Métrique | Score |")
    out.append("| --- | ---: |")
    out.append(f"| Cause racine | {scores.root_cause:.2f} |")
    out.append(f"| Régression | {scores.regression:.2f} |")
    out.append(f"| Fix | {scores.fix:.2f} |")
    out.append(f"| Dans le module patché | {scores.in_module:.2f} |")
    out.append(f"| Hors du module patché | {scores.outside_module:.2f} |")
    out.append("")
    return out


def _render_regression_section(report: BugReport) -> list[str]:
    """Render the regression-zones bullet list.

    Skipped when no zones were identified (neither LLM nor heuristics).
    """
    out: list[str] = []
    if not report.regression_zones:
        return out

    out.append("## ⚠️ Zones à risque de régression")
    for zone in report.regression_zones:
        out.append(f"- `{zone}`")
    out.append("")
    return out


def _render_reproduction_section(report: BugReport) -> list[str]:
    """Render the reproduction recipe.

    Prefers the rich :class:`ReproductionMethod` (preconditions, timing,
    states) when present; falls back to the flat ``reproduction_steps``
    list otherwise. Skipped when neither source has content.
    """
    out: list[str] = []
    method = report.reproduction_method
    flat_steps = report.reproduction_steps

    if method is None and not flat_steps:
        return out

    out.append("## 🔁 Méthode de reproduction")
    if method is not None:
        marker = (
            "✔ systématique" if method.is_systematic else "⚠ intermittent"
        )
        out.append(f"**Reproductible :** {marker}")
        if method.preconditions:
            out.append("**Préconditions :**")
            for pre in method.preconditions:
                out.append(f"- {pre}")
        if method.steps:
            out.append("**Étapes :**")
            for i, step in enumerate(method.steps, start=1):
                out.append(f"{i}. {step}")
        if method.timing_notes:
            out.append(f"**Timing :** {method.timing_notes}")
        if method.states:
            out.append(f"**États préalables :** {method.states}")
    else:
        out.append("**Étapes :**")
        for i, step in enumerate(flat_steps, start=1):
            out.append(f"{i}. {step}")
    out.append("")
    return out


# ---------------------------------------------------------------------------
# Annex renderers (former top-level sections, now under "📎 Annexes")
# ---------------------------------------------------------------------------


def _render_annex_description(ticket) -> list[str]:
    out: list[str] = []
    if not ticket.description.strip():
        return out
    out.append("### Description originale")
    out.append("```")
    out.append(ticket.description.strip())
    out.append("```")
    out.append("")
    return out


def _render_annex_comments(ticket, analysis) -> list[str]:
    out: list[str] = []
    if not analysis.relevant_comments:
        return out
    out.append("### Commentaires")
    relevant_ids = {r.comment_id: r for r in analysis.relevant_comments}
    for comment in ticket.comments:
        marker = relevant_ids.get(comment.id)
        if marker is None:
            continue
        tag = "✔ pertinent" if marker.is_relevant else "✖ bruit"
        out.append(
            f"- [{tag}, conf {marker.confidence:.2f}] "
            f"**{comment.author}** — {marker.reason}"
        )
        body_preview = comment.body.strip().replace("\n", " ")
        if len(body_preview) > 200:
            body_preview = body_preview[:200] + "…"
        out.append(f"  > {body_preview}")
    out.append("")
    return out


_LOG_WINDOW_HEAD_LINES = 80
_LOG_WINDOW_TAIL_LINES = 80


def _render_annex_log_window(report: BugReport) -> list[str]:
    """Render a *bounded* preview of the extracted log window.

    The window file itself can reach tens of MB on bugreport-style
    captures (see CCSEXT-231431: 570k+ lines). Inlining it verbatim
    inside the markdown produces a report nobody can open. We surface
    the head (first ``_LOG_WINDOW_HEAD_LINES`` lines) and the tail
    (last ``_LOG_WINDOW_TAIL_LINES`` lines) with a ``[…]`` separator
    when the file is truncated, plus the absolute path so the reader
    can grep the full file when needed.
    """
    out: list[str] = []
    if report.log_window is None:
        return out
    lw = report.log_window
    out.append("### Fenêtre de logs")
    out.append(
        f"Fenêtre : {lw.start_time.isoformat(sep=' ')} → "
        f"{lw.end_time.isoformat(sep=' ')} — "
        f"{lw.line_count} ligne(s) dans `{lw.window_path}`"
    )
    try:
        window_lines = lw.window_path.read_text(
            encoding="utf-8", errors="replace"
        ).splitlines()
    except OSError:
        window_lines = []
    if window_lines:
        max_inline = _LOG_WINDOW_HEAD_LINES + _LOG_WINDOW_TAIL_LINES
        out.append("```")
        if len(window_lines) <= max_inline:
            out.extend(window_lines)
        else:
            head = window_lines[:_LOG_WINDOW_HEAD_LINES]
            tail = window_lines[-_LOG_WINDOW_TAIL_LINES:]
            omitted = len(window_lines) - len(head) - len(tail)
            out.extend(head)
            out.append(f"[… {omitted} ligne(s) omise(s) — voir le fichier brut …]")
            out.extend(tail)
        out.append("```")
    out.append("")
    return out


def _render_annex_log_excerpts(report: BugReport) -> list[str]:
    out: list[str] = []
    if not report.log_excerpts:
        return out
    out.append("### Extraits de logs")
    for excerpt in report.log_excerpts:
        out.append(
            f"#### `{excerpt.source_file.name}` "
            f"autour de {excerpt.anchor_time.isoformat(sep=' ')}"
        )
        out.append(
            f"Fenêtre : -{excerpt.window_before.total_seconds():.0f}s / "
            f"+{excerpt.window_after.total_seconds():.0f}s"
        )
        out.append("```")
        out.extend(excerpt.lines or ["(aucune ligne de log dans la fenêtre)"])
        out.append("```")
        out.append("")
    return out


def _render_annex_code_references(report: BugReport) -> list[str]:
    out: list[str] = []
    if not report.code_references:
        return out
    out.append("### Références de code")
    for ref in report.code_references:
        loc = f":{ref.line}" if ref.line else ""
        out.append(f"#### `{ref.class_fqn}`")
        out.append(f"`{ref.file_path}{loc}`")
        if ref.snippet:
            out.append("```")
            out.append(ref.snippet)
            out.append("```")
        out.append("")
    return out


def _render_annex_notes(report: BugReport) -> list[str]:
    out: list[str] = []
    if not report.notes:
        return out
    out.append("### Notes")
    for note in report.notes:
        out.append(f"- {note}")
    out.append("")
    return out


# ---------------------------------------------------------------------------
# JSON
# ---------------------------------------------------------------------------


def render_json(report: BugReport) -> str:
    """Render a :class:`BugReport` as pretty-printed JSON."""
    # Pydantic handles datetime/Path/Enum serialization via model_dump(mode="json").
    return json.dumps(report.model_dump(mode="json"), indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------


def write_report(
    report: BugReport,
    out_dir: Path,
    *,
    emit_json: bool = True,
    workspace: Optional[TicketWorkspace] = None,
) -> Path:
    """Write Markdown (and optionally JSON) to ``out_dir`` or ``workspace``.

    When a :class:`TicketWorkspace` is supplied, the report files live
    inside ``workspace.root`` (``<workdir>/analyse/<TICKET>/``) instead of
    directly under ``out_dir`` — which keeps every artefact for a ticket in
    one place and makes the end-of-run cleanup simple.

    Returns the path to the Markdown file (primary artifact).
    """
    if workspace is not None:
        workspace.ensure_dirs()
        md_path = workspace.report_md
        json_path = workspace.report_json
    else:
        out_dir.mkdir(parents=True, exist_ok=True)
        md_path = out_dir / f"{report.ticket.key}.md"
        json_path = out_dir / f"{report.ticket.key}.json"

    markdown = render_markdown(report)
    md_path.write_text(markdown, encoding="utf-8")
    if emit_json:
        json_path.write_text(render_json(report), encoding="utf-8")

    return md_path
