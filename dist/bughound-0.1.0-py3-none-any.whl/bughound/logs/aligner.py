"""Align video time (seconds from start) with log wall-clock time.

The core idea: pick an *anchor* — a moment that exists in both references —
and compute a fixed offset. Afterwards, any ``video_time_s`` can be turned
into a wall-clock ``datetime`` suitable for searching log files.

Three ways to get an anchor:

1. **Explicit**: caller supplies ``(video_time_s, wallclock_datetime)``.
   Useful when the recorder burns a clock into the video.

2. **Auto**: we scan the parsed log for the first FATAL/crash marker and
   align it with the strongest :class:`VideoEvent`. Good-enough default
   when both signals exist and describe the same incident.

3. **Log-range**: when neither display-time OCR nor crash markers are
   available (e.g. silent behavioral bugs with no crash), we assume the
   video recording started at the same moment as the first parseable log
   entry. This lets us still extract a meaningful time window.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Iterable, Optional, Sequence, TYPE_CHECKING

from ..core.models import VideoEvent
from .parser import LogLine

if TYPE_CHECKING:  # pragma: no cover
    from ..video.time_ocr import DisplayTimeSample


class AlignmentError(RuntimeError):
    """Raised when no reliable anchor can be inferred."""


# Patterns mining a wall-clock timestamp out of a log filename. Order
# matters: more specific patterns come first so we don't match a less
# precise prefix when a fully-precise stamp is available.
#
# Real-world examples seen on Renault HU bug tickets:
#   - ``PussADB_20260408_145916_userdefine.log``
#   - ``bugreport-rl1l0qz0t8r-AB_HU_AB-2026-04-08-15-00-13.zip``
#   - ``logcat_2026-04-08_14-59-16.txt``
#   - ``main_20260408-145916.log``
_FILENAME_TIMESTAMP_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    # YYYY-MM-DD-HH-MM-SS (Android bugreport canonical form)
    (
        re.compile(
            r"(?P<y>\d{4})[-_](?P<mo>\d{2})[-_](?P<d>\d{2})"
            r"[-_T ](?P<h>\d{2})[-_:](?P<mi>\d{2})[-_:](?P<s>\d{2})"
        ),
        "iso",
    ),
    # YYYYMMDD[_-]HHMMSS (PussADB and friends)
    (
        re.compile(
            r"(?P<y>\d{4})(?P<mo>\d{2})(?P<d>\d{2})"
            r"[_\-T](?P<h>\d{2})(?P<mi>\d{2})(?P<s>\d{2})"
        ),
        "compact",
    ),
)


# Markers we look for when building an auto anchor. Order matters: earlier
# entries are more specific / trustworthy.
#
# Crash/ANR markers come first. Then common behavioral-bug signals that appear
# in silent (non-crash) bugs — e.g. radio/DAB issues where the UI freezes
# without an exception. These allow auto_anchor to succeed even when there is
# no crash in the log.
_DEFAULT_LOG_ANCHOR_MARKERS: tuple[str, ...] = (
    # --- hard errors (crash / ANR) ---
    "FATAL EXCEPTION",
    "beginning of crash",
    "AndroidRuntime",
    "ANR in ",
    # --- behavioral / silent bugs ---
    "NO_FOUND_LINK",
    "channelId 0",
    "updateDabLogo",
    "TunerCallbackAdapter",
    "ProgramInfo callback is not set",
    "WatchdogImpl",
    "NullPointerException",
    "IllegalStateException",
    "IllegalArgumentException",
    "NetworkOnMainThreadException",
)


@dataclass(frozen=True)
class Anchor:
    """A correspondence between video time and wall-clock time."""

    video_time_s: float
    wallclock: datetime
    source: str   # "explicit", "auto:<marker>"


class VideoLogAligner:
    """Convert video offsets to wall-clock times using a known anchor."""

    def __init__(
        self,
        *,
        log_markers: Sequence[str] = _DEFAULT_LOG_ANCHOR_MARKERS,
    ) -> None:
        self._markers = tuple(log_markers)

    # ---- anchor building --------------------------------------------------

    def explicit_anchor(
        self,
        *,
        video_time_s: float,
        wallclock: datetime,
    ) -> Anchor:
        return Anchor(
            video_time_s=float(video_time_s),
            wallclock=wallclock,
            source="explicit",
        )

    def display_time_anchor(
        self,
        samples: Sequence["DisplayTimeSample"],
        *,
        reference_date: Optional[date] = None,
    ) -> Optional[Anchor]:
        """Anchor built from the on-screen clock read in the video.

        The very first OCR sample gives us both a ``video_time_s``
        (``frame_time_s`` in the sample) and a wall-clock ``HH:MM[:SS]``.
        Combined with ``reference_date`` (or today's date as a fallback),
        that's enough to build a full :class:`Anchor` without ever looking
        at the logcat.

        Returns ``None`` when ``samples`` is empty or the first parseable
        ``HH:MM`` cannot be interpreted — callers fall back on
        :meth:`auto_anchor` in that case.
        """
        if not samples:
            return None

        ref_date = reference_date or date.today()
        for sample in samples:
            wc = _parse_hhmm(sample.wallclock_hhmm, ref_date)
            if wc is None:
                continue
            return Anchor(
                video_time_s=float(sample.frame_time_s),
                wallclock=wc,
                source="display_time",
            )
        return None

    def auto_anchor(
        self,
        *,
        log_lines: Iterable[LogLine],
        video_events: Sequence[VideoEvent],
    ) -> Anchor:
        """Pick an anchor from the strongest video event + first log marker.

        Raises :class:`AlignmentError` if either side is missing a usable
        reference point.
        """
        if not video_events:
            raise AlignmentError("auto_anchor requires at least one video event")

        strongest = max(video_events, key=lambda e: e.confidence)
        marker_line = self._find_first_marker(log_lines)
        if marker_line is None:
            raise AlignmentError(
                "auto_anchor could not find any known log marker "
                f"(tried: {', '.join(self._markers)})"
            )

        return Anchor(
            video_time_s=strongest.timestamp_s,
            wallclock=marker_line.timestamp,        # type: ignore[arg-type]
            source=f"auto:{self._detect_marker(marker_line)}",
        )

    def filename_anchor(
        self,
        *,
        log_paths: Sequence[Path],
        video_time_s: float = 0.0,
    ) -> Optional[Anchor]:
        """Anchor built from a wall-clock timestamp embedded in a log filename.

        Vendor-specific log dumpers consistently encode the dump's start
        wall-clock in the filename (Renault ``PussADB_20260408_145916...``,
        Android bugreports ``bugreport-...-2026-04-08-15-00-13...``,
        custom ``logcat_2026-04-08_14-59-16.txt`` etc.). When the on-screen
        clock OCR fails (police IVI condensée, écran reflétant, vidéo trop
        courte) we can still recover a deterministic anchor straight from
        the filename — far more reliable than ``log_range_anchor`` which
        can fall on a previous boot session.

        Returns ``None`` when no filename in ``log_paths`` matches any of
        the known timestamp patterns.

        The first matching filename wins (callers should pre-prioritise
        ``log_paths`` so the most relevant log comes first — see
        ``_prioritize_bugreports`` in the pipeline).
        """
        for path in log_paths:
            ts = _parse_timestamp_from_filename(path.name)
            if ts is not None:
                return Anchor(
                    video_time_s=float(video_time_s),
                    wallclock=ts,
                    source=f"filename:{path.name[:80]}",
                )
        return None

    def log_range_anchor(
        self,
        *,
        log_lines: Iterable[LogLine],
        video_time_s: float = 0.0,
    ) -> Optional[Anchor]:
        """Build an anchor from the first parseable log timestamp.

        This is the last-resort fallback used when:
        - the video has no readable on-screen clock (no OCR samples), AND
        - the log contains no known crash/behavioral markers for ``auto_anchor``.

        The assumption is that the recording started at or close to the first
        log entry, so ``video_time_s=0`` maps to the first log timestamp.
        Callers can pass a non-zero ``video_time_s`` if they know the video
        offset at which logging started.

        Returns ``None`` when the log is empty or has no parseable timestamps.
        """
        first_ts: Optional[datetime] = None
        for line in log_lines:
            if line.timestamp is not None:
                first_ts = line.timestamp
                break
        if first_ts is None:
            return None
        return Anchor(
            video_time_s=float(video_time_s),
            wallclock=first_ts,
            source="log_range",
        )

    def keyword_anchor(
        self,
        *,
        log_lines: Iterable[LogLine],
        keywords: Sequence[str],
        video_time_s: float = 0.0,
    ) -> Optional[Anchor]:
        """Anchor built from the first log line matching any ticket keyword.

        Used as a fallback when neither on-screen clock OCR nor standard crash
        markers (``auto_anchor``) yield a usable anchor.  Rather than pinning
        to the first log entry (``log_range_anchor``), this method scans the
        log for the first line whose message contains any of ``keywords``
        (case-insensitive).  The anchor wallclock is then that line's
        timestamp, which is far more likely to be close to the actual bug
        moment.

        Keywords are derived from the ticket title and description:
        meaningful words (>3 chars, not stop-words) extracted by the caller.

        Returns ``None`` when no matching line is found or the log is empty.
        """
        if not keywords:
            return None
        lower_kws = [k.lower() for k in keywords if k]
        for line in log_lines:
            if line.timestamp is None:
                continue
            msg_lower = line.message.lower()
            if any(kw in msg_lower for kw in lower_kws):
                return Anchor(
                    video_time_s=float(video_time_s),
                    wallclock=line.timestamp,
                    source=f"keyword:{line.message[:60]}",
                )
        return None

    # ---- conversion -------------------------------------------------------

    @staticmethod
    def to_wallclock(anchor: Anchor, video_time_s: float) -> datetime:
        """Map a video offset (seconds) to a wall-clock datetime."""
        delta = timedelta(seconds=float(video_time_s) - anchor.video_time_s)
        return anchor.wallclock + delta

    # ---- helpers ----------------------------------------------------------

    def _find_first_marker(self, lines: Iterable[LogLine]) -> Optional[LogLine]:
        for line in lines:
            if line.timestamp is None:
                continue
            if any(marker in line.message for marker in self._markers):
                return line
        return None

    def _detect_marker(self, line: LogLine) -> str:
        for marker in self._markers:
            if marker in line.message:
                return marker
        return "unknown"


def _parse_timestamp_from_filename(name: str) -> Optional[datetime]:
    """Extract a ``datetime`` from a log filename, ``None`` if no match.

    The function tries every pattern in ``_FILENAME_TIMESTAMP_PATTERNS``
    in order and returns the first valid match. Out-of-range numeric
    components (month > 12, hour > 23 …) cause the candidate to be
    skipped so we keep scanning rather than accept garbage.
    """
    for pattern, _label in _FILENAME_TIMESTAMP_PATTERNS:
        for match in pattern.finditer(name):
            try:
                year = int(match.group("y"))
                month = int(match.group("mo"))
                day = int(match.group("d"))
                hour = int(match.group("h"))
                minute = int(match.group("mi"))
                second = int(match.group("s"))
            except (ValueError, IndexError):  # pragma: no cover - defensive
                continue
            try:
                return datetime(year, month, day, hour, minute, second)
            except ValueError:
                # Out-of-range component (e.g. month=13, day=32) —
                # try the next match.
                continue
    return None


def _parse_hhmm(text: str, ref_date: date) -> Optional[datetime]:
    """Turn ``HH:MM`` / ``HH:MM:SS`` + a date into a full ``datetime``.

    Returns ``None`` if the input is malformed.
    """
    parts = text.split(":")
    if len(parts) not in (2, 3):
        return None
    try:
        h = int(parts[0])
        m = int(parts[1])
        s = int(parts[2]) if len(parts) == 3 else 0
    except ValueError:
        return None
    if not (0 <= h <= 23 and 0 <= m <= 59 and 0 <= s <= 59):
        return None
    return datetime(
        year=ref_date.year,
        month=ref_date.month,
        day=ref_date.day,
        hour=h,
        minute=m,
        second=s,
    )
