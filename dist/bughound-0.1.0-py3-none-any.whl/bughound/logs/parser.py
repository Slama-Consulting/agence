"""Logcat line parser.

Supports the formats most commonly found in Android bug reports:

  * ``threadtime`` (default of ``logcat -v threadtime``)::

        01-02 10:15:23.123  1234  5678 E AndroidRuntime: FATAL EXCEPTION: main

  * ``time``::

        01-02 10:15:23.123 E/AndroidRuntime( 1234): FATAL EXCEPTION: main

  * ISO timestamp variant found on newer Android versions / bugreport dumps::

        2025-01-02 10:15:23.123000  1234  5678 E AndroidRuntime: message

Unknown / continuation lines (stack trace ``at com.foo.Bar.baz(...)``) are
still returned, with ``timestamp=None``, so they can be attached to the
preceding entry by downstream code.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable, Iterator, Optional


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class LogLine:
    """A single parsed logcat line."""

    timestamp: Optional[datetime]
    level: Optional[str]          # V, D, I, W, E, F
    tag: Optional[str]
    pid: Optional[int]
    tid: Optional[int]
    message: str
    raw: str


# ---------------------------------------------------------------------------
# Regexes
# ---------------------------------------------------------------------------


# 01-02 10:15:23.123  1234  5678 E TagName: message
_THREADTIME_RE = re.compile(
    r"""^
    (?P<ts>\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3,6})
    \s+(?P<pid>\d+)
    \s+(?P<tid>\d+)
    \s+(?P<level>[VDIWEF])
    \s+(?P<tag>[^:]+?)
    :\s?(?P<msg>.*)$
    """,
    re.VERBOSE,
)

# 2025-01-02 10:15:23.123  1234  5678 E TagName: message
_ISO_THREADTIME_RE = re.compile(
    r"""^
    (?P<ts>\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}\.\d{3,6})
    \s+(?P<pid>\d+)
    \s+(?P<tid>\d+)
    \s+(?P<level>[VDIWEF])
    \s+(?P<tag>[^:]+?)
    :\s?(?P<msg>.*)$
    """,
    re.VERBOSE,
)

# 01-02 10:15:23.123 E/TagName( 1234): message
_TIME_RE = re.compile(
    r"""^
    (?P<ts>\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3,6})
    \s+(?P<level>[VDIWEF])/(?P<tag>[^(]+?)
    \(\s*(?P<pid>\d+)\)
    :\s?(?P<msg>.*)$
    """,
    re.VERBOSE,
)

# 2026-04-23 11:16:35.110  2403-3209  TagName  com.proc.name  I  message
#
# Automotive / newer Android dumps: ISO timestamp, PID-TID joined by a dash,
# then tag, process name, a standalone V/D/I/W/E/F level, and the message.
# Tag and process can contain dots and ellipses (truncated tags).
_ISO_SPACE_LEVEL_RE = re.compile(
    r"""^
    (?P<ts>\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}\.\d{3,6})
    \s+(?P<pid>\d+)-(?P<tid>\d+)
    \s+(?P<tag>\S.*?)
    \s+(?P<proc>\S+)
    \s+(?P<level>[VDIWEF])
    \s+(?P<msg>.*)$
    """,
    re.VERBOSE,
)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


class LogcatParser:
    """Parse logcat files line-by-line into :class:`LogLine` objects."""

    def __init__(self, *, default_year: Optional[int] = None) -> None:
        """
        Args:
            default_year: logcat's MM-dd format is year-less, so we need to
                pick one. Defaults to the current year if not provided.
        """
        self._default_year = default_year or datetime.now().year

    # ---- single-line parsing ---------------------------------------------

    def parse_line(self, raw: str) -> LogLine:
        """Parse one log line. Unknown formats return a LogLine with no timestamp."""
        stripped = raw.rstrip("\r\n")

        for regex, has_iso in (
            (_ISO_SPACE_LEVEL_RE, True),
            (_ISO_THREADTIME_RE, True),
            (_THREADTIME_RE, False),
            (_TIME_RE, False),
        ):
            m = regex.match(stripped)
            if not m:
                continue
            ts = self._parse_timestamp(m.group("ts"), iso=has_iso)
            pid = _to_int(m.group("pid"))
            tid = _to_int(m.groupdict().get("tid"))
            return LogLine(
                timestamp=ts,
                level=m.group("level"),
                tag=m.group("tag").strip(),
                pid=pid,
                tid=tid,
                message=m.group("msg"),
                raw=stripped,
            )

        return LogLine(
            timestamp=None,
            level=None,
            tag=None,
            pid=None,
            tid=None,
            message=stripped,
            raw=stripped,
        )

    # ---- bulk parsing -----------------------------------------------------

    def parse_lines(self, lines: Iterable[str]) -> Iterator[LogLine]:
        """Parse an iterable of raw lines into :class:`LogLine` objects."""
        for raw in lines:
            yield self.parse_line(raw)

    def parse_file(
        self,
        path: Path,
        *,
        encoding: str = "utf-8",
        errors: str = "replace",
    ) -> Iterator[LogLine]:
        """Stream-parse a logcat file without loading it all into memory."""
        with path.open("r", encoding=encoding, errors=errors) as fh:
            for raw in fh:
                yield self.parse_line(raw)

    # ---- internals --------------------------------------------------------

    def _parse_timestamp(self, raw: str, *, iso: bool) -> Optional[datetime]:
        raw = raw.strip().replace("T", " ")

        # Normalize sub-second precision to 6 digits for strptime's %f.
        if "." in raw:
            head, frac = raw.rsplit(".", 1)
            frac = (frac + "000000")[:6]
            raw = f"{head}.{frac}"

        if iso:
            fmt = "%Y-%m-%d %H:%M:%S.%f"
            try:
                return datetime.strptime(raw, fmt)
            except ValueError:
                return None

        # Year-less: prepend default year.
        fmt = "%Y-%m-%d %H:%M:%S.%f"
        try:
            return datetime.strptime(f"{self._default_year}-{raw}", fmt)
        except ValueError:
            return None


def _to_int(value: Optional[str]) -> Optional[int]:
    if value is None:
        return None
    try:
        return int(value)
    except ValueError:
        return None
