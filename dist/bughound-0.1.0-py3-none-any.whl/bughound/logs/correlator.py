"""Cut a time-window slice out of logcat files around a video event."""

from __future__ import annotations

import os
import re
from collections import Counter
from datetime import date, datetime, time, timedelta
from pathlib import Path
from typing import Iterable, Optional, Sequence

from ..core.models import LogExcerpt, LogWindow, VideoEvent
from .aligner import Anchor, VideoLogAligner
from .parser import LogcatParser, LogLine


# Match the leading timestamp of an Android logcat line — independent
# from :class:`LogcatParser` because we deliberately want to compare on
# the *time* component only, ignoring the date.
#
# Captures, in order:
#   1) full date prefix (``MM-DD`` or ``YYYY-MM-DD``)
#   2) hour (HH)
#   3) minute (MM)
#   4) second (SS)
_LEADING_TS_RE = re.compile(
    r"^(?P<date>\d{4}-\d{2}-\d{2}|\d{2}-\d{2})[\sT]+"
    r"(?P<h>\d{2}):(?P<m>\d{2}):(?P<s>\d{2})\."
)


def _parse_date_token(
    token: str, *, default_year: Optional[int] = None
) -> Optional[date]:
    """Best-effort parsing of a logcat date prefix to a real :class:`date`.

    Accepts ``YYYY-MM-DD`` (logcat with year) and ``MM-DD`` (yearless,
    the Android default). For ``MM-DD`` the caller can pass
    ``default_year``; otherwise we use the current year.
    """
    if not token:
        return None
    parts = token.split("-")
    try:
        if len(parts) == 3:
            return date(int(parts[0]), int(parts[1]), int(parts[2]))
        if len(parts) == 2:
            year = default_year if default_year is not None else date.today().year
            return date(year, int(parts[0]), int(parts[1]))
    except ValueError:
        return None
    return None


class LogCorrelator:
    """Extract the log lines within a time window around a video event."""

    def __init__(
        self,
        *,
        parser: LogcatParser | None = None,
        window_before_s: float = 30.0,
        window_after_s: float = 15.0,
    ) -> None:
        self._parser = parser or LogcatParser()
        self._before = timedelta(seconds=window_before_s)
        self._after = timedelta(seconds=window_after_s)

    # ---- high-level -------------------------------------------------------

    def excerpt_for_event(
        self,
        *,
        event: VideoEvent,
        anchor: Anchor,
        log_file: Path,
    ) -> LogExcerpt:
        """Return a :class:`LogExcerpt` for a single log file."""
        wallclock = VideoLogAligner.to_wallclock(anchor, event.timestamp_s)
        lines = self._parser.parse_file(log_file)
        return self._build_excerpt(lines, log_file, wallclock)

    def excerpts_for_event(
        self,
        *,
        event: VideoEvent,
        anchor: Anchor,
        log_files: Iterable[Path],
    ) -> list[LogExcerpt]:
        return [
            self.excerpt_for_event(event=event, anchor=anchor, log_file=p)
            for p in log_files
        ]

    # ---- in-memory variant (used by tests and when logs already parsed) ---

    def excerpt_from_lines(
        self,
        *,
        lines: Sequence[LogLine],
        anchor: Anchor,
        event: VideoEvent,
        source_file: Path,
    ) -> LogExcerpt:
        wallclock = VideoLogAligner.to_wallclock(anchor, event.timestamp_s)
        return self._build_excerpt(lines, source_file, wallclock)

    # ---- internals --------------------------------------------------------

    def _build_excerpt(
        self,
        lines: Iterable[LogLine],
        source_file: Path,
        anchor_time: datetime,
    ) -> LogExcerpt:
        lower = anchor_time - self._before
        upper = anchor_time + self._after

        kept: list[str] = []
        last_in_window = False
        for line in lines:
            ts = line.timestamp
            if ts is None:
                # Continuation lines (stack trace ``at ...``) stick to the
                # previous entry's window decision.
                if last_in_window:
                    kept.append(line.raw)
                continue
            if lower <= ts <= upper:
                kept.append(line.raw)
                last_in_window = True
            else:
                last_in_window = False

        return LogExcerpt(
            source_file=source_file,
            anchor_time=anchor_time,
            window_before=self._before,
            window_after=self._after,
            lines=kept,
        )

    # ---- consolidated log window -----------------------------------------

    # ---- log time-range probing ------------------------------------------

    def probe_log_range(
        self,
        log_files: Sequence[Path],
        *,
        head_lines: int = 200,
        tail_bytes: int = 65536,
    ) -> Optional[tuple[datetime, datetime]]:
        """Return ``(min_ts, max_ts)`` covered by ``log_files``, or ``None``.

        The probe is cheap by design: for each file we parse the first
        ``head_lines`` lines to capture an early timestamp, then we seek to
        the last ``tail_bytes`` bytes and parse from there to capture a late
        timestamp. We never load whole files in memory — these dumps can be
        hundreds of megabytes.

        Files with no parseable timestamp at all are silently skipped.
        ``None`` is returned when *no* file yielded a usable range.
        """
        global_min: Optional[datetime] = None
        global_max: Optional[datetime] = None

        for log_file in log_files:
            try:
                first_ts, last_ts = self._probe_one(
                    log_file,
                    head_lines=head_lines,
                    tail_bytes=tail_bytes,
                )
            except OSError:
                continue
            if first_ts is not None:
                if global_min is None or first_ts < global_min:
                    global_min = first_ts
            if last_ts is not None:
                if global_max is None or last_ts > global_max:
                    global_max = last_ts

        if global_min is None or global_max is None:
            return None
        return global_min, global_max

    def _probe_one(
        self,
        log_file: Path,
        *,
        head_lines: int,
        tail_bytes: int,
    ) -> tuple[Optional[datetime], Optional[datetime]]:
        """Return the earliest and latest parseable timestamps in ``log_file``."""
        first_ts: Optional[datetime] = None
        last_ts: Optional[datetime] = None

        # Head scan: stream the beginning of the file until we either find
        # a timestamp or hit ``head_lines`` lines.
        with log_file.open("r", encoding="utf-8", errors="replace") as fh:
            for i, raw in enumerate(fh):
                if i >= head_lines and first_ts is not None:
                    break
                if i >= head_lines:
                    # Give up looking for a head timestamp: file probably
                    # has only metadata in its first ``head_lines``.
                    break
                line = self._parser.parse_line(raw)
                if line.timestamp is not None and first_ts is None:
                    first_ts = line.timestamp

        # Tail scan: seek to ``tail_bytes`` from the end (or to 0 for short
        # files), then parse every line we find.
        try:
            size = log_file.stat().st_size
        except OSError:
            return first_ts, last_ts

        offset = max(0, size - int(tail_bytes))
        with log_file.open("rb") as fh:
            fh.seek(offset, os.SEEK_SET)
            blob = fh.read()
        # Drop the first (likely partial) line so we don't try to parse half
        # of a timestamp.
        if offset > 0:
            nl = blob.find(b"\n")
            if nl >= 0:
                blob = blob[nl + 1:]
        for raw in blob.decode("utf-8", errors="replace").splitlines():
            line = self._parser.parse_line(raw)
            if line.timestamp is not None:
                if last_ts is None or line.timestamp > last_ts:
                    last_ts = line.timestamp

        # Short files: head scan may have already covered the whole file,
        # in which case ``last_ts`` could still be None — fall back to
        # whatever ``first_ts`` we captured.
        if last_ts is None and first_ts is not None:
            last_ts = first_ts

        return first_ts, last_ts

    def build_log_window(
        self,
        *,
        log_files: Sequence[Path],
        start_wallclock: datetime,
        end_wallclock: datetime,
        out_dir: Path,
        pad_before_s: float = 300.0,   # 5 minutes
        pad_after_s: float = 120.0,    # 2 minutes
        file_name: str = "window.log",
    ) -> LogWindow:
        """Extract a wall-clock time window across every ``log_files``.

        The window is ``[start_wallclock − pad_before ; end_wallclock + pad_after]``.
        Every matching line (plus its ``at ...`` continuation lines) is
        collected across all files, sorted chronologically, and written to
        ``out_dir/<file_name>``. The :class:`LogWindow` returned records how
        many lines ended up inside.

        Continuation lines (``LogLine.timestamp is None``) inherit the
        "in-window" decision of the preceding entry, so stack traces stay
        glued to their crash line.
        """
        lower = start_wallclock - timedelta(seconds=float(pad_before_s))
        upper = end_wallclock + timedelta(seconds=float(pad_after_s))

        collected: list[tuple[datetime, str]] = []
        for log_file in log_files:
            last_ts: datetime | None = None
            last_in_window = False
            for line in self._parser.parse_file(log_file):
                ts = line.timestamp
                if ts is None:
                    if last_in_window and last_ts is not None:
                        collected.append((last_ts, line.raw))
                    continue
                if lower <= ts <= upper:
                    collected.append((ts, line.raw))
                    last_ts = ts
                    last_in_window = True
                else:
                    last_ts = ts
                    last_in_window = False

        collected.sort(key=lambda pair: pair[0])

        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / file_name
        with out_path.open("w", encoding="utf-8") as fh:
            for _ts, raw in collected:
                fh.write(raw)
                if not raw.endswith("\n"):
                    fh.write("\n")

        return LogWindow(
            source_files=list(log_files),
            window_path=out_path,
            start_time=lower,
            end_time=upper,
            line_count=len(collected),
        )

    def build_log_window_by_hour(
        self,
        *,
        log_files: Sequence[Path],
        start_time: time,
        end_time: time,
        out_dir: Path,
        pad_before_s: float = 300.0,   # 5 minutes
        pad_after_s: float = 120.0,    # 2 minutes
        file_name: str = "window.log",
        prefer_dominant_day: bool = True,
        reference_date: Optional[date] = None,
    ) -> LogWindow:
        """Extract a window using **time-of-day only** (date-agnostic).

        This is the awk-equivalent of::

            awk '$2 >= "HH:MM:SS" && $2 <= "HH:MM:SS"' input.txt

        ``start_time``/``end_time`` are :class:`datetime.time` objects;
        the date component of every parsed line is ignored.  Useful
        when:

        * the OCR'ed on-screen clock gives only ``HH:MM`` and the
          recording day is unknown,
        * the log files span multiple days and only one of them is the
          actual bug session,
        * the ticket's creation date differs from the log recording
          date (a common pitfall with year-less Android logcat).

        ``prefer_dominant_day`` (default ``True``) keeps lines from the
        single most-represented ``MM-DD`` only, so a noisy log that
        also happens to match the time-of-day on a *different* day
        doesn't pollute the window.  Set to ``False`` to mimic awk
        exactly (every line that matches HH:MM is kept).

        ``pad_before_s`` / ``pad_after_s`` widen the requested time-of-
        day window (default 5 min before / 2 min after, like the
        wall-clock variant).  Continuation lines (``timestamp=None``)
        inherit the in-window decision of the preceding entry, so
        stack traces stay glued to their crash line.
        """
        # Normalise the requested window to seconds-of-day, applying the
        # padding. We use a 24 h modulo so a window crossing midnight
        # (e.g. 23:58 → 00:02) is still handled correctly.
        day = 24 * 3600
        start_sec = (
            start_time.hour * 3600 + start_time.minute * 60 + start_time.second
            - int(pad_before_s)
        )
        end_sec = (
            end_time.hour * 3600 + end_time.minute * 60 + end_time.second
            + int(pad_after_s)
        )
        crosses_midnight = start_sec < 0 or end_sec >= day or start_sec > end_sec
        start_sec %= day
        end_sec %= day

        def _in_window(sec: int) -> bool:
            if crosses_midnight:
                return sec >= start_sec or sec <= end_sec
            return start_sec <= sec <= end_sec

        # Pass 1: collect every matching line + its date.
        # Each entry is (date_str, time_sec, raw, sort_key).
        # ``date_str`` is None when the line had no parseable timestamp
        # and we're inheriting the previous decision (continuation).
        matches: list[tuple[Optional[str], int, str]] = []
        for log_file in log_files:
            last_in_window = False
            last_date: Optional[str] = None
            last_sec: Optional[int] = None
            with log_file.open("r", encoding="utf-8", errors="replace") as fh:
                for raw in fh:
                    m = _LEADING_TS_RE.match(raw)
                    if m is None:
                        # Continuation: inherit previous decision.
                        if last_in_window and last_sec is not None:
                            matches.append((last_date, last_sec, raw))
                        continue
                    h = int(m.group("h"))
                    mn = int(m.group("m"))
                    s = int(m.group("s"))
                    sec = h * 3600 + mn * 60 + s
                    if _in_window(sec):
                        date_str = m.group("date")
                        matches.append((date_str, sec, raw))
                        last_in_window = True
                        last_date = date_str
                        last_sec = sec
                    else:
                        last_in_window = False

        # Pass 2 (optional): keep only lines from the dominant day.
        if prefer_dominant_day and matches:
            day_counts: Counter[str] = Counter(
                d for (d, _sec, _raw) in matches if d is not None
            )
            if day_counts:
                dominant = day_counts.most_common(1)[0][0]
                matches = [
                    (d, sec, raw) for (d, sec, raw) in matches
                    if d is None or d == dominant
                ]

        # Sort chronologically by ``(date, time_sec)`` so multi-file
        # windows are interleaved properly.
        def _sort_key(entry: tuple[Optional[str], int, str]) -> tuple[str, int]:
            d, sec, _raw = entry
            return (d or "", sec)

        matches.sort(key=_sort_key)

        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / file_name
        with out_path.open("w", encoding="utf-8") as fh:
            for _d, _sec, raw in matches:
                fh.write(raw)
                if not raw.endswith("\n"):
                    fh.write("\n")

        # Build a representative ``start_time``/``end_time`` for the
        # returned :class:`LogWindow``. The model expects ``datetime``
        # objects, so we need to pick a real-looking calendar date.
        # Priority order:
        #   1. ``reference_date`` passed by the caller (the pipeline
        #      knows the recording day from log probing or from the
        #      ticket).
        #   2. The dominant ``MM-DD`` (or ``YYYY-MM-DD``) parsed from
        #      the matched lines themselves — these are real log dates.
        #   3. Fallback: today (better than 1970 for a human reader).
        anchor_day = reference_date
        if anchor_day is None and matches:
            day_strs = Counter(
                d for (d, _sec, _raw) in matches if d is not None
            )
            if day_strs:
                top = day_strs.most_common(1)[0][0]
                parser_year = getattr(self._parser, "_default_year", None)
                anchor_day = _parse_date_token(top, default_year=parser_year)
        if anchor_day is None:
            anchor_day = date.today()
        return LogWindow(
            source_files=list(log_files),
            window_path=out_path,
            start_time=datetime.combine(
                anchor_day,
                time(start_sec // 3600, (start_sec % 3600) // 60, start_sec % 60),
            ),
            end_time=datetime.combine(
                anchor_day,
                time(end_sec // 3600, (end_sec % 3600) // 60, end_sec % 60),
            ),
            line_count=len(matches),
        )

    def build_full_log_window(
        self,
        *,
        log_files: Sequence[Path],
        out_dir: Path,
        file_name: str = "window.log",
        reference_date: Optional[date] = None,
    ) -> LogWindow:
        """Last-resort fallback: concatenate the full log file(s) verbatim.

        Used when both the wall-clock window and the HH:MM-only window
        return zero lines (mismatched recording day, unparseable
        timestamps, etc.). Per the user contract: when the bug-window
        extraction fails, we hand the whole file to the LLM rather
        than an empty window.

        ``start_time``/``end_time`` are best-effort — taken from the
        first/last parseable timestamps in the source files; otherwise
        they fall back to ``reference_date`` (or today) at midnight.
        """
        out_dir.mkdir(parents=True, exist_ok=True)
        out_path = out_dir / file_name

        line_count = 0
        first_ts: Optional[datetime] = None
        last_ts: Optional[datetime] = None
        first_date_token: Optional[str] = None
        with out_path.open("w", encoding="utf-8") as out_fh:
            for log_file in log_files:
                with log_file.open("r", encoding="utf-8", errors="replace") as in_fh:
                    for raw in in_fh:
                        out_fh.write(raw)
                        if not raw.endswith("\n"):
                            out_fh.write("\n")
                        line_count += 1
                        m = _LEADING_TS_RE.match(raw)
                        if m is not None:
                            if first_date_token is None:
                                first_date_token = m.group("date")
                            h = int(m.group("h"))
                            mn = int(m.group("m"))
                            s = int(m.group("s"))
                            day = (
                                _parse_date_token(
                                    m.group("date"),
                                    default_year=getattr(
                                        self._parser, "_default_year", None
                                    ),
                                )
                                or reference_date
                            )
                            if day is not None:
                                ts = datetime.combine(day, time(h, mn, s))
                                if first_ts is None:
                                    first_ts = ts
                                last_ts = ts

        if first_ts is None:
            anchor = reference_date or date.today()
            first_ts = datetime.combine(anchor, time(0, 0, 0))
            last_ts = datetime.combine(anchor, time(23, 59, 59))
        elif last_ts is None:
            last_ts = first_ts

        return LogWindow(
            source_files=list(log_files),
            window_path=out_path,
            start_time=first_ts,
            end_time=last_ts,
            line_count=line_count,
        )

    def build_log_window_pair(
        self,
        *,
        log_files: Sequence[Path],
        start_wallclock: datetime,
        end_wallclock: datetime,
        out_dir: Path,
        pad_before_s: float = 300.0,
        pad_after_s: float = 120.0,
        wide_multiplier: float = 2.0,
        min_useful_lines: int = 50,
        file_name: str = "window.log",
        wide_file_name: str = "window.wide.log",
    ) -> tuple[LogWindow, LogWindow | None]:
        """Produce a normal window plus (optionally) a wider fallback window.

        Two files are written:

        * ``file_name`` — the narrow window using
          ``[start − pad_before ; end + pad_after]``. This is what the
          LLM diagnosis step consumes.
        * ``wide_file_name`` — only written when the narrow window is
          "too thin" (fewer than ``min_useful_lines``). The wide window
          doubles both paddings by default
          (``wide_multiplier=2.0``). Kept on disk for manual inspection
          when the automated diagnosis on the narrow window is
          inconclusive.

        Returns ``(narrow, wide_or_None)``. ``wide_or_None`` is ``None``
        when the narrow window was already rich enough.
        """
        narrow = self.build_log_window(
            log_files=log_files,
            start_wallclock=start_wallclock,
            end_wallclock=end_wallclock,
            out_dir=out_dir,
            pad_before_s=pad_before_s,
            pad_after_s=pad_after_s,
            file_name=file_name,
        )
        if narrow.line_count >= max(1, int(min_useful_lines)):
            return narrow, None

        wide = self.build_log_window(
            log_files=log_files,
            start_wallclock=start_wallclock,
            end_wallclock=end_wallclock,
            out_dir=out_dir,
            pad_before_s=float(pad_before_s) * float(wide_multiplier),
            pad_after_s=float(pad_after_s) * float(wide_multiplier),
            file_name=wide_file_name,
        )
        return narrow, wide
