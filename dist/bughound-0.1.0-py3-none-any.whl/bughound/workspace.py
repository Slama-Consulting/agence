"""Per-ticket workspace: one folder under ``analyse/`` groups everything.

Every ticket analysed by BugHound gets its own subdirectory under
``<workdir>/analyse/<TICKET-KEY>/``. This keeps downloads, unpacked
archives, video analysis artefacts and the final report together —
easy to browse, easy to clean up.

The split between "transient" (downloads/extracted/video frames) and
"kept" (report Markdown + JSON) lets us offer a cleanup step at the
end of the pipeline: the user confirms the report is correct, and we
delete only the heavy bulk while keeping the report itself.
"""

from __future__ import annotations

import logging
import shutil
from dataclasses import dataclass
from pathlib import Path

from .utils.fs import ensure_dir, safe_filename

log = logging.getLogger(__name__)


# The subfolder under ``workdir`` that hosts one directory per ticket.
ANALYSE_SUBDIR = "analyse"


@dataclass(frozen=True)
class TicketWorkspace:
    """Isolated workspace for a single ticket analysis.

    Layout::

        <workdir>/analyse/<TICKET>/
            <TICKET>.md              ← report (kept)
            <TICKET>.json            ← report JSON (kept)
            downloads/               ← transient
            extracted/               ← transient
            video_analysis/          ← transient (OCR frames, scene thumbs…)
            frames/                  ← transient (10s sampled frames for OCR clock)
            logs_window/             ← transient (consolidated log window)
    """

    ticket_key: str
    root: Path
    downloads: Path
    extracted: Path
    video_analysis: Path
    frames: Path
    logs_window: Path
    report_md: Path
    report_json: Path

    @classmethod
    def for_ticket(cls, base_workdir: Path, ticket_key: str) -> "TicketWorkspace":
        """Build the canonical workspace for ``ticket_key`` under ``base_workdir``.

        No directories are created yet — call :meth:`ensure_dirs` when you're
        ready to write. This lets tests build a workspace cheaply and assert
        on paths without touching disk.
        """
        safe_key = safe_filename(ticket_key)
        root = Path(base_workdir).expanduser() / ANALYSE_SUBDIR / safe_key
        return cls(
            ticket_key=ticket_key,
            root=root,
            downloads=root / "downloads",
            extracted=root / "extracted",
            video_analysis=root / "video_analysis",
            frames=root / "frames",
            logs_window=root / "logs_window",
            report_md=root / f"{safe_key}.md",
            report_json=root / f"{safe_key}.json",
        )

    # ---- disk lifecycle ---------------------------------------------------

    def ensure_dirs(self) -> None:
        """Create ``root`` and all transient subdirectories."""
        ensure_dir(self.root)
        ensure_dir(self.downloads)
        ensure_dir(self.extracted)
        ensure_dir(self.video_analysis)
        ensure_dir(self.frames)
        ensure_dir(self.logs_window)

    def cleanup_transients(self) -> list[Path]:
        """Delete every transient subdirectory; keep the report files.

        Returns the list of directories that were actually removed, so
        callers can report what was freed.
        """
        removed: list[Path] = []
        for candidate in (
            self.downloads,
            self.extracted,
            self.video_analysis,
            self.frames,
            self.logs_window,
        ):
            if candidate.exists():
                shutil.rmtree(candidate, ignore_errors=True)
                removed.append(candidate)
        return removed


__all__ = ["ANALYSE_SUBDIR", "TicketWorkspace"]
