"""MCP server exposing BugHound to Copilot Chat / Claude Desktop.

Goal: let the user type *"analyse CCSEXT-235266"* inside Copilot Chat and
have the BugHound pipeline run end-to-end, returning the rendered Markdown
report directly in the chat — no terminal commands.

The server exposes three tools:

- ``analyze_ticket(ticket_key, project_path=None)``
    Runs the full pipeline and returns the Markdown report.
- ``list_candidate_projects()``
    Returns directories under the configured ``search_roots`` so the caller
    can offer a manual pick when auto-resolution fails.
- ``get_report(ticket_key)``
    Re-reads an already-generated report from the output directory.

The transport is stdio (``python -m bughound mcp-serve``), which matches
the default VS Code / Claude Desktop configuration.

The server is intentionally thin: it delegates every unit of work to the
existing :class:`BugHoundPipeline`, so the MCP surface stays aligned with
the CLI behaviour without duplicating logic.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Optional

from .analyzers import (
    AutoClarificationHandler,
    BestHandoffPayload,
    InteractiveClarificationHandler,
    MonolithicAnalyzer,
)
from .attachments import (
    AttachmentManager,
    CachingPasswordProvider,
    PasswordProvider,
)
from .config import BugHoundConfig, load_config
from .core.models import ResolvedProject as ResolvedProjectModel
from .jira_client import build_jira_client
from .llm import LLMClient, build_llm_client
from .logs import LogCorrelator, LogcatParser
from .pipeline import BugHoundPipeline
from .projects import ProjectResolver
from .projects.resolver import ResolvedProject
from .reporter import render_markdown, write_report
from .video import OcrDetector, SceneChangeDetector, TesseractOcrEngine, VideoAnalyzer


log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pipeline wiring (pure helpers — no MCP types here so they stay unit-testable)
# ---------------------------------------------------------------------------


def _build_video_analyzer(cfg: BugHoundConfig) -> Optional[VideoAnalyzer]:
    """Best-effort video analyzer. Returns ``None`` if deps are missing.

    We never want a missing Tesseract to make the whole MCP tool fail —
    callers can still get ticket analysis, log correlation and code refs
    without video events.
    """
    scene = SceneChangeDetector(change_threshold=cfg.video.scene_change_threshold)
    engine = None
    try:
        engine = TesseractOcrEngine(
            tesseract_cmd=Path(cfg.video.tesseract_cmd) if cfg.video.tesseract_cmd else None,
        )
    except RuntimeError as exc:
        log.info("OCR disabled: %s", exc)

    ocr_detector = OcrDetector(engine) if engine is not None else None

    # with_defaults wires DisplayTimeDetector + OcrDetector + scene together
    # when Tesseract is available; fall back to a minimal analyzer otherwise.
    if engine is not None:
        return VideoAnalyzer.with_defaults(
            ocr_engine=engine,
            scene_detector=scene,
        )
    return VideoAnalyzer(ocr_detector=ocr_detector, scene_detector=scene)


def _build_pipeline(
    cfg: BugHoundConfig,
    *,
    project_override: Optional[ResolvedProject] = None,
    password_provider: Optional[PasswordProvider] = None,
    llm_override: Optional[LLMClient] = None,
    monolithic: bool = False,
    monolithic_analyzer: Optional[MonolithicAnalyzer] = None,
    mode: str = "legacy",
) -> tuple[BugHoundPipeline, Path]:
    """Build a fully-wired pipeline from a config. Returns (pipeline, out_dir).

    ``llm_override`` lets callers bypass the config-driven factory. The MCP
    tool uses it to substitute the terminal-based ``CopilotClient`` for a
    chat-aware ``MCPCopilotClient`` when ``llm.mode == "copilot"``; without
    that swap, the copilot client would deadlock reading from a stdin that
    is already claimed by the MCP stdio transport.

    ``monolithic`` enables the single-conversation analyser (replaces the
    legacy chain of stateless LLM calls). When the caller does not provide
    a ``monolithic_analyzer``, we build a default one that uses the
    deterministic :class:`AutoClarificationHandler` so the pipeline never
    blocks waiting for chat input.
    """
    out_dir = Path(cfg.output.workdir).expanduser()
    out_dir.mkdir(parents=True, exist_ok=True)

    jira = build_jira_client(
        mode=cfg.jira.mode,
        base_url=cfg.jira.base_url,
        email=cfg.jira.email,
        api_token=cfg.jira.api_token,
        browser_profile_dir=cfg.jira.browser_profile_dir,
        browser_headless_after_login=cfg.jira.browser_headless_after_login,
        write_allowed_projects=cfg.jira.write_allowed_projects,
    )
    if llm_override is not None:
        llm: LLMClient = llm_override
    else:
        llm = build_llm_client(
            mode=cfg.llm.mode,
            provider=cfg.llm.provider,
            model=cfg.llm.model,
            api_key=cfg.llm.api_key,
        )
    video_analyzer = _build_video_analyzer(cfg)
    resolver = ProjectResolver(
        search_roots=cfg.projects.search_roots,
        fuzzy_threshold=cfg.projects.fuzzy_threshold,
    )

    attachment_manager = AttachmentManager(
        jira,
        password_provider=(
            CachingPasswordProvider(password_provider)
            if password_provider is not None
            else None
        ),
    )

    # ``best`` mode never invokes the monolithic analyser inside
    # BugHound — the LLM call is fully delegated to the external chat.
    if mode != "best" and monolithic and monolithic_analyzer is None:
        monolithic_analyzer = MonolithicAnalyzer(
            llm, clarification_handler=AutoClarificationHandler()
        )

    pipeline = BugHoundPipeline(
        jira=jira,
        llm=llm,
        workdir=out_dir,
        attachment_manager=attachment_manager,
        video_analyzer=video_analyzer,
        correlator=LogCorrelator(
            parser=LogcatParser(),
            window_before_s=cfg.logs.window_before_s,
            window_after_s=cfg.logs.window_after_s,
        ),
        project_resolver=resolver,
        project_override=project_override,
        monolithic_analyzer=monolithic_analyzer if mode != "best" else None,
        mode=mode,
    )
    return pipeline, out_dir


def analyze_ticket_impl(
    ticket_key: str,
    *,
    cfg: BugHoundConfig,
    project_path: Optional[Path] = None,
    progress: Optional[Any] = None,
    password_provider: Optional[PasswordProvider] = None,
    llm_override: Optional[LLMClient] = None,
    monolithic: bool = False,
    monolithic_analyzer: Optional[MonolithicAnalyzer] = None,
    mode: str = "legacy",
) -> dict[str, Any]:
    """Pure-Python entry point used by both the MCP tool and the tests.

    Returns a dict with ``markdown`` (the rendered report) and a small
    summary so callers that can't render Markdown still get structured data.

    ``progress`` is an optional callback ``(step, total, message)`` used
    by the MCP tool to stream live status to the chat client; tests
    either omit it or pass a list-appender to capture the sequence.

    ``password_provider`` is optional: when supplied, encrypted archives
    can be unlocked via whatever channel the caller wires up (terminal
    prompt in the CLI, MCP elicitation in the chat).

    ``llm_override`` forces a specific LLM client regardless of
    ``cfg.llm``. Used by the MCP tool to swap the terminal copilot for
    a chat-aware one when stdin/stdout would otherwise collide with the
    JSON-RPC transport.
    """
    override: Optional[ResolvedProject] = None
    if project_path is not None:
        root = Path(project_path).expanduser().resolve()
        override = ResolvedProject(
            ticket_key=ticket_key,
            root=root,
            name=root.name,
            matched_on="manual",
            score=1.0,
        )

    # When the caller asked for ``best`` mode but still passed
    # ``monolithic=True`` (legacy combo), we honour ``best`` — the
    # whole point is to skip BugHound's LLM altogether.
    effective_mode = mode
    if effective_mode == "legacy" and monolithic:
        effective_mode = "monolithic"

    pipeline, out_dir = _build_pipeline(
        cfg,
        project_override=override,
        password_provider=password_provider,
        llm_override=llm_override,
        monolithic=monolithic and effective_mode == "monolithic",
        monolithic_analyzer=(
            monolithic_analyzer if effective_mode == "monolithic" else None
        ),
        mode=effective_mode,
    )
    result = pipeline.run(ticket_key, progress=progress)

    if isinstance(result, BestHandoffPayload):
        # ``best`` mode: BugHound did *no* LLM work. Surface the prompt
        # and artefact paths verbatim so the calling chat can execute
        # the workflow inside its own single context. Persist the
        # prompt to disk so it can be retrieved/inspected later.
        payload = result
        prompt_path = payload.analysis_dir / "handoff_prompt.md"
        try:
            prompt_path.write_text(payload.prompt, encoding="utf-8")
        except OSError as exc:  # pragma: no cover - defensive
            log.warning("failed to persist handoff prompt: %s", exc)
        return {
            "ticket_key": payload.ticket_key,
            "title": payload.ticket_title,
            "mode": "best",
            "project_root": str(payload.project_root),
            "analysis_dir": str(payload.analysis_dir),
            "logs_txt_path": (
                str(payload.logs_txt_path) if payload.logs_txt_path else None
            ),
            "video_anchor": payload.video_anchor,
            "missing": list(payload.missing),
            "prompt": payload.prompt,
            "prompt_path": str(prompt_path),
            "ready": not payload.missing,
        }

    report = result
    workspace = pipeline.last_workspace
    md_path = write_report(
        report,
        out_dir,
        emit_json=cfg.output.emit_json,
        workspace=workspace,
    )

    markdown = render_markdown(report)

    return {
        "ticket_key": report.ticket.key,
        "title": report.ticket.title,
        "report_path": str(md_path),
        "workspace": str(workspace.root) if workspace is not None else None,
        "project": (
            {
                "name": report.project.name,
                "root": str(report.project.root),
                "matched_on": report.project.matched_on,
                "score": report.project.score,
            }
            if report.project is not None
            else None
        ),
        "video_events": len(report.video_events),
        "log_excerpts": len(report.log_excerpts),
        "code_references": len(report.code_references),
        "notes": list(report.notes),
        "markdown": markdown,
    }


def list_candidate_projects_impl(cfg: BugHoundConfig) -> list[dict[str, str]]:
    """Return candidate directories under the configured search roots."""
    out: list[dict[str, str]] = []
    for root in cfg.projects.search_roots:
        root = Path(root).expanduser()
        if not root.exists():
            continue
        for child in sorted(root.iterdir()):
            if child.is_dir() and not child.name.startswith("."):
                out.append({"name": child.name, "path": str(child.resolve())})
    return out


def get_report_impl(ticket_key: str, *, cfg: BugHoundConfig) -> dict[str, Any]:
    """Re-read a previously written report from the output directory.

    Looks first in the per-ticket workspace layout
    (``<workdir>/analyse/<TICKET>/<TICKET>.md``) and falls back to the
    legacy flat layout (``<workdir>/<TICKET>.md``) for reports written by
    older runs.
    """
    from .workspace import TicketWorkspace

    out_dir = Path(cfg.output.workdir).expanduser()
    workspace = TicketWorkspace.for_ticket(out_dir, ticket_key)
    candidates = [workspace.report_md, out_dir / f"{ticket_key}.md"]
    for md_path in candidates:
        if md_path.exists():
            return {
                "ticket_key": ticket_key,
                "found": True,
                "report_path": str(md_path),
                "markdown": md_path.read_text(encoding="utf-8"),
            }
    return {
        "ticket_key": ticket_key,
        "found": False,
        "report_path": str(candidates[0]),
        "markdown": "",
    }


def confirm_and_cleanup_impl(
    ticket_key: str,
    *,
    cfg: BugHoundConfig,
    confirm: bool,
) -> dict[str, Any]:
    """Delete a ticket's transient artefacts once the user validates the report.

    When ``confirm`` is true, removes ``downloads/``, ``extracted/`` and
    ``video_analysis/`` under ``<workdir>/analyse/<TICKET>/``. The
    Markdown/JSON report files stay untouched.
    When ``confirm`` is false, nothing is deleted — the response still
    reports the workspace contents so the caller can relay them to the user.
    """
    from .workspace import TicketWorkspace

    out_dir = Path(cfg.output.workdir).expanduser()
    workspace = TicketWorkspace.for_ticket(out_dir, ticket_key)

    if not workspace.root.exists():
        return {
            "ticket_key": ticket_key,
            "workspace": str(workspace.root),
            "confirmed": bool(confirm),
            "cleaned": False,
            "removed": [],
            "message": (
                f"Aucun dossier d'analyse trouvé pour {ticket_key} "
                f"(chemin attendu : {workspace.root})."
            ),
        }

    if not confirm:
        return {
            "ticket_key": ticket_key,
            "workspace": str(workspace.root),
            "confirmed": False,
            "cleaned": False,
            "removed": [],
            "message": (
                f"Conservation demandée — tous les fichiers de "
                f"{workspace.root} sont laissés en place."
            ),
        }

    removed = workspace.cleanup_transients()
    return {
        "ticket_key": ticket_key,
        "workspace": str(workspace.root),
        "confirmed": True,
        "cleaned": True,
        "removed": [str(p) for p in removed],
        "message": (
            f"{len(removed)} dossier(s) transitoire(s) supprimé(s) ; "
            f"rapport conservé sous {workspace.report_md}."
        ),
    }


# ---------------------------------------------------------------------------
# MCP server glue
# ---------------------------------------------------------------------------


DEFAULT_CONFIG_PATH = Path("config/config.yaml")


def build_server(config_path: Path = DEFAULT_CONFIG_PATH):  # type: ignore[no-untyped-def]
    """Build and return a configured :class:`FastMCP` server.

    ``mcp`` is imported lazily so the test suite (which stubs the helpers
    directly) doesn't require the MCP SDK to be installed.
    """
    from mcp.server.fastmcp import Context, FastMCP

    # Make ``Context`` importable by name from this module's globals so
    # FastMCP's signature introspection (which re-evaluates stringified
    # annotations because of ``from __future__ import annotations``) can
    # resolve ``ctx: Context`` on the tool below. Without this, FastMCP
    # raises ``InvalidSignature: Unable to evaluate type annotations``.
    globals()["Context"] = Context

    server = FastMCP(
        name="bughound",
        instructions=(
            "BugHound analyses a Jira ticket end-to-end: it downloads "
            "attachments, runs OCR + scene detection on videos, aligns "
            "logcat with the detected events and cross-references stack "
            "traces against a local Android Studio codebase. "
            "PREFERRED USAGE: call `analyze_ticket(ticket_key, mode=\"best\")` "
            "by default whenever the user asks to debug/investigate/triage "
            "a ticket. In `best` mode BugHound only prepares the artefacts "
            "(logs.txt, analyse/<TICKET>/) and returns a `prompt` field "
            "containing the full debug workflow — you MUST then execute "
            "that prompt verbatim inside this same chat (single-context "
            "handoff, no second tool call). Only fall back to "
            "`mode=\"legacy\"` or `mode=\"monolithic\"` when the user "
            "explicitly asks for a full BugHound markdown report."
        ),
    )

    # The config is loaded per-call so the server picks up edits to
    # config.yaml without needing a restart.
    def _cfg() -> BugHoundConfig:
        return load_config(config_path)

    # FastMCP invokes each tool from inside an asyncio loop. The browser-
    # backed Jira client uses Playwright's *sync* API, which refuses to
    # run while an asyncio loop is active. We therefore offload the whole
    # pipeline to a worker thread via anyio — that thread has no running
    # loop, so Playwright is happy. The other two tools do no I/O that
    # cares about event loops, but we still offload them for consistency
    # (and so a stray blocking call inside ``load_config`` can't stall
    # the server's heartbeat).
    import anyio

    @server.tool(
        description=(
            "Run the BugHound pipeline on a Jira ticket. Use this whenever "
            "the user asks to analyse, investigate, debug or triage a "
            "ticket. Progress is streamed step-by-step while the pipeline "
            "runs.\n"
            "\n"
            "DEFAULT MODE: always call this tool with `mode=\"best\"` "
            "unless the user explicitly asks for a full BugHound markdown "
            "report. In `best` mode BugHound does ZERO LLM work — it only "
            "downloads the ticket, extracts the relevant log window and "
            "the video timing, then returns a `prompt` field that contains "
            "the full debug workflow (logs analysis, code analysis, "
            "regression check, fix proposal, git verification). You MUST "
            "execute that `prompt` verbatim in this chat as if the user "
            "had typed it themselves. The response also carries "
            "`analysis_dir`, `logs_txt_path` and `missing` (list of inputs "
            "marked `[MANQUANT]` in the prompt — ask the user for them in "
            "this same chat before continuing the workflow).\n"
            "\n"
            "Other modes (only on explicit request):\n"
            "- `mode=\"legacy\"`: BugHound calls its own LLM through the "
            "  legacy analyser chain and returns a rendered `markdown` "
            "  report. Slower, costs extra tokens, breaks single-context.\n"
            "- `mode=\"monolithic\"` (or `monolithic=true`): single-call "
            "  BugHound analyser. Same caveats as legacy."
        ),
    )
    async def analyze_ticket(
        ticket_key: str,
        ctx: Context,
        project_path: Optional[str] = None,
        monolithic: bool = False,
        mode: str = "legacy",
    ) -> dict[str, Any]:
        # Signature de l'agence — émise une seule fois au début de
        # chaque enquête pour rappeler qui mène le bal.
        try:
            await ctx.info(
                "🕵️ SherleKhomes — agent de l'agence Slama Consulting"
            )
        except Exception:  # pragma: no cover - never break analysis on UI glitches
            log.debug("failed to emit agency signature", exc_info=True)

        # Bridge the *sync* progress callback (invoked by the pipeline
        # running in a worker thread) back to the *async* MCP Context
        # that lives on the FastMCP event loop. ``anyio.from_thread.run``
        # is the canonical way to schedule a coroutine from a worker
        # thread without re-entering the main loop from the wrong side.
        import anyio.from_thread as _from_thread

        def _progress(step: int, total: int, message: str) -> None:
            label = f"[{step}/{total}] {message}"
            try:
                _from_thread.run(ctx.info, label)
                _from_thread.run(ctx.report_progress, step, total, message)
            except Exception:  # pragma: no cover - UI glitches must not fail analysis
                log.debug("failed to stream progress event", exc_info=True)

        def _unwrap_elicit(answer: Any) -> Optional[str]:
            """Normalise the various shapes of an MCP elicit response.

            Different MCP SDK versions return either a plain string or a
            small object with a ``.value`` / ``.content`` / ``.text``
            attribute. An empty answer is treated as ``None`` (cancel).
            """
            if answer is None:
                return None
            for attr in ("value", "content", "text"):
                val = getattr(answer, attr, None)
                if isinstance(val, str):
                    return val or None
            if isinstance(answer, str):
                return answer or None
            return None

        def _ask_password(archive: Path) -> Optional[str]:
            """Bridge the extractor's sync password request to ctx.elicit."""
            prompt = (
                f"L'archive « {archive.name} » est protégée par mot de "
                f"passe. Indiquez le mot de passe (laissez vide pour "
                f"ignorer cette archive)."
            )
            try:
                answer = _from_thread.run(ctx.elicit, prompt)
            except Exception:  # pragma: no cover - UI glitches must not fail analysis
                log.debug("password elicitation failed", exc_info=True)
                return None
            return _unwrap_elicit(answer)

        # If the user stayed in copilot mode, swap the terminal-based
        # client for one that talks through the chat. Printing to stdout
        # would corrupt the MCP JSON-RPC framing, and reading stdin would
        # deadlock (the MCP transport already owns it).
        #
        # ``best`` mode skips this entirely: BugHound does not call any
        # LLM, so wiring up MCPCopilotClient would be wasted work and
        # could fail when ctx.elicit isn't available (e.g. tests).
        llm_override: Optional[LLMClient] = None
        cfg_snapshot = _cfg()
        if mode != "best" and cfg_snapshot.llm.mode.lower().strip() == "copilot":
            from .llm import MCPCopilotClient

            def _llm_info(message: str) -> None:
                try:
                    _from_thread.run(ctx.info, message)
                except Exception:  # pragma: no cover - UI glitches
                    log.debug("failed to surface copilot prompt", exc_info=True)

            def _llm_elicit(question: str) -> Optional[str]:
                try:
                    answer = _from_thread.run(ctx.elicit, question)
                except Exception:  # pragma: no cover - UI glitches
                    log.debug("copilot elicit failed", exc_info=True)
                    return None
                return _unwrap_elicit(answer)

            llm_override = MCPCopilotClient(info=_llm_info, elicit=_llm_elicit)

        # Wire a chat-aware monolithic analyser when the caller asked for
        # the new flow. Clarification questions raised by the LLM are
        # forwarded to ``ctx.elicit`` so the user can answer them inline
        # in the chat. The ``InteractiveClarificationHandler`` falls back
        # to the deterministic auto handler when the elicit returns empty.
        # ``best`` mode never calls any LLM, so we skip this entirely.
        monolithic_analyzer: Optional[MonolithicAnalyzer] = None
        if monolithic and mode != "best":
            from .llm import build_llm_client as _build_llm_client

            chat_llm = llm_override or _build_llm_client(
                mode=cfg_snapshot.llm.mode,
                provider=cfg_snapshot.llm.provider,
                model=cfg_snapshot.llm.model,
                api_key=cfg_snapshot.llm.api_key,
            )

            def _ask_clarification(question: str, options: list[str]) -> str:
                prompt = question
                if options:
                    prompt += " (options : " + " | ".join(options) + ")"
                try:
                    answer = _from_thread.run(ctx.elicit, prompt)
                except Exception:  # pragma: no cover - UI glitches
                    log.debug("clarification elicit failed", exc_info=True)
                    return ""
                return _unwrap_elicit(answer) or ""

            monolithic_analyzer = MonolithicAnalyzer(
                chat_llm,
                clarification_handler=InteractiveClarificationHandler(
                    prompt_fn=_ask_clarification,
                ),
            )

        def _run() -> dict[str, Any]:
            return analyze_ticket_impl(
                ticket_key,
                cfg=cfg_snapshot,
                project_path=Path(project_path) if project_path else None,
                progress=_progress,
                password_provider=_ask_password,
                llm_override=llm_override,
                monolithic=monolithic,
                monolithic_analyzer=monolithic_analyzer,
                mode=mode,
            )

        return await anyio.to_thread.run_sync(_run)

    @server.tool(
        description=(
            "List local Android Studio / IntelliJ projects that BugHound "
            "can cross-reference against. Useful when auto-resolution "
            "fails and the user needs to pick one manually."
        ),
    )
    async def list_candidate_projects() -> list[dict[str, str]]:
        return await anyio.to_thread.run_sync(
            lambda: list_candidate_projects_impl(_cfg())
        )

    @server.tool(
        description=(
            "Re-read a report previously generated by `analyze_ticket`. "
            "Returns the Markdown and structured metadata."
        ),
    )
    async def get_report(ticket_key: str) -> dict[str, Any]:
        return await anyio.to_thread.run_sync(
            lambda: get_report_impl(ticket_key, cfg=_cfg())
        )

    @server.tool(
        description=(
            "Call this AFTER `analyze_ticket` when the user tells you the "
            "report is correct. Pass `confirm=true` to delete the ticket's "
            "transient artefacts (downloads, extracted archives, video "
            "frames) while keeping the Markdown/JSON report. Pass "
            "`confirm=false` if the user wants to keep everything for "
            "manual inspection."
        ),
    )
    async def confirm_and_cleanup(
        ticket_key: str,
        confirm: bool,
    ) -> dict[str, Any]:
        return await anyio.to_thread.run_sync(
            lambda: confirm_and_cleanup_impl(
                ticket_key, cfg=_cfg(), confirm=confirm,
            )
        )

    return server


def run_stdio(config_path: Path = DEFAULT_CONFIG_PATH) -> None:
    """Entry point used by ``python -m bughound mcp-serve``.

    Runs the MCP server over stdio; this is the transport VS Code (Copilot
    Chat) and Claude Desktop use by default.
    """
    server = build_server(config_path)
    server.run()
