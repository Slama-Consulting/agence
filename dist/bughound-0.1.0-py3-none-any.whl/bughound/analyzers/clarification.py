"""Answer the clarification questions raised by the monolithic analyzer.

When :class:`~bughound.analyzers.monolithic.MonolithicAnalyzer` receives a
``ask_clarification`` JSON from the LLM, it delegates the answer to a
:class:`ClarificationHandler`. Two canonical implementations ship with
BugHound:

- :class:`AutoClarificationHandler` answers deterministically from a small
  rule set so non-interactive runs (CI, MCP tools that disabled
  ``elicit``, etc.) never block;
- :class:`InteractiveClarificationHandler` forwards the question to a
  user-provided callback (CLI input, MCP ``ctx.elicit``, ...).

The contract is intentionally minimal: a single ``resolve`` method returns
a free-form string the analyzer feeds back to the LLM as the next user
turn. No reasoning happens here — these handlers are *routers*, not
analyzers.
"""

from __future__ import annotations

from typing import Callable, Iterable, Optional, Protocol


class ClarificationHandler(Protocol):
    """Protocol implemented by every clarification router."""

    def resolve(
        self,
        question: str,
        options: list[str],
        missing_signals: list[str],
    ) -> str:
        """Return a free-form answer to be fed back to the LLM.

        ``question`` is the raw text produced by the LLM (French). ``options``
        is an optional list of suggested answers (French). ``missing_signals``
        is the deterministic flag list that the pipeline provided to the
        analyzer (e.g. ``["logs_missing", "video_clock_missing"]``), kept
        here so handlers can apply heuristics without re-parsing prose.
        """
        ...


#: Known deterministic signals that the pipeline may surface to the analyzer.
#: Keep in sync with :class:`bughound.pipeline.BugHoundPipeline` call sites.
LOGS_MISSING = "logs_missing"
VIDEO_CLOCK_MISSING = "video_clock_missing"
NO_CODE_REFS = "no_code_refs"


class AutoClarificationHandler:
    """Deterministic router that never blocks the run.

    The handler scans the ``missing_signals`` first (authoritative) and
    falls back to simple keyword heuristics on the question text. When it
    cannot map the question to a rule, it returns a neutral sentence that
    tells the LLM to proceed with the data it already has.
    """

    #: Canonical responses keyed by missing-signal name. Kept as a class
    #: attribute so tests can patch or extend them without subclassing.
    DEFAULT_ANSWERS: dict[str, str] = {
        LOGS_MISSING: (
            "Pas de logs exploitables disponibles. Procède avec l'analyse "
            "dégradée : indique-le clairement dans root_cause et laisse "
            "reproduction_steps vide."
        ),
        VIDEO_CLOCK_MISSING: (
            "L'horloge vidéo n'a pas pu être lue. Utilise les mots-clés du "
            "ticket pour ancrer la fenêtre de logs, ou procède sans ancrage "
            "temporel si ce n'est pas possible."
        ),
        NO_CODE_REFS: (
            "Aucune référence de code n'a pu être extraite automatiquement. "
            "Si tu ne peux pas proposer de patch sûr, laisse proposed_fix à "
            "null et baisse confidence_score en conséquence."
        ),
    }

    #: Fallback answer when no rule matches.
    FALLBACK_ANSWER: str = (
        "Procède avec les informations dont tu disposes. Si un champ ne peut "
        "pas être rempli avec certitude, laisse-le vide ou baisse "
        "confidence_score plutôt que de spéculer."
    )

    def resolve(
        self,
        question: str,
        options: list[str],
        missing_signals: list[str],
    ) -> str:
        # Signal-driven answers take precedence: they encode pipeline-side
        # knowledge that the LLM cannot see.
        for signal in missing_signals:
            answer = self.DEFAULT_ANSWERS.get(signal)
            if answer:
                return answer

        # Lightweight keyword heuristic on the question itself.
        lowered = question.lower()
        if "log" in lowered and (
            "manque" in lowered
            or "disponib" in lowered
            or "vide" in lowered
        ):
            return self.DEFAULT_ANSWERS[LOGS_MISSING]
        if "horloge" in lowered or "timestamp" in lowered or "heure" in lowered:
            return self.DEFAULT_ANSWERS[VIDEO_CLOCK_MISSING]

        # If options were offered, prefer the safest one (the first): the
        # LLM is responsible for listing the most neutral default first.
        if options:
            return options[0]

        return self.FALLBACK_ANSWER


#: Signature of the prompt callback used by :class:`InteractiveClarificationHandler`.
#: ``question`` is the LLM question, ``options`` is the optional suggestion list.
#: The callback returns the user's free-form answer (or an empty string).
InteractivePromptFn = Callable[[str, list[str]], str]


class InteractiveClarificationHandler:
    """Route the question to a user-provided callback (CLI, MCP, …).

    The callback is completely free to prompt via ``input()``, a GUI, an
    MCP ``ctx.elicit`` call, etc. When it returns an empty string (user
    cancelled or pressed enter), the handler falls back to an internal
    :class:`AutoClarificationHandler` so the run never deadlocks.
    """

    def __init__(
        self,
        prompt_fn: InteractivePromptFn,
        *,
        auto_fallback: Optional[ClarificationHandler] = None,
    ) -> None:
        self._prompt_fn = prompt_fn
        self._auto_fallback = auto_fallback or AutoClarificationHandler()

    def resolve(
        self,
        question: str,
        options: list[str],
        missing_signals: list[str],
    ) -> str:
        try:
            answer = self._prompt_fn(question, list(options))
        except Exception:  # pragma: no cover - defensive, UI glitches happen
            return self._auto_fallback.resolve(question, options, missing_signals)

        if answer is None or not str(answer).strip():
            return self._auto_fallback.resolve(question, options, missing_signals)
        return str(answer).strip()


def _coerce_signal_list(signals: Optional[Iterable[str]]) -> list[str]:
    """Utility used by analyzers to normalise the ``missing_signals`` input."""
    if not signals:
        return []
    return [str(s).strip() for s in signals if str(s).strip()]


__all__ = [
    "AutoClarificationHandler",
    "ClarificationHandler",
    "InteractiveClarificationHandler",
    "InteractivePromptFn",
    "LOGS_MISSING",
    "NO_CODE_REFS",
    "VIDEO_CLOCK_MISSING",
    "_coerce_signal_list",
]
