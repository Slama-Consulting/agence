"""Ticket analyzer: type detection + comment relevance filtering."""

from __future__ import annotations

import logging
from typing import Any, Iterable

from ..core.models import (
    Comment,
    CommentRelevance,
    Ticket,
    TicketAnalysis,
    TicketType,
)
from ..llm import LLMClient
from . import prompts

log = logging.getLogger(__name__)


# Maximum number of comments sent in a single LLM call. Keeps prompts short
# enough to stay within context limits on small models.
DEFAULT_COMMENT_BATCH_SIZE = 10


class TicketAnalyzer:
    """Produces a :class:`TicketAnalysis` from a fetched :class:`Ticket`."""

    def __init__(
        self,
        llm: LLMClient,
        *,
        comment_batch_size: int = DEFAULT_COMMENT_BATCH_SIZE,
    ) -> None:
        self._llm = llm
        self._batch_size = max(1, comment_batch_size)

    # ---- public API -------------------------------------------------------

    def analyze(self, ticket: Ticket) -> TicketAnalysis:
        ticket_type, type_confidence, summary = self._classify_ticket(ticket)
        relevance = self._score_comments(ticket)

        return TicketAnalysis(
            ticket_key=ticket.key,
            ticket_type=ticket_type,
            type_confidence=type_confidence,
            summary=summary,
            relevant_comments=relevance,
        )

    # ---- steps ------------------------------------------------------------

    def _classify_ticket(self, ticket: Ticket) -> tuple[TicketType, float, str]:
        prompt = prompts.render_ticket_type_prompt(
            key=ticket.key,
            title=ticket.title,
            description=ticket.description,
        )
        response = self._llm.complete_json(
            system=prompts.TICKET_TYPE_SYSTEM,
            user=prompt,
            schema_hint=prompts.TICKET_TYPE_SCHEMA,
        )

        data = response.parsed or {}
        raw_type = str(data.get("ticket_type", "")).lower().strip()
        ticket_type = _coerce_ticket_type(raw_type)

        confidence = _coerce_confidence(data.get("confidence"))
        summary = str(data.get("summary") or "").strip()
        if not summary:
            summary = ticket.title

        if ticket_type is TicketType.UNKNOWN:
            log.warning(
                "Ticket %s: could not parse ticket type from LLM response (%r).",
                ticket.key,
                response.raw_text[:200],
            )
            # Fallback on the Jira issue type field when the LLM fails.
            jira_type = _coerce_ticket_type(
                ticket.issue_type_name.lower().strip()
            )
            if jira_type is not TicketType.UNKNOWN:
                log.info(
                    "Ticket %s: falling back to Jira issue type %r -> %s.",
                    ticket.key,
                    ticket.issue_type_name,
                    jira_type.value,
                )
                ticket_type = jira_type
                # Medium confidence: Jira's field is reliable but not the
                # LLM's nuanced classification.
                if confidence == 0.0:
                    confidence = 0.7

        return ticket_type, confidence, summary

    def _score_comments(self, ticket: Ticket) -> list[CommentRelevance]:
        if not ticket.comments:
            return []

        results: list[CommentRelevance] = []
        for batch in _chunks(ticket.comments, self._batch_size):
            payload = [
                {"id": c.id, "author": c.author, "body": c.body}
                for c in batch
            ]
            prompt = prompts.render_comment_relevance_prompt(
                ticket_key=ticket.key,
                ticket_title=ticket.title,
                ticket_description=ticket.description,
                comments=payload,
            )
            response = self._llm.complete_json(
                system=prompts.COMMENT_RELEVANCE_SYSTEM,
                user=prompt,
                schema_hint=prompts.COMMENT_RELEVANCE_SCHEMA,
            )
            results.extend(self._parse_relevance_batch(response.parsed, batch))

        return results

    # ---- parsing ----------------------------------------------------------

    def _parse_relevance_batch(
        self,
        parsed: Any,
        batch: list[Comment],
    ) -> list[CommentRelevance]:
        items = _extract_items(parsed)
        by_id = {str(item.get("comment_id")): item for item in items if item}

        out: list[CommentRelevance] = []
        for comment in batch:
            item = by_id.get(comment.id) or by_id.get(str(comment.id))
            if not item:
                # Missing ids are treated as "unsure, keep it" to stay safe:
                # false positives are cheap, missing a key comment is costly.
                out.append(
                    CommentRelevance(
                        comment_id=comment.id,
                        is_relevant=True,
                        confidence=0.0,
                        reason="LLM did not classify this comment; kept by default.",
                    )
                )
                continue

            out.append(
                CommentRelevance(
                    comment_id=comment.id,
                    is_relevant=bool(item.get("is_relevant", False)),
                    confidence=_coerce_confidence(item.get("confidence")),
                    reason=str(item.get("reason") or "").strip() or "(no reason given)",
                )
            )
        return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _coerce_ticket_type(raw: str) -> TicketType:
    try:
        return TicketType(raw)
    except ValueError:
        # Map a few common synonyms the LLM might emit.
        aliases = {
            "bug": TicketType.FIX,
            "bugfix": TicketType.FIX,
            "feature": TicketType.DEV,
            "new": TicketType.DEV,
            "development": TicketType.DEV,
            "chore": TicketType.TASK,
            "documentation": TicketType.DOC,
        }
        return aliases.get(raw, TicketType.UNKNOWN)


def _coerce_confidence(value: Any) -> float:
    try:
        conf = float(value)
    except (TypeError, ValueError):
        return 0.0
    if conf < 0.0:
        return 0.0
    if conf > 1.0:
        return 1.0
    return conf


def _extract_items(parsed: Any) -> list[dict[str, Any]]:
    if not parsed:
        return []
    # Tolerate models that forget the outer {"items": [...]} wrapper.
    if isinstance(parsed, list):
        return [i for i in parsed if isinstance(i, dict)]
    if isinstance(parsed, dict):
        items = parsed.get("items")
        if isinstance(items, list):
            return [i for i in items if isinstance(i, dict)]
    return []


def _chunks(seq: list[Comment], size: int) -> Iterable[list[Comment]]:
    for i in range(0, len(seq), size):
        yield seq[i : i + size]
