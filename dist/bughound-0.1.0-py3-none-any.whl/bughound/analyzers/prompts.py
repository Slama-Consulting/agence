"""Prompt templates used by the ticket analyzer.

They live in their own module so we can:
  - tweak them without touching the analyzer logic,
  - snapshot-test them in isolation,
  - reuse them between the API-backed and copilot-backed LLM clients.
"""

from __future__ import annotations

from typing import Optional

# ---------------------------------------------------------------------------
# Ticket typing
# ---------------------------------------------------------------------------

TICKET_TYPE_SYSTEM = (
    "You are a senior Android engineer triaging Jira tickets. "
    "Given a ticket title and description, classify the ticket and extract a "
    "concise summary of the need. Be decisive and conservative about confidence."
)

TICKET_TYPE_SCHEMA = """{
  "ticket_type": "dev | fix | refactor | doc | task | question | other",
  "confidence": "float between 0.0 and 1.0",
  "summary": "one or two sentences describing what the ticket is really asking for"
}"""


def render_ticket_type_prompt(*, key: str, title: str, description: str) -> str:
    """Build the user prompt for ticket-type classification."""
    description = description.strip() or "(no description provided)"
    return (
        f"Ticket key: {key}\n"
        f"Title: {title}\n"
        f"Description:\n{description}\n\n"
        "Classify this ticket.\n"
        "- Use 'fix' for bug reports (crash, regression, wrong behavior).\n"
        "- Use 'dev' for new features or new development work.\n"
        "- Use 'refactor' for internal cleanup without behavior change.\n"
        "- Use 'doc' for documentation-only work.\n"
        "- Use 'task' for chores (CI, release, config).\n"
        "- Use 'question' when the ticket is primarily a question.\n"
        "- Use 'other' only when nothing else fits."
    )


# ---------------------------------------------------------------------------
# Comment relevance
# ---------------------------------------------------------------------------

COMMENT_RELEVANCE_SYSTEM = (
    "You are triaging Jira comments for a bug investigation. "
    "Decide which comments are directly related to understanding or reproducing "
    "the reported bug, and which are noise (status updates, thanks, unrelated "
    "discussions, meeting notes, off-topic banter)."
)

COMMENT_RELEVANCE_SCHEMA = """{
  "items": [
    {
      "comment_id": "string matching the input comment id",
      "is_relevant": true,
      "confidence": 0.0,
      "reason": "short justification (max 20 words)"
    }
  ]
}"""


def render_comment_relevance_prompt(
    *,
    ticket_key: str,
    ticket_title: str,
    ticket_description: str,
    comments: list[dict[str, str]],
) -> str:
    """Build the user prompt that asks the model to score each comment.

    ``comments`` must be a list of ``{"id": ..., "author": ..., "body": ...}``.
    """
    lines = [
        f"Ticket: {ticket_key} - {ticket_title}",
        f"Description:\n{ticket_description.strip() or '(none)'}",
        "",
        "Comments to classify (respond for every id, in the same order):",
    ]
    for c in comments:
        body = c["body"].strip().replace("\n", " ")
        if len(body) > 1200:
            body = body[:1200] + " […]"
        lines.append(f"- id={c['id']} | author={c['author']} | body: {body}")
    lines.append("")
    lines.append(
        "A comment is RELEVANT if it helps reproduce, diagnose, or locate the "
        "bug (stack traces, repro steps, affected versions, related logs, "
        "screenshots/videos of the issue, root cause discussion)."
    )
    lines.append(
        "A comment is NOT relevant if it is purely administrative "
        "(assignments, status, thanks, scheduling) or off-topic."
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Monolithic (conversational) analysis
# ---------------------------------------------------------------------------
#
# A single conversation replaces the legacy chain of 4–8 stateless prompts
# (ticket typing, comment relevance, log diagnosis, diagnosis confirmation,
# fix proposal). The model is given all the evidence up-front and must
# either produce the final JSON (``status: "done"``) or explicitly request
# a clarification (``status: "ask_clarification"``). The pipeline answers
# the question and loops until the model commits.

MONOLITHIC_SYSTEM = (
    "You are the senior Android engineer in charge of a full bug investigation. "
    "You receive a Jira ticket, the project documentation, a reduced log window, "
    "and a few candidate code references. Your goal is to produce, in ONE "
    "conversation, a complete structured verdict: ticket type, summary, "
    "relevant comments, root cause, reproduction steps, and — when possible — "
    "a concrete patch proposal.\n\n"
    "PROTOCOL (strict):\n"
    "- Every single reply MUST be a valid JSON object and NOTHING ELSE "
    "(no prose outside the JSON, no Markdown fences).\n"
    "- The JSON has a top-level \"status\" field with two possible values:\n"
    "  * \"ask_clarification\" — when a critical signal is missing and you "
    "cannot finish without more input. Provide a short \"question\" (French) "
    "and an optional list of \"options\" (French) so the caller can answer "
    "quickly. Keep clarifications to the strict minimum.\n"
    "  * \"done\" — when you have enough information to commit to the final "
    "verdict. Populate every field of the final schema.\n"
    "- NEVER mix the two: a reply is either a clarification request OR the "
    "final verdict.\n\n"
    "CRITICAL ANALYSIS RULES:\n"
    "- The log window is the ground truth for diagnosis. Ticket comments are "
    "NOT reliable: ignore any conclusions drawn there.\n"
    "- If the log window is empty or non-diagnostic, say so explicitly in "
    "root_cause_fr (French) and leave reproduction.steps empty rather than "
    "speculating.\n"
    "- If you cannot produce a safe patch, set proposed_fix to null and keep "
    "confidence_score below 0.5.\n"
    "- All free-text fields (summary, root_cause_fr, reproduction.*, "
    "regression_zones, proposed_fix.description, proposed_fix.reason) MUST be "
    "in French. ``root_cause_fr`` targets developers: cite affected classes, "
    "methods, and line numbers.\n"
    "- ``root_cause_en`` is the ONLY field that must be in English: it is a "
    "single short paragraph (<= 80 words) for a non-technical Product Owner. "
    "Describe the user-facing symptom, the underlying cause in plain words, "
    "and the affected scope. Do NOT include class names, method names, "
    "stack traces, or technical jargon.\n"
    "- ``reproduction.is_systematic`` is true when the bug fires every time "
    "the steps are followed. Set it to false for intermittent bugs and use "
    "``timing_notes`` and ``states`` to describe the conditions that make it "
    "fire (e.g. specific timing, prior states, race conditions).\n"
    "- ``regression_zones`` lists files, packages, or modules likely to be "
    "affected by ``proposed_fix`` and that QA should retest. Prefer concrete "
    "paths over generic descriptions.\n"
    "- ``confidence_scores`` ratios live in [0.0, 1.0]. ``in_module`` plus "
    "``outside_module`` should sum to 1.0 and represent how much of the "
    "regression risk is contained inside the patched module versus elsewhere.\n"
    "- When the caller lists \"missing_signals\" (e.g. logs_missing, "
    "video_clock_missing), decide whether a clarification is worth asking "
    "or whether you can proceed with a clearly-labelled degraded analysis.\n\n"
    "MANDATORY ROOT-CAUSE EVIDENCE:\n"
    "- ``root_cause_evidence_logs`` MUST contain 3 to 4 log lines copied "
    "VERBATIM from the provided log window (no paraphrase, no truncation, "
    "no merging). Pick the lines that prove your diagnosis, in chronological "
    "order. If the log window is empty or non-diagnostic, return an empty "
    "list rather than fabricating lines.\n"
    "- ``root_cause_timeline`` tells the bug as an ordered narrative of 4 to "
    "8 steps. Mark with ``\"ok\"`` the steps that ran normally and with "
    "``\"ko\"`` the ones that derailed. Each step has a short ``description`` "
    "in French and an optional ``explanation`` in French.\n\n"
    "REPRODUCTION SOURCE (priority):\n"
    "- The reproduction recipe (``reproduction.steps``, ``preconditions``, "
    "``timing_notes``, ``states``) MUST come PRIMARILY from the ticket "
    "description and the relevant comments. Do NOT re-invent the steps from "
    "the logs when the ticket already provides them. Only complete with what "
    "you derive from the logs when the ticket is silent on a specific point.\n\n"
    "CONFIDENCE SCORING (LLM is the sole source of truth):\n"
    "- No deterministic post-processing will adjust your scores. Justify them "
    "internally with the quality of the log evidence (stack trace present? "
    "enough lines?), the coherence with the relevant ticket comments, your "
    "confidence in the proposed fix, and the isolation of the patched file in "
    "the candidate code references.\n"
    "- Be conservative when the log window is thin or when the proposed fix "
    "is speculative."
)


MONOLITHIC_SCHEMA = """{
  "status": "done | ask_clarification",
  // when status == "ask_clarification":
  "question": "courte question en français",
  "options": ["option 1", "option 2"],
  // when status == "done":
  "ticket_type": "dev | fix | refactor | doc | task | question | other",
  "type_confidence": 0.0,
  "summary": "une ou deux phrases en français",
  "relevant_comments": [
    {
      "comment_id": "string",
      "is_relevant": true,
      "confidence": 0.0,
      "reason": "courte justification en français (max 20 mots)"
    }
  ],
  "root_cause_fr": "un paragraphe en français pour les devs (classes/méthodes/lignes), basé uniquement sur les logs",
  "root_cause_en": "one short paragraph in English (<= 80 words) for a Product Owner: symptom + plain-language cause + scope, no class names",
  "root_cause_evidence_logs": [
    "ligne de log 1 verbatim depuis la fenêtre",
    "ligne de log 2 verbatim depuis la fenêtre",
    "ligne de log 3 verbatim depuis la fenêtre"
  ],
  "root_cause_timeline": [
    {"status": "ok", "description": "étape qui s'est bien déroulée", "explanation": "détail facultatif"},
    {"status": "ko", "description": "étape qui a dérapé", "explanation": "ce qui s'est mal passé"}
  ],
  "reproduction": {
    "is_systematic": true,
    "preconditions": ["condition initiale 1", "..."],
    "steps": ["action courte en français", "..."],
    "timing_notes": "conditions de timing si non systématique, sinon null",
    "states": "états préalables requis si pertinent, sinon null"
  },
  "regression_zones": [
    "chemin/ou/package susceptible d'être affecté par le fix",
    "..."
  ],
  "confidence_scores": {
    "root_cause": 0.0,
    "regression": 0.0,
    "fix": 0.0,
    "in_module": 0.0,
    "outside_module": 0.0
  },
  "proposed_fix": {
    "file_path": "chemin absolu du fichier à modifier",
    "start_line": 0,
    "end_line": 0,
    "before_snippet": "texte exact à chercher dans le fichier",
    "after_snippet": "texte de remplacement",
    "description": "une phrase en français",
    "reason": "un paragraphe en français",
    "confidence_score": 0.0
  },
  "confidence_score": 0.0
}"""


def render_monolithic_prompt(
    *,
    ticket_key: str,
    ticket_title: str,
    ticket_description: str,
    comments: list[dict[str, str]],
    project_doc_markdown: Optional[str] = None,
    project_name: Optional[str] = None,
    log_window_text: Optional[str] = None,
    log_window_confirmation_text: Optional[str] = None,
    video_anchor_summary: Optional[str] = None,
    code_refs: Optional[list[dict[str, object]]] = None,
    missing_signals: Optional[list[str]] = None,
) -> str:
    """Build the opening user turn of the monolithic conversation.

    ``comments`` items: ``{"id", "author", "body"}``.
    ``code_refs`` items: ``{"file_path", "class_fqn", "line", "snippet"}``.
    ``missing_signals`` is a short list of deterministic flags computed by
    the pipeline (e.g. ``"logs_missing"``, ``"video_clock_missing"``) so the
    LLM can decide whether clarification is worth asking.
    """
    lines: list[str] = [
        f"TICKET {ticket_key} — {ticket_title}",
        "",
        "DESCRIPTION (context only — not ground truth):",
        (ticket_description.strip() or "(aucune)"),
        "",
    ]

    if comments:
        lines.append("COMMENTAIRES (à évaluer pour la pertinence) :")
        for c in comments:
            body = str(c.get("body", "")).strip().replace("\n", " ")
            if len(body) > 1200:
                body = body[:1200] + " […]"
            lines.append(
                f"- id={c.get('id', '?')} | author={c.get('author', '?')} "
                f"| body: {body}"
            )
        lines.append("")

    if project_doc_markdown:
        lines.append(
            f"PROJECT DOC ({project_name or '?'}) — tail (20k chars max) :"
        )
        lines.append("```markdown")
        lines.append(_mono_tail(project_doc_markdown, max_chars=20_000))
        lines.append("```")
        lines.append("")

    if log_window_text and log_window_text.strip():
        lines.append("FENÊTRE DE LOGS PRIMAIRE (chronologique) :")
        lines.append("```")
        lines.append(_mono_tail(log_window_text, max_chars=80_000))
        lines.append("```")
        lines.append("")
    else:
        lines.append("FENÊTRE DE LOGS PRIMAIRE : AUCUN LOG DISPONIBLE.")
        lines.append("")

    if log_window_confirmation_text and log_window_confirmation_text.strip():
        lines.append("FENÊTRE DE LOGS DE CONFIRMATION (seconde paire) :")
        lines.append("```")
        lines.append(_mono_tail(log_window_confirmation_text, max_chars=40_000))
        lines.append("```")
        lines.append("")

    if video_anchor_summary:
        lines.append("ANCRE VIDÉO / HORLOGE DÉTECTÉE :")
        lines.append(video_anchor_summary.strip())
        lines.append("")

    if code_refs:
        lines.append("RÉFÉRENCES DE CODE CANDIDATES :")
        for ref in code_refs:
            fqn = ref.get("class_fqn", "?")
            file_path = ref.get("file_path", "?")
            line_no = ref.get("line")
            head = f"- {fqn} → {file_path}"
            if line_no:
                head += f" (ligne {line_no})"
            lines.append(head)
            snippet = str(ref.get("snippet", "")).rstrip()
            if snippet:
                lines.append("  ```")
                for snip_line in snippet.splitlines():
                    lines.append(f"  {snip_line}")
                lines.append("  ```")
        lines.append("")

    if missing_signals:
        lines.append("SIGNAUX MANQUANTS (détectés par le pipeline) :")
        for sig in missing_signals:
            lines.append(f"- {sig}")
        lines.append("")

    lines.append(
        "Produis maintenant une réponse JSON qui respecte STRICTEMENT le "
        "schéma donné. Si tu as besoin d'une clarification critique, utilise "
        "status=\"ask_clarification\" ; sinon produis la verdict finale avec "
        "status=\"done\"."
    )
    return "\n".join(lines)


def _mono_tail(text: str, *, max_chars: int) -> str:
    """Keep only the last ``max_chars`` characters; most diagnostics live near the end."""
    if len(text) <= max_chars:
        return text
    return "…[truncated]…\n" + text[-max_chars:]
