"""LLM-backed diagnosis of the root cause from a reduced log window.

Fed with:

- the ticket's title + description,
- the reduced log window (already narrowed to
  ``[first_seen − 5min ; last_seen + 2min]`` by the correlator),
- optionally, the project's ``doc.md`` so the LLM can reason about
  which module is likely involved,

the diagnostician asks the LLM for a structured verdict::

    {
      "root_cause": "one-paragraph explanation",
      "reproduction_steps": ["step 1", "step 2", ...],
      "suspected_modules": ["module A", "module B"]
    }

Kept deliberately small: no retries, no streaming, no file-walking. The
pipeline passes everything it needs as strings.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Optional

from pydantic import ValidationError

from ..core.models import ConfidenceScores, ReproductionMethod, TimelineStep
from ..llm.base import LLMClient

log = logging.getLogger(__name__)


DIAGNOSTICIAN_SYSTEM = (
    "You are a senior Android engineer diagnosing a bug from a ticket and a "
    "small window of logcat output. You must be decisive: identify the "
    "single most likely root cause, spell out the exact user-facing "
    "reproduction steps that led to it (in French), and name the modules "
    "in the codebase you suspect are responsible.\n\n"
    "CRITICAL RULES:\n"
    "- Base your analysis EXCLUSIVELY on the log content provided. "
    "The log is the ground truth — not the ticket description, not the comments.\n"
    "- Ticket comments are NOT a reliable source of truth and may be wrong or misleading. "
    "Ignore any conclusions drawn in the comments section.\n"
    "- If the log window is empty or non-diagnostic, say so explicitly in root_cause_fr "
    "and do NOT speculate based on the ticket description alone.\n"
    "- All free-text fields are in French EXCEPT ``root_cause_en`` which is "
    "the only English field: a single short paragraph (<= 80 words) for a "
    "non-technical Product Owner. It must describe symptom + cause in plain "
    "language and avoid class names, method names and technical jargon.\n"
    "- ``root_cause_fr`` targets developers: cite affected classes, methods "
    "and line numbers when visible in the logs.\n"
    "- ``reproduction.is_systematic`` is true when the bug fires every time "
    "the steps are followed. Set it to false for intermittent bugs and use "
    "``timing_notes`` and ``states`` to describe the firing conditions.\n"
    "- ``regression_zones`` lists files, packages or modules likely to be "
    "affected when the suspected code is patched (concrete paths preferred).\n"
    "- ``confidence_scores`` ratios live in [0.0, 1.0]. ``in_module`` plus "
    "``outside_module`` should sum to 1.0. The ``fix`` score is reserved for "
    "the dedicated fix-proposer step and is NOT produced here.\n"
    "- ``root_cause_evidence_logs`` MUST contain 3 to 4 log lines copied "
    "VERBATIM from the provided log window (no paraphrase, no truncation), "
    "in chronological order. Pick the lines that prove your diagnosis. "
    "Return an empty list if the log window is non-diagnostic.\n"
    "- ``root_cause_timeline`` tells the bug as 4 to 8 ordered steps; mark "
    "with ``\"ok\"`` what ran normally and with ``\"ko\"`` what derailed. "
    "Each step has a short French ``description`` and an optional French "
    "``explanation``.\n"
    "- You are the sole source of truth for ``confidence_scores``: justify "
    "them by the quality of the log evidence and the coherence with the "
    "ticket. No deterministic post-processing will adjust them."
)

DIAGNOSTICIAN_SCHEMA = """{
  "root_cause_fr": "un paragraphe en français pour les devs (classes/méthodes/lignes), basé uniquement sur les logs",
  "root_cause_en": "one short paragraph in English (<= 80 words) for a Product Owner: symptom + plain-language cause + scope, no class names",
  "root_cause_evidence_logs": [
    "ligne de log 1 verbatim depuis la fenêtre",
    "ligne de log 2 verbatim depuis la fenêtre",
    "ligne de log 3 verbatim depuis la fenêtre"
  ],
  "root_cause_timeline": [
    {"status": "ok", "description": "étape qui s'est bien déroulée", "explanation": "détail facultatif"},
    {"status": "ko", "description": "étape qui a dérapé", "explanation": "ce qui s'est mal passé"}
  ],
  "reproduction": {
    "is_systematic": true,
    "preconditions": ["condition initiale 1", "..."],
    "steps": ["action courte en français", "..."],
    "timing_notes": "conditions de timing si non systématique, sinon null",
    "states": "états préalables requis si pertinent, sinon null"
  },
  "suspected_modules": ["nom du module ou du package", "..."],
  "regression_zones": [
    "chemin/ou/package susceptible d'être affecté par un fix",
    "..."
  ],
  "confidence_scores": {
    "root_cause": 0.0,
    "regression": 0.0,
    "in_module": 0.0,
    "outside_module": 0.0
  }
}"""


@dataclass(frozen=True)
class Diagnosis:
    """Structured output of the diagnostician.

    ``root_cause`` is the French (developer-facing) paragraph and is kept
    under its legacy name for backward compat. ``root_cause_en`` is the new
    PO-friendly English paragraph. ``reproduction_method`` carries the rich
    recipe (preconditions, timing, states) while ``reproduction_steps`` is
    kept as a flat mirror so legacy callers keep working.
    """

    root_cause: str
    reproduction_steps: list[str]
    suspected_modules: list[str]
    root_cause_en: Optional[str] = None
    reproduction_method: Optional[ReproductionMethod] = None
    regression_zones: list[str] = field(default_factory=list)
    confidence_scores: Optional[ConfidenceScores] = None
    # Verbatim log lines proving the diagnosis (3-4 lines, chronological).
    root_cause_evidence_logs: list[str] = field(default_factory=list)
    # Ordered OK/KO narrative of the bug.
    root_cause_timeline: list[TimelineStep] = field(default_factory=list)


class LogDiagnostician:
    """Send a ticket + log window + project doc to the LLM and parse the verdict."""

    def __init__(self, llm: LLMClient) -> None:
        self._llm = llm

    def diagnose(
        self,
        *,
        ticket_title: str,
        ticket_description: str,
        log_window_text: str,
        project_doc_markdown: Optional[str] = None,
        project_name: Optional[str] = None,
    ) -> Diagnosis:
        """Return the LLM-provided diagnosis, with a safe fallback on failure."""
        user_prompt = _render_prompt(
            ticket_title=ticket_title,
            ticket_description=ticket_description,
            log_window_text=log_window_text,
            project_doc_markdown=project_doc_markdown,
            project_name=project_name,
        )
        try:
            response = self._llm.complete_json(
                system=DIAGNOSTICIAN_SYSTEM,
                user=user_prompt,
                schema_hint=DIAGNOSTICIAN_SCHEMA,
            )
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("LogDiagnostician LLM call failed: %s", exc)
            return Diagnosis(
                root_cause="", reproduction_steps=[], suspected_modules=[]
            )

        parsed = response.parsed
        if not isinstance(parsed, dict):
            # The LLM returned plain text; try to parse the raw string.
            try:
                parsed = json.loads(response.raw_text)
            except (ValueError, TypeError):
                parsed = {}

        # Bilingual root cause: prefer ``root_cause_fr`` but fall back to
        # legacy ``root_cause`` so degraded backends still produce something.
        root_cause_fr_raw = parsed.get("root_cause_fr") or parsed.get(
            "root_cause"
        )
        root_cause_en_raw = parsed.get("root_cause_en")
        root_cause_en: Optional[str] = (
            str(root_cause_en_raw).strip() if root_cause_en_raw else None
        )

        # Reproduction recipe — same dual schema (object / flat list) as
        # the monolithic analyzer.
        reproduction_method = _coerce_reproduction(parsed.get("reproduction"))
        if reproduction_method is None:
            legacy_steps = [
                str(s).strip()
                for s in _as_list(parsed.get("reproduction_steps"))
                if str(s).strip()
            ]
            if legacy_steps:
                reproduction_method = ReproductionMethod(steps=legacy_steps)
        reproduction_steps = (
            list(reproduction_method.steps)
            if reproduction_method is not None
            else [
                str(s).strip()
                for s in _as_list(parsed.get("reproduction_steps"))
                if str(s).strip()
            ]
        )

        regression_zones = [
            str(z).strip()
            for z in _as_list(parsed.get("regression_zones"))
            if str(z).strip()
        ]
        confidence_scores = _coerce_confidence_scores(
            parsed.get("confidence_scores")
        )
        evidence_logs = _coerce_evidence_logs(
            parsed.get("root_cause_evidence_logs")
        )
        timeline = _coerce_timeline(parsed.get("root_cause_timeline"))

        return Diagnosis(
            root_cause=str(root_cause_fr_raw or "").strip(),
            reproduction_steps=reproduction_steps,
            suspected_modules=[
                str(s).strip() for s in _as_list(parsed.get("suspected_modules"))
            ],
            root_cause_en=root_cause_en,
            reproduction_method=reproduction_method,
            regression_zones=regression_zones,
            confidence_scores=confidence_scores,
            root_cause_evidence_logs=evidence_logs,
            root_cause_timeline=timeline,
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _render_prompt(
    *,
    ticket_title: str,
    ticket_description: str,
    log_window_text: str,
    project_doc_markdown: Optional[str],
    project_name: Optional[str],
) -> str:
    # Cap the log window to keep the prompt size sane — most LLMs choke
    # past ~120k chars and the interesting lines are usually at the tail.
    clipped_log = _tail(log_window_text, max_chars=80_000)
    doc_section = (
        f"\n\nPROJECT DOC ({project_name or '?'}):\n"
        f"```markdown\n{_tail(project_doc_markdown or '', max_chars=20_000)}\n```"
        if project_doc_markdown
        else ""
    )
    has_logs = bool(log_window_text.strip())
    log_section = (
        f"FENÊTRE DE LOGS (chronologique) :\n```\n{clipped_log}\n```"
        if has_logs
        else (
            "FENÊTRE DE LOGS : AUCUN LOG DISPONIBLE.\n"
            "→ Indique dans root_cause que l'analyse ne peut pas être effectuée "
            "faute de logs, et laisse reproduction_steps et suspected_modules vides."
        )
    )
    return (
        f"Titre du ticket : {ticket_title.strip()}\n"
        f"Description du ticket (contexte uniquement — ne pas utiliser comme source de vérité) :\n"
        f"{ticket_description.strip() or '(aucune)'}\n"
        f"{doc_section}\n\n"
        f"{log_section}\n\n"
        "Produis un JSON qui correspond strictement au schéma. "
        "Ta conclusion doit être basée EXCLUSIVEMENT sur le contenu des logs ci-dessus. "
        "Si les logs sont absents ou non diagnostiques, indique-le clairement dans root_cause."
    )


def _tail(text: str, *, max_chars: int) -> str:
    if len(text) <= max_chars:
        return text
    return "…[truncated]…\n" + text[-max_chars:]


def _as_list(value: object) -> list:
    if isinstance(value, list):
        return value
    if value is None:
        return []
    return [value]


def _coerce_float(value: object) -> float:
    """Clamp arbitrary input to ``[0.0, 1.0]``; default to 0.0 on failure."""
    try:
        f = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0.0
    if f < 0.0:
        return 0.0
    if f > 1.0:
        return 1.0
    return f


def _coerce_reproduction(value: object) -> Optional[ReproductionMethod]:
    """Build a :class:`ReproductionMethod` from the LLM's ``reproduction`` object.

    Mirrors :func:`bughound.analyzers.monolithic._coerce_reproduction` so both
    analyzers handle the same schema. Returns ``None`` when ``value`` is not
    a dict (legacy schema where the only repro field was the flat list).
    """
    if not isinstance(value, dict):
        return None
    steps = [
        str(s).strip()
        for s in _as_list(value.get("steps"))
        if str(s).strip()
    ]
    preconditions = [
        str(p).strip()
        for p in _as_list(value.get("preconditions"))
        if str(p).strip()
    ]
    timing_raw = value.get("timing_notes")
    timing_notes: Optional[str] = (
        str(timing_raw).strip() if timing_raw else None
    )
    states_raw = value.get("states")
    states: Optional[str] = str(states_raw).strip() if states_raw else None
    is_systematic_raw = value.get("is_systematic")
    is_systematic = (
        bool(is_systematic_raw) if is_systematic_raw is not None else True
    )
    if not steps and not preconditions and not timing_notes and not states:
        return None
    try:
        return ReproductionMethod(
            is_systematic=is_systematic,
            preconditions=preconditions,
            steps=steps,
            timing_notes=timing_notes or None,
            states=states or None,
        )
    except Exception:  # pragma: no cover - pydantic validation
        return None


def _coerce_confidence_scores(value: object) -> Optional[ConfidenceScores]:
    """Build a :class:`ConfidenceScores` from the diagnostician's payload.

    The diagnostician schema does NOT include the ``fix`` score (that is the
    fix-proposer's job), so we leave it at 0.0 here. The pipeline merges it
    with the fix proposer's confidence later.
    """
    if not isinstance(value, dict):
        return None
    try:
        return ConfidenceScores(
            root_cause=_coerce_float(value.get("root_cause")),
            regression=_coerce_float(value.get("regression")),
            fix=0.0,  # populated by FixProposer downstream
            in_module=_coerce_float(value.get("in_module")),
            outside_module=_coerce_float(value.get("outside_module")),
        )
    except Exception:  # pragma: no cover - pydantic validation
        return None


def _coerce_evidence_logs(value: object) -> list[str]:
    """Tolerant: list of non-empty strings, capped to 6 lines.

    Returns an empty list when the field is absent or malformed (degraded
    Copilot backends), so the report renders without a proof block but
    nothing crashes.
    """
    if not isinstance(value, list):
        return []
    out: list[str] = []
    for item in value:
        if item is None:
            continue
        text = str(item).strip()
        if text:
            out.append(text)
    return out[:6]


def _coerce_timeline(value: object) -> list[TimelineStep]:
    """Tolerant: ignore malformed entries and unknown statuses.

    Each step needs a ``status`` in ``{"ok", "ko"}`` and a non-empty
    ``description``; everything else is best-effort. Unknown / malformed
    entries are silently dropped so the LLM cannot crash the renderer
    by returning a slightly-off JSON shape.
    """
    if not isinstance(value, list):
        return []
    out: list[TimelineStep] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        status = str(item.get("status", "")).strip().lower()
        if status not in {"ok", "ko"}:
            continue
        description = str(item.get("description", "")).strip()
        if not description:
            continue
        explanation_raw = item.get("explanation")
        explanation = (
            str(explanation_raw).strip() if explanation_raw else None
        )
        try:
            out.append(
                TimelineStep(
                    status=status,  # type: ignore[arg-type]
                    description=description,
                    explanation=explanation or None,
                )
            )
        except ValidationError:  # pragma: no cover - defensive
            continue
    return out


__all__ = ["Diagnosis", "LogDiagnostician"]
