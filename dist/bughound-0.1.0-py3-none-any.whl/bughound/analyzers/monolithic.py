"""Single-conversation bug investigator (Phase 2 of the migration plan).

This analyzer collapses the legacy chain of 4–8 stateless LLM prompts into
one multi-turn conversation. The LLM receives every piece of evidence
up-front and must either produce the final verdict (``status: "done"``)
or request a precise clarification (``status: "ask_clarification"``) that
the pipeline can answer from its own state.

Design:

- The transport is :meth:`LLMClient.complete_conversation` so native
  multi-turn backends (Anthropic, OpenAI) keep their prompt-caching and
  the degraded backends (Copilot, MCP-Copilot) still work through the
  default transcript fallback.
- Clarification answers are routed through a
  :class:`~bughound.analyzers.clarification.ClarificationHandler`,
  decoupling the analyzer from UI concerns (CLI input, MCP elicit, ...).
- The loop is bounded by ``max_clarification_rounds``. If the LLM keeps
  asking or keeps producing malformed JSON, the analyzer returns an empty
  fallback result — the pipeline remains responsible for deciding whether
  to switch back to the legacy chain.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence

from pydantic import ValidationError

from ..core.models import (
    CodeReference,
    CommentRelevance,
    ConfidenceScores,
    ProposedFix,
    ReproductionMethod,
    Ticket,
    TicketType,
    TimelineStep,
)
from ..llm.base import ChatMessage, LLMClient
from .clarification import (
    AutoClarificationHandler,
    ClarificationHandler,
    _coerce_signal_list,
)
from .prompts import (
    MONOLITHIC_SCHEMA,
    MONOLITHIC_SYSTEM,
    render_monolithic_prompt,
)

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result type
# ---------------------------------------------------------------------------


@dataclass
class MonolithicResult:
    """Structured output of :class:`MonolithicAnalyzer`.

    Fields mirror the JSON schema declared in :data:`MONOLITHIC_SCHEMA`, with
    every free-text field in French. The analyzer never raises on parsing
    failures: instead, it returns a partially-populated (or empty) result
    together with a ``clarifications_asked`` trace that the reporter surfaces
    to the user.
    """

    ticket_type: TicketType = TicketType.UNKNOWN
    type_confidence: float = 0.0
    summary: str = ""
    relevant_comments: list[CommentRelevance] = field(default_factory=list)
    #: French paragraph for developers (legacy ``root_cause`` is kept as an
    #: alias of this field for backward compat).
    root_cause: Optional[str] = None
    #: English Product-Owner-friendly paragraph (<= 80 words, no class names).
    root_cause_en: Optional[str] = None
    reproduction_steps: list[str] = field(default_factory=list)
    #: Structured reproduction recipe (preconditions, timing, states).
    reproduction_method: Optional[ReproductionMethod] = None
    #: Files / packages at risk of regression by ``proposed_fix``.
    regression_zones: list[str] = field(default_factory=list)
    proposed_fix: Optional[ProposedFix] = None
    confidence_score: float = 0.0
    #: LLM-authored confidence scores. The LLM is the sole source of truth;
    #: no deterministic post-processing adjusts these values. ``None`` when
    #: the LLM did not provide a ``confidence_scores`` object.
    confidence_scores: Optional[ConfidenceScores] = None
    #: Verbatim log lines proving the diagnosis (3-4 lines, chronological).
    root_cause_evidence_logs: list[str] = field(default_factory=list)
    #: Ordered OK/KO narrative of the bug.
    root_cause_timeline: list[TimelineStep] = field(default_factory=list)
    clarifications_asked: list[str] = field(default_factory=list)
    #: ``True`` when the LLM committed to a ``status: done`` reply.
    completed: bool = False


# ---------------------------------------------------------------------------
# Analyzer
# ---------------------------------------------------------------------------


class MonolithicAnalyzer:
    """Drive a single-conversation analysis from ticket to proposed fix."""

    def __init__(
        self,
        llm: LLMClient,
        *,
        max_clarification_rounds: int = 3,
        clarification_handler: Optional[ClarificationHandler] = None,
    ) -> None:
        if max_clarification_rounds < 0:
            raise ValueError("max_clarification_rounds must be >= 0")
        self._llm = llm
        self._max_rounds = max_clarification_rounds
        self._handler = clarification_handler or AutoClarificationHandler()

    # -- public API --------------------------------------------------------

    def analyze(
        self,
        *,
        ticket: Ticket,
        project_doc_md: Optional[str] = None,
        project_name: Optional[str] = None,
        log_window_text: Optional[str] = None,
        log_window_confirmation_text: Optional[str] = None,
        video_anchor_summary: Optional[str] = None,
        code_refs: Optional[Sequence[CodeReference]] = None,
        project_root: Optional[Path] = None,
        missing_signals: Optional[Iterable[str]] = None,
    ) -> MonolithicResult:
        """Run the conversation and return a :class:`MonolithicResult`."""
        signals = _coerce_signal_list(missing_signals)
        initial_prompt = render_monolithic_prompt(
            ticket_key=ticket.key,
            ticket_title=ticket.title,
            ticket_description=ticket.description or "",
            comments=[
                {"id": c.id, "author": c.author, "body": c.body}
                for c in ticket.comments
            ],
            project_doc_markdown=project_doc_md,
            project_name=project_name,
            log_window_text=log_window_text,
            log_window_confirmation_text=log_window_confirmation_text,
            video_anchor_summary=video_anchor_summary,
            code_refs=[
                {
                    "file_path": str(r.file_path),
                    "class_fqn": r.class_fqn,
                    "line": r.line,
                    "snippet": r.snippet,
                }
                for r in (code_refs or [])
            ],
            missing_signals=signals,
        )

        messages: list[ChatMessage] = [ChatMessage("user", initial_prompt)]
        clarifications: list[str] = []
        malformed_retries = 0

        # One extra iteration beyond ``max_rounds`` lets the LLM produce a
        # final ``done`` reply after its last clarification was answered.
        for _ in range(self._max_rounds + 2):
            try:
                response = self._llm.complete_conversation(
                    system=MONOLITHIC_SYSTEM,
                    messages=messages,
                    schema_hint=MONOLITHIC_SCHEMA,
                )
            except Exception as exc:  # pragma: no cover - defensive
                log.warning("MonolithicAnalyzer LLM call failed: %s", exc)
                return MonolithicResult(clarifications_asked=clarifications)

            parsed = _coerce_parsed(response.parsed, response.raw_text)
            messages.append(ChatMessage("assistant", response.raw_text or ""))

            if parsed is None:
                malformed_retries += 1
                if malformed_retries > 2:
                    log.warning(
                        "MonolithicAnalyzer: too many malformed JSON replies, "
                        "giving up"
                    )
                    return MonolithicResult(clarifications_asked=clarifications)
                messages.append(
                    ChatMessage(
                        "user",
                        "Ta réponse précédente n'est pas un JSON valide. "
                        "Renvoie STRICTEMENT un objet JSON conforme au "
                        "schéma donné, sans prose ni balise Markdown.",
                    )
                )
                continue

            status = str(parsed.get("status", "")).strip().lower()

            if status == "done":
                return self._build_result(
                    parsed,
                    clarifications=clarifications,
                    project_root=project_root,
                )

            if status == "ask_clarification":
                if len(clarifications) >= self._max_rounds:
                    # Force the LLM to commit on its next turn.
                    messages.append(
                        ChatMessage(
                            "user",
                            "Tu as atteint le nombre maximal de "
                            "clarifications. Produis maintenant ta réponse "
                            "finale avec status=\"done\" en t'appuyant sur "
                            "les informations dont tu disposes.",
                        )
                    )
                    continue

                question = str(parsed.get("question", "")).strip()
                options = [
                    str(o).strip()
                    for o in _as_list(parsed.get("options"))
                    if str(o).strip()
                ]
                if not question:
                    # Malformed clarification — treat like malformed JSON.
                    malformed_retries += 1
                    messages.append(
                        ChatMessage(
                            "user",
                            "Ta demande de clarification n'avait pas de "
                            "question lisible. Reformule : soit produis le "
                            "verdict final, soit pose une question claire.",
                        )
                    )
                    continue

                answer = self._handler.resolve(question, options, signals)
                clarifications.append(question)
                messages.append(
                    ChatMessage(
                        "user",
                        f"Réponse à ta question : {answer}\n\n"
                        "Poursuis l'analyse et produis ta réponse JSON.",
                    )
                )
                continue

            # Unknown status — nudge the LLM back on track.
            malformed_retries += 1
            messages.append(
                ChatMessage(
                    "user",
                    "Le champ \"status\" doit valoir \"done\" ou "
                    "\"ask_clarification\". Renvoie un JSON conforme.",
                )
            )

        # Hard ceiling reached — return what we have (empty).
        return MonolithicResult(clarifications_asked=clarifications)

    # -- internals ---------------------------------------------------------

    def _build_result(
        self,
        parsed: dict[str, Any],
        *,
        clarifications: list[str],
        project_root: Optional[Path],
    ) -> MonolithicResult:
        ticket_type = _coerce_ticket_type(parsed.get("ticket_type"))
        type_confidence = _coerce_float(parsed.get("type_confidence"))
        summary = str(parsed.get("summary", "")).strip()
        confidence_score = _coerce_float(parsed.get("confidence_score"))

        relevant_comments: list[CommentRelevance] = []
        for item in _as_list(parsed.get("relevant_comments")):
            if not isinstance(item, dict):
                continue
            try:
                relevant_comments.append(
                    CommentRelevance(
                        comment_id=str(item.get("comment_id", "")).strip(),
                        is_relevant=bool(item.get("is_relevant", False)),
                        confidence=_coerce_float(item.get("confidence")),
                        reason=str(item.get("reason", "")).strip(),
                    )
                )
            except Exception:  # pragma: no cover - pydantic validation
                continue

        # Bilingual root cause: prefer the new ``root_cause_fr`` field but fall
        # back to legacy ``root_cause`` so degraded backends that strip unknown
        # keys still produce something readable.
        root_cause_fr_raw = parsed.get("root_cause_fr") or parsed.get("root_cause")
        root_cause = (
            str(root_cause_fr_raw).strip() if root_cause_fr_raw else None
        )
        root_cause_en_raw = parsed.get("root_cause_en")
        root_cause_en = (
            str(root_cause_en_raw).strip() if root_cause_en_raw else None
        )

        # Reproduction recipe: prefer the new ``reproduction`` object; fall
        # back to a flat ``reproduction_steps`` list when only the legacy
        # field is present.
        reproduction_method = _coerce_reproduction(parsed.get("reproduction"))
        if reproduction_method is None:
            legacy_steps = [
                str(s).strip()
                for s in _as_list(parsed.get("reproduction_steps"))
                if str(s).strip()
            ]
            if legacy_steps:
                reproduction_method = ReproductionMethod(steps=legacy_steps)
        reproduction_steps = (
            list(reproduction_method.steps)
            if reproduction_method is not None
            else [
                str(s).strip()
                for s in _as_list(parsed.get("reproduction_steps"))
                if str(s).strip()
            ]
        )

        regression_zones = [
            str(z).strip()
            for z in _as_list(parsed.get("regression_zones"))
            if str(z).strip()
        ]

        confidence_scores = _coerce_confidence_scores(
            parsed.get("confidence_scores")
        )

        evidence_logs = _coerce_evidence_logs(
            parsed.get("root_cause_evidence_logs")
        )
        timeline = _coerce_timeline(parsed.get("root_cause_timeline"))

        proposed_fix = _coerce_proposed_fix(
            parsed.get("proposed_fix"), project_root=project_root
        )

        return MonolithicResult(
            ticket_type=ticket_type,
            type_confidence=type_confidence,
            summary=summary,
            relevant_comments=relevant_comments,
            root_cause=root_cause,
            root_cause_en=root_cause_en,
            reproduction_steps=reproduction_steps,
            reproduction_method=reproduction_method,
            regression_zones=regression_zones,
            proposed_fix=proposed_fix,
            confidence_score=confidence_score,
            confidence_scores=confidence_scores,
            root_cause_evidence_logs=evidence_logs,
            root_cause_timeline=timeline,
            clarifications_asked=clarifications,
            completed=True,
        )


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------


def _coerce_parsed(parsed: Optional[dict[str, Any]], raw: str) -> Optional[dict[str, Any]]:
    """Return a dict or ``None``. Falls back to manual JSON parsing on ``raw``."""
    if isinstance(parsed, dict):
        return parsed
    if not raw:
        return None
    try:
        candidate = json.loads(raw)
    except (ValueError, TypeError):
        return None
    return candidate if isinstance(candidate, dict) else None


def _as_list(value: object) -> list:
    if isinstance(value, list):
        return value
    if value is None:
        return []
    return [value]


def _coerce_float(value: object) -> float:
    try:
        f = float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0.0
    if f < 0.0:
        return 0.0
    if f > 1.0:
        return 1.0
    return f


def _coerce_ticket_type(value: object) -> TicketType:
    if isinstance(value, TicketType):
        return value
    try:
        return TicketType(str(value).strip().lower())
    except (ValueError, TypeError):
        return TicketType.UNKNOWN


def _coerce_reproduction(value: object) -> Optional[ReproductionMethod]:
    """Build a :class:`ReproductionMethod` from the LLM's ``reproduction`` object.

    Returns ``None`` when ``value`` is not a dict (legacy schema where the
    only repro field was ``reproduction_steps: list[str]``). Tolerant on
    missing keys so degraded backends that drop optional fields still produce
    a valid recipe.
    """
    if not isinstance(value, dict):
        return None
    steps = [
        str(s).strip()
        for s in _as_list(value.get("steps"))
        if str(s).strip()
    ]
    preconditions = [
        str(p).strip()
        for p in _as_list(value.get("preconditions"))
        if str(p).strip()
    ]
    timing_raw = value.get("timing_notes")
    timing_notes: Optional[str] = (
        str(timing_raw).strip() if timing_raw else None
    )
    states_raw = value.get("states")
    states: Optional[str] = str(states_raw).strip() if states_raw else None
    is_systematic_raw = value.get("is_systematic")
    is_systematic = (
        bool(is_systematic_raw) if is_systematic_raw is not None else True
    )
    if not steps and not preconditions and not timing_notes and not states:
        return None
    try:
        return ReproductionMethod(
            is_systematic=is_systematic,
            preconditions=preconditions,
            steps=steps,
            timing_notes=timing_notes or None,
            states=states or None,
        )
    except Exception:  # pragma: no cover - pydantic validation
        return None


def _coerce_confidence_scores(value: object) -> Optional[ConfidenceScores]:
    """Build a :class:`ConfidenceScores` from the LLM's ``confidence_scores``.

    Each individual score is clamped to ``[0.0, 1.0]`` by :func:`_coerce_float`.
    Missing fields default to 0.0. Returns ``None`` only when ``value`` is not
    a dict at all (legacy responses).
    """
    if not isinstance(value, dict):
        return None
    try:
        return ConfidenceScores(
            root_cause=_coerce_float(value.get("root_cause")),
            regression=_coerce_float(value.get("regression")),
            fix=_coerce_float(value.get("fix")),
            in_module=_coerce_float(value.get("in_module")),
            outside_module=_coerce_float(value.get("outside_module")),
        )
    except Exception:  # pragma: no cover - pydantic validation
        return None


def _coerce_evidence_logs(value: object) -> list[str]:
    """Tolerant: list of non-empty strings, capped at 6 lines.

    The LLM is asked for 3-4 verbatim log lines but degraded backends may
    return more or malformed entries. We trim to keep the proof block tight
    and silently drop empty values.
    """
    if not isinstance(value, list):
        return []
    out: list[str] = []
    for item in value:
        if item is None:
            continue
        text = str(item).strip()
        if text:
            out.append(text)
    return out[:6]


def _coerce_timeline(value: object) -> list[TimelineStep]:
    """Tolerant: ignore malformed entries and unknown statuses.

    Each step needs a ``status`` in ``{"ok", "ko"}`` and a non-empty
    ``description``; everything else is best-effort. Returns an empty list
    on a missing or non-list payload so degraded backends fall back to a
    bug report without a timeline block.
    """
    if not isinstance(value, list):
        return []
    out: list[TimelineStep] = []
    for item in value:
        if not isinstance(item, dict):
            continue
        status = str(item.get("status", "")).strip().lower()
        if status not in {"ok", "ko"}:
            continue
        description = str(item.get("description", "")).strip()
        if not description:
            continue
        explanation_raw = item.get("explanation")
        explanation = (
            str(explanation_raw).strip() if explanation_raw else None
        )
        try:
            out.append(
                TimelineStep(
                    status=status,  # type: ignore[arg-type]
                    description=description,
                    explanation=explanation or None,
                )
            )
        except ValidationError:  # pragma: no cover - defensive
            continue
    return out


def _coerce_proposed_fix(
    value: object, *, project_root: Optional[Path]
) -> Optional[ProposedFix]:
    if not isinstance(value, dict):
        return None

    file_path_raw = str(value.get("file_path", "")).strip()
    before = str(value.get("before_snippet", ""))
    after = str(value.get("after_snippet", ""))
    if not file_path_raw or not before:
        return None

    file_path = Path(file_path_raw)
    if not file_path.is_absolute() and project_root is not None:
        file_path = (project_root / file_path).resolve()

    try:
        return ProposedFix(
            file_path=file_path,
            start_line=int(value.get("start_line", 0) or 0),
            end_line=int(value.get("end_line", 0) or 0),
            before_snippet=before,
            after_snippet=after,
            description=str(value.get("description", "")).strip(),
            reason=str(value.get("reason", "")).strip(),
            confidence_score=_coerce_float(value.get("confidence_score")),
        )
    except Exception:  # pragma: no cover - pydantic validation
        return None


__all__ = ["MonolithicAnalyzer", "MonolithicResult"]
