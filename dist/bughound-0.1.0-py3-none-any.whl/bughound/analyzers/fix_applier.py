"""Apply a :class:`ProposedFix` on disk.

Deliberately simple-minded: we open the target file, check that
``before_snippet`` appears **exactly once**, and replace it with
``after_snippet``. No ``.bak``, no ``git``, no fuzzy matching.

The pipeline only calls us when ``proposed.confidence_score > 0.90``;
we additionally refuse to touch anything that isn't under
``project_root`` (when provided) to avoid pathological LLM outputs
rewriting ``/etc/passwd`` et al.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

from ..core.models import AppliedFix, ProposedFix

log = logging.getLogger(__name__)


def apply_fix(
    proposed: ProposedFix,
    *,
    project_root: Optional[Path] = None,
) -> AppliedFix:
    """Literal ``before → after`` replacement on ``proposed.file_path``.

    Returns an :class:`AppliedFix` with ``applied=True`` on success and
    ``applied=False`` with a short ``reason`` otherwise. Failure modes:

    * target file missing or unreadable,
    * target file outside ``project_root`` when it is set,
    * ``before_snippet`` absent from the file,
    * ``before_snippet`` appearing more than once (we refuse to guess
      which occurrence to rewrite).
    """
    file_path = Path(proposed.file_path)

    if project_root is not None:
        try:
            file_path.resolve().relative_to(Path(project_root).resolve())
        except ValueError:
            return AppliedFix(
                file_path=file_path,
                applied=False,
                reason=f"file is outside project_root ({project_root})",
            )

    if not file_path.exists() or not file_path.is_file():
        return AppliedFix(
            file_path=file_path,
            applied=False,
            reason="target file does not exist",
        )

    try:
        content = file_path.read_text(encoding="utf-8")
    except Exception as exc:
        return AppliedFix(
            file_path=file_path, applied=False, reason=f"could not read file: {exc}"
        )

    before = proposed.before_snippet
    if not before:
        return AppliedFix(
            file_path=file_path,
            applied=False,
            reason="before_snippet is empty",
        )

    occurrences = content.count(before)
    if occurrences == 0:
        return AppliedFix(
            file_path=file_path,
            applied=False,
            reason="before_snippet not found in file",
        )
    if occurrences > 1:
        return AppliedFix(
            file_path=file_path,
            applied=False,
            reason=f"before_snippet appears {occurrences} times (ambiguous)",
        )

    new_content = content.replace(before, proposed.after_snippet, 1)
    try:
        file_path.write_text(new_content, encoding="utf-8")
    except Exception as exc:
        return AppliedFix(
            file_path=file_path, applied=False, reason=f"could not write file: {exc}"
        )

    return AppliedFix(file_path=file_path, applied=True, reason=None)


__all__ = ["apply_fix"]
