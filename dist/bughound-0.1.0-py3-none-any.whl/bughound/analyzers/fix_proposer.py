"""LLM-backed fix proposal.

Given the :class:`Diagnosis` produced by :class:`LogDiagnostician`, a few
candidate :class:`CodeReference` extracted from the stack trace, and the
project's ``doc.md``, the proposer asks the LLM for a concrete patch::

    {
      "file_path": "absolute path of the file to edit",
      "start_line": 123,
      "end_line": 140,
      "before_snippet": "exact text to find in the file",
      "after_snippet": "replacement text",
      "description": "what the change does",
      "reason": "why it fixes the root cause",
      "confidence_score": 0.0..1.0
    }

The returned :class:`ProposedFix` is consumed by :func:`apply_fix` which
does the actual disk write (only when ``confidence_score > 0.90``).
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional, Sequence

from ..core.models import CodeReference, ProposedFix
from ..llm.base import LLMClient
from .log_diagnostician import Diagnosis

log = logging.getLogger(__name__)


FIX_PROPOSER_SYSTEM = (
    "You are a senior Android engineer proposing the smallest possible patch "
    "that fixes a known bug. You must output the EXACT text to replace "
    "(before_snippet) and its replacement (after_snippet) so that a dumb "
    "string replacement applies the fix cleanly. Pick a before_snippet that "
    "is guaranteed unique in the target file — include enough surrounding "
    "context to disambiguate, but no more. Be conservative: if you are not "
    "sure the patch is correct, lower confidence_score below 0.9."
)

FIX_PROPOSER_SCHEMA = """{
  "file_path": "absolute path of the file to edit",
  "start_line": 0,
  "end_line": 0,
  "before_snippet": "exact text to find in the file (multi-line allowed)",
  "after_snippet": "replacement text",
  "description": "one sentence in French describing the change",
  "reason": "one paragraph in French explaining why it fixes the root cause",
  "confidence_score": 0.0
}"""


class FixProposer:
    """Produce a :class:`ProposedFix` from a diagnosis + code context."""

    def __init__(self, llm: LLMClient) -> None:
        self._llm = llm

    def propose(
        self,
        *,
        diagnosis: Diagnosis,
        code_refs: Sequence[CodeReference],
        project_doc_markdown: Optional[str] = None,
        project_root: Optional[Path] = None,
    ) -> Optional[ProposedFix]:
        """Ask the LLM for a patch. Returns ``None`` if it cannot commit."""
        if not diagnosis.root_cause and not code_refs:
            return None

        user_prompt = _render_prompt(
            diagnosis=diagnosis,
            code_refs=code_refs,
            project_doc_markdown=project_doc_markdown,
            project_root=project_root,
        )
        try:
            response = self._llm.complete_json(
                system=FIX_PROPOSER_SYSTEM,
                user=user_prompt,
                schema_hint=FIX_PROPOSER_SCHEMA,
            )
        except Exception as exc:  # pragma: no cover - defensive
            log.warning("FixProposer LLM call failed: %s", exc)
            return None

        parsed = response.parsed
        if not isinstance(parsed, dict):
            try:
                parsed = json.loads(response.raw_text)
            except (ValueError, TypeError):
                return None

        file_path_raw = str(parsed.get("file_path", "")).strip()
        before = str(parsed.get("before_snippet", ""))
        after = str(parsed.get("after_snippet", ""))
        if not file_path_raw or not before:
            return None

        # Resolve relative paths against ``project_root`` when provided.
        file_path = Path(file_path_raw)
        if not file_path.is_absolute() and project_root is not None:
            file_path = (project_root / file_path).resolve()

        try:
            confidence = float(parsed.get("confidence_score", 0.0))
        except (TypeError, ValueError):
            confidence = 0.0
        confidence = max(0.0, min(1.0, confidence))

        return ProposedFix(
            file_path=file_path,
            start_line=int(parsed.get("start_line", 0) or 0),
            end_line=int(parsed.get("end_line", 0) or 0),
            before_snippet=before,
            after_snippet=after,
            description=str(parsed.get("description", "")).strip(),
            reason=str(parsed.get("reason", "")).strip(),
            confidence_score=confidence,
        )


# ---------------------------------------------------------------------------
# Prompt
# ---------------------------------------------------------------------------


def _render_prompt(
    *,
    diagnosis: Diagnosis,
    code_refs: Sequence[CodeReference],
    project_doc_markdown: Optional[str],
    project_root: Optional[Path],
) -> str:
    refs_block = (
        "\n\n".join(
            f"FILE: {ref.file_path}\n"
            f"CLASS: {ref.class_fqn}"
            + (f" (line {ref.line})" if ref.line else "")
            + f"\n```\n{ref.snippet or '(no snippet)'}\n```"
            for ref in code_refs
        )
        or "(no code references available)"
    )
    doc_section = (
        f"\n\nPROJECT DOC:\n```markdown\n{project_doc_markdown[-15_000:]}\n```"
        if project_doc_markdown
        else ""
    )
    root_note = (
        f"\n\nPROJECT ROOT: {project_root}" if project_root is not None else ""
    )

    return (
        f"Root cause (French):\n{diagnosis.root_cause or '(unknown)'}\n\n"
        f"Reproduction steps:\n"
        + "\n".join(f"- {s}" for s in diagnosis.reproduction_steps or ["(none)"])
        + "\n\n"
        f"Suspected modules: {', '.join(diagnosis.suspected_modules) or '(none)'}"
        f"{root_note}\n\n"
        f"CANDIDATE CODE REFERENCES:\n{refs_block}"
        f"{doc_section}\n\n"
        "Produce JSON that strictly matches the schema. The before_snippet "
        "MUST appear exactly once in the target file (we use a literal string "
        "replace, no fuzzy match). If you cannot produce a safe patch, set "
        "confidence_score below 0.5 and keep the fields consistent."
    )


__all__ = ["FixProposer"]
